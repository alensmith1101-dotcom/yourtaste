import { PrismaClient } from '@prisma/client'
import { hash } from 'bcryptjs'
import { randomBytes } from 'crypto'

const prisma = new PrismaClient()

function randomSku(prefix: string): string {
  return `${prefix}-${randomBytes(4).toString('hex').toUpperCase()}`
}

async function main() {
  console.log('Seeding database...')

  await prisma.$transaction(async (tx) => {
    const password = await hash('Password123', 10)

    const admin = await tx.user.upsert({
      where: { email: 'admin@yourtaste.com' },
      update: {},
      create: {
        email: 'admin@yourtaste.com',
        name: 'Admin User',
        password: password,
        role: 'ADMIN',
        isActive: true,
      },
    })

    const vendorUser1 = await tx.user.upsert({
      where: { email: 'vendor@yourtaste.com' },
      update: {},
      create: {
        email: 'vendor@yourtaste.com',
        name: 'Marco Rossi',
        password: password,
        role: 'VENDOR',
        isActive: true,
      },
    })

    const vendorUser2 = await tx.user.upsert({
      where: { email: 'vendor2@yourtaste.com' },
      update: {},
      create: {
        email: 'vendor2@yourtaste.com',
        name: 'Priya Sharma',
        password: password,
        role: 'VENDOR',
        isActive: true,
      },
    })

    const customer = await tx.user.upsert({
      where: { email: 'customer@yourtaste.com' },
      update: {},
      create: {
        email: 'customer@yourtaste.com',
        name: 'John Customer',
        password: password,
        role: 'CUSTOMER',
        isActive: true,
      },
    })

    const vendor1 = await tx.vendor.upsert({
      where: { slug: 'bella-cucina' },
      update: {},
      create: {
        name: 'Bella Cucina',
        slug: 'bella-cucina',
        description: 'Authentic Italian ingredients and gourmet pasta',
        isApproved: true,
        isActive: true,
        ownerId: vendorUser1.id,
        rating: 4.7,
        totalRatings: 234,
      },
    })

    const vendor2 = await tx.vendor.upsert({
      where: { slug: 'spice-bazaar' },
      update: {},
      create: {
        name: 'Spice Bazaar',
        slug: 'spice-bazaar',
        description: 'Premium Indian spices, teas, and artisan snacks',
        isApproved: true,
        isActive: true,
        ownerId: vendorUser2.id,
        rating: 4.5,
        totalRatings: 189,
      },
    })

    const electronics = await tx.category.upsert({
      where: { slug: 'electronics' },
      update: {},
      create: { name: 'Electronics', slug: 'electronics' },
    })
    const phones = await tx.category.upsert({
      where: { slug: 'phones' },
      update: {},
      create: { name: 'Phones', slug: 'phones', parentId: electronics.id },
    })
    const audio = await tx.category.upsert({
      where: { slug: 'audio' },
      update: {},
      create: { name: 'Audio', slug: 'audio', parentId: electronics.id },
    })

    const groceries = await tx.category.upsert({
      where: { slug: 'groceries' },
      update: {},
      create: { name: 'Groceries', slug: 'groceries' },
    })
    const pasta = await tx.category.upsert({
      where: { slug: 'pasta' },
      update: {},
      create: { name: 'Pasta & Noodles', slug: 'pasta', parentId: groceries.id },
    })
    const sauces = await tx.category.upsert({
      where: { slug: 'sauces' },
      update: {},
      create: { name: 'Sauces & Condiments', slug: 'sauces', parentId: groceries.id },
    })

    const spices = await tx.category.upsert({
      where: { slug: 'spices' },
      update: {},
      create: { name: 'Spices', slug: 'spices', parentId: groceries.id },
    })
    const tea = await tx.category.upsert({
      where: { slug: 'tea' },
      update: {},
      create: { name: 'Tea & Coffee', slug: 'tea', parentId: groceries.id },
    })

    const clothing = await tx.category.upsert({
      where: { slug: 'clothing' },
      update: {},
      create: { name: 'Clothing', slug: 'clothing' },
    })
    const mens = await tx.category.upsert({
      where: { slug: 'mens' },
      update: {},
      create: { name: "Men's Wear", slug: 'mens', parentId: clothing.id },
    })
    const womens = await tx.category.upsert({
      where: { slug: 'womens' },
      update: {},
      create: { name: "Women's Wear", slug: 'womens', parentId: clothing.id },
    })

    const productData = [
      { name: 'Wireless Noise-Cancelling Headphones', priceCents: 12999, originalPriceCents: 17999, stock: 45, categoryId: audio.id, vendorId: vendor1.id, desc: 'Premium over-ear headphones with active noise cancellation and 40-hour battery life.' },
      { name: 'USB-C Fast Charger 65W', priceCents: 3499, originalPriceCents: 4999, stock: 120, categoryId: phones.id, vendorId: vendor1.id, desc: 'GaN fast charger compatible with laptops, tablets, and phones.' },
      { name: 'Artisan Marinara Sauce', priceCents: 799, originalPriceCents: null, stock: 200, categoryId: sauces.id, vendorId: vendor1.id, desc: 'Handcrafted San Marzano tomato sauce with fresh basil.' },
      { name: 'Handmade Fettuccine Pasta', priceCents: 599, originalPriceCents: 899, stock: 150, categoryId: pasta.id, vendorId: vendor1.id, desc: 'Traditional bronze-die extruded fettuccine, 500g pack.' },
      { name: 'Organic Garam Masala Blend', priceCents: 899, originalPriceCents: null, stock: 180, categoryId: spices.id, vendorId: vendor2.id, desc: 'Aromatic blend of 12 whole spices, stone-ground in small batches.' },
      { name: 'Darjeeling First Flush Tea', priceCents: 1299, originalPriceCents: 1599, stock: 90, categoryId: tea.id, vendorId: vendor2.id, desc: 'Single-estate first flush Darjeeling loose leaf tea, 100g tin.' },
      { name: 'Kashmiri Red Chilli Powder', priceCents: 499, originalPriceCents: null, stock: 250, categoryId: spices.id, vendorId: vendor2.id, desc: 'Vibrant colour and mild heat, perfect for curries and tandoori.' },
      { name: 'Slim Fit Oxford Shirt', priceCents: 3499, originalPriceCents: 4499, stock: 75, categoryId: mens.id, vendorId: vendor1.id, desc: 'Premium cotton oxford shirt in classic blue, slim fit cut.' },
      { name: 'Silk Blend Scarf', priceCents: 2499, originalPriceCents: null, stock: 60, categoryId: womens.id, vendorId: vendor2.id, desc: 'Lightweight silk-cotton blend scarf with hand-rolled edges.' },
      { name: 'Bluetooth Earbuds Pro', priceCents: 7999, originalPriceCents: 9999, stock: 80, categoryId: audio.id, vendorId: vendor1.id, desc: 'True wireless earbuds with spatial audio and IPX5 rating.' },
    ]

    const createdProducts = []
    for (const p of productData) {
      const slug = p.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/-+$/, '')
      const product = await tx.product.upsert({
        where: { slug },
        update: {},
        create: {
          name: p.name,
          slug,
          description: p.desc,
          priceCents: p.priceCents,
          originalPriceCents: p.originalPriceCents,
          stockQuantity: p.stock,
          images: JSON.stringify(['https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500']),
          sku: randomSku('YT'),
          isActive: true,
          isPublished: true,
          vendorId: p.vendorId,
          categoryId: p.categoryId,
          tags: JSON.stringify([]),
        },
      })
      createdProducts.push(product)
    }

    const address = await tx.address.upsert({
      where: { id: 'seed-address-1' },
      update: {},
      create: {
        id: 'seed-address-1',
        userId: customer.id,
        title: 'Home',
        fullName: 'John Customer',
        phone: '+1-555-0123',
        street: '123 Main Street, Apt 4B',
        city: 'New York',
        state: 'NY',
        zipCode: '10001',
        country: 'US',
        isDefault: true,
      },
    })

    const order1 = await tx.order.create({
      data: {
        orderNumber: `ORD-${randomBytes(4).toString('hex').toUpperCase()}`,
        userId: customer.id,
        vendorId: vendor1.id,
        status: 'DELIVERED',
        subtotal: createdProducts[0].priceCents + createdProducts[2].priceCents,
        total: createdProducts[0].priceCents + createdProducts[2].priceCents + 499,
        tax: 0,
        shippingCost: 499,
        shippingAddress: `${address.street}, ${address.city}, ${address.state} ${address.zipCode}`,
        paymentMethod: 'stripe',
        paymentStatus: 'COMPLETED',
        trackingNumber: `TRK-${randomBytes(5).toString('hex').toUpperCase()}`,
      },
    })

    await tx.orderItem.createMany({
      data: [
        { orderId: order1.id, productId: createdProducts[0].id, quantity: 1, priceCents: createdProducts[0].priceCents },
        { orderId: order1.id, productId: createdProducts[2].id, quantity: 2, priceCents: createdProducts[2].priceCents },
      ],
    })

    await tx.orderStatusHistory.createMany({
      data: [
        { orderId: order1.id, fromStatus: 'PENDING', toStatus: 'CONFIRMED', changedBy: 'system' },
        { orderId: order1.id, fromStatus: 'CONFIRMED', toStatus: 'SHIPPED', changedBy: vendorUser1.id },
        { orderId: order1.id, fromStatus: 'SHIPPED', toStatus: 'DELIVERED', changedBy: 'system' },
      ],
    })

    const order2 = await tx.order.create({
      data: {
        orderNumber: `ORD-${randomBytes(4).toString('hex').toUpperCase()}`,
        userId: customer.id,
        vendorId: vendor2.id,
        status: 'PROCESSING',
        subtotal: createdProducts[4].priceCents + createdProducts[5].priceCents,
        total: createdProducts[4].priceCents + createdProducts[5].priceCents,
        tax: 0,
        shippingCost: 0,
        shippingAddress: `${address.street}, ${address.city}, ${address.state} ${address.zipCode}`,
        paymentMethod: 'stripe',
        paymentStatus: 'COMPLETED',
      },
    })

    await tx.orderItem.createMany({
      data: [
        { orderId: order2.id, productId: createdProducts[4].id, quantity: 1, priceCents: createdProducts[4].priceCents },
        { orderId: order2.id, productId: createdProducts[5].id, quantity: 1, priceCents: createdProducts[5].priceCents },
      ],
    })

    const order3 = await tx.order.create({
      data: {
        orderNumber: `ORD-${randomBytes(4).toString('hex').toUpperCase()}`,
        userId: customer.id,
        vendorId: vendor1.id,
        status: 'PENDING',
        subtotal: createdProducts[7].priceCents,
        total: createdProducts[7].priceCents + 499,
        tax: 0,
        shippingCost: 499,
        shippingAddress: `${address.street}, ${address.city}, ${address.state} ${address.zipCode}`,
        paymentMethod: 'stripe',
        paymentStatus: 'PENDING',
      },
    })

    await tx.orderItem.create({
      data: { orderId: order3.id, productId: createdProducts[7].id, quantity: 1, priceCents: createdProducts[7].priceCents },
    })

    await tx.review.createMany({
      data: [
        { userId: customer.id, productId: createdProducts[0].id, rating: 5, comment: 'Excellent sound quality and very comfortable for long listening sessions.' },
        { userId: customer.id, productId: createdProducts[4].id, rating: 4, comment: 'Amazing aroma, fresh and authentic blend.' },
      ],
    })

    const languages = [
      { code: 'en', name: 'English', nativeName: 'English', flag: 'US' },
      { code: 'es', name: 'Spanish', nativeName: 'Espanol', flag: 'ES' },
      { code: 'fr', name: 'French', nativeName: 'Francais', flag: 'FR' },
      { code: 'de', name: 'German', nativeName: 'Deutsch', flag: 'DE' },
      { code: 'hi', name: 'Hindi', nativeName: 'Hindi', flag: 'IN' },
    ]
    for (const lang of languages) {
      await tx.languageConfig.upsert({
        where: { code: lang.code },
        update: {},
        create: lang,
      })
    }

    const currencies = [
      { code: 'USD', name: 'US Dollar', symbol: '$', exchangeRate: 1.0, isDefault: true },
      { code: 'EUR', name: 'Euro', symbol: '\u20ac', exchangeRate: 0.85, isDefault: false },
      { code: 'GBP', name: 'British Pound', symbol: '\u00a3', exchangeRate: 0.73, isDefault: false },
      { code: 'INR', name: 'Indian Rupee', symbol: '\u20b9', exchangeRate: 83.0, isDefault: false },
    ]
    for (const curr of currencies) {
      await tx.currencyConfig.upsert({
        where: { code: curr.code },
        update: {},
        create: { ...curr, symbolPosition: 'before', decimalPlaces: 2, isActive: true },
      })
    }

    await tx.coupon.create({
      data: {
        code: 'WELCOME10',
        title: '10% Off Welcome Coupon',
        type: 'PERCENTAGE',
        discountValue: 10,
        maxDiscountAmount: 50000,
        minOrderValue: 50000,
        usageLimit: 1000,
        userUsageLimit: 1,
        startsAt: new Date(),
        expiresAt: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000),
        scope: 'GLOBAL',
        isActive: true,
      },
    })

    await tx.coupon.create({
      data: {
        code: 'FREESHIP',
        title: 'Free Shipping',
        type: 'FREE_SHIPPING',
        usageLimit: 500,
        userUsageLimit: 3,
        startsAt: new Date(),
        expiresAt: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000),
        scope: 'GLOBAL',
        isActive: true,
      },
    })

    await tx.coupon.create({
      data: {
        code: 'FLAT200',
        title: '₹200 Off',
        type: 'FIXED_AMOUNT',
        discountValue: 20000,
        minOrderValue: 100000,
        usageLimit: 200,
        userUsageLimit: 1,
        startsAt: new Date(),
        expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
        scope: 'GLOBAL',
        isActive: true,
      },
    })

    const wishlistCustomer = await tx.user.findFirst({ where: { email: 'customer@yourtaste.com' } })
    const wishlistProducts = await tx.product.findMany({ take: 3 })
    if (wishlistCustomer && wishlistProducts.length > 0) {
      let defaultWishlist = await tx.wishlist.findFirst({
        where: { userId: wishlistCustomer.id, isDefault: true },
      })
      if (!defaultWishlist) {
        defaultWishlist = await tx.wishlist.create({
          data: { userId: wishlistCustomer.id, name: 'My Wishlist', isDefault: true },
        })
      }
      for (const product of wishlistProducts) {
        await tx.wishlistItem.upsert({
          where: { wishlistId_productId: { wishlistId: defaultWishlist.id, productId: product.id } },
          update: {},
          create: { wishlistId: defaultWishlist.id, productId: product.id },
        })
      }
    }

    console.log('Seed complete')
    console.log('\n📝 Login credentials:')
    console.log('  Admin: admin@yourtaste.com / Password123')
    console.log('  Vendor: vendor@yourtaste.com / Password123')
    console.log('  Customer: customer@yourtaste.com / Password123\n')
  })
}

main()
  .catch((e) => {
    console.error('Seeding failed:', e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
