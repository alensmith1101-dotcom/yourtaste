import { describe, it, expect } from 'vitest'
import { CouponService } from '@/lib/coupons'

describe('CouponService.calculateDiscount', () => {
  it('should calculate percentage discount correctly', () => {
    const coupon = {
      type: 'PERCENTAGE',
      value: 10,
      discountValue: 10,
      maxDiscountAmount: null,
      maxDiscount: null,
      buyQuantity: null,
      getQuantity: null,
      getDiscountValue: null,
    }

    const discount = CouponService.calculateDiscount(coupon, 10000)
    expect(discount).toBe(1000) // 10% of 10000 cents = 1000 cents
  })

  it('should cap percentage discount at maxDiscountAmount', () => {
    const coupon = {
      type: 'PERCENTAGE',
      value: 50,
      discountValue: 50,
      maxDiscountAmount: 2000,
      maxDiscount: null,
      buyQuantity: null,
      getQuantity: null,
      getDiscountValue: null,
    }

    const discount = CouponService.calculateDiscount(coupon, 10000)
    expect(discount).toBe(2000) // 50% of 10000 = 5000, capped at 2000
  })

  it('should calculate fixed amount discount', () => {
    const coupon = {
      type: 'FIXED_AMOUNT',
      value: 500,
      discountValue: 500,
      maxDiscountAmount: null,
      maxDiscount: null,
      buyQuantity: null,
      getQuantity: null,
      getDiscountValue: null,
    }

    const discount = CouponService.calculateDiscount(coupon, 10000)
    expect(discount).toBe(500)
  })

  it('should not exceed order total for fixed amount', () => {
    const coupon = {
      type: 'FIXED_AMOUNT',
      value: 15000,
      discountValue: 15000,
      maxDiscountAmount: null,
      maxDiscount: null,
      buyQuantity: null,
      getQuantity: null,
      getDiscountValue: null,
    }

    const discount = CouponService.calculateDiscount(coupon, 10000)
    expect(discount).toBe(10000) // capped at order total
  })

  it('should return 0 for free shipping type', () => {
    const coupon = {
      type: 'FREE_SHIPPING',
      value: 0,
      discountValue: 0,
      maxDiscountAmount: null,
      maxDiscount: null,
      buyQuantity: null,
      getQuantity: null,
      getDiscountValue: null,
    }

    const discount = CouponService.calculateDiscount(coupon, 10000)
    expect(discount).toBe(0)
  })
})
