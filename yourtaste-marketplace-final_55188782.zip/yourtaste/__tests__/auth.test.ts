import { describe, it, expect, beforeAll } from 'vitest'

beforeAll(() => {
  process.env.NEXTAUTH_SECRET = 'test-secret-key-for-testing-only'
})

describe('Auth Configuration', () => {
  it('authOptions has required NextAuth config', async () => {
    const { authOptions } = await import('@/lib/auth')
    expect(authOptions).toBeDefined()
    expect(authOptions.providers).toBeDefined()
    expect(authOptions.callbacks).toBeDefined()
    expect(authOptions.pages).toBeDefined()
  })

  it('has Credentials provider', () => {
    return import('@/lib/auth').then(({ authOptions }) => {
      const credentialsProvider = authOptions.providers.find(
        (p: any) => p.id === 'credentials' || p.type === 'credentials'
      )
      expect(credentialsProvider).toBeDefined()
    })
  })

  it('has JWT strategy', async () => {
    const { authOptions } = await import('@/lib/auth')
    expect(authOptions.session?.strategy).toBe('jwt')
  })

  it('has custom sign-in page', async () => {
    const { authOptions } = await import('@/lib/auth')
    expect(authOptions.pages?.signIn).toBe('/auth/signin')
  })

  it('has jwt callback', async () => {
    const { authOptions } = await import('@/lib/auth')
    expect(authOptions.callbacks?.jwt).toBeDefined()
    expect(typeof authOptions.callbacks?.jwt).toBe('function')
  })

  it('has session callback', async () => {
    const { authOptions } = await import('@/lib/auth')
    expect(authOptions.callbacks?.session).toBeDefined()
    expect(typeof authOptions.callbacks?.session).toBe('function')
  })

  it('sign-in page path is correct', async () => {
    const { authOptions } = await import('@/lib/auth')
    expect(authOptions.pages?.signIn).toContain('/auth/signin')
  })
})

describe('Auth Validation Schemas', () => {
  it('registerSchema rejects duplicate-like emails with invalid format', async () => {
    const { registerSchema } = await import('@/lib/validations')
    const result = registerSchema.safeParse({
      name: 'Test User',
      email: 'not-valid-email',
      password: 'Password123',
    })
    expect(result.success).toBe(false)
  })

  it('loginSchema requires email and password', async () => {
    const { loginSchema } = await import('@/lib/validations')

    const noEmail = loginSchema.safeParse({ password: 'test' })
    expect(noEmail.success).toBe(false)

    const noPassword = loginSchema.safeParse({ email: 'test@test.com' })
    expect(noPassword.success).toBe(false)

    const valid = loginSchema.safeParse({ email: 'test@test.com', password: 'Password123' })
    expect(valid.success).toBe(true)
  })

  it('password reset schema validates email format', async () => {
    const { passwordSchema } = await import('@/lib/validations')
    const result = passwordSchema.safeParse({ password: 'short' })
    expect(result.success).toBe(false)
  })
})

describe('Session Type Safety', () => {
  it('User roles are properly typed', () => {
    type SessionUser = { id: string; email: string; role: 'CUSTOMER' | 'VENDOR' | 'ADMIN'; name?: string | null }
    const user: SessionUser = { id: '1', email: 'test@test.com', role: 'CUSTOMER' }
    expect(user.role).toBe('CUSTOMER')

    const admin: SessionUser = { id: '2', email: 'admin@test.com', role: 'ADMIN' }
    expect(admin.role).toBe('ADMIN')
  })
})
