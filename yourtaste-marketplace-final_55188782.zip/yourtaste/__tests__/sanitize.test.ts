import { describe, it, expect } from 'vitest'
import { sanitizeText, sanitizeHtml, sanitizeProductDescription } from '@/lib/sanitize'

describe('sanitizeText', () => {
  it('should strip all HTML tags', () => {
    expect(sanitizeText('<script>alert("xss")</script>hello')).toBe('hello')
  })

  it('should handle plain text', () => {
    expect(sanitizeText('Hello World')).toBe('Hello World')
  })

  it('should strip nested tags', () => {
    expect(sanitizeText('<b>bold</b> <i>italic</i>')).toBe('bold italic')
  })
})

describe('sanitizeHtml', () => {
  it('should allow basic formatting tags', () => {
    const result = sanitizeHtml('<b>bold</b> <i>italic</i>')
    expect(result).toContain('<b>bold</b>')
    expect(result).toContain('<i>italic</i>')
  })

  it('should strip script tags', () => {
    const result = sanitizeHtml('<script>alert("xss")</script>Hello')
    expect(result).not.toContain('<script>')
    expect(result).toContain('Hello')
  })
})

describe('sanitizeProductDescription', () => {
  it('should allow paragraph and heading tags', () => {
    const result = sanitizeProductDescription('<p>Description</p><h3>Details</h3>')
    expect(result).toContain('<p>')
    expect(result).toContain('<h3>')
  })

  it('should strip dangerous tags', () => {
    const result = sanitizeProductDescription('<iframe src="evil.com"></iframe><p>Safe</p>')
    expect(result).not.toContain('<iframe>')
    expect(result).toContain('<p>Safe</p>')
  })
})
