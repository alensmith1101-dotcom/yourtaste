import { describe, it, expect } from 'vitest'
import {
  registerSchema,
  loginSchema,
  productSchema,
  reviewSchema,
  addressSchema,
  profileSchema,
  passwordSchema,
  searchSchema,
} from '@/lib/validations'

describe('Validation Schemas', () => {
  describe('registerSchema', () => {
    it('accepts valid registration data', () => {
      const result = registerSchema.safeParse({
        name: 'John Doe',
        email: 'john@example.com',
        password: 'Password123',
      })
      expect(result.success).toBe(true)
    })

    it('rejects invalid email', () => {
      const result = registerSchema.safeParse({
        name: 'John',
        email: 'not-an-email',
        password: 'Password123',
      })
      expect(result.success).toBe(false)
    })

    it('rejects short password', () => {
      const result = registerSchema.safeParse({
        name: 'John',
        email: 'john@example.com',
        password: 'short',
      })
      expect(result.success).toBe(false)
    })

    it('rejects empty name', () => {
      const result = registerSchema.safeParse({
        name: '',
        email: 'john@example.com',
        password: 'Password123',
      })
      expect(result.success).toBe(false)
    })
  })

  describe('loginSchema', () => {
    it('accepts valid login data', () => {
      const result = loginSchema.safeParse({
        email: 'john@example.com',
        password: 'Password123',
      })
      expect(result.success).toBe(true)
    })

    it('rejects missing email', () => {
      const result = loginSchema.safeParse({
        password: 'Password123',
      })
      expect(result.success).toBe(false)
    })
  })

  describe('productSchema', () => {
    it('accepts valid product data', () => {
      const result = productSchema.safeParse({
        name: 'Test Product',
        description: 'A test product',
        priceCents: 1999,
        sku: 'TEST-001',
        stockQuantity: 100,
        categoryId: 'cat-1',
      })
      expect(result.success).toBe(true)
    })

    it('rejects negative price', () => {
      const result = productSchema.safeParse({
        name: 'Test',
        priceCents: -100,
        sku: 'TEST-001',
        stockQuantity: 0,
      })
      expect(result.success).toBe(false)
    })

    it('rejects empty name', () => {
      const result = productSchema.safeParse({
        name: '',
        priceCents: 100,
        sku: 'TEST-001',
        stockQuantity: 0,
      })
      expect(result.success).toBe(false)
    })
  })

  describe('reviewSchema', () => {
    it('accepts valid review', () => {
      const result = reviewSchema.safeParse({
        rating: 5,
        comment: 'Great product!',
      })
      expect(result.success).toBe(true)
    })

    it('rejects rating out of range', () => {
      const result = reviewSchema.safeParse({
        rating: 6,
        comment: 'Too high',
      })
      expect(result.success).toBe(false)
    })

    it('rejects rating below 1', () => {
      const result = reviewSchema.safeParse({
        rating: 0,
      })
      expect(result.success).toBe(false)
    })
  })

  describe('addressSchema', () => {
    it('accepts valid address with India default', () => {
      const result = addressSchema.safeParse({
        title: 'Home',
        fullName: 'John Doe',
        street: '123 Main St',
        city: 'Mumbai',
        state: 'Maharashtra',
        zipCode: '400001',
      })
      expect(result.success).toBe(true)
      if (result.success) {
        expect(result.data.country).toBe('IN')
      }
    })

    it('rejects missing required fields', () => {
      const result = addressSchema.safeParse({
        title: 'Home',
      })
      expect(result.success).toBe(false)
    })
  })

  describe('searchSchema', () => {
    it('accepts valid search query', () => {
      const result = searchSchema.safeParse({
        query: 'laptop',
      })
      expect(result.success).toBe(true)
    })
  })
})
