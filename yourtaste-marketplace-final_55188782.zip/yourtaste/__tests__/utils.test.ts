import { describe, it, expect } from 'vitest'
import { formatPrice, formatDate, generateSlug, generateOrderNumber, escapeHtml, isSafeUrl, parseImages } from '@/lib/utils'

describe('Utility Functions', () => {
  describe('formatPrice', () => {
    it('formats cents to dollars correctly', () => {
      expect(formatPrice(1999)).toBe('$19.99')
    })

    it('formats zero correctly', () => {
      expect(formatPrice(0)).toBe('$0.00')
    })

    it('formats large amounts', () => {
      expect(formatPrice(99999)).toBe('$999.99')
    })
  })

  describe('generateSlug', () => {
    it('converts text to slug', () => {
      const slug = generateSlug('Hello World')
      expect(slug).toBe('hello-world')
    })

    it('handles special characters', () => {
      const slug = generateSlug('Hello & World!')
      expect(slug).not.toContain('&')
      expect(slug).not.toContain('!')
    })

    it('handles multiple spaces', () => {
      const slug = generateSlug('Hello   World')
      expect(slug).toBe('hello-world')
    })
  })

  describe('generateOrderNumber', () => {
    it('generates a string starting with YT-', () => {
      const orderNumber = generateOrderNumber()
      expect(orderNumber).toMatch(/^YT-/)
    })

    it('generates unique values', () => {
      const a = generateOrderNumber()
      const b = generateOrderNumber()
      expect(a).not.toBe(b)
    })
  })

  describe('escapeHtml', () => {
    it('escapes HTML entities', () => {
      expect(escapeHtml('<script>alert("xss")</script>')).not.toContain('<script>')
      expect(escapeHtml('&')).toBe('&amp;')
      expect(escapeHtml('<')).toBe('&lt;')
      expect(escapeHtml('>')).toBe('&gt;')
      expect(escapeHtml('"')).toBe('&quot;')
      expect(escapeHtml("'")).toBe('&#39;')
    })
  })

  describe('isSafeUrl', () => {
    it('allows http and https URLs', () => {
      expect(isSafeUrl('https://example.com')).toBe(true)
      expect(isSafeUrl('http://example.com')).toBe(true)
    })

    it('blocks javascript: protocol', () => {
      expect(isSafeUrl('javascript:alert(1)')).toBe(false)
    })

    it('blocks data: protocol', () => {
      expect(isSafeUrl('data:text/html,<script>alert(1)</script>')).toBe(false)
    })
  })

  describe('parseImages', () => {
    it('parses JSON array of images', () => {
      const images = parseImages('["https://example.com/1.jpg", "https://example.com/2.jpg"]')
      expect(images).toHaveLength(2)
      expect(images[0]).toBe('https://example.com/1.jpg')
    })

    it('returns empty array for invalid JSON', () => {
      const images = parseImages('not-json')
      expect(images).toEqual([])
    })

    it('returns empty array for empty string', () => {
      const images = parseImages('')
      expect(images).toEqual([])
    })
  })
})
