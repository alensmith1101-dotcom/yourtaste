import { describe, it, expect } from 'vitest'
import { rateLimit, rateLimiters } from '@/lib/rate-limit'

describe('rateLimit', () => {
  it('should allow requests under the limit', async () => {
    const limiter = rateLimit({ windowMs: 60000, maxRequests: 5 })
    const result = await limiter('test-ip-1')
    expect(result.success).toBe(true)
  })

  it('should block requests over the limit', async () => {
    const limiter = rateLimit({ windowMs: 60000, maxRequests: 2, message: 'Too many' })
    await limiter('test-ip-2')
    await limiter('test-ip-2')
    const result = await limiter('test-ip-2')
    expect(result.success).toBe(false)
  })

  it('should track different identifiers separately', async () => {
    const limiter = rateLimit({ windowMs: 60000, maxRequests: 1 })
    const r1 = await limiter('ip-a')
    const r2 = await limiter('ip-b')
    expect(r1.success).toBe(true)
    expect(r2.success).toBe(true)
  })
})
