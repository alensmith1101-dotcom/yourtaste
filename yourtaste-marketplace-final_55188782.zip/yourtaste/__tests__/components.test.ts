import { describe, it, expect } from 'vitest'

describe('Component Exports', () => {
  it('SortSelect exports correctly', async () => {
    const mod = await import('@/components/shared/SortSelect')
    expect(mod.SortSelect).toBeDefined()
    expect(typeof mod.SortSelect).toBe('function')
  })

  it('VariantSelector exports correctly', async () => {
    const mod = await import('@/components/shared/VariantSelector')
    expect(mod.VariantSelector).toBeDefined()
    expect(typeof mod.VariantSelector).toBe('function')
  })

  it('AddAllToCartButton exports correctly', async () => {
    const mod = await import('@/components/shared/AddAllToCartButton')
    expect(mod.AddAllToCartButton).toBeDefined()
    expect(typeof mod.AddAllToCartButton).toBe('function')
  })

  it('WishlistButton exports correctly', async () => {
    const mod = await import('@/components/shared/WishlistButton')
    expect(mod.WishlistButton).toBeDefined()
    expect(typeof mod.WishlistButton).toBe('function')
  })

  it('CurrencySwitcher exports correctly', async () => {
    const mod = await import('@/components/shared/CurrencySwitcher')
    expect(mod.CurrencySwitcher).toBeDefined()
    expect(typeof mod.CurrencySwitcher).toBe('function')
  })

  it('LanguageSwitcher exports correctly', async () => {
    const mod = await import('@/components/shared/LanguageSwitcher')
    expect(mod.LanguageSwitcher).toBeDefined()
    expect(typeof mod.LanguageSwitcher).toBe('function')
  })

  it('SearchAutocomplete exports correctly', async () => {
    const mod = await import('@/components/shared/SearchAutocomplete')
    expect(mod.SearchAutocomplete).toBeDefined()
    expect(typeof mod.SearchAutocomplete).toBe('function')
  })

  it('CountdownTimer exports correctly', async () => {
    const mod = await import('@/components/shared/CountdownTimer')
    expect(mod.CountdownTimer).toBeDefined()
    expect(typeof mod.CountdownTimer).toBe('function')
  })

  it('ProductCard exports correctly', async () => {
    const mod = await import('@/components/shared/ProductCard')
    expect(mod.ProductCard).toBeDefined()
    expect(typeof mod.ProductCard).toBe('function')
  })

  it('QuickViewModal exports correctly', async () => {
    const mod = await import('@/components/shared/QuickViewModal')
    expect(mod.QuickViewModal).toBeDefined()
    expect(typeof mod.QuickViewModal).toBe('function')
  })

  it('AddToCartButton exports correctly', async () => {
    const mod = await import('@/components/shared/AddToCartButton')
    expect(mod.AddToCartButton).toBeDefined()
    expect(typeof mod.AddToCartButton).toBe('function')
  })

  it('AdminCharts exports correctly', async () => {
    const mod = await import('@/components/admin/AdminCharts')
    expect(mod.AdminCharts).toBeDefined()
    expect(typeof mod.AdminCharts).toBe('function')
  })
})

describe('Component Logic', () => {
  it('toast export has expected methods', async () => {
    const { toast } = await import('@/hooks/use-toast')
    expect(toast.success).toBeDefined()
    expect(toast.error).toBeDefined()
    expect(toast.info).toBeDefined()
    expect(toast.warning).toBeDefined()
    expect(toast.dismiss).toBeDefined()
  })
})
