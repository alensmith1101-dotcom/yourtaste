import { describe, it, expect } from 'vitest'
import { AppError, NotFoundError, BadRequestError, ValidationError, UnauthorizedError, ForbiddenError, ConflictError, TooManyRequestsError } from '@/lib/errors'

describe('Error Classes', () => {
  it('AppError has correct properties', () => {
    const err = new AppError('Test error', 500, 'TEST_ERROR')
    expect(err.message).toBe('Test error')
    expect(err.statusCode).toBe(500)
    expect(err.code).toBe('TEST_ERROR')
    expect(err.isOperational).toBe(true)
    expect(err instanceof Error).toBe(true)
  })

  it('NotFoundError has 404 status', () => {
    const err = new NotFoundError('Resource not found')
    expect(err.statusCode).toBe(404)
    expect(err.message).toBe('Resource not found')
  })

  it('BadRequestError has 400 status', () => {
    const err = new BadRequestError('Invalid input')
    expect(err.statusCode).toBe(400)
  })

  it('ValidationError has 400 status', () => {
    const err = new ValidationError('Validation failed')
    expect(err.statusCode).toBe(400)
  })

  it('UnauthorizedError has 401 status', () => {
    const err = new UnauthorizedError()
    expect(err.statusCode).toBe(401)
  })

  it('ForbiddenError has 403 status', () => {
    const err = new ForbiddenError()
    expect(err.statusCode).toBe(403)
  })

  it('ConflictError has 409 status', () => {
    const err = new ConflictError('Already exists')
    expect(err.statusCode).toBe(409)
  })

  it('TooManyRequestsError has 429 status', () => {
    const err = new TooManyRequestsError()
    expect(err.statusCode).toBe(429)
  })

  it('Error.captureStackTrace is safely guarded', () => {
    const original = Error.captureStackTrace
    try {
      delete (Error as any).captureStackTrace
      const err = new AppError('test', 500)
      expect(err.message).toBe('test')
    } finally {
      Error.captureStackTrace = original
    }
  })
})
