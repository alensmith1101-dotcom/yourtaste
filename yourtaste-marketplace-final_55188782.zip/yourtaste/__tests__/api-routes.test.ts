import { describe, it, expect } from 'vitest'
import { z } from 'zod'

const disputeSchema = z.object({
  orderId: z.string().min(1, 'Order ID required'),
  type: z.enum(['PRODUCT', 'SHIPPING', 'PAYMENT', 'SERVICE', 'OTHER']),
  reason: z.string().min(10, 'Reason must be at least 10 characters'),
  description: z.string().min(20, 'Description must be at least 20 characters'),
})

const returnSchema = z.object({
  orderId: z.string().min(1),
  type: z.enum(['RETURN', 'REFUND', 'EXCHANGE']),
  reason: z.string().min(5),
  items: z.array(z.object({ orderItemId: z.string().min(1), quantity: z.number().int().min(1) })).min(1),
  customerComments: z.string().optional(),
})

const addToCartSchema = z.object({
  productId: z.string().min(1),
  quantity: z.number().int().min(1).max(99).default(1),
  variantId: z.string().optional(),
})

const updateCartSchema = z.object({
  itemId: z.string().min(1),
  quantity: z.number().int().min(0).max(99),
})

describe('Dispute Schema', () => {
  it('validates correct input', () => {
    const result = disputeSchema.safeParse({
      orderId: 'order-1',
      type: 'PRODUCT',
      reason: 'Product is defective and broken',
      description: 'The product arrived broken and is completely unusable for its intended purpose',
    })
    expect(result.success).toBe(true)
  })

  it('rejects empty orderId', () => {
    const result = disputeSchema.safeParse({
      orderId: '',
      type: 'PRODUCT',
      reason: 'Product is defective and broken',
      description: 'The product arrived broken and is completely unusable for its intended purpose',
    })
    expect(result.success).toBe(false)
  })

  it('rejects invalid type', () => {
    const result = disputeSchema.safeParse({
      orderId: 'order-1',
      type: 'INVALID',
      reason: 'Product is defective and broken',
      description: 'The product arrived broken and is completely unusable for its intended purpose',
    })
    expect(result.success).toBe(false)
  })

  it('rejects short reason', () => {
    const result = disputeSchema.safeParse({
      orderId: 'order-1',
      type: 'PRODUCT',
      reason: 'short',
      description: 'The product arrived broken and is completely unusable for its intended purpose',
    })
    expect(result.success).toBe(false)
  })

  it('rejects short description', () => {
    const result = disputeSchema.safeParse({
      orderId: 'order-1',
      type: 'PRODUCT',
      reason: 'Product is defective and broken',
      description: 'Too short',
    })
    expect(result.success).toBe(false)
  })
})

describe('Return Schema', () => {
  it('validates correct input', () => {
    const result = returnSchema.safeParse({
      orderId: 'order-1',
      type: 'RETURN',
      reason: 'Wrong size',
      items: [{ orderItemId: 'item-1', quantity: 1 }],
    })
    expect(result.success).toBe(true)
  })

  it('rejects empty items array', () => {
    const result = returnSchema.safeParse({
      orderId: 'order-1',
      type: 'RETURN',
      reason: 'Wrong size',
      items: [],
    })
    expect(result.success).toBe(false)
  })

  it('rejects invalid type', () => {
    const result = returnSchema.safeParse({
      orderId: 'order-1',
      type: 'COMPLAINT',
      reason: 'Wrong size',
      items: [{ orderItemId: 'item-1', quantity: 1 }],
    })
    expect(result.success).toBe(false)
  })

  it('rejects zero quantity', () => {
    const result = returnSchema.safeParse({
      orderId: 'order-1',
      type: 'RETURN',
      reason: 'Wrong size',
      items: [{ orderItemId: 'item-1', quantity: 0 }],
    })
    expect(result.success).toBe(false)
  })
})

describe('Add to Cart Schema', () => {
  it('validates correct input', () => {
    const result = addToCartSchema.safeParse({
      productId: 'prod-1',
      quantity: 2,
    })
    expect(result.success).toBe(true)
  })

  it('defaults quantity to 1', () => {
    const result = addToCartSchema.safeParse({ productId: 'prod-1' })
    expect(result.success).toBe(true)
    if (result.success) expect(result.data.quantity).toBe(1)
  })

  it('rejects quantity over 99', () => {
    const result = addToCartSchema.safeParse({ productId: 'prod-1', quantity: 100 })
    expect(result.success).toBe(false)
  })

  it('rejects empty productId', () => {
    const result = addToCartSchema.safeParse({ productId: '', quantity: 1 })
    expect(result.success).toBe(false)
  })
})

describe('Update Cart Schema', () => {
  it('validates correct input', () => {
    const result = updateCartSchema.safeParse({ itemId: 'item-1', quantity: 5 })
    expect(result.success).toBe(true)
  })

  it('allows quantity 0 for removal', () => {
    const result = updateCartSchema.safeParse({ itemId: 'item-1', quantity: 0 })
    expect(result.success).toBe(true)
  })

  it('rejects quantity over 99', () => {
    const result = updateCartSchema.safeParse({ itemId: 'item-1', quantity: 100 })
    expect(result.success).toBe(false)
  })

  it('rejects negative quantity', () => {
    const result = updateCartSchema.safeParse({ itemId: 'item-1', quantity: -1 })
    expect(result.success).toBe(false)
  })
})
