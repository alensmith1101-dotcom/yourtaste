import { describe, it, expect } from 'vitest'

describe('CouponService.calculateDiscount', () => {
  it('calculates percentage discount correctly', async () => {
    const { CouponService } = await import('@/lib/coupons')
    const result = CouponService.calculateDiscount(
      { type: 'PERCENTAGE', discountValue: 10, maxDiscountAmount: null, buyQuantity: null, getQuantity: null, getDiscountValue: null },
      10000
    )
    expect(result).toBe(1000)
  })

  it('caps discount at maxDiscountAmount', async () => {
    const { CouponService } = await import('@/lib/coupons')
    const result = CouponService.calculateDiscount(
      { type: 'PERCENTAGE', discountValue: 50, maxDiscountAmount: 2000, buyQuantity: null, getQuantity: null, getDiscountValue: null },
      10000
    )
    expect(result).toBe(2000)
  })

  it('fixed amount discount does not exceed order total', async () => {
    const { CouponService } = await import('@/lib/coupons')
    const result = CouponService.calculateDiscount(
      { type: 'FIXED_AMOUNT', discountValue: 5000, maxDiscountAmount: null, buyQuantity: null, getQuantity: null, getDiscountValue: null },
      3000
    )
    expect(result).toBe(3000)
  })

  it('free shipping returns 0 discount', async () => {
    const { CouponService } = await import('@/lib/coupons')
    const result = CouponService.calculateDiscount(
      { type: 'FREE_SHIPPING', discountValue: null, maxDiscountAmount: null, buyQuantity: null, getQuantity: null, getDiscountValue: null },
      10000
    )
    expect(result).toBe(0)
  })
})

describe('TaxService', () => {
  it('getGstSlab returns closest slab', async () => {
    const { getGstSlab } = await import('@/lib/tax')
    expect(getGstSlab(18)).toBe(18)
    expect(getGstSlab(5)).toBe(5)
    expect(getGstSlab(12)).toBe(12)
    expect(getGstSlab(28)).toBe(28)
  })

  it('calculateGst splits correctly for intra-state', async () => {
    const { calculateGst } = await import('@/lib/tax')
    const result = calculateGst(10000, 18)
    expect(result.total).toBe(1800)
    expect(result.cgst + result.sgst).toBe(1800)
    expect(result.igst).toBe(1800)
  })
})

describe('I18nService.formatPrice', () => {
  it('formatPrice converts cents correctly', () => {
    const priceCents = 199900
    const exchangeRate = 1
    const convertedAmount = (priceCents / 100) * exchangeRate
    expect(convertedAmount).toBe(1999)
  })
})

describe('SearchService', () => {
  it('EnhancedSearchService has search method', async () => {
    const { EnhancedSearchService } = await import('@/lib/search')
    expect(EnhancedSearchService.search).toBeDefined()
    expect(typeof EnhancedSearchService.search).toBe('function')
  })
})
