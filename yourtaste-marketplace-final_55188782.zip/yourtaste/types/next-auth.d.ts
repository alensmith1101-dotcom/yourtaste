import NextAuth from "next-auth"

declare module "next-auth" {
  interface Session {
    user: {
      id: string
      email: string
      name?: string | null
      role: 'CUSTOMER' | 'VENDOR' | 'ADMIN'
      image?: string | null
    }
  }

  interface User {
    id: string
    email: string
    name?: string | null
    role: 'CUSTOMER' | 'VENDOR' | 'ADMIN'
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    role: 'CUSTOMER' | 'VENDOR' | 'ADMIN'
  }
}
