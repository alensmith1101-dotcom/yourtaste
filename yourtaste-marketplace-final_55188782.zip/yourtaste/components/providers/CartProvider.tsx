"use client"

import React, {
  createContext,
  useContext,
  useEffect,
  useReducer,
  useCallback,
  useRef,
} from "react"
import { useSession } from "next-auth/react"
import { formatPrice } from "@/lib/utils"

export interface CartItem {
  id: string
  name: string
  priceCents: number
  image?: string
  slug?: string
  vendorId?: string
  quantity: number
}

interface CartState {
  items: CartItem[]
}

type CartAction =
  | { type: "ADD_ITEM"; payload: Omit<CartItem, "quantity"> & { quantity?: number } }
  | { type: "REMOVE_ITEM"; payload: string }
  | { type: "UPDATE_QUANTITY"; payload: { id: string; quantity: number } }
  | { type: "CLEAR_CART" }
  | { type: "HYDRATE"; payload: CartItem[] }

const CART_STORAGE_KEY = "yourtaste-cart"

function cartReducer(state: CartState, action: CartAction): CartState {
  switch (action.type) {
    case "ADD_ITEM": {
      const existing = state.items.find((item) => item.id === action.payload.id)
      if (existing) {
        return {
          items: state.items.map((item) =>
            item.id === action.payload.id
              ? {
                  ...item,
                  quantity:
                    item.quantity + (action.payload.quantity ?? 1),
                }
              : item
          ),
        }
      }
      return {
        items: [
          ...state.items,
          { ...action.payload, quantity: action.payload.quantity ?? 1 },
        ],
      }
    }
    case "REMOVE_ITEM":
      return {
        items: state.items.filter((item) => item.id !== action.payload),
      }
    case "UPDATE_QUANTITY": {
      if (action.payload.quantity <= 0) {
        return {
          items: state.items.filter(
            (item) => item.id !== action.payload.id
          ),
        }
      }
      return {
        items: state.items.map((item) =>
          item.id === action.payload.id
            ? { ...item, quantity: action.payload.quantity }
            : item
        ),
      }
    }
    case "CLEAR_CART":
      return { items: [] }
    case "HYDRATE":
      return { items: action.payload }
    default:
      return state
  }
}

interface CartContextValue {
  items: CartItem[]
  addToCart: (item: Omit<CartItem, "quantity"> & { quantity?: number }) => void
  removeFromCart: (id: string) => void
  updateQuantity: (id: string, quantity: number) => void
  clearCart: () => void
  syncCart: () => Promise<void>
  itemCount: number
  totalCents: number
  formatTotal: () => string
}

const CartContext = createContext<CartContextValue | undefined>(undefined)

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(cartReducer, { items: [] })
  const { data: session } = useSession()
  const isSyncing = useRef(false)

  useEffect(() => {
    try {
      const stored = localStorage.getItem(CART_STORAGE_KEY)
      if (stored) {
        const parsed = JSON.parse(stored) as CartItem[]
        if (Array.isArray(parsed)) {
          dispatch({ type: "HYDRATE", payload: parsed })
        }
      }
    } catch (err) {
      console.error('Failed to parse cart data:', err)
    }
  }, [])

  useEffect(() => {
    try {
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(state.items))
    } catch (err) {
      console.error('Failed to save cart:', err)
    }
  }, [state.items])

  const syncCart = useCallback(async () => {
    if (!session?.user || isSyncing.current) return
    isSyncing.current = true
    try {
      const res = await fetch("/api/cart")
      if (!res.ok) return
      const json = await res.json()
      const serverItems: CartItem[] = (json.data || []).map((item: any) => ({
        id: item.product?.id || item.productId,
        name: item.product?.name || "",
        priceCents: item.product?.priceCents || 0,
        image: item.product?.images?.[0] || item.product?.image,
        slug: item.product?.slug,
        vendorId: item.product?.vendorId,
        quantity: item.quantity,
      }))

      const localItems = state.items
      const serverIds = new Set(serverItems.map((i) => i.id))
      const localIds = new Set(localItems.map((i) => i.id))

      const toAdd = localItems.filter((i) => !serverIds.has(i.id))
      for (const item of toAdd) {
        await fetch("/api/cart", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ productId: item.id, quantity: item.quantity }),
        })
      }

      const toRemove = serverItems.filter((i) => !localIds.has(i.id))
      for (const item of toRemove) {
        await fetch("/api/cart", {
          method: "DELETE",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ cartItemId: item.id }),
        })
      }

      for (const si of serverItems) {
        const li = localItems.find((i) => i.id === si.id)
        if (li && li.quantity !== si.quantity) {
          await fetch("/api/cart", {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ cartItemId: si.id, quantity: li.quantity }),
          })
        }
      }
    } catch (err) {
      console.error('Sync failed:', err)
    } finally {
      isSyncing.current = false
    }
  }, [session, state.items])

  useEffect(() => {
    if (session?.user) {
      syncCart()
    }
  }, [session?.user])

  const addToCart = useCallback(
    async (item: Omit<CartItem, "quantity"> & { quantity?: number }) => {
      dispatch({ type: "ADD_ITEM", payload: item })
      if (session?.user) {
        try {
          await fetch("/api/cart", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ productId: item.id, quantity: item.quantity ?? 1 }),
          })
        } catch (err) {
          console.error('Failed to add item to cart:', err)
        }
      }
    },
    [session]
  )

  const removeFromCart = useCallback(
    async (id: string) => {
      dispatch({ type: "REMOVE_ITEM", payload: id })
      if (session?.user) {
        try {
          await fetch("/api/cart", {
            method: "DELETE",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ cartItemId: id }),
          })
        } catch (err) {
          console.error('Failed to remove item from cart:', err)
        }
      }
    },
    [session]
  )

  const updateQuantity = useCallback(
    async (id: string, quantity: number) => {
      dispatch({ type: "UPDATE_QUANTITY", payload: { id, quantity } })
      if (session?.user) {
        try {
          await fetch("/api/cart", {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ cartItemId: id, quantity }),
          })
        } catch (err) {
          console.error('Failed to update cart:', err)
        }
      }
    },
    [session]
  )

  const clearCart = useCallback(() => {
    dispatch({ type: "CLEAR_CART" })
  }, [])

  const itemCount = state.items.reduce((sum, item) => sum + item.quantity, 0)
  const totalCents = state.items.reduce(
    (sum, item) => sum + item.priceCents * item.quantity,
    0
  )
  const formatTotal = useCallback(() => formatPrice(totalCents), [totalCents])

  return (
    <CartContext.Provider
      value={{
        items: state.items,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        syncCart,
        itemCount,
        totalCents,
        formatTotal,
      }}
    >
      {children}
    </CartContext.Provider>
  )
}

export function useCart() {
  const context = useContext(CartContext)
  if (context === undefined) {
    throw new Error("useCart must be used within a CartProvider")
  }
  return context
}
