'use client'

import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'

const COLORS = ['#f97316', '#22d3ee', '#a78bfa', '#34d399', '#fbbf24', '#f87171']

interface RevenueData {
  date: string
  revenue: number
  orders: number
}

interface StatusData {
  name: string
  value: number
}

export function AdminCharts({ revenueData, statusData }: { revenueData: RevenueData[]; statusData: StatusData[] }) {
  return (
    <div className="grid gap-6 md:grid-cols-2">
      <div className="rounded-xl border bg-white p-6">
        <h3 className="mb-4 text-lg font-semibold">Revenue (Last 7 Days)</h3>
        <ResponsiveContainer width="100%" height={250}>
          <LineChart data={revenueData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
            <XAxis dataKey="date" tick={{ fontSize: 11 }} stroke="#94a3b8" />
            <YAxis tick={{ fontSize: 11 }} stroke="#94a3b8" tickFormatter={(v) => `₹${v}`} />
            <Tooltip formatter={(value: number) => [`₹${(value / 100).toFixed(2)}`, 'Revenue']} />
            <Line type="monotone" dataKey="revenue" stroke="#f97316" strokeWidth={2} dot={{ r: 4 }} />
          </LineChart>
        </ResponsiveContainer>
      </div>
      <div className="rounded-xl border bg-white p-6">
        <h3 className="mb-4 text-lg font-semibold">Orders by Status</h3>
        <ResponsiveContainer width="100%" height={250}>
          <PieChart>
            <Pie data={statusData} cx="50%" cy="50%" outerRadius={80} dataKey="value" label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
              {statusData.map((_, i) => (
                <Cell key={i} fill={COLORS[i % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
