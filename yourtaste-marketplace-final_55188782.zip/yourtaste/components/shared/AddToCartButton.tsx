"use client"

import { useState } from "react"
import { ShoppingBag, Minus, Plus } from "lucide-react"
import toast from "react-hot-toast"
import { Button } from "@/components/ui/button"

interface AddToCartButtonProps {
  productId: string
  disabled?: boolean
}

export function AddToCartButton({ productId, disabled }: AddToCartButtonProps) {
  const [quantity, setQuantity] = useState(1)
  const [addingToCart, setAddingToCart] = useState(false)

  const addToCart = async () => {
    setAddingToCart(true)
    try {
      const res = await fetch('/api/cart', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ productId, quantity }),
      })
      if (!res.ok) throw new Error('Failed to add to cart')
      toast.success('Added to cart!')
    } catch (err) {
      toast.error('Failed to add to cart. Please try again.')
    } finally {
      setAddingToCart(false)
    }
  }

  return (
    <div className="flex items-center gap-3">
      <div className="flex items-center rounded-lg border border-gray-200">
        <Button
          variant="ghost"
          size="icon"
          className="h-10 w-10"
          onClick={() => setQuantity((q) => Math.max(1, q - 1))}
        >
          <Minus className="h-4 w-4" />
        </Button>
        <span className="w-12 text-center text-sm font-medium">{quantity}</span>
        <Button
          variant="ghost"
          size="icon"
          className="h-10 w-10"
          onClick={() => setQuantity((q) => q + 1)}
        >
          <Plus className="h-4 w-4" />
        </Button>
      </div>
      <Button
        className="flex-1"
        size="lg"
        disabled={disabled || addingToCart}
        onClick={addToCart}
      >
        <ShoppingBag className="mr-2 h-4 w-4" />
        {addingToCart ? "Adding..." : "Add to Cart"}
      </Button>
    </div>
  )
}
