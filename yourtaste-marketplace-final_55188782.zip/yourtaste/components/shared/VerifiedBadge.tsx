import { BadgeCheck } from "lucide-react"

export function VerifiedBadge() {
  return (
    <span className="inline-flex items-center gap-1 rounded-full bg-green-50 px-2 py-0.5 text-xs font-medium text-green-700">
      <BadgeCheck className="h-3.5 w-3.5" />
      Verified Purchase
    </span>
  )
}
