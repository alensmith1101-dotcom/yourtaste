'use client'

import { Suspense } from 'react'
import { useRouter, usePathname, useSearchParams } from 'next/navigation'
import { useEffect, useRef } from 'react'

interface Vendor {
  id: string
  name: string
  slug: string
}

function VendorFilterInner({ vendors, selectedVendors }: { vendors: Vendor[]; selectedVendors: string[] }) {
  const router = useRouter()
  const pathname = usePathname()
  const searchParams = useSearchParams()
  const initialized = useRef(false)

  useEffect(() => {
    initialized.current = true
  }, [])

  const handleChange = (slug: string, checked: boolean) => {
    const params = new URLSearchParams(searchParams.toString())
    let updated: string[]
    if (checked) {
      updated = [...selectedVendors, slug]
    } else {
      updated = selectedVendors.filter(v => v !== slug)
    }
    if (updated.length > 0) {
      params.set('vendor', updated.join(','))
    } else {
      params.delete('vendor')
    }
    params.delete('page')
    router.push(`${pathname}?${params.toString()}`)
  }

  return (
    <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
      {vendors.map(v => (
        <label key={v.id} className="flex cursor-pointer items-center gap-2 rounded-md px-2 py-1 text-sm hover:bg-gray-50 transition-colors">
          <input
            type="checkbox"
            value={v.slug}
            checked={selectedVendors.includes(v.slug)}
            onChange={e => handleChange(v.slug, e.target.checked)}
            className="rounded border-gray-300 text-orange-600 focus:ring-orange-500"
          />
          <span className="text-gray-700">{v.name}</span>
        </label>
      ))}
    </div>
  )
}

export function VendorFilter({ vendors, selectedVendors }: { vendors: Vendor[]; selectedVendors: string[] }) {
  return (
    <Suspense fallback={<div className="space-y-2 max-h-40 overflow-y-auto pr-1"><div className="h-4 bg-gray-200 rounded animate-pulse"></div></div>}>
      <VendorFilterInner vendors={vendors} selectedVendors={selectedVendors} />
    </Suspense>
  )
}
