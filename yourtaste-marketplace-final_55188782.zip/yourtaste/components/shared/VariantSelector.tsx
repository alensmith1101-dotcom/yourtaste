'use client'

import { useState } from 'react'

interface Variant {
  id: string
  name: string
  value: string
  priceCents: number
  stockQuantity: number
}

export function VariantSelector({ variants, onSelect }: { variants: Variant[]; onSelect?: (variant: Variant) => void }) {
  const [selected, setSelected] = useState<string | null>(null)

  const handleSelect = (variant: Variant) => {
    setSelected(variant.id)
    onSelect?.(variant)
  }

  return (
    <div className="flex flex-wrap gap-2">
      {variants.map((variant) => (
        <button
          key={variant.id}
          onClick={() => handleSelect(variant)}
          disabled={variant.stockQuantity <= 0}
          className={`rounded-lg border px-4 py-2 text-sm font-medium transition-colors ${
            selected === variant.id
              ? 'border-orange-500 bg-orange-50 text-orange-700'
              : variant.stockQuantity <= 0
              ? 'border-gray-200 bg-gray-100 text-gray-400 cursor-not-allowed'
              : 'border-gray-300 bg-white text-gray-700 hover:border-orange-300'
          }`}
        >
          {variant.name}: {variant.value}
          {variant.stockQuantity <= 0 && ' (Out of stock)'}
        </button>
      ))}
    </div>
  )
}
