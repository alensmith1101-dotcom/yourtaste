'use client'

import { useState, useRef, useCallback } from 'react'
import { X, Upload, Loader2, AlertCircle } from 'lucide-react'

interface ReviewImageUploadProps {
  reviewId: string
  existingImages?: { id: string; url: string }[]
  maxImages?: number
  onImagesChange?: (images: { id: string; url: string }[]) => void
}

const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif']
const MAX_FILE_SIZE = 5 * 1024 * 1024

export function ReviewImageUpload({
  reviewId,
  existingImages = [],
  maxImages = 5,
  onImagesChange,
}: ReviewImageUploadProps) {
  const [images, setImages] = useState(existingImages)
  const [uploading, setUploading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [dragOver, setDragOver] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)

  const remaining = maxImages - images.length

  const uploadFile = useCallback(async (file: File) => {
    if (!ALLOWED_TYPES.includes(file.type)) {
      setError('Invalid file type. Allowed: JPEG, PNG, WebP, GIF')
      return
    }
    if (file.size > MAX_FILE_SIZE) {
      setError('File too large. Maximum size is 5MB')
      return
    }

    setUploading(true)
    setError(null)

    try {
      const formData = new FormData()
      formData.append('file', file)

      const res = await fetch(`/api/reviews/${reviewId}/images`, {
        method: 'POST',
        body: formData,
      })

      const data = await res.json()

      if (!res.ok) {
        setError(data.error || 'Upload failed')
        return
      }

      setImages(prev => {
        const next = [...prev, data.data]
        onImagesChange?.(next)
        return next
      })
    } catch {
      setError('Upload failed. Please try again.')
    } finally {
      setUploading(false)
    }
  }, [reviewId, onImagesChange])

  const handleDelete = useCallback(async (imageId: string) => {
    try {
      const res = await fetch(`/api/reviews/${reviewId}/images`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imageId }),
      })

      if (!res.ok) return

      setImages(prev => {
        const next = prev.filter(img => img.id !== imageId)
        onImagesChange?.(next)
        return next
      })
    } catch {
      // silent fail for delete
    }
  }, [reviewId, onImagesChange])

  const handleFiles = useCallback((files: FileList | null) => {
    if (!files || remaining <= 0) return
    const toUpload = Array.from(files).slice(0, remaining)
    toUpload.forEach(file => uploadFile(file))
  }, [remaining, uploadFile])

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setDragOver(false)
    handleFiles(e.dataTransfer.files)
  }, [handleFiles])

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-3">
        {images.map((img) => (
          <div
            key={img.id}
            className="group relative h-20 w-20 overflow-hidden rounded-lg border border-gray-200"
          >
            <img
              src={img.url}
              alt="Review"
              className="h-full w-full object-cover"
            />
            <button
              type="button"
              onClick={() => handleDelete(img.id)}
              className="absolute inset-0 flex items-center justify-center bg-black/50 opacity-0 transition-opacity group-hover:opacity-100"
              aria-label="Remove image"
            >
              <X className="h-5 w-5 text-white" />
            </button>
          </div>
        ))}

        {uploading && (
          <div className="flex h-20 w-20 items-center justify-center rounded-lg border-2 border-dashed border-orange-300 bg-orange-50">
            <Loader2 className="h-5 w-5 animate-spin text-orange-500" />
          </div>
        )}

        {remaining > 0 && !uploading && (
          <button
            type="button"
            onClick={() => inputRef.current?.click()}
            onDragOver={(e) => { e.preventDefault(); setDragOver(true) }}
            onDragLeave={() => setDragOver(false)}
            onDrop={handleDrop}
            className={`flex h-20 w-20 flex-col items-center justify-center rounded-lg border-2 border-dashed transition-colors ${
              dragOver
                ? 'border-orange-500 bg-orange-50'
                : 'border-gray-300 hover:border-orange-400 hover:bg-gray-50'
            }`}
          >
            <Upload className="h-5 w-5 text-gray-400" />
            <span className="mt-1 text-[10px] text-gray-500">Add</span>
          </button>
        )}
      </div>

      <input
        ref={inputRef}
        type="file"
        accept={ALLOWED_TYPES.join(',')}
        multiple
        className="hidden"
        onChange={(e) => handleFiles(e.target.files)}
      />

      {error && (
        <div className="flex items-center gap-2 text-sm text-red-600">
          <AlertCircle className="h-4 w-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      <p className="text-xs text-gray-400">
        {images.length}/{maxImages} images &middot; JPEG, PNG, WebP, GIF &middot; Max 5MB each
      </p>
    </div>
  )
}
