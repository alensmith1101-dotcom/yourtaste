'use client'

import { useEffect, useState, useRef, useCallback } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { ChevronLeft, ChevronRight, Star, X, ShoppingBag } from 'lucide-react'
import {
  getRecentlyViewed,
  clearRecentlyViewed,
  type RecentlyViewedProduct,
} from '@/lib/recently-viewed'
import { parseImages, formatPrice } from '@/lib/utils'

export function RecentlyViewed() {
  const [products, setProducts] = useState<RecentlyViewedProduct[]>([])
  const [mounted, setMounted] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)
  const [canScrollLeft, setCanScrollLeft] = useState(false)
  const [canScrollRight, setCanScrollRight] = useState(false)

  useEffect(() => {
    setMounted(true)
    setProducts(getRecentlyViewed())
  }, [])

  const updateScrollButtons = useCallback(() => {
    const el = scrollRef.current
    if (!el) return
    setCanScrollLeft(el.scrollLeft > 0)
    setCanScrollRight(el.scrollLeft + el.clientWidth < el.scrollWidth - 1)
  }, [])

  useEffect(() => {
    const el = scrollRef.current
    if (!el) return
    updateScrollButtons()
    el.addEventListener('scroll', updateScrollButtons, { passive: true })
    window.addEventListener('resize', updateScrollButtons)
    return () => {
      el.removeEventListener('scroll', updateScrollButtons)
      window.removeEventListener('resize', updateScrollButtons)
    }
  }, [updateScrollButtons, products])

  const scroll = (direction: 'left' | 'right') => {
    const el = scrollRef.current
    if (!el) return
    const amount = el.clientWidth * 0.75
    el.scrollBy({ left: direction === 'left' ? -amount : amount, behavior: 'smooth' })
  }

  const handleClear = () => {
    clearRecentlyViewed()
    setProducts([])
  }

  if (!mounted || products.length === 0) return null

  return (
    <section className="bg-gray-50">
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold text-gray-900 sm:text-3xl">
            Recently Viewed
          </h2>
          <button
            onClick={handleClear}
            className="flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-sm font-medium text-gray-500 transition hover:bg-gray-200 hover:text-gray-700"
          >
            <X className="h-4 w-4" />
            Clear
          </button>
        </div>

        <div className="relative mt-8">
          {canScrollLeft && (
            <button
              onClick={() => scroll('left')}
              className="absolute -left-2 top-1/2 z-10 -translate-y-1/2 rounded-full border border-gray-200 bg-white p-2 shadow-md transition hover:bg-gray-50 sm:-left-4"
              aria-label="Scroll left"
            >
              <ChevronLeft className="h-5 w-5 text-gray-700" />
            </button>
          )}

          <div
            ref={scrollRef}
            className="flex gap-4 overflow-x-auto scroll-smooth pb-2 [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
          >
            {products.map((product) => {
              const images = parseImages(product.images)
              const imageUrl = images[0] || ''
              const hasDiscount =
                product.originalPriceCents &&
                product.originalPriceCents > product.priceCents
              const discountPercent = hasDiscount
                ? Math.round(
                    ((product.originalPriceCents! - product.priceCents) /
                      product.originalPriceCents!) *
                      100
                  )
                : 0

              return (
                <Link
                  key={product.id}
                  href={`/products/${product.slug}`}
                  className="group w-[180px] shrink-0 sm:w-[200px]"
                >
                  <div className="relative aspect-square overflow-hidden rounded-xl bg-gray-100">
                    {imageUrl ? (
                      <Image
                        src={imageUrl}
                        alt={product.name}
                        fill
                        sizes="200px"
                        className="object-cover transition-transform duration-300 group-hover:scale-105"
                      />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center">
                        <ShoppingBag className="h-10 w-10 text-gray-300" />
                      </div>
                    )}
                    {discountPercent > 0 && (
                      <span className="absolute left-2 top-2 rounded-full bg-red-500 px-2 py-0.5 text-xs font-semibold text-white">
                        -{discountPercent}%
                      </span>
                    )}
                  </div>
                  <p className="mt-3 line-clamp-1 text-xs font-medium text-orange-600">
                    {product.vendorName}
                  </p>
                  <h3 className="mt-1 line-clamp-2 text-sm font-semibold text-gray-900 group-hover:text-orange-600">
                    {product.name}
                  </h3>
                  <div className="mt-1.5 flex items-center gap-1">
                    <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                    <span className="text-xs font-medium text-gray-700">
                      {product.averageRating.toFixed(1)}
                    </span>
                    {product.totalReviews > 0 && (
                      <span className="text-xs text-gray-400">
                        ({product.totalReviews})
                      </span>
                    )}
                  </div>
                  <div className="mt-2 flex items-baseline gap-2">
                    <span className="text-base font-bold text-gray-900">
                      {formatPrice(product.priceCents)}
                    </span>
                    {product.originalPriceCents && (
                      <span className="text-xs text-gray-400 line-through">
                        {formatPrice(product.originalPriceCents)}
                      </span>
                    )}
                  </div>
                </Link>
              )
            })}
          </div>

          {canScrollRight && (
            <button
              onClick={() => scroll('right')}
              className="absolute -right-2 top-1/2 z-10 -translate-y-1/2 rounded-full border border-gray-200 bg-white p-2 shadow-md transition hover:bg-gray-50 sm:-right-4"
              aria-label="Scroll right"
            >
              <ChevronRight className="h-5 w-5 text-gray-700" />
            </button>
          )}
        </div>
      </div>
    </section>
  )
}
