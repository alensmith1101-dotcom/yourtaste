'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'

export function NewsletterSignup() {
  const [email, setEmail] = useState('')
  const [subscribed, setSubscribed] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email) return
    try {
      setSubscribed(true)
      setEmail('')
    } catch (err) {
      console.error('Newsletter signup failed:', err)
    }
  }

  if (subscribed) {
    return (
      <p className="text-lg font-semibold text-white">Thanks for subscribing!</p>
    )
  }

  return (
    <form className="flex gap-2 max-w-md mx-auto" onSubmit={handleSubmit}>
      <input
        type="email"
        placeholder="Enter your email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        className="flex-1 px-4 py-2 rounded-lg text-gray-900 focus:outline-none focus:ring-2 focus:ring-white"
      />
      <Button type="submit" className="bg-white text-orange-600 hover:bg-orange-50">
        Subscribe
      </Button>
    </form>
  )
}
