'use client'

import { Suspense } from 'react'
import { useState, useMemo } from 'react'
import { useRouter, useSearchParams, usePathname } from 'next/navigation'
import { ProductToolbar } from './ProductToolbar'
import { ProductDisplay } from './ProductDisplay'
import { ShoppingBag } from 'lucide-react'
import { Button } from '@/components/ui/button'
import Link from 'next/link'

interface Product {
  id: string
  slug: string
  name: string
  description?: string | null
  priceCents: number
  originalPriceCents?: number | null
  images: string
  averageRating?: number | null
  totalReviews?: number
  vendor?: { name: string; slug: string } | null
}

interface ProductsClientProps {
  products: Product[]
  totalProducts: number
  currentPage: number
  totalPages: number
  sort: string
  search: string
  category: string
  minPrice?: number
  maxPrice?: number
  minRating?: number
  vendorSlugs: string[]
  categoryLabels: Record<string, string>
  vendorLabels: Record<string, string>
}

function ProductsClientInner({
  products,
  totalProducts,
  currentPage,
  totalPages,
  sort,
  search,
  category,
  minPrice,
  maxPrice,
  minRating,
  vendorSlugs,
  categoryLabels,
  vendorLabels,
}: ProductsClientProps) {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const router = useRouter()
  const pathname = usePathname()
  const searchParams = useSearchParams()

  const activeFilters = useMemo(() => {
    const filters: { key: string; label: string; value: string }[] = []
    if (search) filters.push({ key: 'search', label: `Search: "${search}"`, value: search })
    if (category) filters.push({ key: 'category', label: categoryLabels[category] || category, value: category })
    if (minPrice !== undefined) filters.push({ key: 'minPrice', label: `Min: ₹${minPrice}`, value: String(minPrice) })
    if (maxPrice !== undefined) filters.push({ key: 'maxPrice', label: `Max: ₹${maxPrice}`, value: String(maxPrice) })
    if (minRating !== undefined) filters.push({ key: 'minRating', label: `${minRating}★ & up`, value: String(minRating) })
    vendorSlugs.forEach((slug) => {
      filters.push({ key: `vendor:${slug}`, label: vendorLabels[slug] || slug, value: slug })
    })
    return filters
  }, [search, category, minPrice, maxPrice, minRating, vendorSlugs, categoryLabels, vendorLabels])

  const handleClearFilter = (key: string) => {
    const params = new URLSearchParams(searchParams.toString())
    if (key === 'search') {
      params.delete('search')
    } else if (key === 'category') {
      params.delete('category')
    } else if (key === 'minPrice') {
      params.delete('minPrice')
    } else if (key === 'maxPrice') {
      params.delete('maxPrice')
    } else if (key === 'minRating') {
      params.delete('minRating')
    } else if (key.startsWith('vendor:')) {
      const slug = key.replace('vendor:', '')
      const updated = vendorSlugs.filter((v) => v !== slug)
      if (updated.length > 0) {
        params.set('vendor', updated.join(','))
      } else {
        params.delete('vendor')
      }
    }
    params.delete('page')
    router.push(`${pathname}?${params.toString()}`)
  }

  const handleClearAll = () => {
    router.push('/products')
  }

  const queryParams = useMemo(() => {
    const params = new URLSearchParams()
    if (search) params.set('search', search)
    if (category) params.set('category', category)
    if (sort !== 'newest') params.set('sort', sort)
    if (minPrice !== undefined) params.set('minPrice', minPrice.toString())
    if (maxPrice !== undefined) params.set('maxPrice', maxPrice.toString())
    if (minRating !== undefined) params.set('minRating', minRating.toString())
    if (vendorSlugs.length > 0) params.set('vendor', vendorSlugs.join(','))
    return params.toString()
  }, [search, category, sort, minPrice, maxPrice, minRating, vendorSlugs])

  if (products.length === 0) {
    return (
      <div className="rounded-2xl border-2 border-dashed border-gray-200 py-16 text-center">
        <ShoppingBag className="mx-auto h-12 w-12 text-gray-300" />
        <h3 className="mt-4 text-lg font-medium text-gray-900">No products found</h3>
        <p className="mt-2 text-sm text-gray-500">Try adjusting your search or filter criteria.</p>
        <Link href="/products" className="mt-4 inline-block">
          <Button variant="outline">Clear Filters</Button>
        </Link>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <ProductToolbar
        viewMode={viewMode}
        onViewModeChange={setViewMode}
        activeFilters={activeFilters}
        onClearFilter={handleClearFilter}
        onClearAll={handleClearAll}
        sortValue={sort}
        totalProducts={totalProducts}
      />
      <ProductDisplay
        initialProducts={products}
        viewMode={viewMode}
        currentPage={currentPage}
        totalPages={totalPages}
        queryParams={queryParams}
      />
    </div>
  )
}

export function ProductsClient(props: ProductsClientProps) {
  return (
    <Suspense fallback={<div className="space-y-4"><div className="h-10 bg-gray-200 rounded animate-pulse"></div><div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">{Array.from({ length: 8 }).map((_, i) => (<div key={i} className="h-64 bg-gray-200 rounded animate-pulse"></div>))}</div></div>}>
      <ProductsClientInner {...props} />
    </Suspense>
  )
}
