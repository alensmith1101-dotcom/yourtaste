'use client'

import { useState, useCallback } from 'react'
import { ProductCard } from './ProductCard'
import { ProductListView } from './ProductListView'
import { Button } from '@/components/ui/button'
import { Loader2 } from 'lucide-react'

interface Product {
  id: string
  slug: string
  name: string
  description?: string | null
  priceCents: number
  originalPriceCents?: number | null
  images: string
  averageRating?: number | null
  totalReviews?: number
  vendor?: { name: string; slug: string } | null
}

interface ProductDisplayProps {
  initialProducts: Product[]
  viewMode: 'grid' | 'list'
  currentPage: number
  totalPages: number
  queryParams: string
}

export function ProductDisplay({
  initialProducts,
  viewMode,
  currentPage,
  totalPages,
  queryParams,
}: ProductDisplayProps) {
  const [products, setProducts] = useState(initialProducts)
  const [loadedPage, setLoadedPage] = useState(currentPage)
  const [isLoading, setIsLoading] = useState(false)
  const [hasMore, setHasMore] = useState(currentPage < totalPages)

  const handleLoadMore = useCallback(async () => {
    if (isLoading || !hasMore) return

    setIsLoading(true)
    try {
      const params = new URLSearchParams(queryParams)
      params.set('page', String(loadedPage + 1))
      const res = await fetch(`/api/products/listing?${params.toString()}`)

      if (res.ok) {
        const data = await res.json()
        if (data.products.length > 0) {
          setProducts((prev) => [...prev, ...data.products])
          setLoadedPage((prev) => prev + 1)
          if (data.products.length < 12) {
            setHasMore(false)
          }
        } else {
          setHasMore(false)
        }
      }
    } catch (error) {
      console.error('Failed to load more products:', error)
    } finally {
      setIsLoading(false)
    }
  }, [isLoading, hasMore, loadedPage, queryParams])

  if (products.length === 0) {
    return null
  }

  if (viewMode === 'list') {
    return (
      <div className="space-y-6">
        <ProductListView products={products} />
        {hasMore && (
          <div className="flex justify-center pt-4">
            <Button
              variant="outline"
              onClick={handleLoadMore}
              disabled={isLoading}
              className="min-w-[160px]"
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Loading...
                </>
              ) : (
                'Load More'
              )}
            </Button>
          </div>
        )}
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} layout="grid" />
        ))}
      </div>
      {hasMore && (
        <div className="flex justify-center pt-4">
          <Button
            variant="outline"
            onClick={handleLoadMore}
            disabled={isLoading}
            className="min-w-[160px]"
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Loading...
              </>
            ) : (
              'Load More'
            )}
          </Button>
        </div>
      )}
    </div>
  )
}
