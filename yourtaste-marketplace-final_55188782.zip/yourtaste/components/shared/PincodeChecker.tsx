'use client'

import { useState } from 'react'
import { Truck, MapPin, Check, X } from 'lucide-react'

export function PincodeChecker() {
  const [pincode, setPincode] = useState('')
  const [result, setResult] = useState<{ available: boolean; days?: string; price?: number } | null>(null)
  const [loading, setLoading] = useState(false)

  const checkPincode = async () => {
    if (pincode.length !== 6) return
    setLoading(true)
    try {
      const res = await fetch(`/api/shipping/rates?toZip=${pincode}&subtotal=100000`)
      const data = await res.json()
      if (data.rates && data.rates.length > 0) {
        const fastest = data.rates.sort((a: any, b: any) => parseInt(a.estimatedDays) - parseInt(b.estimatedDays))[0]
        setResult({ available: true, days: fastest.estimatedDays, price: fastest.price })
      } else {
        setResult({ available: false })
      }
    } catch (err) {
      console.error('Pincode check failed:', err)
      setResult({ available: false })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="rounded-lg border p-4">
      <div className="flex items-center gap-2 mb-3">
        <Truck className="h-4 w-4 text-gray-600" />
        <span className="text-sm font-medium">Check Delivery</span>
      </div>
      <div className="flex gap-2">
        <div className="relative flex-1">
          <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <input
            type="text"
            value={pincode}
            onChange={e => setPincode(e.target.value.replace(/\D/g, '').slice(0, 6))}
            placeholder="Enter PIN code"
            maxLength={6}
            className="w-full rounded-lg border py-2 pl-9 pr-3 text-sm focus:border-orange-500 focus:outline-none"
            onKeyDown={e => e.key === 'Enter' && checkPincode()}
          />
        </div>
        <button onClick={checkPincode} disabled={pincode.length !== 6 || loading} className="rounded-lg bg-orange-600 px-4 py-2 text-sm font-medium text-white hover:bg-orange-700 disabled:opacity-50">
          {loading ? '...' : 'Check'}
        </button>
      </div>
      {result && (
        <div className={`mt-3 flex items-center gap-2 text-sm ${result.available ? 'text-green-600' : 'text-red-500'}`}>
          {result.available ? (
            <>
              <Check className="h-4 w-4" />
              <span>Delivery in {result.days} days {result.price === 0 ? '• FREE shipping' : `• ₹${(result.price! / 100).toFixed(2)}`}</span>
            </>
          ) : (
            <>
              <X className="h-4 w-4" />
              <span>Delivery not available for this PIN code</span>
            </>
          )}
        </div>
      )}
    </div>
  )
}
