'use client'

import { useState } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { Star, Store, Heart, Zap, MessageCircle } from 'lucide-react'
import { parseImages, formatPrice } from '@/lib/utils'

interface ProductCardProps {
  product: {
    id: string
    slug: string
    name: string
    description?: string | null
    priceCents: number
    originalPriceCents?: number | null
    images: string
    averageRating?: number | null
    totalReviews?: number
    totalQuestions?: number
    vendor?: { name: string; slug: string } | null
    deal?: {
      discountPercent: number
      endsAt: string | Date
      stockLimit: number
      soldCount: number
    } | null
  }
  layout?: 'grid' | 'list'
}

export function ProductCard({ product, layout = 'grid' }: ProductCardProps) {
  const [isWishlisted, setIsWishlisted] = useState(false)
  const images = parseImages(product.images)
  const imageUrl = images[0] || '/placeholder-product.jpg'
  const hasDiscount = product.originalPriceCents && product.originalPriceCents > product.priceCents
  const discountPercent = hasDiscount
    ? Math.round(((product.originalPriceCents! - product.priceCents) / product.originalPriceCents!) * 100)
    : 0
  const hasDeal = !!product.deal && product.deal.discountPercent > 0

  const handleWishlistClick = async (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()

    try {
      const res = await fetch('/api/wishlist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ productId: product.id }),
      })

      if (res.ok) {
        setIsWishlisted(!isWishlisted)
      }
    } catch (error) {
      console.error('Failed to toggle wishlist:', error)
    }
  }

  if (layout === 'list') {
    return (
      <div className="group relative flex gap-4 rounded-xl border border-gray-200 bg-white p-4 transition-shadow hover:shadow-md sm:gap-6 sm:p-5">
        <Link href={`/products/${product.slug}`} className="relative block h-32 w-32 shrink-0 overflow-hidden rounded-lg bg-slate-100 sm:h-44 sm:w-44">
          <Image
            src={imageUrl}
            alt={product.name}
            fill
            className="object-cover transition-transform duration-300 group-hover:scale-105"
            sizes="176px"
          />
          <div className="absolute top-2 left-2 flex flex-col gap-1.5">
            {hasDeal && (
              <span className="inline-flex items-center gap-1 rounded-full bg-red-600 px-2 py-0.5 text-xs font-bold text-white shadow-md">
                <Zap className="h-3 w-3" />
                -{product.deal!.discountPercent}%
              </span>
            )}
            {!hasDeal && hasDiscount && discountPercent > 0 && (
              <span className="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full">
                -{discountPercent}%
              </span>
            )}
          </div>
        </Link>

        <div className="flex flex-1 flex-col justify-between min-w-0">
          <div>
            {product.vendor && (
              <div className="flex items-center gap-1 text-xs text-slate-500 mb-1">
                <Store className="w-3 h-3" />
                <span>{product.vendor.name}</span>
              </div>
            )}
            <Link href={`/products/${product.slug}`}>
              <h3 className="font-medium text-base text-slate-900 line-clamp-2 group-hover:text-indigo-600 transition-colors">
                {product.name}
              </h3>
            </Link>
            {product.description && (
              <p className="mt-1 text-sm text-slate-500 line-clamp-2 hidden sm:block">
                {product.description}
              </p>
            )}
          </div>

          <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-2">
            <div className="flex items-center gap-1">
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
              <span className="text-xs text-slate-600">
                {(product.averageRating || 0).toFixed(1)}
                {product.totalReviews ? ` (${product.totalReviews})` : ''}
              </span>
            </div>
            {product.totalQuestions ? (
              <div className="flex items-center gap-1">
                <MessageCircle className="w-3.5 h-3.5 text-slate-400" />
                <span className="text-xs text-slate-600">{product.totalQuestions}</span>
              </div>
            ) : null}
            <div className="flex items-center gap-2">
              <span className="font-bold text-lg text-slate-900">{formatPrice(product.priceCents)}</span>
              {hasDiscount && product.originalPriceCents && (
                <span className="text-sm text-slate-400 line-through">{formatPrice(product.originalPriceCents)}</span>
              )}
            </div>
          </div>
        </div>

        <button
          onClick={handleWishlistClick}
          className="absolute top-3 right-3 p-2 rounded-full bg-white/80 backdrop-blur-sm hover:bg-white transition-all"
          aria-label="Add to wishlist"
        >
          <Heart
            className={`w-5 h-5 transition-colors ${
              isWishlisted ? 'fill-red-500 text-red-500' : 'text-slate-400'
            }`}
          />
        </button>
      </div>
    )
  }

  return (
    <div className="relative group">
      <Link href={`/products/${product.slug}`} className="block">
        <div className="relative aspect-square overflow-hidden rounded-xl bg-slate-100 mb-3">
          <Image
            src={imageUrl}
            alt={product.name}
            fill
            className="object-cover transition-transform duration-300 group-hover:scale-105"
            sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
          />
          <div className="absolute top-2 left-2 flex flex-col gap-1.5">
            {hasDeal && (
              <span className="inline-flex items-center gap-1 rounded-full bg-red-600 px-2.5 py-1 text-xs font-bold text-white shadow-md">
                <Zap className="h-3 w-3" />
                -{product.deal!.discountPercent}% DEAL
              </span>
            )}
            {!hasDeal && hasDiscount && discountPercent > 0 && (
              <span className="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full">
                -{discountPercent}%
              </span>
            )}
          </div>
          <button
            onClick={handleWishlistClick}
            className="absolute top-2 right-2 p-2 rounded-full bg-white/80 backdrop-blur-sm hover:bg-white transition-all opacity-0 group-hover:opacity-100"
            aria-label="Add to wishlist"
          >
            <Heart
              className={`w-5 h-5 transition-colors ${
                isWishlisted ? 'fill-red-500 text-red-500' : 'text-slate-600'
              }`}
            />
          </button>
        </div>
        {product.vendor && (
          <div className="flex items-center gap-1 text-xs text-slate-500 mb-1">
            <Store className="w-3 h-3" />
            <span>{product.vendor.name}</span>
          </div>
        )}
        <h3 className="font-medium text-sm text-slate-900 line-clamp-2 group-hover:text-indigo-600 transition-colors">
          {product.name}
        </h3>
        <div className="flex items-center gap-1 mt-1">
          <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
          <span className="text-xs text-slate-600">
            {(product.averageRating || 0).toFixed(1)}
            {product.totalReviews ? ` (${product.totalReviews})` : ''}
          </span>
          {product.totalQuestions ? (
            <>
              <span className="text-xs text-slate-300">|</span>
              <MessageCircle className="w-3.5 h-3.5 text-slate-400" />
              <span className="text-xs text-slate-600">{product.totalQuestions}</span>
            </>
          ) : null}
        </div>
        <div className="flex items-center gap-2 mt-2">
          <span className="font-bold text-slate-900">{formatPrice(product.priceCents)}</span>
          {hasDiscount && product.originalPriceCents && (
            <span className="text-sm text-slate-400 line-through">{formatPrice(product.originalPriceCents)}</span>
          )}
        </div>
      </Link>
    </div>
  )
}
