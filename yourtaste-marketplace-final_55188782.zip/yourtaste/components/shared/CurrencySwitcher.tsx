'use client'

import { useState, useEffect } from 'react'

const currencies = [
  { code: 'INR', symbol: '₹', name: 'Indian Rupee' },
  { code: 'USD', symbol: '$', name: 'US Dollar' },
  { code: 'EUR', symbol: '€', name: 'Euro' },
  { code: 'GBP', symbol: '£', name: 'British Pound' },
]

export function CurrencySwitcher() {
  const [currency, setCurrency] = useState('INR')
  const [open, setOpen] = useState(false)

  useEffect(() => {
    const saved = localStorage.getItem('yt-currency')
    if (saved) setCurrency(saved)
  }, [])

  const handleSelect = (code: string) => {
    setCurrency(code)
    localStorage.setItem('yt-currency', code)
    setOpen(false)
    window.dispatchEvent(new CustomEvent('currency-change', { detail: code }))
  }

  const current = currencies.find(c => c.code === currency) || currencies[0]

  return (
    <div className="relative">
      <button onClick={() => setOpen(!open)} className="flex items-center gap-1 rounded-lg border px-3 py-1.5 text-sm hover:bg-gray-50">
        <span>{current.symbol}</span>
        <span>{current.code}</span>
        <svg className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
      </button>
      {open && (
        <div className="absolute right-0 top-full z-50 mt-1 w-44 rounded-lg border bg-white py-1 shadow-lg">
          {currencies.map(c => (
            <button key={c.code} onClick={() => handleSelect(c.code)} className={`flex w-full items-center gap-2 px-4 py-2 text-sm hover:bg-gray-50 ${c.code === currency ? 'bg-orange-50 text-orange-700' : ''}`}>
              <span className="w-5">{c.symbol}</span>
              <span>{c.name}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
