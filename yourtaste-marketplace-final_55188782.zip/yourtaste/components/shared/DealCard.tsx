'use client'

import Link from 'next/link'
import Image from 'next/image'
import { Zap, Clock, Flame } from 'lucide-react'
import { parseImages, formatPrice } from '@/lib/utils'
import { CountdownTimer } from './CountdownTimer'

interface DealCardProps {
  deal: {
    id: string
    discountPercent: number
    endsAt: string | Date
    stockLimit: number
    soldCount: number
    isActive: boolean
    product: {
      id: string
      name: string
      slug: string
      priceCents: number
      images: string
      vendor?: { name: string; slug?: string } | null
    }
    dealPrice?: number
    status?: string
  }
}

function getDealStatus(deal: DealCardProps['deal']): { label: string; color: string } {
  const now = new Date()
  const endsAt = new Date(deal.endsAt)
  if (!deal.isActive || endsAt < now) return { label: 'Expired', color: 'bg-gray-500' }
  if (deal.stockLimit > 0 && deal.soldCount >= deal.stockLimit) return { label: 'Sold Out', color: 'bg-red-500' }
  const hoursLeft = (endsAt.getTime() - now.getTime()) / 3600000
  if (hoursLeft < 2) return { label: 'Ending Soon', color: 'bg-amber-500' }
  return { label: 'Active', color: 'bg-emerald-500' }
}

export function DealCard({ deal }: DealCardProps) {
  const images = parseImages(deal.product.images)
  const imageUrl = images[0] || '/placeholder-product.jpg'
  const originalPrice = deal.product.priceCents
  const dealPrice = deal.dealPrice ?? Math.round(originalPrice * (1 - deal.discountPercent / 100))
  const status = deal.status ? { label: deal.status.replace(/_/g, ' '), color: deal.status === 'ACTIVE' ? 'bg-emerald-500' : deal.status === 'ENDING_SOON' ? 'bg-amber-500' : deal.status === 'SOLD_OUT' ? 'bg-red-500' : 'bg-gray-500' } : getDealStatus(deal)
  const stockPercent = deal.stockLimit > 0 ? Math.min(100, Math.round((deal.soldCount / deal.stockLimit) * 100)) : 0
  const isSoldOut = deal.stockLimit > 0 && deal.soldCount >= deal.stockLimit

  return (
    <div className="group relative overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-sm transition-all hover:shadow-lg">
      <div className="absolute top-3 left-3 z-10 flex items-center gap-2">
        <span className="inline-flex items-center gap-1 rounded-full bg-red-600 px-3 py-1 text-xs font-bold text-white shadow-lg">
          <Zap className="h-3 w-3" />
          -{deal.discountPercent}%
        </span>
        <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-semibold text-white ${status.color}`}>
          {status.label}
        </span>
      </div>

      <Link href={`/products/${deal.product.slug}`} className="block">
        <div className="relative aspect-square overflow-hidden bg-gray-100">
          <Image
            src={imageUrl}
            alt={deal.product.name}
            fill
            sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
            className="object-cover transition-transform duration-300 group-hover:scale-105"
          />
          {isSoldOut && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/50">
              <span className="rounded-lg bg-white px-4 py-2 text-lg font-bold text-gray-900">SOLD OUT</span>
            </div>
          )}
        </div>
      </Link>

      <div className="p-4">
        {deal.product.vendor && (
          <p className="text-xs font-medium text-orange-600">{deal.product.vendor.name}</p>
        )}
        <Link href={`/products/${deal.product.slug}`}>
          <h3 className="mt-1 line-clamp-2 text-sm font-semibold text-gray-900 transition-colors group-hover:text-orange-600">
            {deal.product.name}
          </h3>
        </Link>

        <div className="mt-3 flex items-baseline gap-2">
          <span className="text-xl font-bold text-gray-900">{formatPrice(dealPrice)}</span>
          <span className="text-sm text-gray-400 line-through">{formatPrice(originalPrice)}</span>
        </div>

        <div className="mt-3">
          <div className="flex items-center justify-between text-xs text-gray-500">
            <span className="flex items-center gap-1">
              <Clock className="h-3 w-3" />
              Ends in:
            </span>
          </div>
          <div className="mt-1">
            <CountdownTimer targetDate={new Date(deal.endsAt).toISOString()} compact />
          </div>
        </div>

        {deal.stockLimit > 0 && (
          <div className="mt-3">
            <div className="flex items-center justify-between text-xs">
              <span className="flex items-center gap-1 text-gray-500">
                <Flame className="h-3 w-3 text-orange-500" />
                {deal.soldCount} sold
              </span>
              <span className="font-medium text-gray-700">
                {deal.stockLimit - deal.soldCount} left
              </span>
            </div>
            <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-gray-100">
              <div
                className={`h-full rounded-full transition-all ${
                  stockPercent > 80 ? 'bg-red-500' : stockPercent > 50 ? 'bg-amber-500' : 'bg-orange-500'
                }`}
                style={{ width: `${stockPercent}%` }}
              />
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
