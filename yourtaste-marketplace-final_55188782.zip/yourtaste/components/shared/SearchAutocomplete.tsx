'use client'

import { useState, useEffect, useRef } from 'react'
import { useRouter } from 'next/navigation'

interface Suggestion {
  query: string
  type: 'search' | 'product' | 'category'
}

export function SearchAutocomplete({ className }: { className?: string }) {
  const [query, setQuery] = useState('')
  const [suggestions, setSuggestions] = useState<Suggestion[]>([])
  const [open, setOpen] = useState(false)
  const [selected, setSelected] = useState(-1)
  const router = useRouter()
  const ref = useRef<HTMLDivElement>(null)
  const debounceRef = useRef<NodeJS.Timeout>()

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false)
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [])

  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current)
    if (query.length < 2) { setSuggestions([]); return }
    debounceRef.current = setTimeout(async () => {
      try {
        const res = await fetch(`/api/search/suggestions?q=${encodeURIComponent(query)}`)
        const data = await res.json()
        setSuggestions(data.suggestions || [])
        setOpen(true)
        setSelected(-1)
      } catch { /* ignore */ }
    }, 200)
  }, [query])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (query.trim()) {
      router.push(`/products?search=${encodeURIComponent(query)}`)
      setOpen(false)
    }
  }

  const handleSelect = (suggestion: Suggestion) => {
    setQuery(suggestion.query)
    setOpen(false)
    if (suggestion.type === 'category') {
      router.push(`/products?category=${encodeURIComponent(suggestion.query)}`)
    } else {
      router.push(`/products?search=${encodeURIComponent(suggestion.query)}`)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); setSelected(s => Math.min(s + 1, suggestions.length - 1)) }
    if (e.key === 'ArrowUp') { e.preventDefault(); setSelected(s => Math.max(s - 1, -1)) }
    if (e.key === 'Enter' && selected >= 0) { e.preventDefault(); handleSelect(suggestions[selected]) }
    if (e.key === 'Escape') setOpen(false)
  }

  return (
    <div ref={ref} className={`relative ${className || ''}`}>
      <form onSubmit={handleSubmit} className="flex">
        <input
          type="text"
          value={query}
          onChange={e => setQuery(e.target.value)}
          onFocus={() => suggestions.length > 0 && setOpen(true)}
          onKeyDown={handleKeyDown}
          placeholder="Search products, brands..."
          className="w-full rounded-l-lg border px-4 py-2.5 text-sm focus:border-orange-500 focus:outline-none focus:ring-1 focus:ring-orange-500"
        />
        <button type="submit" className="rounded-r-lg bg-orange-600 px-4 text-white hover:bg-orange-700">
          <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
        </button>
      </form>
      {open && suggestions.length > 0 && (
        <div className="absolute left-0 right-0 top-full z-50 mt-1 rounded-lg border bg-white py-1 shadow-lg">
          {suggestions.map((s, i) => (
            <button
              key={`${s.type}-${s.query}`}
              onClick={() => handleSelect(s)}
              className={`flex w-full items-center gap-2 px-4 py-2 text-left text-sm hover:bg-gray-50 ${i === selected ? 'bg-orange-50' : ''}`}
            >
              <svg className="h-4 w-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                {s.type === 'category' ? <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z" /> : <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />}
              </svg>
              <span>{s.query}</span>
              {s.type === 'category' && <span className="ml-auto rounded bg-gray-100 px-1.5 py-0.5 text-xs text-gray-500">Category</span>}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
