'use client'

import { useState } from 'react'
import { CreditCard, ChevronDown, ChevronUp } from 'lucide-react'

export function EmiCalculator({ priceCents }: { priceCents: number }) {
  const [expanded, setExpanded] = useState(false)
  const price = priceCents / 100
  const banks = [
    { name: 'HDFC Bank', months: [3, 6, 9, 12], rate: 13 },
    { name: 'ICICI Bank', months: [3, 6, 9, 12], rate: 13.5 },
    { name: 'SBI Card', months: [3, 6, 9, 12, 18, 24], rate: 14 },
  ]

  const calculateEmi = (principal: number, annualRate: number, months: number) => {
    const monthlyRate = annualRate / 12 / 100
    const emi = (principal * monthlyRate * Math.pow(1 + monthlyRate, months)) / (Math.pow(1 + monthlyRate, months) - 1)
    return Math.round(emi)
  }

  if (price < 1000) return null

  return (
    <div className="rounded-lg border p-4">
      <button onClick={() => setExpanded(!expanded)} className="flex w-full items-center justify-between">
        <div className="flex items-center gap-2">
          <CreditCard className="h-4 w-4 text-gray-600" />
          <span className="text-sm font-medium">EMI from ₹{calculateEmi(price, 13, 12).toLocaleString()}/month</span>
        </div>
        {expanded ? <ChevronUp className="h-4 w-4 text-gray-400" /> : <ChevronDown className="h-4 w-4 text-gray-400" />}
      </button>
      {expanded && (
        <div className="mt-4 space-y-4">
          {banks.map(bank => (
            <div key={bank.name}>
              <div className="text-xs font-medium text-gray-600 mb-2">{bank.name} ({bank.rate}% p.a.)</div>
              <div className="flex flex-wrap gap-2">
                {bank.months.map(m => (
                  <span key={m} className="rounded bg-gray-100 px-2 py-1 text-xs text-gray-700">
                    {m}m: ₹{calculateEmi(price, bank.rate, m).toLocaleString()}/mo
                  </span>
                ))}
              </div>
            </div>
          ))}
          <p className="text-xs text-gray-400">*EMI calculated at {banks[0].rate}% per annum. Actual rates may vary.</p>
        </div>
      )}
    </div>
  )
}
