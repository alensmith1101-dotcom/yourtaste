'use client'

import { useState, useEffect, useRef } from 'react'
import { Plus, Check, Heart } from 'lucide-react'

interface WishlistOption {
  id: string
  name: string
  isDefault: boolean
}

export function WishlistButton({ productId }: { productId: string }) {
  const [inWishlists, setInWishlists] = useState<Set<string>>(new Set())
  const [loading, setLoading] = useState(false)
  const [open, setOpen] = useState(false)
  const [wishlists, setWishlists] = useState<WishlistOption[]>([])
  const [showCreate, setShowCreate] = useState(false)
  const [newName, setNewName] = useState('')
  const dropdownRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    fetch('/api/wishlists')
      .then((res) => res.json())
      .then((data) => {
        if (data.success) {
          setWishlists(data.data.map((w: any) => ({ id: w.id, name: w.name, isDefault: w.isDefault })))
        }
      })
      .catch(console.error)
  }, [])

  useEffect(() => {
    async function checkWishlists() {
      try {
        const res = await fetch('/api/wishlists')
        const data = await res.json()
        if (data.success) {
          const ids = new Set<string>()
          for (const w of data.data) {
            const itemsRes = await fetch(`/api/wishlists/${w.id}/items`)
            const itemsData = await itemsRes.json()
            if (itemsData.success) {
              const found = itemsData.data.find((item: any) => item.productId === productId)
              if (found) ids.add(w.id)
            }
          }
          setInWishlists(ids)
        }
      } catch (err) {
        console.error('Failed to check wishlists:', err)
      }
    }
    checkWishlists()
  }, [productId])

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setOpen(false)
        setShowCreate(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  async function toggleInWishlist(wishlistId: string) {
    setLoading(true)
    try {
      if (inWishlists.has(wishlistId)) {
        await fetch(`/api/wishlists/${wishlistId}/items?productId=${productId}`, {
          method: 'DELETE',
        })
        setInWishlists((prev) => {
          const next = new Set(prev)
          next.delete(wishlistId)
          return next
        })
      } else {
        await fetch(`/api/wishlists/${wishlistId}/items`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ productId }),
        })
        setInWishlists((prev) => new Set(prev).add(wishlistId))
      }
    } catch (err) {
      console.error('Failed to update wishlist:', err)
    } finally {
      setLoading(false)
    }
  }

  async function createAndAdd() {
    if (!newName.trim()) return
    setLoading(true)
    try {
      const res = await fetch('/api/wishlists', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: newName.trim() }),
      })
      const data = await res.json()
      if (data.success) {
        const newId = data.data.id
        setWishlists((prev) => [...prev, { id: newId, name: newName.trim(), isDefault: false }])
        await fetch(`/api/wishlists/${newId}/items`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ productId }),
        })
        setInWishlists((prev) => new Set(prev).add(newId))
        setNewName('')
        setShowCreate(false)
      }
    } catch (err) {
      console.error('Failed to create wishlist:', err)
    } finally {
      setLoading(false)
    }
  }

  const isInAny = inWishlists.size > 0

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setOpen(!open)}
        disabled={loading}
        className={`inline-flex items-center gap-2 rounded-lg border px-4 py-2.5 text-sm font-medium transition-colors ${
          isInAny
            ? 'border-red-300 bg-red-50 text-red-600 hover:bg-red-100'
            : 'border-gray-300 bg-white text-gray-700 hover:bg-gray-50'
        }`}
      >
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill={isInAny ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
        </svg>
        {isInAny ? `In ${inWishlists.size} Wishlist${inWishlists.size > 1 ? 's' : ''}` : 'Add to Wishlist'}
      </button>

      {open && (
        <div className="absolute right-0 top-full z-50 mt-1 w-64 rounded-lg border bg-white shadow-lg">
          <div className="border-b px-3 py-2">
            <p className="text-xs font-medium text-gray-500">Add to wishlist</p>
          </div>
          <div className="max-h-48 overflow-y-auto p-1">
            {wishlists.map((w) => (
              <button
                key={w.id}
                onClick={() => toggleInWishlist(w.id)}
                disabled={loading}
                className="flex w-full items-center gap-2 rounded-md px-3 py-2 text-left text-sm hover:bg-gray-50"
              >
                {inWishlists.has(w.id) ? (
                  <Check className="h-4 w-4 text-orange-600" />
                ) : (
                  <Heart className="h-4 w-4 text-gray-400" />
                )}
                <span className="flex-1 truncate">{w.name}</span>
                {w.isDefault && (
                  <span className="text-[10px] text-gray-400">Default</span>
                )}
              </button>
            ))}
          </div>
          <div className="border-t p-1">
            {showCreate ? (
              <div className="flex items-center gap-1 px-2 py-1">
                <input
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && createAndAdd()}
                  placeholder="Wishlist name..."
                  className="h-8 flex-1 rounded border px-2 text-sm focus:outline-none focus:ring-1 focus:ring-orange-500"
                  autoFocus
                />
                <button
                  onClick={createAndAdd}
                  disabled={loading || !newName.trim()}
                  className="rounded p-1 text-green-600 hover:bg-green-50 disabled:opacity-50"
                >
                  <Check className="h-4 w-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => setShowCreate(true)}
                className="flex w-full items-center gap-2 rounded-md px-3 py-2 text-sm text-gray-600 hover:bg-gray-50"
              >
                <Plus className="h-4 w-4" />
                Create new wishlist
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
