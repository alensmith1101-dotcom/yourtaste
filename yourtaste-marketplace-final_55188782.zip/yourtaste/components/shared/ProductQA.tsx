'use client'

import { useState, useEffect, useCallback } from 'react'
import { Search, MessageCircle, ThumbsUp, Send, CheckCircle2, Loader2 } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { formatDate } from '@/lib/utils'

interface Answer {
  id: string
  answer: string
  isVendorAnswer: boolean
  upvotes: number
  createdAt: string
  user: { id: string; name: string | null }
}

interface Question {
  id: string
  question: string
  isAnswered: boolean
  createdAt: string
  user: { id: string; name: string | null }
  answers: Answer[]
}

interface ProductQAProps {
  productId: string
  initialQuestionCount?: number
}

export function ProductQA({ productId, initialQuestionCount = 0 }: ProductQAProps) {
  const [questions, setQuestions] = useState<Question[]>([])
  const [totalQuestions, setTotalQuestions] = useState(initialQuestionCount)
  const [search, setSearch] = useState('')
  const [newQuestion, setNewQuestion] = useState('')
  const [answerTexts, setAnswerTexts] = useState<Record<string, string>>({})
  const [showAnswerForm, setShowAnswerForm] = useState<Record<string, boolean>>({})
  const [loading, setLoading] = useState(false)
  const [submittingQuestion, setSubmittingQuestion] = useState(false)
  const [submittingAnswer, setSubmittingAnswer] = useState<Record<string, boolean>>({})
  const [page, setPage] = useState(1)
  const [hasMore, setHasMore] = useState(false)

  const fetchQuestions = useCallback(async (pageNum: number, searchQuery: string) => {
    setLoading(true)
    try {
      const params = new URLSearchParams({
        page: pageNum.toString(),
        limit: '10',
      })
      if (searchQuery) params.set('search', searchQuery)

      const res = await fetch(`/api/products/${productId}/questions?${params}`)
      const data = await res.json()

      if (data.success) {
        if (pageNum === 1) {
          setQuestions(data.data)
        } else {
          setQuestions(prev => [...prev, ...data.data])
        }
        setTotalQuestions(data.pagination.total)
        setHasMore(data.pagination.hasNext)
      }
    } catch (error) {
      console.error('Failed to fetch questions:', error)
    } finally {
      setLoading(false)
    }
  }, [productId])

  useEffect(() => {
    fetchQuestions(1, search)
  }, [search, fetchQuestions])

  const handleAskQuestion = async () => {
    if (!newQuestion.trim()) return

    setSubmittingQuestion(true)
    try {
      const res = await fetch(`/api/products/${productId}/questions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question: newQuestion.trim() }),
      })

      if (res.ok) {
        setNewQuestion('')
        fetchQuestions(1, search)
      }
    } catch (error) {
      console.error('Failed to submit question:', error)
    } finally {
      setSubmittingQuestion(false)
    }
  }

  const handleAnswer = async (questionId: string) => {
    const answerText = answerTexts[questionId]
    if (!answerText?.trim()) return

    setSubmittingAnswer(prev => ({ ...prev, [questionId]: true }))
    try {
      const res = await fetch(`/api/products/${productId}/questions/${questionId}/answers`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ answer: answerText.trim() }),
      })

      if (res.ok) {
        setAnswerTexts(prev => ({ ...prev, [questionId]: '' }))
        setShowAnswerForm(prev => ({ ...prev, [questionId]: false }))
        fetchQuestions(page, search)
      }
    } catch (error) {
      console.error('Failed to submit answer:', error)
    } finally {
      setSubmittingAnswer(prev => ({ ...prev, [questionId]: false }))
    }
  }

  const handleUpvote = async (questionId: string, answerId: string) => {
    try {
      const res = await fetch(`/api/products/${productId}/questions/${questionId}/answers`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ answerId }),
      })

      if (res.ok) {
        fetchQuestions(page, search)
      }
    } catch (error) {
      console.error('Failed to upvote answer:', error)
    }
  }

  const handleLoadMore = () => {
    const nextPage = page + 1
    setPage(nextPage)
    fetchQuestions(nextPage, search)
  }

  const handleSearchChange = (value: string) => {
    setSearch(value)
    setPage(1)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-900">
          Questions & Answers ({totalQuestions})
        </h3>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
        <Input
          placeholder="Search questions..."
          value={search}
          onChange={(e) => handleSearchChange(e.target.value)}
          className="pl-10"
        />
      </div>

      <Card>
        <CardContent className="p-4">
          <h4 className="mb-3 text-sm font-medium text-gray-700">Ask a Question</h4>
          <Textarea
            placeholder="What would you like to know about this product?"
            value={newQuestion}
            onChange={(e) => setNewQuestion(e.target.value)}
            rows={3}
            maxLength={1000}
          />
          <div className="mt-3 flex items-center justify-between">
            <span className="text-xs text-gray-500">{newQuestion.length}/1000</span>
            <Button
              onClick={handleAskQuestion}
              disabled={!newQuestion.trim() || submittingQuestion}
              size="sm"
            >
              {submittingQuestion ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Send className="mr-2 h-4 w-4" />
              )}
              Submit Question
            </Button>
          </div>
        </CardContent>
      </Card>

      {loading && questions.length === 0 ? (
        <div className="flex items-center justify-center py-8">
          <Loader2 className="h-6 w-6 animate-spin text-gray-400" />
        </div>
      ) : questions.length === 0 ? (
        <div className="py-8 text-center">
          <MessageCircle className="mx-auto h-12 w-12 text-gray-300" />
          <p className="mt-3 text-sm text-gray-500">
            {search ? 'No questions match your search.' : 'No questions yet. Be the first to ask!'}
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {questions.map((q) => (
            <Card key={q.id}>
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <MessageCircle className="mt-0.5 h-5 w-5 shrink-0 text-orange-600" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900">{q.question}</p>
                    <div className="mt-1 flex items-center gap-2 text-xs text-gray-500">
                      <span>{q.user.name || 'Anonymous'}</span>
                      <span>·</span>
                      <span>{formatDate(q.createdAt)}</span>
                      {q.isAnswered && (
                        <>
                          <span>·</span>
                          <Badge className="bg-green-100 text-green-700 hover:bg-green-100 text-xs">
                            <CheckCircle2 className="mr-1 h-3 w-3" />
                            Answered
                          </Badge>
                        </>
                      )}
                    </div>

                    {q.answers.length > 0 && (
                      <div className="mt-4 space-y-3 border-l-2 border-gray-100 pl-4">
                        <p className="text-xs font-medium text-gray-600">
                          {q.answers.length} {q.answers.length === 1 ? 'answer' : 'answers'}
                        </p>
                        {q.answers.map((a) => (
                          <div key={a.id} className="space-y-2">
                            <div className="flex items-start gap-2">
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2">
                                  <span className="text-sm font-medium text-gray-900">
                                    {a.user.name || 'Anonymous'}
                                  </span>
                                  {a.isVendorAnswer && (
                                    <Badge className="bg-orange-100 text-orange-700 hover:bg-orange-100 text-xs">
                                      Vendor
                                    </Badge>
                                  )}
                                </div>
                                <p className="mt-1 text-sm text-gray-600">{a.answer}</p>
                                <div className="mt-2 flex items-center gap-3">
                                  <button
                                    onClick={() => handleUpvote(q.id, a.id)}
                                    className="flex items-center gap-1 text-xs text-gray-500 hover:text-orange-600 transition-colors"
                                  >
                                    <ThumbsUp className="h-3.5 w-3.5" />
                                    <span>Helpful ({a.upvotes})</span>
                                  </button>
                                  <span className="text-xs text-gray-400">
                                    {formatDate(a.createdAt)}
                                  </span>
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    <div className="mt-3">
                      {showAnswerForm[q.id] ? (
                        <div className="space-y-2">
                          <Textarea
                            placeholder="Write your answer..."
                            value={answerTexts[q.id] || ''}
                            onChange={(e) =>
                              setAnswerTexts(prev => ({ ...prev, [q.id]: e.target.value }))
                            }
                            rows={2}
                            maxLength={2000}
                          />
                          <div className="flex items-center gap-2">
                            <Button
                              onClick={() => handleAnswer(q.id)}
                              disabled={!answerTexts[q.id]?.trim() || submittingAnswer[q.id]}
                              size="sm"
                            >
                              {submittingAnswer[q.id] ? (
                                <Loader2 className="mr-2 h-3 w-3 animate-spin" />
                              ) : (
                                <Send className="mr-2 h-3 w-3" />
                              )}
                              Submit
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                setShowAnswerForm(prev => ({ ...prev, [q.id]: false }))
                                setAnswerTexts(prev => ({ ...prev, [q.id]: '' }))
                              }}
                            >
                              Cancel
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <button
                          onClick={() => setShowAnswerForm(prev => ({ ...prev, [q.id]: true }))}
                          className="text-xs font-medium text-orange-600 hover:text-orange-700"
                        >
                          Answer this question
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}

          {hasMore && (
            <div className="flex justify-center pt-2">
              <Button variant="outline" onClick={handleLoadMore} disabled={loading}>
                {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                Load More Questions
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
