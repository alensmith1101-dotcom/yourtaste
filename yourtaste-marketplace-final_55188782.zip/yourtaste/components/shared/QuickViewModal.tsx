'use client'

import { useState } from 'react'
import Image from 'next/image'
import { X, ShoppingBag, Star } from 'lucide-react'
import toast from 'react-hot-toast'
import { formatPrice } from '@/lib/utils'

interface QuickViewModalProps {
  product: {
    id: string
    slug: string
    name: string
    priceCents: number
    originalPriceCents?: number | null
    images: string
    description?: string
    averageRating?: number
    totalReviews?: number
    vendor?: { name: string }
  }
  isOpen: boolean
  onClose: () => void
}

export function QuickViewModal({ product, isOpen, onClose }: QuickViewModalProps) {
  const [quantity, setQuantity] = useState(1)

  if (!isOpen) return null

  let images: string[] = []
  try {
    images = JSON.parse(product.images || '[]')
  } catch (err) {
    console.error('Failed to parse images:', err)
    images = []
  }
  const imageUrl = images[0] || '/placeholder-product.jpg'

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="relative w-full max-w-4xl rounded-2xl bg-white shadow-2xl">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 z-10 rounded-full bg-white/80 p-2 backdrop-blur-sm transition hover:bg-white"
        >
          <X className="h-5 w-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          {/* Image */}
          <div className="relative aspect-square overflow-hidden rounded-l-2xl bg-gray-100">
            <Image
              src={imageUrl}
              alt={product.name}
              fill
              className="object-cover"
            />
          </div>

          {/* Details */}
          <div className="flex flex-col p-6">
            {product.vendor && (
              <p className="text-sm text-orange-600">{product.vendor.name}</p>
            )}
            <h2 className="mt-1 text-2xl font-bold text-gray-900">{product.name}</h2>
            
            <div className="mt-2 flex items-center gap-2">
              <div className="flex items-center gap-1">
                <Star className="h-4 w-4 fill-amber-400 text-amber-400" />
                <span className="text-sm font-medium">{product.averageRating?.toFixed(1)}</span>
              </div>
              <span className="text-sm text-gray-500">({product.totalReviews} reviews)</span>
            </div>

            <div className="mt-4 flex items-baseline gap-2">
              <span className="text-3xl font-bold text-gray-900">
                {formatPrice(product.priceCents)}
              </span>
              {product.originalPriceCents && (
                <span className="text-lg text-gray-400 line-through">
                  {formatPrice(product.originalPriceCents)}
                </span>
              )}
            </div>

            {product.description && (
              <p className="mt-4 text-sm text-gray-600 line-clamp-4">
                {product.description}
              </p>
            )}

            <div className="mt-6 flex items-center gap-3">
              <div className="flex items-center rounded-lg border border-gray-300">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-3 py-2 text-gray-600 hover:bg-gray-50"
                >
                  -
                </button>
                <span className="px-4 py-2 text-sm font-medium">{quantity}</span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="px-3 py-2 text-gray-600 hover:bg-gray-50"
                >
                  +
                </button>
              </div>
            </div>

            <div className="mt-auto flex gap-3">
              <button
                onClick={async () => {
                  try {
                    const res = await fetch('/api/cart', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({ productId: product.id, quantity }),
                    })
                    if (!res.ok) throw new Error('Failed')
                    toast.success(`Added ${quantity} to cart`)
                    onClose()
                  } catch (err) {
                    console.error('Failed to add to cart:', err)
                    toast.error('Failed to add to cart')
                  }
                }}
                className="flex-1 rounded-lg bg-orange-600 px-6 py-3 text-sm font-semibold text-white transition hover:bg-orange-700"
              >
                Add to Cart
              </button>
              <a
                href={`/products/${product.slug}`}
                className="flex-1 rounded-lg border-2 border-gray-300 px-6 py-3 text-center text-sm font-semibold text-gray-700 transition hover:border-gray-400"
              >
                View Details
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
