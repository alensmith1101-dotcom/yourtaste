'use client'

import { useState, useEffect, useCallback } from 'react'
import { ChevronLeft, ChevronRight } from 'lucide-react'

const slides = [
  { title: 'Mega Electronics Sale', subtitle: 'Up to 70% off on smartphones, laptops & more', cta: 'Shop Now', link: '/products?category=electronics', bg: 'from-orange-600 to-red-600' },
  { title: 'Fashion Fiesta', subtitle: 'New arrivals starting ₹299. Free shipping on orders above ₹499', cta: 'Explore', link: '/products?category=fashion', bg: 'from-purple-600 to-pink-600' },
  { title: 'Home Makeover', subtitle: 'Furniture, decor & kitchen essentials at best prices', cta: 'Discover', link: '/products?category=home-kitchen', bg: 'from-teal-600 to-cyan-600' },
  { title: 'New User Welcome', subtitle: 'Flat 10% off on your first order. Use code WELCOME10', cta: 'Start Shopping', link: '/products', bg: 'from-amber-600 to-orange-600' },
]

export function HeroCarousel() {
  const [current, setCurrent] = useState(0)

  const next = useCallback(() => setCurrent(i => (i + 1) % slides.length), [])
  const prev = useCallback(() => setCurrent(i => (i - 1 + slides.length) % slides.length), [])

  useEffect(() => {
    const timer = setInterval(next, 5000)
    return () => clearInterval(timer)
  }, [next])

  return (
    <div className="relative overflow-hidden rounded-2xl">
      <div className="relative h-48 sm:h-64 md:h-80">
        {slides.map((slide, i) => (
          <div
            key={i}
            className={`absolute inset-0 flex items-center justify-center bg-gradient-to-r ${slide.bg} transition-all duration-500 ${
              i === current ? 'opacity-100 translate-x-0' : i < current ? 'opacity-0 -translate-x-full' : 'opacity-0 translate-x-full'
            }`}
          >
            <div className="text-center text-white px-6">
              <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-2 sm:mb-3">{slide.title}</h2>
              <p className="text-sm sm:text-base md:text-lg opacity-90 mb-4 sm:mb-6 max-w-lg mx-auto">{slide.subtitle}</p>
              <a href={slide.link} className="inline-block rounded-full bg-white px-6 py-2.5 text-sm font-semibold text-gray-900 hover:bg-gray-100 transition-colors">
                {slide.cta} →
              </a>
            </div>
          </div>
        ))}
      </div>

      <button onClick={prev} className="absolute left-3 top-1/2 -translate-y-1/2 rounded-full bg-white/30 p-2 text-white backdrop-blur-sm hover:bg-white/50 transition-colors">
        <ChevronLeft className="h-5 w-5" />
      </button>
      <button onClick={next} className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full bg-white/30 p-2 text-white backdrop-blur-sm hover:bg-white/50 transition-colors">
        <ChevronRight className="h-5 w-5" />
      </button>

      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
        {slides.map((_, i) => (
          <button key={i} onClick={() => setCurrent(i)} className={`h-2 rounded-full transition-all ${i === current ? 'w-6 bg-white' : 'w-2 bg-white/50'}`} />
        ))}
      </div>
    </div>
  )
}
