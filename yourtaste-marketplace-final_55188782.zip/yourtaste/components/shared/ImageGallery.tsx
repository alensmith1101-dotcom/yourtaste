'use client'

import { useState } from 'react'
import Image from 'next/image'
import { X, ChevronLeft, ChevronRight, ZoomIn } from 'lucide-react'

interface ImageGalleryProps {
  images: string[]
  productName: string
}

export function ImageGallery({ images, productName }: ImageGalleryProps) {
  const [selectedIdx, setSelectedIdx] = useState(0)
  const [lightbox, setLightbox] = useState(false)
  const [hoverZoom, setHoverZoom] = useState(false)
  const [mousePos, setMousePos] = useState({ x: 50, y: 50 })

  const handlePrev = () => setSelectedIdx(i => (i > 0 ? i - 1 : images.length - 1))
  const handleNext = () => setSelectedIdx(i => (i < images.length - 1 ? i + 1 : 0))

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect()
    const x = ((e.clientX - rect.left) / rect.width) * 100
    const y = ((e.clientY - rect.top) / rect.height) * 100
    setMousePos({ x, y })
  }

  if (images.length === 0) {
    return (
      <div className="aspect-square rounded-xl bg-gray-100 flex items-center justify-center">
        <span className="text-gray-400">No images</span>
      </div>
    )
  }

  return (
    <>
      <div className="flex gap-3">
        {images.length > 1 && (
          <div className="hidden sm:flex flex-col gap-2">
            {images.map((img, i) => (
              <button
                key={i}
                onClick={() => setSelectedIdx(i)}
                className={`relative h-16 w-16 shrink-0 overflow-hidden rounded-lg border-2 transition-all ${
                  i === selectedIdx ? 'border-orange-500 ring-2 ring-orange-200' : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <Image src={img} alt={`${productName} ${i + 1}`} fill className="object-cover" sizes="64px" />
              </button>
            ))}
          </div>
        )}

        <div className="flex-1 relative">
          <div
            className="relative aspect-square overflow-hidden rounded-xl bg-gray-100 cursor-zoom-in"
            onMouseEnter={() => setHoverZoom(true)}
            onMouseLeave={() => setHoverZoom(false)}
            onMouseMove={handleMouseMove}
            onClick={() => setLightbox(true)}
          >
            <Image
              src={images[selectedIdx]}
              alt={productName}
              fill
              className={`object-contain transition-transform duration-200 ${hoverZoom ? 'scale-150' : 'scale-100'}`}
              style={hoverZoom ? { transformOrigin: `${mousePos.x}% ${mousePos.y}%` } : undefined}
              sizes="(max-width: 768px) 100vw, 500px"
              priority
            />
            <div className="absolute bottom-3 right-3 flex items-center gap-1 rounded-full bg-black/50 px-2 py-1 text-xs text-white backdrop-blur-sm">
              <ZoomIn className="h-3 w-3" /> Click to zoom
            </div>
          </div>

          {images.length > 1 && (
            <>
              <button onClick={handlePrev} className="absolute left-2 top-1/2 -translate-y-1/2 rounded-full bg-white/90 p-1.5 shadow-md hover:bg-white transition-colors">
                <ChevronLeft className="h-5 w-5" />
              </button>
              <button onClick={handleNext} className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full bg-white/90 p-1.5 shadow-md hover:bg-white transition-colors">
                <ChevronRight className="h-5 w-5" />
              </button>
            </>
          )}

          <div className="absolute bottom-3 left-3 rounded-full bg-black/50 px-2.5 py-1 text-xs text-white backdrop-blur-sm">
            {selectedIdx + 1} / {images.length}
          </div>
        </div>
      </div>

      {lightbox && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90" onClick={() => setLightbox(false)}>
          <button onClick={() => setLightbox(false)} className="absolute right-4 top-4 rounded-full bg-white/20 p-2 text-white hover:bg-white/30">
            <X className="h-6 w-6" />
          </button>
          {images.length > 1 && (
            <>
              <button onClick={e => { e.stopPropagation(); handlePrev() }} className="absolute left-4 rounded-full bg-white/20 p-2 text-white hover:bg-white/30">
                <ChevronLeft className="h-6 w-6" />
              </button>
              <button onClick={e => { e.stopPropagation(); handleNext() }} className="absolute right-4 rounded-full bg-white/20 p-2 text-white hover:bg-white/30">
                <ChevronRight className="h-6 w-6" />
              </button>
            </>
          )}
          <div className="relative h-[80vh] w-[80vw]" onClick={e => e.stopPropagation()}>
            <Image src={images[selectedIdx]} alt={productName} fill className="object-contain" sizes="80vw" />
          </div>
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 rounded-full bg-white/20 px-3 py-1 text-sm text-white backdrop-blur-sm">
            {selectedIdx + 1} / {images.length}
          </div>
        </div>
      )}
    </>
  )
}
