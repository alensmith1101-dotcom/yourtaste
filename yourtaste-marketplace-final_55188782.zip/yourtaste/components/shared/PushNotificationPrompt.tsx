'use client'

import { useState, useEffect, useCallback } from 'react'
import { Bell, X } from 'lucide-react'
import { useSession } from 'next-auth/react'

function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4)
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/')
  const rawData = window.atob(base64)
  const outputArray = new Uint8Array(rawData.length)
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i)
  }
  return outputArray
}

export function PushNotificationPrompt() {
  const { data: session } = useSession()
  const [showPrompt, setShowPrompt] = useState(false)
  const [permission, setPermission] = useState<NotificationPermission | null>(null)

  useEffect(() => {
    if (!session?.user) return
    if (!('Notification' in window) || !('serviceWorker' in navigator)) return

    setPermission(Notification.permission)

    const dismissed = localStorage.getItem('push-notification-dismissed')
    if (dismissed) {
      const dismissedAt = parseInt(dismissed, 10)
      if (Date.now() - dismissedAt < 7 * 24 * 60 * 60 * 1000) return
    }

    if (Notification.permission === 'default') {
      const timer = setTimeout(() => setShowPrompt(true), 5000)
      return () => clearTimeout(timer)
    }
  }, [session])

  const subscribeToPush = useCallback(async () => {
    if (!session?.user) return

    try {
      const permissionResult = await Notification.requestPermission()
      setPermission(permissionResult)

      if (permissionResult !== 'granted') {
        setShowPrompt(false)
        return
      }

      const registration = await navigator.serviceWorker.ready
      const vapidPublicKey = process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY
      if (!vapidPublicKey) return

      const subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(vapidPublicKey) as BufferSource,
      })

      await fetch('/api/notifications/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ subscription: subscription.toJSON() }),
      })

      setShowPrompt(false)
    } catch (err) {
      console.error('Failed to subscribe to push notifications:', err)
    }
  }, [session])

  const dismissPrompt = useCallback(() => {
    setShowPrompt(false)
    localStorage.setItem('push-notification-dismissed', Date.now().toString())
  }, [])

  if (!showPrompt || !session?.user) return null

  return (
    <div className="fixed bottom-4 right-4 z-50 max-w-sm animate-in slide-in-from-bottom-4 fade-in duration-300">
      <div className="rounded-lg border border-orange-200 bg-white p-4 shadow-lg dark:border-orange-800 dark:bg-gray-900">
        <div className="flex items-start gap-3">
          <div className="flex-shrink-0 rounded-full bg-orange-100 p-2 dark:bg-orange-900/30">
            <Bell className="h-5 w-5 text-orange-600 dark:text-orange-400" />
          </div>
          <div className="flex-1">
            <h3 className="text-sm font-semibold text-gray-900 dark:text-gray-100">
              Stay Updated
            </h3>
            <p className="mt-1 text-xs text-gray-600 dark:text-gray-400">
              Get instant notifications for order updates, price drops, and exclusive deals.
            </p>
            <div className="mt-3 flex gap-2">
              <button
                onClick={subscribeToPush}
                className="rounded-md bg-orange-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-orange-700 transition-colors"
              >
                Enable Notifications
              </button>
              <button
                onClick={dismissPrompt}
                className="rounded-md px-3 py-1.5 text-xs font-medium text-gray-600 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-800 transition-colors"
              >
                Not now
              </button>
            </div>
          </div>
          <button
            onClick={dismissPrompt}
            className="flex-shrink-0 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  )
}
