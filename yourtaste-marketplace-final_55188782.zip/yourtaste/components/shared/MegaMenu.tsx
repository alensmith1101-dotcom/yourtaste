'use client'

import { useState, useRef, useEffect } from 'react'
import Link from 'next/link'
import { ChevronDown } from 'lucide-react'

const categories = [
  {
    name: 'Electronics',
    slug: 'electronics',
    icon: '📱',
    subcategories: ['Mobiles', 'Laptops', 'Tablets', 'Headphones', 'Cameras', 'Smart Watches'],
  },
  {
    name: 'Fashion',
    slug: 'fashion',
    icon: '👕',
    subcategories: ['Men', 'Women', 'Kids', 'Footwear', 'Accessories', 'Watches'],
  },
  {
    name: 'Home & Kitchen',
    slug: 'home-kitchen',
    icon: '🏠',
    subcategories: ['Furniture', 'Kitchen Appliances', 'Decor', 'Bedding', 'Storage', 'Lighting'],
  },
  {
    name: 'Beauty',
    slug: 'beauty',
    icon: '💄',
    subcategories: ['Skincare', 'Makeup', 'Haircare', 'Fragrances', 'Personal Care', 'Wellness'],
  },
  {
    name: 'Sports',
    slug: 'sports',
    icon: '⚽',
    subcategories: ['Fitness', 'Outdoor', 'Cycling', 'Swimming', 'Team Sports', 'Yoga'],
  },
  {
    name: 'Groceries',
    slug: 'groceries',
    icon: '🛒',
    subcategories: ['Fruits & Vegetables', 'Dairy', 'Snacks', 'Beverages', 'Staples', 'Personal Care'],
  },
]

export function MegaMenu() {
  const [open, setOpen] = useState(false)
  const timeoutRef = useRef<NodeJS.Timeout>()
  const menuRef = useRef<HTMLDivElement>(null)

  const handleMouseEnter = () => {
    if (timeoutRef.current) clearTimeout(timeoutRef.current)
    setOpen(true)
  }

  const handleMouseLeave = () => {
    timeoutRef.current = setTimeout(() => setOpen(false), 200)
  }

  return (
    <div ref={menuRef} className="relative" onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}>
      <button className="flex items-center gap-1 text-sm font-medium text-gray-700 hover:text-orange-600 transition-colors px-3 py-2 rounded-lg hover:bg-orange-50">
        Categories
        <ChevronDown className={`h-4 w-4 transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>

      {open && (
        <div className="absolute left-0 top-full z-50 mt-1 w-[800px] rounded-xl border bg-white shadow-xl">
          <div className="grid grid-cols-3 gap-0">
            {categories.map(cat => (
              <Link
                key={cat.slug}
                href={`/products?category=${cat.slug}`}
                className="group p-4 hover:bg-orange-50 border-b border-r border-gray-100 transition-colors"
              >
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-xl">{cat.icon}</span>
                  <span className="font-semibold text-sm text-gray-900 group-hover:text-orange-600">{cat.name}</span>
                </div>
                <div className="space-y-1">
                  {cat.subcategories.map(sub => (
                    <div key={sub} className="text-xs text-gray-500 group-hover:text-orange-600 transition-colors">
                      {sub}
                    </div>
                  ))}
                </div>
              </Link>
            ))}
          </div>
          <div className="p-3 bg-gray-50 rounded-b-xl border-t flex items-center justify-between">
            <span className="text-xs text-gray-500">Explore all categories</span>
            <Link href="/products" className="text-xs font-semibold text-orange-600 hover:text-orange-700">
              View All Products →
            </Link>
          </div>
        </div>
      )}
    </div>
  )
}
