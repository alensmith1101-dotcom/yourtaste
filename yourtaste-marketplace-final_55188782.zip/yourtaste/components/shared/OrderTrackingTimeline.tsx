'use client'

import { useState } from 'react'
import {
  ShoppingCart,
  CheckCircle,
  Package,
  Truck,
  MapPin,
  Home,
  Copy,
  Check,
  ChevronDown,
  ChevronUp,
  Phone,
  AlertTriangle,
  Clock,
  Navigation,
} from 'lucide-react'

interface TrackingStep {
  status: string
  label: string
  timestamp: string | null
  description: string | null
  location: string | null
}

interface StatusHistoryEntry {
  fromStatus: string
  toStatus: string
  createdAt: string
}

interface ShippingAddress {
  fullName?: string
  street?: string
  city?: string
  state?: string
  zipCode?: string
  phone?: string
}

interface OrderTrackingTimelineProps {
  steps: TrackingStep[]
  currentStatus: string
  trackingNumber: string | null
  shippingCarrier: string | null
  estimatedDelivery: string | null
  deliveredAt: string | null
  shippingAddress: ShippingAddress | null
  createdAt: string
  statusHistory: StatusHistoryEntry[]
  deliveryAttempts?: number
}

const STEP_ICONS: Record<string, React.ElementType> = {
  PENDING: ShoppingCart,
  CONFIRMED: CheckCircle,
  PROCESSING: Package,
  SHIPPED: Truck,
  OUT_FOR_DELIVERY: Navigation,
  DELIVERED: Home,
}

const CARRIER_LOGOS: Record<string, string> = {
  FedEx: '🟣',
  UPS: '🟤',
  USPS: '🔵',
  DHL: '🟡',
  'Blue Dart': '🔷',
  Delhivery: '🟠',
  'India Post': '🟢',
}

function formatTimestamp(date: string | Date): string {
  const d = new Date(date)
  return d.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  }) + ' at ' + d.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
  })
}

function formatEstimatedDate(date: string | Date): string {
  const d = new Date(date)
  return d.toLocaleDateString('en-US', {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
  })
}

function isDeliveryDelayed(estimatedDelivery: string | null, currentStatus: string): boolean {
  if (!estimatedDelivery || currentStatus === 'DELIVERED') return false
  return new Date() > new Date(estimatedDelivery)
}

export function OrderTrackingTimeline({
  steps,
  currentStatus,
  trackingNumber,
  shippingCarrier,
  estimatedDelivery,
  deliveredAt,
  shippingAddress,
  createdAt,
  statusHistory,
  deliveryAttempts = 0,
}: OrderTrackingTimelineProps) {
  const [copied, setCopied] = useState(false)
  const [showDetails, setShowDetails] = useState(false)

  const currentStepIndex = steps.findIndex((s) => s.status === currentStatus)
  const delayed = isDeliveryDelayed(estimatedDelivery, currentStatus)

  const copyTracking = async () => {
    if (!trackingNumber) return
    try {
      await navigator.clipboard.writeText(trackingNumber)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch {
      const el = document.createElement('textarea')
      el.value = trackingNumber
      document.body.appendChild(el)
      el.select()
      document.execCommand('copy')
      document.body.removeChild(el)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const getStepTimestamp = (status: string): string | null => {
    const step = steps.find((s) => s.status === status)
    if (step?.timestamp) return step.timestamp

    const historyEntry = statusHistory.find((h) => h.toStatus === status)
    if (historyEntry) return historyEntry.createdAt

    if (status === 'PENDING') return createdAt

    return null
  }

  return (
    <div className="space-y-6">
      <div className="rounded-lg border bg-white p-6">
        <div className="mb-6 flex items-center justify-between">
          <h3 className="text-lg font-semibold text-gray-900">
            Order Tracking
          </h3>
          {estimatedDelivery && currentStatus !== 'DELIVERED' && (
            <div className={`flex items-center gap-2 rounded-full px-3 py-1.5 text-sm font-medium ${delayed ? 'bg-red-50 text-red-700' : 'bg-green-50 text-green-700'}`}>
              <Clock className="h-4 w-4" />
              <span>
                {delayed ? 'Delayed' : 'Est. delivery: '}
                {!delayed && formatEstimatedDate(estimatedDelivery)}
              </span>
            </div>
          )}
        </div>

        <div className="relative">
          {steps.map((step, i) => {
            const Icon = STEP_ICONS[step.status] || Package
            const isCompleted = i < currentStepIndex || currentStatus === 'DELIVERED' && i <= currentStepIndex
            const isCurrent = i === currentStepIndex && currentStatus !== 'DELIVERED'
            const isPending = i > currentStepIndex
            const timestamp = getStepTimestamp(step.status)

            return (
              <div key={step.status} className="relative flex gap-4 pb-8 last:pb-0">
                {i < steps.length - 1 && (
                  <div
                    className={`absolute left-5 top-10 h-[calc(100%-2.5rem)] w-0.5 ${
                      isCompleted ? 'bg-green-400' : 'bg-gray-200'
                    }`}
                  />
                )}

                <div className={`relative z-10 flex h-10 w-10 shrink-0 items-center justify-center rounded-full border-2 ${
                  isCompleted
                    ? 'border-green-500 bg-green-500 text-white'
                    : isCurrent
                    ? 'border-orange-500 bg-orange-500 text-white ring-4 ring-orange-100'
                    : 'border-gray-200 bg-white text-gray-400'
                }`}>
                  <Icon className="h-5 w-5" />
                </div>

                <div className="flex-1 pt-1">
                  <div className="flex items-center justify-between">
                    <p className={`text-sm font-semibold ${
                      isCompleted
                        ? 'text-green-700'
                        : isCurrent
                        ? 'text-orange-700'
                        : 'text-gray-400'
                    }`}>
                      {step.label}
                    </p>
                    {isCurrent && (
                      <span className="rounded-full bg-orange-100 px-2 py-0.5 text-xs font-medium text-orange-700">
                        Current
                      </span>
                    )}
                    {isCompleted && !isCurrent && (
                      <span className="rounded-full bg-green-100 px-2 py-0.5 text-xs font-medium text-green-700">
                        Complete
                      </span>
                    )}
                  </div>

                  {timestamp && (
                    <p className={`mt-0.5 text-xs ${isPending ? 'text-gray-300' : 'text-gray-500'}`}>
                      {formatTimestamp(timestamp)}
                    </p>
                  )}

                  {step.description && (isCompleted || isCurrent) && (
                    <p className="mt-1 text-sm text-gray-600">
                      {step.description}
                    </p>
                  )}

                  {step.location && (isCompleted || isCurrent) && (
                    <p className="mt-0.5 flex items-center gap-1 text-xs text-gray-500">
                      <MapPin className="h-3 w-3" />
                      {step.location}
                    </p>
                  )}

                  {step.status === 'SHIPPED' && trackingNumber && (isCompleted || isCurrent) && (
                    <div className="mt-2 flex items-center gap-2 rounded-md bg-gray-50 px-3 py-2">
                      <Truck className="h-4 w-4 text-gray-500" />
                      <div className="flex-1">
                        <p className="text-xs text-gray-500">Tracking Number</p>
                        <p className="font-mono text-sm font-medium text-gray-900">
                          {trackingNumber}
                        </p>
                      </div>
                      <button
                        onClick={copyTracking}
                        className="flex items-center gap-1 rounded-md border border-gray-200 bg-white px-2 py-1 text-xs font-medium text-gray-600 transition-colors hover:bg-gray-50"
                      >
                        {copied ? (
                          <>
                            <Check className="h-3 w-3 text-green-500" />
                            <span className="text-green-600">Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy className="h-3 w-3" />
                            <span>Copy</span>
                          </>
                        )}
                      </button>
                    </div>
                  )}

                  {step.status === 'SHIPPED' && shippingCarrier && (isCompleted || isCurrent) && (
                    <div className="mt-2 flex items-center gap-2 text-sm text-gray-600">
                      <span className="text-base">{CARRIER_LOGOS[shippingCarrier] || '📦'}</span>
                      <span>Shipped via <span className="font-medium text-gray-900">{shippingCarrier}</span></span>
                    </div>
                  )}

                  {step.status === 'OUT_FOR_DELIVERY' && isCurrent && (
                    <div className="mt-3 overflow-hidden rounded-lg border border-gray-200">
                      <div className="flex h-32 items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-50">
                        <div className="text-center">
                          <Navigation className="mx-auto h-8 w-8 text-blue-400" />
                          <p className="mt-1 text-sm font-medium text-blue-600">
                            Package is out for delivery
                          </p>
                          <p className="text-xs text-blue-400">
                            Live tracking map coming soon
                          </p>
                        </div>
                      </div>
                    </div>
                  )}

                  {step.status === 'DELIVERED' && isCompleted && shippingAddress && (
                    <div className="mt-2 flex items-start gap-2 rounded-md bg-green-50 px-3 py-2">
                      <Home className="mt-0.5 h-4 w-4 text-green-600" />
                      <div>
                        <p className="text-xs text-green-600">Delivered to</p>
                        <p className="text-sm text-green-800">
                          {shippingAddress.fullName}
                        </p>
                        <p className="text-xs text-green-600">
                          {shippingAddress.street}, {shippingAddress.city}, {shippingAddress.state} {shippingAddress.zipCode}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {delayed && currentStatus !== 'DELIVERED' && (
        <div className="rounded-lg border border-red-200 bg-red-50 p-4">
          <div className="flex items-start gap-3">
            <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-red-500" />
            <div className="flex-1">
              <p className="text-sm font-semibold text-red-800">
                Delivery Delayed
              </p>
              <p className="mt-1 text-sm text-red-700">
                Your package was expected by {estimatedDelivery && formatEstimatedDate(estimatedDelivery)} but hasn&apos;t been delivered yet.
                {deliveryAttempts > 0 && (
                  <span className="mt-1 block">
                    Delivery attempts: {deliveryAttempts}
                  </span>
                )}
              </p>
              <button
                onClick={() => window.open('/support', '_blank')}
                className="mt-3 inline-flex items-center gap-2 rounded-md bg-red-600 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-red-700"
              >
                <Phone className="h-4 w-4" />
                Contact Support
              </button>
            </div>
          </div>
        </div>
      )}

      {deliveryAttempts > 0 && currentStatus !== 'DELIVERED' && !delayed && (
        <div className="rounded-lg border border-yellow-200 bg-yellow-50 p-4">
          <div className="flex items-center gap-3">
            <AlertTriangle className="h-5 w-5 text-yellow-600" />
            <div>
              <p className="text-sm font-semibold text-yellow-800">
                {deliveryAttempts} delivery attempt{deliveryAttempts > 1 ? 's' : ''} made
              </p>
              <p className="mt-0.5 text-sm text-yellow-700">
                Please ensure someone is available to receive the package.
              </p>
            </div>
          </div>
        </div>
      )}

      <div className="rounded-lg border bg-white">
        <button
          onClick={() => setShowDetails(!showDetails)}
          className="flex w-full items-center justify-between p-4 text-left"
        >
          <span className="text-sm font-semibold text-gray-900">
            Tracking Details
          </span>
          {showDetails ? (
            <ChevronUp className="h-4 w-4 text-gray-500" />
          ) : (
            <ChevronDown className="h-4 w-4 text-gray-500" />
          )}
        </button>

        {showDetails && (
          <div className="border-t px-4 pb-4">
            {steps
              .filter((step) => step.description || step.location)
              .map((step, i) => (
                <div key={i} className="flex gap-3 py-3 border-b last:border-b-0">
                  <div className="mt-1 h-2 w-2 shrink-0 rounded-full bg-gray-300" />
                  <div>
                    <p className="text-sm font-medium text-gray-900">
                      {step.label}
                    </p>
                    {step.description && (
                      <p className="text-sm text-gray-600">{step.description}</p>
                    )}
                    {step.location && (
                      <p className="flex items-center gap-1 text-xs text-gray-500">
                        <MapPin className="h-3 w-3" />
                        {step.location}
                      </p>
                    )}
                    {step.timestamp && (
                      <p className="mt-0.5 text-xs text-gray-400">
                        {formatTimestamp(step.timestamp)}
                      </p>
                    )}
                  </div>
                </div>
              ))}

            {steps.every((s) => !s.description && !s.location) && (
              <p className="py-4 text-center text-sm text-gray-400">
                No detailed tracking updates yet
              </p>
            )}
          </div>
        )}
      </div>

      {shippingAddress && currentStatus !== 'DELIVERED' && (
        <div className="rounded-lg border bg-white p-4">
          <div className="flex items-center gap-2 mb-3">
            <MapPin className="h-4 w-4 text-orange-600" />
            <h4 className="text-sm font-semibold text-gray-900">
              Delivery Address
            </h4>
          </div>
          <div className="text-sm text-gray-600">
            <p className="font-medium text-gray-900">{shippingAddress.fullName}</p>
            <p>{shippingAddress.street}</p>
            <p>
              {shippingAddress.city}, {shippingAddress.state} {shippingAddress.zipCode}
            </p>
            {shippingAddress.phone && (
              <p className="mt-1">{shippingAddress.phone}</p>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
