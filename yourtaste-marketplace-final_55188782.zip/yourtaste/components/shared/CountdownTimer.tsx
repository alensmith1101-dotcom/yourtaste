'use client'

import { useState, useEffect } from 'react'

interface CountdownTimerProps {
  targetDate: string
  compact?: boolean
  onExpire?: () => void
}

export function CountdownTimer({ targetDate, compact = false, onExpire }: CountdownTimerProps) {
  const [timeLeft, setTimeLeft] = useState({ hours: 0, minutes: 0, seconds: 0 })
  const [expired, setExpired] = useState(false)

  useEffect(() => {
    const target = new Date(targetDate).getTime()

    const tick = () => {
      const diff = target - Date.now()
      if (diff <= 0) {
        setTimeLeft({ hours: 0, minutes: 0, seconds: 0 })
        setExpired(true)
        onExpire?.()
        return
      }
      setTimeLeft({
        hours: Math.floor(diff / 3600000),
        minutes: Math.floor((diff % 3600000) / 60000),
        seconds: Math.floor((diff % 60000) / 1000),
      })
    }

    tick()
    const interval = setInterval(tick, 1000)
    return () => clearInterval(interval)
  }, [targetDate, onExpire])

  const pad = (n: number) => String(n).padStart(2, '0')

  if (expired) {
    return (
      <span className={`font-mono font-bold ${compact ? 'text-sm' : 'text-lg'} text-red-500`}>
        EXPIRED
      </span>
    )
  }

  if (compact) {
    return (
      <div className="flex items-center gap-0.5 font-mono text-sm font-bold">
        <span className="rounded bg-gray-900 px-1.5 py-0.5 text-white">{pad(timeLeft.hours)}</span>
        <span className="text-gray-400">:</span>
        <span className="rounded bg-gray-900 px-1.5 py-0.5 text-white">{pad(timeLeft.minutes)}</span>
        <span className="text-gray-400">:</span>
        <span className="rounded bg-gray-900 px-1.5 py-0.5 text-white">{pad(timeLeft.seconds)}</span>
      </div>
    )
  }

  return (
    <div className="flex items-center gap-1 font-mono text-lg font-bold">
      <div className="flex flex-col items-center">
        <span className="rounded-lg bg-gray-900 px-2.5 py-1.5 text-white">{pad(timeLeft.hours)}</span>
        <span className="mt-0.5 text-[10px] font-normal text-gray-400 uppercase">hrs</span>
      </div>
      <span className="text-gray-400 text-xl">:</span>
      <div className="flex flex-col items-center">
        <span className="rounded-lg bg-gray-900 px-2.5 py-1.5 text-white">{pad(timeLeft.minutes)}</span>
        <span className="mt-0.5 text-[10px] font-normal text-gray-400 uppercase">min</span>
      </div>
      <span className="text-gray-400 text-xl">:</span>
      <div className="flex flex-col items-center">
        <span className="rounded-lg bg-gray-900 px-2.5 py-1.5 text-white">{pad(timeLeft.seconds)}</span>
        <span className="mt-0.5 text-[10px] font-normal text-gray-400 uppercase">sec</span>
      </div>
    </div>
  )
}
