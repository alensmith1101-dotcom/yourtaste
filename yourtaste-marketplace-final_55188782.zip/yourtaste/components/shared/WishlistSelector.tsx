'use client'

import { useState, useEffect, useRef } from 'react'
import { Heart, Plus, ChevronDown, Check, Share2, Trash2, Edit2, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

interface Wishlist {
  id: string
  name: string
  isDefault: boolean
  shareToken: string | null
  itemCount: number
}

interface WishlistSelectorProps {
  selectedId?: string
  onSelect: (wishlist: Wishlist) => void
  onCreateNew?: (name: string) => void
  onRename?: (id: string, name: string) => void
  onDelete?: (id: string) => void
  onShare?: (id: string) => void
}

export function WishlistSelector({
  selectedId,
  onSelect,
  onCreateNew,
  onRename,
  onDelete,
  onShare,
}: WishlistSelectorProps) {
  const [wishlists, setWishlists] = useState<Wishlist[]>([])
  const [open, setOpen] = useState(false)
  const [showCreate, setShowCreate] = useState(false)
  const [newName, setNewName] = useState('')
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editName, setEditName] = useState('')
  const dropdownRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    fetch('/api/wishlists')
      .then((res) => res.json())
      .then((data) => {
        if (data.success) setWishlists(data.data)
      })
      .catch(console.error)
  }, [])

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setOpen(false)
        setShowCreate(false)
        setEditingId(null)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  async function handleCreate() {
    if (!newName.trim() || !onCreateNew) return
    onCreateNew(newName.trim())
    setNewName('')
    setShowCreate(false)
    const res = await fetch('/api/wishlists')
    const data = await res.json()
    if (data.success) setWishlists(data.data)
  }

  async function handleRename(id: string) {
    if (!editName.trim() || !onRename) return
    await onRename(id, editName.trim())
    setEditingId(null)
    setEditName('')
    const res = await fetch('/api/wishlists')
    const data = await res.json()
    if (data.success) setWishlists(data.data)
  }

  async function handleDelete(id: string) {
    if (!onDelete) return
    await onDelete(id)
    const res = await fetch('/api/wishlists')
    const data = await res.json()
    if (data.success) setWishlists(data.data)
  }

  const selected = wishlists.find((w) => w.id === selectedId)

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-2 rounded-lg border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
      >
        <Heart className="h-4 w-4" />
        <span className="max-w-[150px] truncate">{selected?.name || 'Select Wishlist'}</span>
        <ChevronDown className="h-4 w-4" />
      </button>

      {open && (
        <div className="absolute left-0 top-full z-50 mt-1 w-72 rounded-lg border bg-white shadow-lg">
          <div className="max-h-64 overflow-y-auto p-2">
            {wishlists.map((w) => (
              <div key={w.id} className="group">
                {editingId === w.id ? (
                  <div className="flex items-center gap-1 p-2">
                    <Input
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleRename(w.id)}
                      className="h-8 text-sm"
                      autoFocus
                    />
                    <button
                      onClick={() => handleRename(w.id)}
                      className="rounded p-1 text-green-600 hover:bg-green-50"
                    >
                      <Check className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => setEditingId(null)}
                      className="rounded p-1 text-gray-400 hover:bg-gray-100"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center gap-2 rounded-md px-2 py-2 hover:bg-gray-50">
                    <button
                      onClick={() => {
                        onSelect(w)
                        setOpen(false)
                      }}
                      className="flex flex-1 items-center gap-2 text-left"
                    >
                      {selectedId === w.id && <Check className="h-4 w-4 text-orange-600" />}
                      <span className="flex-1 truncate text-sm">{w.name}</span>
                      <span className="text-xs text-gray-400">{w.itemCount}</span>
                    </button>
                    <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100">
                      {onShare && (
                        <button
                          onClick={() => onShare(w.id)}
                          className="rounded p-1 text-gray-400 hover:bg-gray-100 hover:text-blue-600"
                          title="Share"
                        >
                          <Share2 className="h-3.5 w-3.5" />
                        </button>
                      )}
                      {onRename && (
                        <button
                          onClick={() => {
                            setEditingId(w.id)
                            setEditName(w.name)
                          }}
                          className="rounded p-1 text-gray-400 hover:bg-gray-100 hover:text-gray-600"
                          title="Rename"
                        >
                          <Edit2 className="h-3.5 w-3.5" />
                        </button>
                      )}
                      {onDelete && !w.isDefault && (
                        <button
                          onClick={() => handleDelete(w.id)}
                          className="rounded p-1 text-gray-400 hover:bg-red-50 hover:text-red-600"
                          title="Delete"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>

          {onCreateNew && (
            <div className="border-t p-2">
              {showCreate ? (
                <div className="flex items-center gap-1">
                  <Input
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleCreate()}
                    placeholder="Wishlist name..."
                    className="h-8 text-sm"
                    autoFocus
                  />
                  <button
                    onClick={handleCreate}
                    className="rounded p-1 text-green-600 hover:bg-green-50"
                  >
                    <Check className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => {
                      setShowCreate(false)
                      setNewName('')
                    }}
                    className="rounded p-1 text-gray-400 hover:bg-gray-100"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setShowCreate(true)}
                  className="flex w-full items-center gap-2 rounded-md px-2 py-2 text-sm text-gray-600 hover:bg-gray-50"
                >
                  <Plus className="h-4 w-4" />
                  Create new wishlist
                </button>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
