'use client'

import { useState } from 'react'
import toast from 'react-hot-toast'

export function AddAllToCartButton({ productIds }: { productIds: string[] }) {
  const [loading, setLoading] = useState(false)

  const handleAddAll = async () => {
    setLoading(true)
    try {
      for (const productId of productIds) {
        await fetch('/api/cart', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ productId, quantity: 1 }),
        })
      }
      toast.success(`${productIds.length} items added to cart!`)
    } catch (err) {
      console.error('Failed to add items to cart:', err)
      toast.error('Failed to add items to cart')
    } finally {
      setLoading(false)
    }
  }

  return (
    <button
      onClick={handleAddAll}
      disabled={loading}
      className="mt-2 rounded-lg bg-orange-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-orange-700 disabled:opacity-50"
    >
      {loading ? 'Adding...' : 'Add All to Cart'}
    </button>
  )
}
