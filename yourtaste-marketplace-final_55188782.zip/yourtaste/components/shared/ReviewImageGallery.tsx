'use client'

import { useState, useEffect, useCallback } from 'react'
import { X, ChevronLeft, ChevronRight } from 'lucide-react'

interface ReviewImageGalleryProps {
  images: { url: string }[]
  reviewerName?: string
}

export function ReviewImageGallery({ images, reviewerName }: ReviewImageGalleryProps) {
  const [lightbox, setLightbox] = useState<number | null>(null)

  const goNext = useCallback(() => {
    setLightbox(prev => (prev !== null ? (prev + 1) % images.length : null))
  }, [images.length])

  const goPrev = useCallback(() => {
    setLightbox(prev => (prev !== null ? (prev - 1 + images.length) % images.length : null))
  }, [images.length])

  useEffect(() => {
    if (lightbox === null) return
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setLightbox(null)
      if (e.key === 'ArrowRight') goNext()
      if (e.key === 'ArrowLeft') goPrev()
    }
    document.addEventListener('keydown', handler)
    document.body.style.overflow = 'hidden'
    return () => {
      document.removeEventListener('keydown', handler)
      document.body.style.overflow = ''
    }
  }, [lightbox, goNext, goPrev])

  if (images.length === 0) return null

  return (
    <>
      <div className="mt-3 flex flex-wrap gap-2">
        {images.map((img, idx) => (
          <button
            key={idx}
            type="button"
            onClick={() => setLightbox(idx)}
            className="group relative h-16 w-16 overflow-hidden rounded-md border border-gray-200 transition-all hover:border-orange-400 hover:shadow-md sm:h-20 sm:w-20"
          >
            <img
              src={img.url}
              alt={`Review photo ${idx + 1}`}
              className="h-full w-full object-cover transition-transform group-hover:scale-105"
            />
            {images.length > 4 && idx === 3 && (
              <div className="absolute inset-0 flex items-center justify-center bg-black/60 text-sm font-semibold text-white">
                +{images.length - 4}
              </div>
            )}
          </button>
        ))}
      </div>

      {lightbox !== null && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-sm"
          onClick={() => setLightbox(null)}
        >
          <button
            type="button"
            onClick={() => setLightbox(null)}
            className="absolute right-4 top-4 rounded-full bg-white/10 p-2 text-white transition hover:bg-white/20"
            aria-label="Close"
          >
            <X className="h-6 w-6" />
          </button>

          {images.length > 1 && (
            <>
              <button
                type="button"
                onClick={(e) => { e.stopPropagation(); goPrev() }}
                className="absolute left-4 rounded-full bg-white/10 p-3 text-white transition hover:bg-white/20"
                aria-label="Previous"
              >
                <ChevronLeft className="h-6 w-6" />
              </button>
              <button
                type="button"
                onClick={(e) => { e.stopPropagation(); goNext() }}
                className="absolute right-4 rounded-full bg-white/10 p-3 text-white transition hover:bg-white/20"
                aria-label="Next"
              >
                <ChevronRight className="h-6 w-6" />
              </button>
            </>
          )}

          <div className="max-h-[85vh] max-w-[90vw]" onClick={(e) => e.stopPropagation()}>
            <img
              src={images[lightbox].url}
              alt={reviewerName ? `Photo by ${reviewerName}` : 'Review photo'}
              className="max-h-[85vh] max-w-[90vw] rounded-lg object-contain"
            />
            <div className="mt-3 text-center text-sm text-white/70">
              {lightbox + 1} / {images.length}
              {reviewerName && <span className="ml-2">&middot; {reviewerName}</span>}
            </div>
          </div>
        </div>
      )}
    </>
  )
}
