'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { Sparkles, ChevronLeft, ChevronRight, ShoppingBag, Star } from 'lucide-react'
import { parseImages, formatPrice } from '@/lib/utils'

interface RecommendedProduct {
  id: string
  slug: string
  name: string
  priceCents: number
  originalPriceCents?: number | null
  images: string
  averageRating: number
  totalReviews: number
  vendor: { name: string; slug: string }
  reason: string
}

export function PersonalizedRecommendations() {
  const [products, setProducts] = useState<RecommendedProduct[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchRecommendations() {
      try {
        const res = await fetch('/api/recommendations/personalized')
        if (!res.ok) return
        const json = await res.json()
        if (json.success && json.data?.length > 0) {
          setProducts(json.data)
        }
      } catch {
      } finally {
        setLoading(false)
      }
    }

    fetchRecommendations()
  }, [])

  if (loading) {
    return (
      <section className="bg-white">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-violet-100">
              <Sparkles className="h-5 w-5 text-violet-600" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-gray-900 sm:text-3xl">
                Recommended For You
              </h2>
              <p className="mt-0.5 text-sm text-gray-600">Loading...</p>
            </div>
          </div>
          <div className="mt-10 flex gap-4 overflow-hidden">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="w-64 flex-shrink-0 animate-pulse">
                <div className="aspect-square rounded-xl bg-gray-200" />
                <div className="mt-3 h-4 w-3/4 rounded bg-gray-200" />
                <div className="mt-2 h-4 w-1/2 rounded bg-gray-200" />
              </div>
            ))}
          </div>
        </div>
      </section>
    )
  }

  if (products.length === 0) return null

  const handleScroll = (direction: 'left' | 'right') => {
    const el = document.getElementById('recommendations-scroll-container')
    if (!el) return
    const scrollAmount = 300
    el.scrollBy({
      left: direction === 'left' ? -scrollAmount : scrollAmount,
      behavior: 'smooth',
    })
  }

  return (
    <section className="bg-white">
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-violet-100">
              <Sparkles className="h-5 w-5 text-violet-600" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-gray-900 sm:text-3xl">
                Recommended For You
              </h2>
              <p className="mt-0.5 text-sm text-gray-600">
                Based on your browsing and purchase history
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => handleScroll('left')}
              className="rounded-full border border-gray-200 p-2 transition hover:bg-gray-50"
              aria-label="Scroll left"
            >
              <ChevronLeft className="h-4 w-4 text-gray-600" />
            </button>
            <button
              onClick={() => handleScroll('right')}
              className="rounded-full border border-gray-200 p-2 transition hover:bg-gray-50"
              aria-label="Scroll right"
            >
              <ChevronRight className="h-4 w-4 text-gray-600" />
            </button>
          </div>
        </div>

        <div
          id="recommendations-scroll-container"
          className="mt-10 flex gap-4 overflow-x-auto scroll-smooth pb-4 scrollbar-hide"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {products.map((product) => {
            const images = parseImages(product.images)
            const discount = product.originalPriceCents
              ? Math.round(
                  ((product.originalPriceCents - product.priceCents) /
                    product.originalPriceCents) *
                    100
                )
              : 0

            return (
              <Link
                key={product.id}
                href={`/products/${product.slug}`}
                className="group w-64 flex-shrink-0 overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-sm transition-all hover:shadow-lg"
              >
                <div className="relative aspect-square overflow-hidden bg-gray-100">
                  {images.length > 0 ? (
                    <Image
                      src={images[0]}
                      alt={product.name}
                      fill
                      sizes="256px"
                      className="object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center">
                      <ShoppingBag className="h-12 w-12 text-gray-300" />
                    </div>
                  )}
                  {discount > 0 && (
                    <span className="absolute left-3 top-3 rounded-full bg-red-500 px-2.5 py-0.5 text-xs font-semibold text-white">
                      -{discount}%
                    </span>
                  )}
                </div>
                <div className="p-4">
                  <p className="text-xs font-medium text-orange-600">
                    {product.vendor.name}
                  </p>
                  <h3 className="mt-1 line-clamp-1 text-sm font-semibold text-gray-900 group-hover:text-orange-600">
                    {product.name}
                  </h3>
                  <p className="mt-1.5 text-xs text-violet-600 italic">
                    {product.reason}
                  </p>
                  <div className="mt-2 flex items-center gap-1">
                    <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                    <span className="text-xs font-medium text-gray-700">
                      {product.averageRating.toFixed(1)}
                    </span>
                    <span className="text-xs text-gray-400">
                      ({product.totalReviews})
                    </span>
                  </div>
                  <div className="mt-3 flex items-baseline gap-2">
                    <span className="text-lg font-bold text-gray-900">
                      {formatPrice(product.priceCents)}
                    </span>
                    {product.originalPriceCents && (
                      <span className="text-sm text-gray-400 line-through">
                        {formatPrice(product.originalPriceCents)}
                      </span>
                    )}
                  </div>
                </div>
              </Link>
            )
          })}
        </div>
      </div>
    </section>
  )
}
