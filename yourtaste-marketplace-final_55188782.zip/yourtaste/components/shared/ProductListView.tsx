'use client'

import { ProductCard } from './ProductCard'

interface Product {
  id: string
  slug: string
  name: string
  description?: string | null
  priceCents: number
  originalPriceCents?: number | null
  images: string
  averageRating?: number | null
  totalReviews?: number
  vendor?: { name: string; slug: string } | null
}

interface ProductListViewProps {
  products: Product[]
}

export function ProductListView({ products }: ProductListViewProps) {
  return (
    <div className="flex flex-col gap-4" role="list" aria-label="Products in list view">
      {products.map((product) => (
        <div key={product.id} role="listitem">
          <ProductCard product={product} layout="list" />
        </div>
      ))}
    </div>
  )
}
