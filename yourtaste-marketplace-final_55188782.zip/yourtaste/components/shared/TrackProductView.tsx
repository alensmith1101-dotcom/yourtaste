'use client'

import { useEffect } from 'react'
import { addRecentlyViewed, type RecentlyViewedProduct } from '@/lib/recently-viewed'

interface TrackProductViewProps {
  product: RecentlyViewedProduct
}

export function TrackProductView({ product }: TrackProductViewProps) {
  useEffect(() => {
    addRecentlyViewed(product)
  }, [product])

  return null
}
