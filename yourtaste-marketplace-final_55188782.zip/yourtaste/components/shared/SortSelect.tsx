'use client'

import { Suspense } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'

function SortSelectInner({ defaultValue }: { defaultValue: string }) {
  const router = useRouter()
  const searchParams = useSearchParams()

  const handleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const params = new URLSearchParams(searchParams.toString())
    const val = e.target.value
    if (val === 'newest') {
      params.delete('sort')
    } else {
      params.set('sort', val)
    }
    params.delete('page')
    router.push(`/products?${params.toString()}`)
  }

  return (
    <select
      defaultValue={defaultValue}
      onChange={handleChange}
      className="rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:border-orange-500 focus:outline-none focus:ring-1 focus:ring-orange-500"
      aria-label="Sort products"
    >
      <option value="relevance">Relevance</option>
      <option value="price_asc">Price: Low to High</option>
      <option value="price_desc">Price: High to Low</option>
      <option value="newest">Newest</option>
      <option value="rating">Top Rated</option>
      <option value="popularity">Most Popular</option>
    </select>
  )
}

export function SortSelect({ defaultValue }: { defaultValue: string }) {
  return (
    <Suspense fallback={<select disabled className="rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm"><option>Loading...</option></select>}>
      <SortSelectInner defaultValue={defaultValue} />
    </Suspense>
  )
}
