'use client'

import { useState, useEffect } from 'react'

const languages = [
  { code: 'en', name: 'English', flag: '🇬🇧' },
  { code: 'hi', name: 'हिन्दी', flag: '🇮🇳' },
  { code: 'es', name: 'Español', flag: '🇪🇸' },
  { code: 'fr', name: 'Français', flag: '🇫🇷' },
  { code: 'ar', name: 'العربية', flag: '🇸🇦' },
]

export function LanguageSwitcher() {
  const [lang, setLang] = useState('en')
  const [open, setOpen] = useState(false)

  useEffect(() => {
    const saved = localStorage.getItem('yt-language')
    if (saved) setLang(saved)
  }, [])

  const handleSelect = (code: string) => {
    setLang(code)
    localStorage.setItem('yt-language', code)
    setOpen(false)
    document.documentElement.lang = code
    document.documentElement.dir = code === 'ar' ? 'rtl' : 'ltr'
    window.dispatchEvent(new CustomEvent('language-change', { detail: code }))
  }

  const current = languages.find(l => l.code === lang) || languages[0]

  return (
    <div className="relative">
      <button onClick={() => setOpen(!open)} className="flex items-center gap-1 rounded-lg border px-3 py-1.5 text-sm hover:bg-gray-50">
        <span>{current.flag}</span>
        <span className="hidden sm:inline">{current.name}</span>
        <svg className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
      </button>
      {open && (
        <div className="absolute right-0 top-full z-50 mt-1 w-40 rounded-lg border bg-white py-1 shadow-lg">
          {languages.map(l => (
            <button key={l.code} onClick={() => handleSelect(l.code)} className={`flex w-full items-center gap-2 px-4 py-2 text-sm hover:bg-gray-50 ${l.code === lang ? 'bg-orange-50 text-orange-700' : ''}`}>
              <span>{l.flag}</span>
              <span>{l.name}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
