'use client'

import { Suspense } from 'react'
import { useRouter, useSearchParams, usePathname } from 'next/navigation'
import { LayoutGrid, List, X, SlidersHorizontal, ArrowUpDown } from 'lucide-react'
import { Button } from '@/components/ui/button'

interface ActiveFilter {
  key: string
  label: string
  value: string
}

interface ProductToolbarProps {
  viewMode: 'grid' | 'list'
  onViewModeChange: (mode: 'grid' | 'list') => void
  activeFilters: ActiveFilter[]
  onClearFilter: (key: string) => void
  onClearAll: () => void
  sortValue: string
  totalProducts: number
}

const SORT_OPTIONS = [
  { label: 'Relevance', value: 'relevance' },
  { label: 'Price: Low to High', value: 'price_asc' },
  { label: 'Price: High to Low', value: 'price_desc' },
  { label: 'Newest', value: 'newest' },
  { label: 'Top Rated', value: 'rating' },
  { label: 'Most Popular', value: 'popularity' },
]

function ProductToolbarInner({
  viewMode,
  onViewModeChange,
  activeFilters,
  onClearFilter,
  onClearAll,
  sortValue,
  totalProducts,
}: ProductToolbarProps) {
  const router = useRouter()
  const pathname = usePathname()
  const searchParams = useSearchParams()

  const handleSortChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const params = new URLSearchParams(searchParams.toString())
    const val = e.target.value
    if (val === 'newest') {
      params.delete('sort')
    } else {
      params.set('sort', val)
    }
    params.delete('page')
    router.push(`${pathname}?${params.toString()}`)
  }

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-2">
          <ArrowUpDown className="h-4 w-4 text-gray-500" />
          <select
            value={sortValue}
            onChange={handleSortChange}
            className="rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:border-orange-500 focus:outline-none focus:ring-1 focus:ring-orange-500"
            aria-label="Sort products"
          >
            {SORT_OPTIONS.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.label}
              </option>
            ))}
          </select>
        </div>

        <div className="ml-auto flex items-center gap-1 rounded-lg border border-gray-200 bg-white p-1">
          <button
            onClick={() => onViewModeChange('grid')}
            className={`rounded-md p-2 transition-colors ${
              viewMode === 'grid'
                ? 'bg-orange-100 text-orange-700'
                : 'text-gray-500 hover:bg-gray-100'
            }`}
            aria-label="Grid view"
            aria-pressed={viewMode === 'grid'}
          >
            <LayoutGrid className="h-4 w-4" />
          </button>
          <button
            onClick={() => onViewModeChange('list')}
            className={`rounded-md p-2 transition-colors ${
              viewMode === 'list'
                ? 'bg-orange-100 text-orange-700'
                : 'text-gray-500 hover:bg-gray-100'
            }`}
            aria-label="List view"
            aria-pressed={viewMode === 'list'}
          >
            <List className="h-4 w-4" />
          </button>
        </div>
      </div>

      {activeFilters.length > 0 && (
        <div className="flex flex-wrap items-center gap-2">
          <SlidersHorizontal className="h-3.5 w-3.5 text-gray-500" />
          {activeFilters.map((filter) => (
            <span
              key={filter.key}
              className="inline-flex items-center gap-1 rounded-full bg-orange-50 px-3 py-1 text-xs font-medium text-orange-700 border border-orange-200"
            >
              {filter.label}
              <button
                onClick={() => onClearFilter(filter.key)}
                className="ml-0.5 rounded-full p-0.5 hover:bg-orange-200 transition-colors"
                aria-label={`Remove ${filter.label} filter`}
              >
                <X className="h-3 w-3" />
              </button>
            </span>
          ))}
          <Button
            variant="ghost"
            size="sm"
            onClick={onClearAll}
            className="text-xs text-gray-500 hover:text-gray-700 h-7"
          >
            Clear all
          </Button>
        </div>
      )}

      <p className="text-sm text-gray-500">
        {totalProducts} product{totalProducts !== 1 ? 's' : ''} found
      </p>
    </div>
  )
}

export function ProductToolbar(props: ProductToolbarProps) {
  return (
    <Suspense fallback={<div className="space-y-3"><div className="h-10 bg-gray-200 rounded animate-pulse"></div></div>}>
      <ProductToolbarInner {...props} />
    </Suspense>
  )
}
