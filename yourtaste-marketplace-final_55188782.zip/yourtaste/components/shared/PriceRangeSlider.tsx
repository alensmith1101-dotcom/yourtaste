'use client'

import { Suspense } from 'react'
import { useState, useEffect, useCallback, useRef } from 'react'
import { useRouter, useSearchParams, usePathname } from 'next/navigation'

interface PriceRangeSliderProps {
  min?: number
  max?: number
  defaultMin?: number
  defaultMax?: number
  currencySymbol?: string
  debounceMs?: number
}

function PriceRangeSliderInner({
  min = 0,
  max = 10000,
  defaultMin,
  defaultMax,
  currencySymbol = '₹',
  debounceMs = 400,
}: PriceRangeSliderProps) {
  const router = useRouter()
  const pathname = usePathname()
  const searchParams = useSearchParams()

  const [localMin, setLocalMin] = useState(defaultMin ?? min)
  const [localMax, setLocalMax] = useState(defaultMax ?? max)
  const [inputMin, setInputMin] = useState(defaultMin?.toString() ?? '')
  const [inputMax, setInputMax] = useState(defaultMax?.toString() ?? '')

  const debounceTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  const navigateWithPrices = useCallback(
    (newMin: number, newMax: number) => {
      const params = new URLSearchParams(searchParams.toString())
      if (newMin > min) {
        params.set('minPrice', newMin.toString())
      } else {
        params.delete('minPrice')
      }
      if (newMax < max) {
        params.set('maxPrice', newMax.toString())
      } else {
        params.delete('maxPrice')
      }
      params.delete('page')
      router.push(`${pathname}?${params.toString()}`)
    },
    [router, pathname, searchParams, min, max],
  )

  const debouncedNavigate = useCallback(
    (newMin: number, newMax: number) => {
      if (debounceTimer.current) clearTimeout(debounceTimer.current)
      debounceTimer.current = setTimeout(() => {
        navigateWithPrices(newMin, newMax)
      }, debounceMs)
    },
    [navigateWithPrices, debounceMs],
  )

  useEffect(() => {
    return () => {
      if (debounceTimer.current) clearTimeout(debounceTimer.current)
    }
  }, [])

  const handleSliderMin = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = Math.min(Number(e.target.value), localMax - 1)
    setLocalMin(val)
    setInputMin(val.toString())
    debouncedNavigate(val, localMax)
  }

  const handleSliderMax = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = Math.max(Number(e.target.value), localMin + 1)
    setLocalMax(val)
    setInputMax(val.toString())
    debouncedNavigate(localMin, val)
  }

  const handleInputMin = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value
    setInputMin(raw)
    const val = Math.max(min, Math.min(Number(raw) || min, localMax - 1))
    setLocalMin(val)
    debouncedNavigate(val, localMax)
  }

  const handleInputMax = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value
    setInputMax(raw)
    const val = Math.min(max, Math.max(Number(raw) || max, localMin + 1))
    setLocalMax(val)
    debouncedNavigate(localMin, val)
  }

  const leftPercent = ((localMin - min) / (max - min)) * 100
  const rightPercent = 100 - ((localMax - min) / (max - min)) * 100

  return (
    <div className="space-y-3" role="group" aria-label="Price range filter">
      <div className="relative h-2 rounded-full bg-gray-200">
        <div
          className="absolute h-full rounded-full bg-orange-500"
          style={{ left: `${leftPercent}%`, right: `${rightPercent}%` }}
        />
        <input
          type="range"
          min={min}
          max={max}
          value={localMin}
          onChange={handleSliderMin}
          className="pointer-events-none absolute inset-0 h-full w-full appearance-none bg-transparent [&::-webkit-slider-thumb]:pointer-events-auto [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-orange-500 [&::-webkit-slider-thumb]:shadow-md [&::-webkit-slider-thumb]:cursor-grab [&::-webkit-slider-thumb]:border-2 [&::-webkit-slider-thumb]:border-white [&::-moz-range-thumb]:pointer-events-auto [&::-moz-range-thumb]:h-4 [&::-moz-range-thumb]:w-4 [&::-moz-range-thumb]:appearance-none [&::-moz-range-thumb]:rounded-full [&::-moz-range-thumb]:bg-orange-500 [&::-moz-range-thumb]:shadow-md [&::-moz-range-thumb]:cursor-grab [&::-moz-range-thumb]:border-2 [&::-moz-range-thumb]:border-white"
          aria-label="Minimum price"
          aria-valuetext={`${currencySymbol}${localMin}`}
        />
        <input
          type="range"
          min={min}
          max={max}
          value={localMax}
          onChange={handleSliderMax}
          className="pointer-events-none absolute inset-0 h-full w-full appearance-none bg-transparent [&::-webkit-slider-thumb]:pointer-events-auto [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-orange-500 [&::-webkit-slider-thumb]:shadow-md [&::-webkit-slider-thumb]:cursor-grab [&::-webkit-slider-thumb]:border-2 [&::-webkit-slider-thumb]:border-white [&::-moz-range-thumb]:pointer-events-auto [&::-moz-range-thumb]:h-4 [&::-moz-range-thumb]:w-4 [&::-moz-range-thumb]:appearance-none [&::-moz-range-thumb]:rounded-full [&::-moz-range-thumb]:bg-orange-500 [&::-moz-range-thumb]:shadow-md [&::-moz-range-thumb]:cursor-grab [&::-moz-range-thumb]:border-2 [&::-moz-range-thumb]:border-white"
          aria-label="Maximum price"
          aria-valuetext={`${currencySymbol}${localMax}`}
        />
      </div>

      <div className="flex items-center gap-3">
        <div className="relative flex-1">
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-gray-400">
            {currencySymbol}
          </span>
          <input
            type="number"
            value={inputMin}
            onChange={handleInputMin}
            placeholder="Min"
            min={min}
            max={localMax - 1}
            className="h-9 w-full rounded-md border border-gray-300 bg-white pl-7 pr-2 text-sm focus:border-orange-500 focus:outline-none focus:ring-1 focus:ring-orange-500"
            aria-label="Minimum price input"
          />
        </div>
        <div className="h-px w-4 bg-gray-300" />
        <div className="relative flex-1">
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-gray-400">
            {currencySymbol}
          </span>
          <input
            type="number"
            value={inputMax}
            onChange={handleInputMax}
            placeholder="Max"
            min={localMin + 1}
            max={max}
            className="h-9 w-full rounded-md border border-gray-300 bg-white pl-7 pr-2 text-sm focus:border-orange-500 focus:outline-none focus:ring-1 focus:ring-orange-500"
            aria-label="Maximum price input"
          />
        </div>
      </div>
    </div>
  )
}

export function PriceRangeSlider(props: PriceRangeSliderProps) {
  return (
    <Suspense fallback={<div className="space-y-3"><div className="h-2 bg-gray-200 rounded animate-pulse"></div><div className="flex gap-3"><div className="h-9 flex-1 bg-gray-200 rounded animate-pulse"></div><div className="h-9 flex-1 bg-gray-200 rounded animate-pulse"></div></div></div>}>
      <PriceRangeSliderInner {...props} />
    </Suspense>
  )
}
