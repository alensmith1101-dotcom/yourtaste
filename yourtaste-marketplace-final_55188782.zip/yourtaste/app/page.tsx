export const dynamic = 'force-dynamic'

import Link from "next/link";
import Image from "next/image";
import {
  Search,
  ShoppingBag,
  Store,
  Truck,
  Star,
  ArrowRight,
  Utensils,
  Palette,
  Shirt,
  Home,
  Heart,
  Gem,
  TrendingUp,
  Users,
  Package,
  ChevronRight,
  Clock,
  Shield,
  Zap,
  Flame,
} from "lucide-react";
import { prisma } from "@/lib/prisma";
import { formatPrice } from "@/lib/utils";
import { HeroCarousel } from "@/components/shared/HeroCarousel";
import { RecentlyViewed } from "@/components/shared/RecentlyViewed";
import { PersonalizedRecommendations } from "@/components/shared/PersonalizedRecommendations";
import { DealCard } from "@/components/shared/DealCard";

const CATEGORIES = [
  { name: "Food & Gourmet", icon: Utensils, slug: "food-gourmet", color: "bg-orange-100 text-orange-600" },
  { name: "Art & Crafts", icon: Palette, slug: "art-crafts", color: "bg-purple-100 text-purple-600" },
  { name: "Fashion", icon: Shirt, slug: "fashion", color: "bg-pink-100 text-pink-600" },
  { name: "Home & Living", icon: Home, slug: "home-living", color: "bg-emerald-100 text-emerald-600" },
  { name: "Health & Beauty", icon: Heart, slug: "health-beauty", color: "bg-red-100 text-red-600" },
  { name: "Jewelry & Accessories", icon: Gem, slug: "jewelry-accessories", color: "bg-amber-100 text-amber-600" },
];

function parseImages(images: string): string[] {
  try {
    const parsed = JSON.parse(images);
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.error('Failed to parse images:', err)
    return [];
  }
}

export default async function HomePage() {
  const now = new Date();

  const [trendingProducts, vendors, stats, flashDeals] = await Promise.all([
    prisma.product.findMany({
      where: { isActive: true, isPublished: true },
      include: { vendor: { select: { name: true, slug: true } } },
      orderBy: { createdAt: "desc" },
      take: 8,
    }),
    prisma.vendor.findMany({
      where: { isApproved: true, isActive: true },
      orderBy: { rating: "desc" },
      take: 4,
    }),
    prisma.$transaction([
      prisma.product.count({ where: { isActive: true, isPublished: true } }),
      prisma.vendor.count({ where: { isApproved: true } }),
      prisma.order.count(),
    ]),
    prisma.deal.findMany({
      where: {
        isActive: true,
        startsAt: { lte: now },
        endsAt: { gte: now },
        product: { isActive: true, isPublished: true },
      },
      include: {
        product: {
          select: {
            id: true,
            name: true,
            slug: true,
            priceCents: true,
            images: true,
            vendor: { select: { name: true, slug: true } },
          },
        },
      },
      orderBy: { endsAt: "asc" },
      take: 4,
    }),
  ]);

  const [totalProducts, totalVendors, totalOrders] = stats;

  const enrichedDeals = flashDeals.map((deal) => ({
    ...deal,
    dealPrice: Math.round(deal.product.priceCents * (1 - deal.discountPercent / 100)),
    status: (() => {
      const hoursLeft = (deal.endsAt.getTime() - now.getTime()) / 3600000;
      if (deal.stockLimit > 0 && deal.soldCount >= deal.stockLimit) return 'SOLD_OUT';
      if (hoursLeft < 2) return 'ENDING_SOON';
      return 'ACTIVE';
    })(),
  }));



  return (
    <div className="flex flex-col">
      {/* Hero Banner Carousel */}
      <section className="relative overflow-hidden">
        <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
          <HeroCarousel />

          {/* Trust Badges */}
          <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
            <div className="flex items-center gap-2 rounded-lg border border-gray-200 bg-white px-4 py-3">
              <Truck className="h-5 w-5 text-orange-600" />
              <div>
                <p className="text-xs font-semibold text-gray-900">Free Shipping</p>
                <p className="text-xs text-gray-500">On orders $50+</p>
              </div>
            </div>
            <div className="flex items-center gap-2 rounded-lg border border-gray-200 bg-white px-4 py-3">
              <Shield className="h-5 w-5 text-orange-600" />
              <div>
                <p className="text-xs font-semibold text-gray-900">Secure Payment</p>
                <p className="text-xs text-gray-500">100% protected</p>
              </div>
            </div>
            <div className="flex items-center gap-2 rounded-lg border border-gray-200 bg-white px-4 py-3">
              <Clock className="h-5 w-5 text-orange-600" />
              <div>
                <p className="text-xs font-semibold text-gray-900">24/7 Support</p>
                <p className="text-xs text-gray-500">Always here</p>
              </div>
            </div>
            <div className="flex items-center gap-2 rounded-lg border border-gray-200 bg-white px-4 py-3">
              <Package className="h-5 w-5 text-orange-600" />
              <div>
                <p className="text-xs font-semibold text-gray-900">Easy Returns</p>
                <p className="text-xs text-gray-500">30-day policy</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Original Hero Section - Now Simplified */}
      <section className="relative overflow-hidden bg-gradient-to-br from-orange-50 via-white to-amber-50">
        <div className="absolute inset-0 bg-[url('/grid.svg')] bg-center [mask-image:linear-gradient(180deg,white,rgba(255,255,255,0))]" />
        <div className="relative mx-auto max-w-7xl px-4 py-24 sm:px-6 sm:py-32 lg:px-8 lg:py-40">
          <div className="mx-auto max-w-3xl text-center">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-orange-200 bg-orange-50 px-4 py-1.5 text-sm font-medium text-orange-700">
              <Truck className="h-4 w-4" />
              Free shipping on orders over $50
            </div>
            <h1 className="text-4xl font-bold tracking-tight text-gray-900 sm:text-5xl lg:text-6xl">
              Discover Unique Products from{" "}
              <span className="bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">
                Trusted Vendors
              </span>
            </h1>
            <p className="mt-6 text-lg leading-8 text-gray-600 sm:text-xl">
              YourTaste connects you with artisan creators and local businesses.
              Shop handcrafted goods, gourmet foods, fashion, and more — all in one marketplace.
            </p>

            <form action="/products" method="GET" className="mt-10 flex items-center gap-2 rounded-xl border border-gray-200 bg-white p-2 shadow-lg shadow-gray-200/50 sm:mx-auto sm:max-w-lg">
              <div className="flex flex-1 items-center gap-3 px-3">
                <Search className="h-5 w-5 shrink-0 text-gray-400" />
                <input
                  type="text"
                  name="search"
                  placeholder="Search products, vendors, categories..."
                  className="w-full border-0 bg-transparent text-sm text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-0"
                />
              </div>
              <button
                type="submit"
                className="shrink-0 rounded-lg bg-orange-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-offset-2"
              >
                Search
              </button>
            </form>

            <div className="mt-8 flex flex-wrap items-center justify-center gap-6 text-sm text-gray-500">
              <span className="flex items-center gap-1.5">
                <Package className="h-4 w-4 text-orange-500" />
                {totalProducts.toLocaleString()}+ Products
              </span>
              <span className="flex items-center gap-1.5">
                <Store className="h-4 w-4 text-orange-500" />
                {totalVendors.toLocaleString()}+ Vendors
              </span>
              <span className="flex items-center gap-1.5">
                <Truck className="h-4 w-4 text-orange-500" />
                Fast Delivery
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-gray-900 sm:text-3xl">
              Shop by Category
            </h2>
            <p className="mt-2 text-gray-600">
              Browse our curated collection of categories
            </p>
          </div>
          <Link
            href="/products"
            className="hidden items-center gap-1 text-sm font-medium text-orange-600 transition hover:text-orange-700 sm:flex"
          >
            View all <ArrowRight className="h-4 w-4" />
          </Link>
        </div>

        <div className="mt-10 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
          {CATEGORIES.map((category) => {
            const Icon = category.icon;
            return (
              <Link
                key={category.slug}
                href={`/products?category=${category.slug}`}
                className="group flex flex-col items-center gap-3 rounded-2xl border border-gray-100 bg-white p-6 text-center shadow-sm transition-all hover:border-orange-200 hover:shadow-md"
              >
                <div
                  className={`flex h-14 w-14 items-center justify-center rounded-xl ${category.color} transition-transform group-hover:scale-110`}
                >
                  <Icon className="h-7 w-7" />
                </div>
                <span className="text-sm font-medium text-gray-900">
                  {category.name}
                </span>
              </Link>
            );
          })}
        </div>
      </section>

      {/* Flash Deals Section */}
      {enrichedDeals.length > 0 && (
        <section className="bg-gradient-to-br from-red-50 via-orange-50 to-amber-50">
          <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-100">
                  <Zap className="h-5 w-5 text-red-600" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 sm:text-3xl">
                    Flash Deals
                  </h2>
                  <p className="mt-0.5 text-sm text-gray-600">
                    Grab them before they&apos;re gone!
                  </p>
                </div>
              </div>
              <Link
                href="/deals"
                className="flex items-center gap-1 text-sm font-medium text-orange-600 transition hover:text-orange-700"
              >
                View all <ChevronRight className="h-4 w-4" />
              </Link>
            </div>

            <div className="mt-10 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {enrichedDeals.map((deal) => (
                <DealCard key={deal.id} deal={deal} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Trending Products */}
      <section className="bg-gray-50">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-100">
                <TrendingUp className="h-5 w-5 text-orange-600" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-gray-900 sm:text-3xl">
                  Trending Products
                </h2>
                <p className="mt-0.5 text-sm text-gray-600">
                  Most popular items this week
                </p>
              </div>
            </div>
            <Link
              href="/products"
              className="flex items-center gap-1 text-sm font-medium text-orange-600 transition hover:text-orange-700"
            >
              See all <ChevronRight className="h-4 w-4" />
            </Link>
          </div>

          <div className="mt-10 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {trendingProducts.map((product) => {
              const images = parseImages(product.images);
              const discount = product.originalPriceCents
                ? Math.round(
                    ((product.originalPriceCents - product.priceCents) /
                      product.originalPriceCents) *
                      100
                  )
                : 0;

              return (
                <Link
                  key={product.id}
                  href={`/products/${product.slug}`}
                  className="group overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-sm transition-all hover:shadow-lg"
                >
                  <div className="relative aspect-square overflow-hidden bg-gray-100">
                    {images.length > 0 ? (
                      <Image
                        src={images[0]}
                        alt={product.name}
                        fill
                        sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
                        className="object-cover transition-transform duration-300 group-hover:scale-105"
                      />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center">
                        <ShoppingBag className="h-12 w-12 text-gray-300" />
                      </div>
                    )}
                    {discount > 0 && (
                      <span className="absolute left-3 top-3 rounded-full bg-red-500 px-2.5 py-0.5 text-xs font-semibold text-white">
                        -{discount}%
                      </span>
                    )}
                  </div>
                  <div className="p-4">
                    <p className="text-xs font-medium text-orange-600">
                      {product.vendor.name}
                    </p>
                    <h3 className="mt-1 line-clamp-1 text-sm font-semibold text-gray-900 group-hover:text-orange-600">
                      {product.name}
                    </h3>
                    <div className="mt-2 flex items-center gap-1">
                      <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                      <span className="text-xs font-medium text-gray-700">
                        {product.averageRating.toFixed(1)}
                      </span>
                      <span className="text-xs text-gray-400">
                        ({product.totalReviews})
                      </span>
                    </div>
                    <div className="mt-3 flex items-baseline gap-2">
                      <span className="text-lg font-bold text-gray-900">
                        {formatPrice(product.priceCents)}
                      </span>
                      {product.originalPriceCents && (
                        <span className="text-sm text-gray-400 line-through">
                          {formatPrice(product.originalPriceCents)}
                        </span>
                      )}
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>

          {trendingProducts.length === 0 && (
            <div className="mt-10 rounded-2xl border-2 border-dashed border-gray-200 py-16 text-center">
              <ShoppingBag className="mx-auto h-12 w-12 text-gray-300" />
              <h3 className="mt-4 text-lg font-medium text-gray-900">
                No products yet
              </h3>
              <p className="mt-2 text-sm text-gray-500">
                Products will appear here once vendors start listing them.
              </p>
            </div>
          )}
        </div>
      </section>

      <RecentlyViewed />

      {/* Personalized Recommendations */}
      <PersonalizedRecommendations />

      {/* Featured Vendors */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-100">
              <Users className="h-5 w-5 text-emerald-600" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-gray-900 sm:text-3xl">
                Featured Vendors
              </h2>
              <p className="mt-0.5 text-sm text-gray-600">
                Shop from our top-rated sellers
              </p>
            </div>
          </div>
          <Link
            href="/vendors"
            className="flex items-center gap-1 text-sm font-medium text-orange-600 transition hover:text-orange-700"
          >
            View all <ChevronRight className="h-4 w-4" />
          </Link>
        </div>

        <div className="mt-10 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {vendors.map((vendor) => (
            <Link
              key={vendor.id}
              href={`/store/${vendor.slug}`}
              className="group overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-sm transition-all hover:shadow-lg"
            >
              <div className="relative h-28 overflow-hidden bg-gradient-to-br from-orange-100 to-amber-100">
                {vendor.banner ? (
                  <Image
                    src={vendor.banner}
                    alt={vendor.name}
                    fill
                    sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
                    className="object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                ) : (
                  <div className="h-full w-full bg-gradient-to-br from-orange-200/50 to-amber-200/50" />
                )}
              </div>
              <div className="px-5 pb-5">
                <div className="-mt-8 mb-3">
                  <div className="relative flex h-16 w-16 items-center justify-center overflow-hidden rounded-xl border-4 border-white bg-white shadow-sm">
                    {vendor.logo ? (
                      <Image
                        src={vendor.logo}
                        alt={vendor.name}
                        fill
                        sizes="64px"
                        className="object-cover"
                      />
                    ) : (
                      <Store className="h-7 w-7 text-orange-500" />
                    )}
                  </div>
                </div>
                <h3 className="font-semibold text-gray-900 group-hover:text-orange-600">
                  {vendor.name}
                </h3>
                {vendor.description && (
                  <p className="mt-1 line-clamp-2 text-sm text-gray-500">
                    {vendor.description}
                  </p>
                )}
                <div className="mt-3 flex items-center gap-3">
                  <div className="flex items-center gap-1">
                    <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                    <span className="text-sm font-medium text-gray-700">
                      {vendor.rating.toFixed(1)}
                    </span>
                  </div>
                  <span className="text-xs text-gray-400">
                    {vendor.totalRatings} reviews
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>

        {vendors.length === 0 && (
          <div className="mt-10 rounded-2xl border-2 border-dashed border-gray-200 py-16 text-center">
            <Store className="mx-auto h-12 w-12 text-gray-300" />
            <h3 className="mt-4 text-lg font-medium text-gray-900">
              No vendors yet
            </h3>
            <p className="mt-2 text-sm text-gray-500">
              Vendors will appear here once they are approved.
            </p>
          </div>
        )}
      </section>

      {/* Stats Section */}
      <section className="border-t border-gray-100 bg-gray-50">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-gray-900 sm:text-3xl">
              Trusted by Thousands
            </h2>
            <p className="mt-2 text-gray-600">
              Join our growing community of buyers and sellers
            </p>
          </div>
          <div className="mt-12 grid grid-cols-1 gap-8 sm:grid-cols-3">
            <div className="flex flex-col items-center rounded-2xl bg-white p-8 shadow-sm">
              <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-orange-100">
                <ShoppingBag className="h-7 w-7 text-orange-600" />
              </div>
              <p className="mt-4 text-3xl font-bold text-gray-900">
                {totalProducts.toLocaleString()}+
              </p>
              <p className="mt-1 text-sm font-medium text-gray-500">
                Products Available
              </p>
            </div>
            <div className="flex flex-col items-center rounded-2xl bg-white p-8 shadow-sm">
              <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-emerald-100">
                <Store className="h-7 w-7 text-emerald-600" />
              </div>
              <p className="mt-4 text-3xl font-bold text-gray-900">
                {totalVendors.toLocaleString()}+
              </p>
              <p className="mt-1 text-sm font-medium text-gray-500">
                Verified Vendors
              </p>
            </div>
            <div className="flex flex-col items-center rounded-2xl bg-white p-8 shadow-sm">
              <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-blue-100">
                <Truck className="h-7 w-7 text-blue-600" />
              </div>
              <p className="mt-4 text-3xl font-bold text-gray-900">
                {totalOrders.toLocaleString()}+
              </p>
              <p className="mt-1 text-sm font-medium text-gray-500">
                Orders Completed
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="overflow-hidden rounded-3xl bg-gradient-to-r from-orange-600 to-amber-600 px-6 py-16 shadow-xl sm:px-16">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-bold text-white sm:text-4xl">
              Start Selling on YourTaste
            </h2>
            <p className="mt-4 text-lg text-orange-100">
              Join hundreds of vendors already growing their business on our
              platform. Set up your store in minutes.
            </p>
            <div className="mt-8 flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
              <Link
                href="/vendor/register"
                className="inline-flex items-center gap-2 rounded-lg bg-white px-6 py-3 text-sm font-semibold text-orange-600 shadow-sm transition hover:bg-orange-50"
              >
                Become a Vendor
                <ArrowRight className="h-4 w-4" />
              </Link>
              <Link
                href="/products"
                className="inline-flex items-center gap-2 rounded-lg border border-white/30 px-6 py-3 text-sm font-semibold text-white transition hover:bg-white/10"
              >
                Browse Products
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
