import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireAuth, errorResponse } from '@/lib/api'

export async function GET(
  request: NextRequest,
  { params }: { params: { orderId: string } }
) {
  try {
    const user = await requireAuth()

    const order = await prisma.order.findUnique({
      where: { id: params.orderId },
      select: { userId: true, status: true },
    })

    if (!order) return errorResponse('Order not found', 404)
    if (order.userId !== user.id) return errorResponse('Access denied', 403)

    const encoder = new TextEncoder()

    const stream = new ReadableStream({
      async start(controller) {
        let lastStatus = ''

        const send = async () => {
          try {
            const tracking = await prisma.orderTracking.findMany({
              where: { orderId: params.orderId },
              orderBy: { timestamp: 'desc' },
              take: 10,
            })

            const order = await prisma.order.findUnique({
              where: { id: params.orderId },
              select: { status: true },
            })

            const data = JSON.stringify({ tracking, status: order?.status })

            if (order?.status !== lastStatus) {
              lastStatus = order?.status ?? ''
              controller.enqueue(encoder.encode(`data: ${data}\n\n`))
            }

            if (order?.status === 'DELIVERED' || order?.status === 'CANCELLED') {
              controller.enqueue(encoder.encode(`data: ${JSON.stringify({ done: true })}\n\n`))
              controller.close()
              return
            }
          } catch (err) {
            console.error('Tracking stream error:', err)
            controller.close()
            return
          }
        }

        await send()
        const interval = setInterval(send, 5000)

        request.signal.addEventListener('abort', () => {
          clearInterval(interval)
          controller.close()
        })
      },
    })

    return new Response(stream, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        Connection: 'keep-alive',
      },
    })
  } catch (error) {
    return errorResponse('Internal server error', 500)
  }
}
