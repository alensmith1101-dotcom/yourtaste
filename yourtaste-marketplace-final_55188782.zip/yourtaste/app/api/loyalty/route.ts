import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const loyalty = await prisma.userLoyaltyPoints.findFirst({
    where: { userId: session.user.id },
  })

  const orders = await prisma.order.count({
    where: { userId: session.user.id, paymentStatus: 'PAID' },
  })

  const points = loyalty?.availablePoints || 0
  let tier = 'BRONZE'
  if (points >= 10000) tier = 'PLATINUM'
  else if (points >= 5000) tier = 'GOLD'
  else if (points >= 1000) tier = 'SILVER'

  return NextResponse.json({
    points, tier, totalOrders: orders,
    nextTier: tier === 'BRONZE' ? { name: 'SILVER', points: 1000 } :
               tier === 'SILVER' ? { name: 'GOLD', points: 5000 } :
               tier === 'GOLD' ? { name: 'PLATINUM', points: 10000 } : null,
  })
}

export async function POST(request: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { pointsToRedeem } = await request.json()
  if (!pointsToRedeem || pointsToRedeem <= 0) return NextResponse.json({ error: 'Invalid points' }, { status: 400 })

  const loyalty = await prisma.userLoyaltyPoints.findFirst({ where: { userId: session.user.id } })
  if (!loyalty || loyalty.availablePoints < pointsToRedeem) return NextResponse.json({ error: 'Insufficient points' }, { status: 400 })

  const discountValue = Math.floor(pointsToRedeem / 100) * 100
  await prisma.userLoyaltyPoints.update({
    where: { id: loyalty.id },
    data: {
      availablePoints: { decrement: pointsToRedeem },
      lifetimeRedeemed: { increment: pointsToRedeem },
      lastRedeemedAt: new Date()
    }
  })

  return NextResponse.json({ success: true, redeemed: pointsToRedeem, discountValue })
}
