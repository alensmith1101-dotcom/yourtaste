import { NextRequest } from 'next/server'
import { successResponse, handleApiError, getCurrentUser } from '@/lib/api'
import { EnhancedSearchService, SortOption } from '@/lib/search'
import { rateLimiters, getClientIp } from '@/lib/rate-limit'

export async function GET(request: NextRequest) {
  try {
    const ip = getClientIp(request)
    const limited = await rateLimiters.search(ip, 'search')
    if (!limited.success) return limited.response

    const { searchParams } = new URL(request.url)
    const query = searchParams.get('q') || ''
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '20')
    const sortBy = (searchParams.get('sortBy') || 'relevance') as SortOption
    const categoryIds = searchParams.get('categoryIds')?.split(',').filter(Boolean)
    const vendorIds = searchParams.get('vendorIds')?.split(',').filter(Boolean)
    const minPrice = searchParams.get('minPrice') ? parseInt(searchParams.get('minPrice')!) : undefined
    const maxPrice = searchParams.get('maxPrice') ? parseInt(searchParams.get('maxPrice')!) : undefined
    const minRating = searchParams.get('minRating') ? parseFloat(searchParams.get('minRating')!) : undefined
    const inStock = searchParams.get('inStock') === 'true'
    const tags = searchParams.get('tags')?.split(',').filter(Boolean)

    const user = await getCurrentUser()

    const results = await EnhancedSearchService.search({
      query,
      page,
      limit,
      sortBy,
      filters: {
        categoryIds,
        vendorIds,
        minPrice,
        maxPrice,
        minRating,
        inStock,
        tags,
      },
      userId: user?.id,
    })

    return successResponse(results)
  } catch (error) {
    return handleApiError(error)
  }
}
