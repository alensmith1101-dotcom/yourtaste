import { NextRequest } from 'next/server'
import { successResponse, handleApiError } from '@/lib/api'
import { EnhancedSearchService } from '@/lib/search'
import { rateLimiters, getClientIp } from '@/lib/rate-limit'

export async function GET(request: NextRequest) {
  try {
    const ip = getClientIp(request)
    const limit = await rateLimiters.search(ip)
    if (!limit.success) return limit.response

    const { searchParams } = new URL(request.url)
    const query = searchParams.get('q') || ''

    if (!query.trim()) {
      return successResponse({ suggestions: [], trending: [] })
    }

    const results = await EnhancedSearchService.getSearchSuggestions(query)

    return successResponse(results)
  } catch (error) {
    return handleApiError(error)
  }
}
