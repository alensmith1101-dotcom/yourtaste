import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export const dynamic = 'force-dynamic'

export async function GET() {
  const faqs = await prisma.faq.findMany({ where: { isActive: true }, orderBy: [{ category: 'asc' }, { order: 'asc' }] })
  return NextResponse.json({ faqs })
}
