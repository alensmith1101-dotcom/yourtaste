import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireAdmin, successResponse, errorResponse, handleApiError, parsePagination } from '@/lib/api'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const { skip, limit } = parsePagination(searchParams)
    const activeOnly = searchParams.get('active') !== 'false'
    const now = new Date()

    const where = activeOnly
      ? {
          isActive: true,
          startsAt: { lte: now },
          endsAt: { gte: now },
          product: { isActive: true, isPublished: true },
        }
      : {}

    const [deals, total] = await Promise.all([
      prisma.deal.findMany({
        where,
        include: {
          product: {
            select: {
              id: true,
              name: true,
              slug: true,
              priceCents: true,
              originalPriceCents: true,
              images: true,
              stockQuantity: true,
              vendor: { select: { name: true, slug: true } },
            },
          },
        },
        orderBy: { endsAt: 'asc' },
        skip,
        take: limit,
      }),
      prisma.deal.count({ where }),
    ])

    const enriched = deals.map((deal) => {
      const dealPrice = Math.round(
        deal.product.priceCents * (1 - deal.discountPercent / 100)
      )
      const status = getDealStatus(deal)
      return { ...deal, dealPrice, status }
    })

    return successResponse({ deals: enriched, total })
  } catch (error) {
    return handleApiError(error)
  }
}

export async function POST(request: NextRequest) {
  try {
    await requireAdmin()
    const body = await request.json()
    const { productId, discountPercent, startsAt, endsAt, stockLimit } = body

    if (!productId || !discountPercent || !startsAt || !endsAt) {
      return errorResponse('Missing required fields: productId, discountPercent, startsAt, endsAt', 400)
    }

    if (discountPercent < 1 || discountPercent > 99) {
      return errorResponse('Discount percent must be between 1 and 99', 400)
    }

    if (new Date(endsAt) <= new Date(startsAt)) {
      return errorResponse('End date must be after start date', 400)
    }

    const product = await prisma.product.findUnique({ where: { id: productId } })
    if (!product) {
      return errorResponse('Product not found', 404)
    }

    const deal = await prisma.deal.create({
      data: {
        productId,
        discountPercent,
        startsAt: new Date(startsAt),
        endsAt: new Date(endsAt),
        stockLimit: stockLimit || 0,
        isActive: true,
      },
      include: {
        product: {
          select: {
            id: true,
            name: true,
            slug: true,
            priceCents: true,
            images: true,
            vendor: { select: { name: true } },
          },
        },
      },
    })

    return successResponse(deal, 201)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function PATCH(request: NextRequest) {
  try {
    await requireAdmin()
    const body = await request.json()
    const { id, ...updates } = body

    if (!id) {
      return errorResponse('Deal ID is required', 400)
    }

    if (updates.discountPercent !== undefined && (updates.discountPercent < 1 || updates.discountPercent > 99)) {
      return errorResponse('Discount percent must be between 1 and 99', 400)
    }

    if (updates.startsAt && updates.endsAt && new Date(updates.endsAt) <= new Date(updates.startsAt)) {
      return errorResponse('End date must be after start date', 400)
    }

    const data: Record<string, any> = {}
    if (updates.discountPercent !== undefined) data.discountPercent = updates.discountPercent
    if (updates.startsAt !== undefined) data.startsAt = new Date(updates.startsAt)
    if (updates.endsAt !== undefined) data.endsAt = new Date(updates.endsAt)
    if (updates.isActive !== undefined) data.isActive = updates.isActive
    if (updates.stockLimit !== undefined) data.stockLimit = updates.stockLimit

    const deal = await prisma.deal.update({
      where: { id },
      data,
      include: {
        product: {
          select: { id: true, name: true, slug: true, priceCents: true, images: true },
        },
      },
    })

    return successResponse(deal)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function DELETE(request: NextRequest) {
  try {
    await requireAdmin()
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return errorResponse('Deal ID is required', 400)
    }

    await prisma.deal.delete({ where: { id } })
    return successResponse({ deleted: true })
  } catch (error) {
    return handleApiError(error)
  }
}

function getDealStatus(deal: { isActive: boolean; endsAt: Date; stockLimit: number; soldCount: number }): string {
  const now = new Date()
  if (!deal.isActive) return 'EXPIRED'
  if (deal.endsAt < now) return 'EXPIRED'
  if (deal.stockLimit > 0 && deal.soldCount >= deal.stockLimit) return 'SOLD_OUT'
  const hoursLeft = (deal.endsAt.getTime() - now.getTime()) / 3600000
  if (hoursLeft < 2) return 'ENDING_SOON'
  return 'ACTIVE'
}
