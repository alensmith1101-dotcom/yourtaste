import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'
import { rateLimiters, getClientIp } from '@/lib/rate-limit'

const newsletterSchema = z.object({
  email: z.string().email('Invalid email address'),
})

export async function POST(request: NextRequest) {
  const ip = getClientIp(request)
  const limited = await rateLimiters.api(ip, 'newsletter')
  if (!limited.success) return limited.response

  const body = await request.json()
  const parsed = newsletterSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json({ error: parsed.error.errors[0].message }, { status: 400 })

  const { email } = parsed.data

  // Check if already subscribed
  const existing = await prisma.newsletter.findUnique({ where: { email } })
  if (existing) {
    return NextResponse.json({ error: 'Email already subscribed' }, { status: 400 })
  }

  // Subscribe
  await prisma.newsletter.create({ data: { email, isActive: true } })

  return NextResponse.json({ success: true, message: 'Successfully subscribed to newsletter' })
}
