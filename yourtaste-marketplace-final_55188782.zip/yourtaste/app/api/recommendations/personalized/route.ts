import { requireAuth, successResponse, handleApiError } from '@/lib/api'
import { getPersonalizedRecommendations } from '@/lib/recommendations'

export async function GET() {
  try {
    const user = await requireAuth()

    const recommendations = await getPersonalizedRecommendations(user.id, 8)

    return successResponse(recommendations)
  } catch (error) {
    return handleApiError(error)
  }
}
