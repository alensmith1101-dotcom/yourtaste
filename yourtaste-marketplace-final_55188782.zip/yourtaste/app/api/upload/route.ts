import { NextRequest } from 'next/server'
import { requireAuth, successResponse, errorResponse, handleApiError } from '@/lib/api'
import { uploadImage } from '@/lib/cloudinary'
import { rateLimiters, getClientIp } from '@/lib/rate-limit'

const MAX_FILE_SIZE = 5 * 1024 * 1024 // 5MB
const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif']

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth()

    const ip = getClientIp(request)
    const limit = await rateLimiters.upload(ip)
    if (!limit.success) return limit.response

    const formData = await request.formData()
    const file = formData.get('file') as File | null
    const folder = (formData.get('folder') as string) || 'yourtaste/products'

    if (!file) {
      return errorResponse('No file provided', 400)
    }

    if (!ALLOWED_TYPES.includes(file.type)) {
      return errorResponse('Invalid file type. Allowed: JPEG, PNG, WebP, GIF', 400)
    }

    if (file.size > MAX_FILE_SIZE) {
      return errorResponse('File too large. Maximum size is 5MB', 400)
    }

    const buffer = Buffer.from(await file.arrayBuffer())
    const base64 = `data:${file.type};base64,${buffer.toString('base64')}`

    const result = await uploadImage(base64, folder)

    return successResponse({
      url: result.url,
      publicId: result.publicId,
      width: result.width,
      height: result.height,
      format: result.format,
    })
  } catch (error) {
    return handleApiError(error)
  }
}

export async function PUT(request: NextRequest) {
  try {
    await requireAuth()
    const { url, folder } = await request.json()
    if (!url) return errorResponse('URL required', 400)
    try { new URL(url) } catch (err) { console.error('Invalid URL:', err); return errorResponse('Invalid URL', 400) }
    try {
      const result = await uploadImage(url, folder || 'yourtaste/uploads')
      return successResponse({ success: true, url: result.url, publicId: result.publicId })
    } catch (err) { console.error('Upload optimization failed:', err); return successResponse({ success: true, url, optimized: false }) }
  } catch (error) {
    return handleApiError(error)
  }
}
