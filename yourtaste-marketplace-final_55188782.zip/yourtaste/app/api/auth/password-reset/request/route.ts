import { NextRequest } from 'next/server'
import { randomBytes } from 'crypto'
import { prisma } from '@/lib/prisma'
import { successResponse, errorResponse, handleApiError } from '@/lib/api'
import { sendEmail, passwordResetTemplate } from '@/lib/email'
import { rateLimiters, getClientIp } from '@/lib/rate-limit'

export async function POST(request: NextRequest) {
  try {
    const ip = getClientIp(request)
    const limit = await rateLimiters.auth(ip)
    if (!limit.success) return limit.response

    const { email } = await request.json()

    if (!email) {
      return errorResponse('Email is required', 400)
    }

    const user = await prisma.user.findUnique({ where: { email: email.toLowerCase().trim() } })

    // Always return success to prevent email enumeration
    if (!user) {
      return successResponse({ message: 'If an account exists with that email, a reset link has been sent.' })
    }

    // Generate reset token
    const token = randomBytes(32).toString('hex')
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000) // 1 hour

    // Invalidate any existing tokens
    await prisma.passwordResetToken.updateMany({
      where: { email: user.email, usedAt: null },
      data: { usedAt: new Date() },
    })

    // Create new token
    await prisma.passwordResetToken.create({
      data: {
        email: user.email,
        token,
        expiresAt,
      },
    })

    // Send reset email
    const appUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'
    const resetUrl = `${appUrl}/auth/reset-password?token=${token}`

    const template = passwordResetTemplate({
      userName: user.name || 'User',
      resetUrl,
      expiryMinutes: 60,
    })

    await sendEmail({
      to: user.email,
      subject: template.subject,
      html: template.html,
      text: template.text,
    })

    return successResponse({ message: 'If an account exists with that email, a reset link has been sent.' })
  } catch (error) {
    return handleApiError(error)
  }
}
