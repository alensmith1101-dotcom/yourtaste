import { NextRequest } from 'next/server'
import { hash } from 'bcryptjs'
import { prisma } from '@/lib/prisma'
import { successResponse, errorResponse, handleApiError } from '@/lib/api'
import { rateLimiters, getClientIp } from '@/lib/rate-limit'

export async function POST(request: NextRequest) {
  try {
    const ip = getClientIp(request)
    const limit = await rateLimiters.auth(ip)
    if (!limit.success) return limit.response

    const { token, newPassword } = await request.json()

    if (!token || !newPassword) {
      return errorResponse('Token and new password are required', 400)
    }

    if (newPassword.length < 8) {
      return errorResponse('Password must be at least 8 characters', 400)
    }

    // Find valid token
    const resetToken = await prisma.passwordResetToken.findUnique({
      where: { token },
    })

    if (!resetToken || resetToken.usedAt || resetToken.expiresAt < new Date()) {
      return errorResponse('Invalid or expired reset token', 400)
    }

    // Hash new password
    const hashedPassword = await hash(newPassword, 10)

    // Update user password and mark token as used
    await prisma.$transaction([
      prisma.user.update({
        where: { email: resetToken.email },
        data: { password: hashedPassword },
      }),
      prisma.passwordResetToken.update({
        where: { id: resetToken.id },
        data: { usedAt: new Date() },
      }),
    ])

    return successResponse({ message: 'Password reset successfully' })
  } catch (error) {
    return handleApiError(error)
  }
}
