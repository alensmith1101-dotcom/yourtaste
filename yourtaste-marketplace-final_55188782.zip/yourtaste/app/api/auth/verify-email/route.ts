import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { randomBytes } from 'crypto'
import { sendEmail } from '@/lib/email'
import { rateLimiters, getClientIp } from '@/lib/rate-limit'

export async function POST(request: NextRequest) {
  const ip = getClientIp(request)
  const limited = await rateLimiters.auth(ip, 'verify-email')
  if (!limited.success) return limited.response

  try {
    const { email, token } = await request.json()

    if (token) {
      const user = await prisma.user.findFirst({
        where: {
          email,
          emailVerificationToken: token,
          emailVerificationTokenExpiry: { gte: new Date() },
        },
      })

      if (!user) {
        return NextResponse.json({ error: 'Invalid or expired verification link' }, { status: 400 })
      }

      await prisma.user.update({
        where: { id: user.id },
        data: {
          emailVerified: new Date(),
          emailVerificationToken: null,
          emailVerificationTokenExpiry: null,
        },
      })

      return NextResponse.json({ success: true, message: 'Email verified successfully' })
    }

    if (email) {
      const user = await prisma.user.findUnique({ where: { email } })
      if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 })
      if (user.emailVerified) return NextResponse.json({ success: true, message: 'Email already verified' })

      const verifyToken = randomBytes(32).toString('hex')
      const expiry = new Date(Date.now() + 24 * 60 * 60 * 1000)

      await prisma.user.update({
        where: { id: user.id },
        data: {
          emailVerificationToken: verifyToken,
          emailVerificationTokenExpiry: expiry,
        },
      })

      const baseUrl = process.env.NEXT_PUBLIC_APP_URL || 'https://yourtaste.com'
      const verifyUrl = `${baseUrl}/auth/verify-email?token=${verifyToken}&email=${encodeURIComponent(email)}`

      await sendEmail({
        to: email,
        subject: 'Verify your YourTaste account',
        html: `
          <h2>Welcome to YourTaste!</h2>
          <p>Please verify your email address by clicking the link below:</p>
          <p><a href="${verifyUrl}" style="display:inline-block;padding:12px 24px;background:#f97316;color:white;text-decoration:none;border-radius:8px;font-weight:bold;">Verify Email</a></p>
          <p>This link expires in 24 hours.</p>
        `,
      })

      return NextResponse.json({ success: true, message: 'Verification email sent' })
    }

    return NextResponse.json({ error: 'Email or token required' }, { status: 400 })
  } catch (error) {
    console.error('Email verification error:', error)
    return NextResponse.json({ error: 'Verification failed' }, { status: 500 })
  }
}
