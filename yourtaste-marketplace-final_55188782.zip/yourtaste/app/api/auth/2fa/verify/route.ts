import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { verifySync, generateSecret } from "otplib"
import { z } from "zod"
import { rateLimiters, getClientIp } from "@/lib/rate-limit"
import crypto from "crypto"

const verifySchema = z.object({
  token: z.string().min(6).max(6),
})

const backupCodeSchema = z.object({
  backupCode: z.string().min(1),
})

function generateBackupCodes(): string[] {
  const codes: string[] = []
  for (let i = 0; i < 10; i++) {
    const code = crypto.randomBytes(4).toString("hex").toUpperCase()
    const formatted = `${code.slice(0, 4)}-${code.slice(4)}`
    codes.push(formatted)
  }
  return codes
}

export async function POST(request: NextRequest) {
  const ip = getClientIp(request)
  const limit = await rateLimiters.auth(ip, "2fa-verify")
  if (!limit.success) return limit.response

  const session = await getServerSession(authOptions)
  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const body = await request.json()

  const user = await prisma.user.findUnique({
    where: { id: session.user.id },
    select: {
      twoFactorSecret: true,
      twoFactorEnabled: true,
      twoFactorBackupCodes: true,
    },
  })

  if (!user || !user.twoFactorSecret) {
    return NextResponse.json(
      { error: "2FA is not set up" },
      { status: 400 }
    )
  }

  let isValid = false

  const tokenResult = verifySchema.safeParse(body)
  if (tokenResult.success) {
    const result = verifySync({
      secret: user.twoFactorSecret,
      token: tokenResult.data.token,
    })
    isValid = result.valid
  }

  if (!isValid) {
    const backupResult = backupCodeSchema.safeParse(body)
    if (backupResult.success && user.twoFactorBackupCodes) {
      const existingCodes: string[] = JSON.parse(user.twoFactorBackupCodes)
      const normalizedInput = backupResult.data.backupCode
        .trim()
        .toUpperCase()
      const codeIndex = existingCodes.findIndex(
        (code) => code.toUpperCase() === normalizedInput
      )

      if (codeIndex !== -1) {
        isValid = true
        existingCodes.splice(codeIndex, 1)
        await prisma.user.update({
          where: { id: session.user.id },
          data: { twoFactorBackupCodes: JSON.stringify(existingCodes) },
        })
      }
    }
  }

  if (!isValid) {
    return NextResponse.json(
      { error: "Invalid verification code" },
      { status: 400 }
    )
  }

  if (!user.twoFactorEnabled) {
    const backupCodes = generateBackupCodes()

    await prisma.user.update({
      where: { id: session.user.id },
      data: {
        twoFactorEnabled: true,
        twoFactorBackupCodes: JSON.stringify(backupCodes),
      },
    })

    return NextResponse.json({
      success: true,
      backupCodes,
      message: "2FA has been enabled successfully",
    })
  }

  return NextResponse.json({
    success: true,
    message: "Verification successful",
  })
}
