import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { verifySync } from "otplib"
import { compare } from "bcryptjs"
import { z } from "zod"
import { rateLimiters, getClientIp } from "@/lib/rate-limit"

const loginVerifySchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
  token: z.string().min(6).max(6).optional(),
  backupCode: z.string().optional(),
})

export async function POST(request: NextRequest) {
  const ip = getClientIp(request)
  const limit = await rateLimiters.auth(ip, "2fa-login-verify")
  if (!limit.success) return limit.response

  const body = await request.json()
  const parsed = loginVerifySchema.safeParse(body)

  if (!parsed.success) {
    return NextResponse.json(
      { error: "Invalid request" },
      { status: 400 }
    )
  }

  const user = await prisma.user.findUnique({
    where: { email: parsed.data.email.toLowerCase().trim() },
    select: {
      id: true,
      email: true,
      name: true,
      password: true,
      role: true,
      isActive: true,
      twoFactorEnabled: true,
      twoFactorSecret: true,
      twoFactorBackupCodes: true,
    },
  })

  if (!user || !user.password || !user.isActive || !user.twoFactorEnabled) {
    return NextResponse.json(
      { error: "Invalid credentials or 2FA not enabled" },
      { status: 401 }
    )
  }

  const isPasswordValid = await compare(parsed.data.password, user.password)
  if (!isPasswordValid) {
    return NextResponse.json(
      { error: "Invalid credentials" },
      { status: 401 }
    )
  }

  let isValid = false

  if (parsed.data.token) {
    const result = verifySync({
      secret: user.twoFactorSecret!,
      token: parsed.data.token,
    })
    isValid = result.valid
  }

  if (!isValid && parsed.data.backupCode && user.twoFactorBackupCodes) {
    const existingCodes: string[] = JSON.parse(user.twoFactorBackupCodes)
    const normalizedInput = parsed.data.backupCode.trim().toUpperCase()
    const codeIndex = existingCodes.findIndex(
      (code) => code.toUpperCase() === normalizedInput
    )

    if (codeIndex !== -1) {
      isValid = true
      existingCodes.splice(codeIndex, 1)
      await prisma.user.update({
        where: { id: user.id },
        data: { twoFactorBackupCodes: JSON.stringify(existingCodes) },
      })
    }
  }

  if (!isValid) {
    return NextResponse.json(
      { error: "Invalid verification code" },
      { status: 400 }
    )
  }

  await prisma.user.update({
    where: { id: user.id },
    data: { lastLogin: new Date() },
  })

  return NextResponse.json({
    success: true,
    verified: true,
  })
}
