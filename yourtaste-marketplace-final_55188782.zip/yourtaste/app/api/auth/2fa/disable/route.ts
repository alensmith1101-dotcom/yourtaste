import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { verifySync } from "otplib"
import { compare } from "bcryptjs"
import { z } from "zod"
import { rateLimiters, getClientIp } from "@/lib/rate-limit"

const disableSchema = z.object({
  token: z.string().min(6).max(6),
  password: z.string().min(1),
})

export async function POST(request: NextRequest) {
  const ip = getClientIp(request)
  const limit = await rateLimiters.auth(ip, "2fa-disable")
  if (!limit.success) return limit.response

  const session = await getServerSession(authOptions)
  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const body = await request.json()
  const parsed = disableSchema.safeParse(body)

  if (!parsed.success) {
    return NextResponse.json(
      { error: "Invalid request body" },
      { status: 400 }
    )
  }

  const user = await prisma.user.findUnique({
    where: { id: session.user.id },
    select: {
      password: true,
      twoFactorSecret: true,
      twoFactorEnabled: true,
    },
  })

  if (!user || !user.twoFactorEnabled) {
    return NextResponse.json(
      { error: "2FA is not enabled" },
      { status: 400 }
    )
  }

  if (!user.password) {
    return NextResponse.json(
      { error: "Account has no password set" },
      { status: 400 }
    )
  }

  const isPasswordValid = await compare(parsed.data.password, user.password)
  if (!isPasswordValid) {
    return NextResponse.json(
      { error: "Invalid password" },
      { status: 400 }
    )
  }

  if (!user.twoFactorSecret) {
    return NextResponse.json(
      { error: "2FA secret not found" },
      { status: 400 }
    )
  }

  const result = verifySync({
    secret: user.twoFactorSecret,
    token: parsed.data.token,
  })

  if (!result.valid) {
    return NextResponse.json(
      { error: "Invalid verification code" },
      { status: 400 }
    )
  }

  await prisma.user.update({
    where: { id: session.user.id },
    data: {
      twoFactorEnabled: false,
      twoFactorSecret: null,
      twoFactorBackupCodes: null,
    },
  })

  return NextResponse.json({
    success: true,
    message: "2FA has been disabled successfully",
  })
}
