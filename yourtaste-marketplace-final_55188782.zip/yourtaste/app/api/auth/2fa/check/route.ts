import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { z } from "zod"
import { rateLimiters, getClientIp } from "@/lib/rate-limit"

const checkSchema = z.object({
  email: z.string().email(),
})

export async function POST(request: NextRequest) {
  const ip = getClientIp(request)
  const limit = await rateLimiters.auth(ip, "2fa-check")
  if (!limit.success) return limit.response

  const body = await request.json()
  const parsed = checkSchema.safeParse(body)

  if (!parsed.success) {
    return NextResponse.json(
      { error: "Invalid email" },
      { status: 400 }
    )
  }

  const user = await prisma.user.findUnique({
    where: { email: parsed.data.email.toLowerCase().trim() },
    select: { twoFactorEnabled: true },
  })

  if (!user) {
    return NextResponse.json({ twoFactorRequired: false })
  }

  return NextResponse.json({
    twoFactorRequired: user.twoFactorEnabled,
  })
}
