import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { generateSecret, generateURI } from "otplib"
import QRCode from "qrcode"
import { rateLimiters, getClientIp } from "@/lib/rate-limit"

export async function POST(request: NextRequest) {
  const ip = getClientIp(request)
  const limit = await rateLimiters.api(ip, "2fa-setup")
  if (!limit.success) return limit.response

  const session = await getServerSession(authOptions)
  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const user = await prisma.user.findUnique({
    where: { id: session.user.id },
    select: { email: true, twoFactorEnabled: true },
  })

  if (!user) {
    return NextResponse.json({ error: "User not found" }, { status: 404 })
  }

  if (user.twoFactorEnabled) {
    return NextResponse.json(
      { error: "2FA is already enabled" },
      { status: 400 }
    )
  }

  const secret = generateSecret()
  const otpauthUrl = generateURI({
    issuer: "YourTaste",
    label: user.email,
    secret,
  })
  const qrCodeDataUrl = await QRCode.toDataURL(otpauthUrl)

  await prisma.user.update({
    where: { id: session.user.id },
    data: { twoFactorSecret: secret },
  })

  return NextResponse.json({
    secret,
    qrCode: qrCodeDataUrl,
    otpauthUrl,
  })
}
