import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireAuth, successResponse, errorResponse, handleApiError } from '@/lib/api'
import { randomBytes } from 'crypto'

async function ensureDefaultWishlist(userId: string) {
  const existing = await prisma.wishlist.findFirst({
    where: { userId, isDefault: true },
  })
  if (!existing) {
    await prisma.wishlist.create({
      data: {
        userId,
        name: 'My Wishlist',
        isDefault: true,
      },
    })
  }
}

export async function GET() {
  try {
    const user = await requireAuth()
    await ensureDefaultWishlist(user.id)

    const wishlists = await prisma.wishlist.findMany({
      where: { userId: user.id },
      include: {
        items: {
          select: { id: true },
        },
      },
      orderBy: [
        { isDefault: 'desc' },
        { createdAt: 'asc' },
      ],
    })

    const result = wishlists.map((w) => ({
      id: w.id,
      name: w.name,
      isDefault: w.isDefault,
      shareToken: w.shareToken,
      itemCount: w.items.length,
      createdAt: w.createdAt,
      updatedAt: w.updatedAt,
    }))

    return successResponse(result)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth()
    const { name } = await request.json()

    if (!name || !name.trim()) {
      return errorResponse('Wishlist name is required', 400)
    }

    const wishlist = await prisma.wishlist.create({
      data: {
        userId: user.id,
        name: name.trim(),
        isDefault: false,
      },
    })

    return successResponse(wishlist, 201)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function PUT(request: NextRequest) {
  try {
    const user = await requireAuth()
    const { id, name } = await request.json()

    if (!id || !name?.trim()) {
      return errorResponse('Wishlist ID and name are required', 400)
    }

    const wishlist = await prisma.wishlist.findFirst({
      where: { id, userId: user.id },
    })

    if (!wishlist) {
      return errorResponse('Wishlist not found', 404)
    }

    const updated = await prisma.wishlist.update({
      where: { id },
      data: { name: name.trim() },
    })

    return successResponse(updated)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const user = await requireAuth()
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return errorResponse('Wishlist ID is required', 400)
    }

    const wishlist = await prisma.wishlist.findFirst({
      where: { id, userId: user.id },
    })

    if (!wishlist) {
      return errorResponse('Wishlist not found', 404)
    }

    if (wishlist.isDefault) {
      return errorResponse('Cannot delete the default wishlist', 400)
    }

    await prisma.wishlist.delete({ where: { id } })

    return successResponse({ message: 'Wishlist deleted' })
  } catch (error) {
    return handleApiError(error)
  }
}
