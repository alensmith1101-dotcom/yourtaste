import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireAuth, successResponse, errorResponse, handleApiError } from '@/lib/api'
import { randomBytes } from 'crypto'

export async function GET(
  _request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireAuth()

    const wishlist = await prisma.wishlist.findFirst({
      where: { id: params.id, userId: user.id },
    })

    if (!wishlist) {
      return errorResponse('Wishlist not found', 404)
    }

    const items = await prisma.wishlistItem.findMany({
      where: { wishlistId: params.id },
      include: {
        product: {
          include: {
            vendor: { select: { id: true, name: true, slug: true } },
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    })

    return successResponse(items)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireAuth()
    const { productId, fromWishlistId } = await request.json()

    if (!productId) {
      return errorResponse('Product ID is required', 400)
    }

    const wishlist = await prisma.wishlist.findFirst({
      where: { id: params.id, userId: user.id },
    })

    if (!wishlist) {
      return errorResponse('Wishlist not found', 404)
    }

    const product = await prisma.product.findUnique({ where: { id: productId } })
    if (!product) {
      return errorResponse('Product not found', 404)
    }

    const existing = await prisma.wishlistItem.findUnique({
      where: { wishlistId_productId: { wishlistId: params.id, productId } },
    })
    if (existing) {
      return errorResponse('Product already in this wishlist', 409)
    }

    const item = await prisma.wishlistItem.create({
      data: { wishlistId: params.id, productId },
      include: { product: true },
    })

    if (fromWishlistId && fromWishlistId !== params.id) {
      const sourceWishlist = await prisma.wishlist.findFirst({
        where: { id: fromWishlistId, userId: user.id },
      })
      if (sourceWishlist) {
        await prisma.wishlistItem.deleteMany({
          where: { wishlistId: fromWishlistId, productId },
        })
      }
    }

    return successResponse(item, 201)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireAuth()
    const { searchParams } = new URL(request.url)
    const itemId = searchParams.get('itemId')
    const productId = searchParams.get('productId')

    const wishlist = await prisma.wishlist.findFirst({
      where: { id: params.id, userId: user.id },
    })

    if (!wishlist) {
      return errorResponse('Wishlist not found', 404)
    }

    if (itemId) {
      const item = await prisma.wishlistItem.findFirst({
        where: { id: itemId, wishlistId: params.id },
      })
      if (!item) {
        return errorResponse('Item not found', 404)
      }
      await prisma.wishlistItem.delete({ where: { id: itemId } })
    } else if (productId) {
      const item = await prisma.wishlistItem.findFirst({
        where: { productId, wishlistId: params.id },
      })
      if (!item) {
        return errorResponse('Item not found', 404)
      }
      await prisma.wishlistItem.delete({ where: { id: item.id } })
    } else {
      return errorResponse('itemId or productId is required', 400)
    }

    return successResponse({ message: 'Removed from wishlist' })
  } catch (error) {
    return handleApiError(error)
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireAuth()
    const { action } = await request.json()

    const wishlist = await prisma.wishlist.findFirst({
      where: { id: params.id, userId: user.id },
    })

    if (!wishlist) {
      return errorResponse('Wishlist not found', 404)
    }

    if (action === 'share') {
      const shareToken = wishlist.shareToken || randomBytes(16).toString('hex')
      const updated = await prisma.wishlist.update({
        where: { id: params.id },
        data: { shareToken },
      })
      return successResponse({ shareToken: updated.shareToken })
    }

    if (action === 'unshare') {
      await prisma.wishlist.update({
        where: { id: params.id },
        data: { shareToken: null },
      })
      return successResponse({ shareToken: null })
    }

    return errorResponse('Invalid action', 400)
  } catch (error) {
    return handleApiError(error)
  }
}
