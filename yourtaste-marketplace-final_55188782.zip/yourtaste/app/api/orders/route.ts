import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireAuth, successResponse, errorResponse, paginatedResponse, parsePagination, handleApiError } from '@/lib/api'
import { orderSchema } from '@/lib/validations'
import { CouponService } from '@/lib/coupons'
import { TaxService } from '@/lib/tax'
import { NotificationService } from '@/lib/notifications'
import { rateLimiters, getClientIp } from '@/lib/rate-limit'
import { calculateCommission } from '@/lib/affiliate'

export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth()
    const { searchParams } = new URL(request.url)
    const { page, limit, skip } = parsePagination(searchParams)
    const status = searchParams.get('status')

    const where: Record<string, unknown> = {}

    if (user.role === 'ADMIN') {
      // admin sees all
    } else if (user.role === 'VENDOR') {
      const vendor = await prisma.vendor.findUnique({ where: { ownerId: user.id } })
      if (!vendor) return errorResponse('Vendor profile not found', 404)
      where.vendorId = vendor.id
    } else {
      where.userId = user.id
    }

    if (status) where.status = status

    const [orders, total] = await Promise.all([
      prisma.order.findMany({
        where,
        include: {
          items: {
            include: { product: { select: { id: true, name: true, images: true } } },
          },
          vendor: { select: { id: true, name: true } },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      prisma.order.count({ where }),
    ])

    return paginatedResponse(orders, total, page, limit)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function POST(request: NextRequest) {
  try {
    const ip = getClientIp(request)
    const limited = await rateLimiters.orders(ip, 'orders')
    if (!limited.success) return limited.response

    const user = await requireAuth()
    const body = await request.json()
    const validation = orderSchema.safeParse(body)

    if (!validation.success) {
      return errorResponse(validation.error.errors[0].message, 400)
    }

    const { shippingAddress, billingAddress, paymentMethod, couponCode, notes } = validation.data

    const cartItems = await prisma.cartItem.findMany({
      where: { userId: user.id },
      include: { product: true },
    })

    if (cartItems.length === 0) {
      return errorResponse('Cart is empty', 400)
    }

    // Group cart items by vendor for multi-vendor order splitting
    const vendorGroups = new Map<string, typeof cartItems>()

    for (const cartItem of cartItems) {
      const product = cartItem.product
      if (!product.isActive || !product.isPublished) {
        return errorResponse(`Product "${product.name}" is no longer available`, 400)
      }
      if (product.stockQuantity < cartItem.quantity) {
        return errorResponse(`Insufficient stock for "${product.name}". Only ${product.stockQuantity} left.`, 400)
      }
      const vendorId = product.vendorId
      if (!vendorGroups.has(vendorId)) {
        vendorGroups.set(vendorId, [])
      }
      vendorGroups.get(vendorId)!.push(cartItem)
    }

    // Validate coupon if provided
    let couponDiscountCents = 0
    let coupon: any = null
    if (couponCode) {
      const allProductIds = cartItems.map((ci) => ci.product.id)
      const allCategoryIds = cartItems.map((ci) => ci.product.categoryId).filter(Boolean) as string[]
      const totalCents = cartItems.reduce((sum, ci) => sum + ci.product.priceCents * ci.quantity, 0)

      const couponValidation = await CouponService.validate({
        code: couponCode,
        userId: user.id,
        orderTotal: totalCents / 100,
        productIds: allProductIds,
        categoryIds: allCategoryIds,
      })

      if (!couponValidation.valid) {
        return errorResponse(couponValidation.error || 'Invalid coupon', 400)
      }

      coupon = couponValidation.coupon
      couponDiscountCents = Math.round(couponValidation.discount * 100)
    }

    // Calculate tax based on shipping address
    const allSubtotalCents = cartItems.reduce((sum, ci) => sum + ci.product.priceCents * ci.quantity, 0)
    const taxResult = await TaxService.calculateTax(allSubtotalCents, {
      country: shippingAddress.country,
      state: shippingAddress.state,
      city: shippingAddress.city,
      zipCode: shippingAddress.zipCode,
    })

    // Create orders - one per vendor (multi-vendor split)
    const orders = await prisma.$transaction(async (tx) => {
      const createdOrders: any[] = []
      const vendorCount = vendorGroups.size

      for (const [vendorId, items] of vendorGroups.entries()) {
        const vendorSubtotalCents = items.reduce((sum, ci) => sum + ci.product.priceCents * ci.quantity, 0)
        const proportion = vendorSubtotalCents / allSubtotalCents
        const vendorTaxCents = Math.round(taxResult.taxAmount * proportion)
        const vendorDiscountCents = vendorCount === 1
          ? couponDiscountCents
          : Math.round(couponDiscountCents * proportion)
        const subtotalCents = items.reduce((sum, ci) => sum + ci.product.priceCents * ci.quantity, 0)
        const shippingCents = body.shippingCost ?? (subtotalCents >= 49900 ? 0 : 4900)
        const shippingMethod = body.shippingMethod ?? 'STANDARD'
        const vendorTotalCents = vendorSubtotalCents - vendorDiscountCents + vendorTaxCents + shippingCents

        const orderItems = items.map((ci) => ({
          productId: ci.product.id,
          quantity: ci.quantity,
          priceCents: ci.product.priceCents,
          variantId: ci.variantId,
        }))

        const order = await tx.order.create({
          data: {
            userId: user.id,
            vendorId,
            status: 'PENDING',
            total: vendorTotalCents,
            subtotal: vendorSubtotalCents,
            tax: vendorTaxCents,
            shippingCost: shippingCents,
            shippingCarrier: shippingMethod,
            discount: vendorDiscountCents,
            shippingAddress: JSON.stringify(shippingAddress),
            billingAddress: billingAddress ? JSON.stringify(billingAddress) : null,
            paymentMethod,
            paymentStatus: 'PENDING',
            couponCode: couponCode || null,
            notes,
            items: {
              create: orderItems,
            },
          },
          include: {
            items: {
              include: {
                product: { select: { id: true, name: true, images: true, priceCents: true } },
              },
            },
            vendor: { select: { id: true, name: true } },
          },
        })

        createdOrders.push(order)
      }

      // Apply coupon
      if (couponCode && coupon) {
        for (const order of createdOrders) {
          await CouponService.apply({
            code: couponCode,
            userId: user.id,
            orderId: order.id,
            orderTotal: order.subtotal / 100,
            productIds: order.items.map((i: any) => i.productId),
            vendorId: order.vendorId || undefined,
          })
        }
      }

      // Clear cart after successful order creation
      await tx.cartItem.deleteMany({ where: { userId: user.id } })

      return createdOrders
    })

    const affiliateCode = request.cookies.get('yt_ref')?.value
    if (affiliateCode) {
      const affiliateLink = await prisma.affiliateLink.findUnique({
        where: { code: affiliateCode, isActive: true },
      })
      if (affiliateLink && affiliateLink.userId !== user.id) {
        for (const order of orders) {
          const commission = calculateCommission(order.subtotal)
          await prisma.affiliateConversion.create({
            data: {
              linkId: affiliateLink.id,
              orderId: order.id,
              userId: user.id,
              orderTotal: order.subtotal,
              commission,
              status: 'PENDING',
            },
          })
          await prisma.affiliateLink.update({
            where: { id: affiliateLink.id },
            data: {
              conversions: { increment: 1 },
              commissionEarned: { increment: commission },
            },
          })
        }
      }
    }

    // Send notifications
    for (const order of orders) {
      NotificationService.sendOrderConfirmed(user.id, order.id).catch(() => {})
    }

    return successResponse(orders.length === 1 ? orders[0] : orders, 201)
  } catch (error) {
    return handleApiError(error)
  }
}
