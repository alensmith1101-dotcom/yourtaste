import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireAuth, successResponse, errorResponse, handleApiError } from '@/lib/api'

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireAuth()

    const order = await prisma.order.findUnique({
      where: { id: params.id },
      include: {
        items: {
          include: {
            product: {
              select: { id: true, name: true, images: true, slug: true },
            },
          },
        },
        tracking: { orderBy: { timestamp: 'desc' } },
        vendor: { select: { id: true, name: true } },
      },
    })

    if (!order) {
      return errorResponse('Order not found', 404)
    }

    if (user.role !== 'ADMIN' && order.userId !== user.id) {
      if (user.role === 'VENDOR') {
        const vendor = await prisma.vendor.findUnique({ where: { ownerId: user.id } })
        if (!vendor || order.vendorId !== vendor.id) {
          return errorResponse('Access denied', 403)
        }
      } else {
        return errorResponse('Access denied', 403)
      }
    }

    return successResponse(order)
  } catch (error) {
    return handleApiError(error)
  }
}
