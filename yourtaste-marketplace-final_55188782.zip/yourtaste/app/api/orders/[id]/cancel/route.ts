import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireAuth, successResponse, errorResponse, handleApiError } from '@/lib/api'
import { NotificationService } from '@/lib/notifications'

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireAuth()
    const { reason } = await request.json()

    const order = await prisma.order.findUnique({
      where: { id: params.id },
      include: {
        items: { include: { product: true } },
        user: { select: { email: true, name: true } },
      },
    })

    if (!order) {
      return errorResponse('Order not found', 404)
    }

    // Check permissions
    const isOwner = order.userId === user.id
    const isVendor = user.role === 'VENDOR' && order.vendorId === user.id
    const isAdmin = user.role === 'ADMIN'

    if (!isOwner && !isVendor && !isAdmin) {
      return errorResponse('Access denied', 403)
    }

    // Check if order can be cancelled
    const cancellableStatuses = ['PENDING', 'CONFIRMED']
    if (!cancellableStatuses.includes(order.status)) {
      return errorResponse(`Order cannot be cancelled in ${order.status} status`, 400)
    }

    // Cancel order and restore stock
    await prisma.$transaction(async (tx) => {
      await tx.order.update({
        where: { id: params.id },
        data: {
          status: 'CANCELLED',
          cancelledAt: new Date(),
        },
      })

      // Restore stock for each item
      for (const item of order.items) {
        await tx.product.update({
          where: { id: item.productId },
          data: {
            stockQuantity: { increment: item.quantity },
          },
        })
      }

      // Record status change
      await tx.orderStatusHistory.create({
        data: {
          orderId: params.id,
          fromStatus: order.status,
          toStatus: 'CANCELLED',
          changedBy: user.id,
          reason: reason || null,
        },
      })
    })

    // Send notification
    if (isOwner) {
      await NotificationService.send({
        userId: order.userId,
        type: 'ORDER_CANCELLED',
        channel: 'EMAIL',
        title: 'Order Cancelled',
        message: `Your order #${order.id} has been cancelled.`,
        email: order.user.email,
        orderId: order.id,
      })
    }

    return successResponse({ message: 'Order cancelled successfully' })
  } catch (error) {
    return handleApiError(error)
  }
}
