import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'

const redeemSchema = z.object({ code: z.string().min(8) })

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const cards = await prisma.giftCard.findMany({ where: { purchasedById: session.user.id }, orderBy: { createdAt: 'desc' } })
  return NextResponse.json({ cards })
}

export async function POST(request: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await request.json()
  const parsed = redeemSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json({ error: 'Invalid code' }, { status: 400 })

  const card = await prisma.giftCard.findUnique({ where: { code: parsed.data.code } })
  if (!card) return NextResponse.json({ error: 'Gift card not found' }, { status: 404 })
  if (!card.isActive) return NextResponse.json({ error: 'Gift card is no longer active' }, { status: 400 })
  if (card.currentBalance <= 0) return NextResponse.json({ error: 'Gift card has no balance' }, { status: 400 })
  if (card.expiresAt && card.expiresAt < new Date()) return NextResponse.json({ error: 'Expired' }, { status: 400 })

  // Create a usage record to track redemption
  const usage = await prisma.giftCardUsage.create({
    data: {
      giftCardId: card.id,
      userId: session.user.id,
      orderId: 'redeemed', // Placeholder - in real app this would be an actual order
      amount: card.currentBalance,
    }
  })

  // Zero out the card balance
  await prisma.giftCard.update({
    where: { id: card.id },
    data: { currentBalance: 0, isActive: false }
  })

  return NextResponse.json({
    success: true,
    balance: card.currentBalance,
    message: `₹${card.currentBalance / 100} added to your account`
  })
}
