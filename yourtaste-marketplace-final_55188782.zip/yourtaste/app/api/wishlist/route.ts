import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireAuth, successResponse, errorResponse, handleApiError } from '@/lib/api'

async function getOrCreateDefaultWishlist(userId: string) {
  let wishlist = await prisma.wishlist.findFirst({
    where: { userId, isDefault: true },
  })
  if (!wishlist) {
    wishlist = await prisma.wishlist.create({
      data: { userId, name: 'My Wishlist', isDefault: true },
    })
  }
  return wishlist
}

export async function GET() {
  try {
    const user = await requireAuth()
    const wishlist = await getOrCreateDefaultWishlist(user.id)

    const items = await prisma.wishlistItem.findMany({
      where: { wishlistId: wishlist.id },
      include: {
        product: {
          include: {
            vendor: { select: { id: true, name: true, slug: true } },
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    })

    return successResponse(items)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth()
    const { productId, wishlistId } = await request.json()

    if (!productId) {
      return errorResponse('Product ID is required', 400)
    }

    let targetWishlistId = wishlistId
    if (!targetWishlistId) {
      const wishlist = await getOrCreateDefaultWishlist(user.id)
      targetWishlistId = wishlist.id
    } else {
      const wishlist = await prisma.wishlist.findFirst({
        where: { id: targetWishlistId, userId: user.id },
      })
      if (!wishlist) {
        return errorResponse('Wishlist not found', 404)
      }
    }

    const product = await prisma.product.findUnique({ where: { id: productId } })
    if (!product) {
      return errorResponse('Product not found', 404)
    }

    const existing = await prisma.wishlistItem.findUnique({
      where: { wishlistId_productId: { wishlistId: targetWishlistId, productId } },
    })
    if (existing) {
      return errorResponse('Product already in wishlist', 409)
    }

    const item = await prisma.wishlistItem.create({
      data: { wishlistId: targetWishlistId, productId },
      include: { product: true },
    })

    return successResponse(item, 201)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const user = await requireAuth()
    const { productId, wishlistId } = await request.json()

    if (!productId) {
      return errorResponse('Product ID is required', 400)
    }

    let targetWishlistId = wishlistId
    if (!targetWishlistId) {
      const wishlist = await getOrCreateDefaultWishlist(user.id)
      targetWishlistId = wishlist.id
    }

    const item = await prisma.wishlistItem.findFirst({
      where: { productId, wishlistId: targetWishlistId },
    })

    if (!item) {
      return errorResponse('Wishlist item not found', 404)
    }

    await prisma.wishlistItem.delete({ where: { id: item.id } })

    return successResponse({ message: 'Removed from wishlist' })
  } catch (error) {
    return handleApiError(error)
  }
}
