import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireAdmin, requireVendor, successResponse, errorResponse, handleApiError } from '@/lib/api'

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireVendor()
    const body = await request.json()
    const { status, trackingNumber, shippingCarrier, estimatedDelivery } = body

    const order = await prisma.order.findUnique({ where: { id: params.id } })
    if (!order) return errorResponse('Order not found', 404)

    // Verify ownership
    if (user.role !== 'ADMIN') {
      const vendor = await prisma.vendor.findUnique({ where: { ownerId: user.id } })
      if (!vendor || order.vendorId !== vendor.id) {
        return errorResponse('Access denied', 403)
      }
    }

    const validStatuses = ['PENDING', 'CONFIRMED', 'PROCESSING', 'SHIPPED', 'DELIVERED', 'CANCELLED', 'REFUNDED']
    if (status && !validStatuses.includes(status)) {
      return errorResponse('Invalid order status', 400)
    }

    const updateData: Record<string, unknown> = {}
    if (status) {
      updateData.status = status
      // Record status change
      await prisma.orderStatusHistory.create({
        data: {
          orderId: params.id,
          fromStatus: order.status,
          toStatus: status,
          changedBy: user.id,
        },
      })
    }
    if (trackingNumber) updateData.trackingNumber = trackingNumber
    if (shippingCarrier) updateData.shippingCarrier = shippingCarrier
    if (estimatedDelivery) updateData.estimatedDelivery = new Date(estimatedDelivery)

    const updated = await prisma.order.update({
      where: { id: params.id },
      data: updateData,
      include: {
        items: { include: { product: { select: { id: true, name: true, images: true } } } },
        user: { select: { id: true, name: true, email: true } },
        vendor: { select: { id: true, name: true } },
      },
    })

    return successResponse(updated)
  } catch (error) {
    return handleApiError(error)
  }
}
