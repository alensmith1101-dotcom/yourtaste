import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireAdmin, successResponse, errorResponse, handleApiError } from '@/lib/api'

export async function GET() {
  try {
    await requireAdmin()
    const settings = await prisma.languageConfig.findMany({ orderBy: { sortOrder: 'asc' } })
    const currencies = await prisma.currencyConfig.findMany()

    // Load site settings from DB
    const siteSettingsRows = await prisma.siteSetting.findMany()
    const siteSettings: Record<string, string> = {}
    for (const row of siteSettingsRows) {
      siteSettings[row.key] = row.value
    }

    return successResponse({
      languages: settings,
      currencies,
      siteSettings,
    })
  } catch (error) {
    return handleApiError(error)
  }
}

export async function PUT(request: NextRequest) {
  try {
    await requireAdmin()
    const body = await request.json()
    const { siteName, siteDescription, contactEmail, maintenanceMode, defaultCurrency, defaultLanguage } = body

    // Persist each setting to DB
    const settingsToSave: Record<string, string> = {}
    if (siteName !== undefined) settingsToSave.siteName = siteName
    if (siteDescription !== undefined) settingsToSave.siteDescription = siteDescription
    if (contactEmail !== undefined) settingsToSave.contactEmail = contactEmail
    if (maintenanceMode !== undefined) settingsToSave.maintenanceMode = String(maintenanceMode)
    if (defaultCurrency !== undefined) settingsToSave.defaultCurrency = defaultCurrency
    if (defaultLanguage !== undefined) settingsToSave.defaultLanguage = defaultLanguage

    await prisma.$transaction(
      Object.entries(settingsToSave).map(([key, value]) =>
        prisma.siteSetting.upsert({
          where: { key },
          update: { value },
          create: { key, value },
        })
      )
    )

    return successResponse({
      message: 'Settings updated successfully',
      settings: settingsToSave,
    })
  } catch (error) {
    return handleApiError(error)
  }
}
