import { NextRequest, NextResponse } from 'next/server'
import { requireAdmin } from '@/lib/api'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'

const faqSchema = z.object({
  id: z.string().optional(),
  question: z.string().min(1, 'Question required'),
  answer: z.string().min(1, 'Answer required'),
  category: z.string().default('general'),
  order: z.number().default(0),
  isActive: z.boolean().default(true),
})

export async function GET() {
  const admin = await requireAdmin()
  if (!admin) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const faqs = await prisma.faq.findMany({ orderBy: [{ category: 'asc' }, { order: 'asc' }] })
  return NextResponse.json({ faqs })
}

export async function POST(request: NextRequest) {
  const admin = await requireAdmin()
  if (!admin) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await request.json()
  const parsed = faqSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json({ error: parsed.error.errors[0].message }, { status: 400 })

  const faq = await prisma.faq.create({ data: parsed.data })
  return NextResponse.json({ faq })
}

export async function PUT(request: NextRequest) {
  const admin = await requireAdmin()
  if (!admin) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await request.json()
  const parsed = faqSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json({ error: parsed.error.errors[0].message }, { status: 400 })

  if (!parsed.data.id) return NextResponse.json({ error: 'FAQ ID required' }, { status: 400 })

  const faq = await prisma.faq.update({ where: { id: parsed.data.id }, data: parsed.data })
  return NextResponse.json({ faq })
}

export async function DELETE(request: NextRequest) {
  const admin = await requireAdmin()
  if (!admin) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { searchParams } = new URL(request.url)
  const id = searchParams.get('id')
  if (!id) return NextResponse.json({ error: 'FAQ ID required' }, { status: 400 })

  await prisma.faq.delete({ where: { id } })
  return NextResponse.json({ success: true })
}
