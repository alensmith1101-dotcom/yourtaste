import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireAuth, successResponse, errorResponse, handleApiError } from '@/lib/api'
import { addressSchema } from '@/lib/validations'

export async function GET() {
  try {
    const user = await requireAuth()

    const addresses = await prisma.address.findMany({
      where: { userId: user.id },
      orderBy: { isDefault: 'desc', createdAt: 'desc' },
    })

    return successResponse(addresses)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth()
    const body = await request.json()
    const validation = addressSchema.safeParse(body)

    if (!validation.success) {
      return errorResponse(validation.error.errors[0].message, 400)
    }

    const data = validation.data

    if (data.isDefault) {
      await prisma.address.updateMany({
        where: { userId: user.id, isDefault: true },
        data: { isDefault: false },
      })
    }

    const address = await prisma.address.create({
      data: { ...data, userId: user.id },
    })

    return successResponse(address, 201)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function PUT(request: NextRequest) {
  try {
    const user = await requireAuth()
    const body = await request.json()
    const { id, ...data } = body

    if (!id) {
      return errorResponse('Address ID is required', 400)
    }

    const validation = addressSchema.safeParse(data)
    if (!validation.success) {
      return errorResponse(validation.error.errors[0].message, 400)
    }

    const address = await prisma.address.findUnique({ where: { id } })
    if (!address || address.userId !== user.id) {
      return errorResponse('Address not found', 404)
    }

    if (validation.data.isDefault) {
      await prisma.address.updateMany({
        where: { userId: user.id, isDefault: true, id: { not: id } },
        data: { isDefault: false },
      })
    }

    const updated = await prisma.address.update({
      where: { id },
      data: validation.data,
    })

    return successResponse(updated)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const user = await requireAuth()
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return errorResponse('Address ID is required', 400)
    }

    const address = await prisma.address.findUnique({ where: { id } })
    if (!address || address.userId !== user.id) {
      return errorResponse('Address not found', 404)
    }

    await prisma.address.delete({ where: { id } })

    return successResponse({ message: 'Address deleted' })
  } catch (error) {
    return handleApiError(error)
  }
}
