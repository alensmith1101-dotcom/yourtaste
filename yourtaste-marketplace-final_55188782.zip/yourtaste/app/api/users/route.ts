import { NextRequest } from 'next/server'
import { hash } from 'bcryptjs'
import { prisma } from '@/lib/prisma'
import { registerSchema } from '@/lib/validations'
import { successResponse, errorResponse, handleApiError } from '@/lib/api'
import { rateLimiters, getClientIp } from '@/lib/rate-limit'
import { sanitizeText } from '@/lib/sanitize'
import { NotificationService } from '@/lib/notifications'

export async function POST(request: NextRequest) {
  try {
    const ip = getClientIp(request)
    const limit = await rateLimiters.auth(ip)
    if (!limit.success) return limit.response

    const body = await request.json()
    const validation = registerSchema.safeParse(body)

    if (!validation.success) {
      return errorResponse(validation.error.errors[0].message, 400)
    }

    const { name, email, password, phone } = validation.data

    const safeName = sanitizeText(name)
    const safeEmail = email.toLowerCase().trim()

    const existingUser = await prisma.user.findUnique({ where: { email: safeEmail } })
    if (existingUser) {
      return errorResponse('Email already registered', 409)
    }

    const hashedPassword = await hash(password, 10)

    const user = await prisma.user.create({
      data: {
        name: safeName,
        email: safeEmail,
        password: hashedPassword,
        phone: phone || null,
        role: 'CUSTOMER',
        wishlists: {
          create: {
            name: 'My Wishlist',
            isDefault: true,
          },
        },
      },
    })

    await NotificationService.createDefaultPreferences(user.id)

    const { password: _, ...userWithoutPassword } = user

    return successResponse(userWithoutPassword, 201)
  } catch (error) {
    return handleApiError(error)
  }
}
