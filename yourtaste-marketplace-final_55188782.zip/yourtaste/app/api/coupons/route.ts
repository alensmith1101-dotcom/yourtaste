import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireAuth, successResponse, errorResponse, handleApiError } from '@/lib/api'
import { CouponService } from '@/lib/coupons'
import { rateLimiters, getClientIp } from '@/lib/rate-limit'

export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth()
    const now = new Date()

    const coupons = await prisma.coupon.findMany({
      where: {
        isActive: true,
        OR: [
          { startsAt: null },
          { startsAt: { lte: now } },
        ],
        AND: [
          {
            OR: [
              { expiresAt: null },
              { expiresAt: { gte: now } },
            ],
          },
        ],
      },
      orderBy: { createdAt: 'desc' },
    })

    if (user.role === 'ADMIN') {
      return successResponse(coupons)
    }

    const sanitized = coupons.map((coupon) => ({
      code: coupon.code,
      type: coupon.type,
      discountValue: coupon.discountValue,
      minOrderValue: coupon.minOrderValue,
      expiresAt: coupon.expiresAt,
    }))

    return successResponse(sanitized)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function POST(request: NextRequest) {
  try {
    const ip = getClientIp(request)
    const limited = await rateLimiters.coupons(ip, 'coupons')
    if (!limited.success) return limited.response

    const user = await requireAuth()
    const { code, cartTotal, productIds, categoryIds, vendorId } = await request.json()

    if (!code) {
      return errorResponse('Coupon code is required', 400)
    }

    const result = await CouponService.validate({
      code,
      userId: user.id,
      orderTotal: cartTotal || 0,
      productIds,
      categoryIds,
      vendorId,
    })

    if (!result.valid) {
      return errorResponse(result.error || 'Invalid coupon', 400)
    }

    return successResponse({
      valid: true,
      code: result.coupon?.code,
      discount: result.discount,
      type: result.coupon?.type,
    })
  } catch (error) {
    return handleApiError(error)
  }
}
