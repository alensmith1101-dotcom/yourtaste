import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { MIN_PAYOUT_CENTS } from '@/lib/affiliate'

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const links = await prisma.affiliateLink.findMany({
    where: { userId: session.user.id },
  })

  const linkIds = links.map(l => l.id)

  const [totalClicks, totalConversions, totalCommission, conversions, payouts] = await Promise.all([
    prisma.affiliateLink.aggregate({
      where: { id: { in: linkIds } },
      _sum: { clicks: true },
    }),
    prisma.affiliateLink.aggregate({
      where: { id: { in: linkIds } },
      _sum: { conversions: true },
    }),
    prisma.affiliateLink.aggregate({
      where: { id: { in: linkIds } },
      _sum: { commissionEarned: true },
    }),
    prisma.affiliateConversion.findMany({
      where: { linkId: { in: linkIds } },
      orderBy: { createdAt: 'desc' },
      take: 20,
      include: {
        link: { select: { code: true } },
      },
    }),
    prisma.affiliateConversion.findMany({
      where: {
        linkId: { in: linkIds },
        status: 'PAID',
      },
      orderBy: { paidAt: 'desc' },
      take: 20,
    }),
  ])

  const totalEarned = totalCommission._sum.commissionEarned ?? 0
  const totalPaid = payouts.reduce((sum, p) => sum + p.commission, 0)
  const pendingPayout = totalEarned - totalPaid
  const canWithdraw = pendingPayout >= MIN_PAYOUT_CENTS

  const clicksByDay: Record<string, number> = {}
  const conversionsByDay: Record<string, number> = {}
  const last30 = new Date()
  last30.setDate(last30.getDate() - 30)

  for (let d = new Date(last30); d <= new Date(); d.setDate(d.getDate() + 1)) {
    const key = d.toISOString().split('T')[0]
    clicksByDay[key] = 0
    conversionsByDay[key] = 0
  }

  return NextResponse.json({
    totalClicks: totalClicks._sum.clicks ?? 0,
    totalConversions: totalConversions._sum.conversions ?? 0,
    totalEarned,
    totalPaid,
    pendingPayout,
    canWithdraw,
    minPayout: MIN_PAYOUT_CENTS,
    conversionRate: (totalClicks._sum.clicks ?? 0) > 0
      ? ((totalConversions._sum.conversions ?? 0) / (totalClicks._sum.clicks ?? 1)) * 100
      : 0,
    recentConversions: conversions,
    payoutHistory: payouts,
    activeLinks: links.filter(l => l.isActive).length,
  })
}
