import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { generateAffiliateCode } from '@/lib/affiliate'

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const links = await prisma.affiliateLink.findMany({
    where: { userId: session.user.id },
    orderBy: { createdAt: 'desc' },
  })

  return NextResponse.json({ links })
}

export async function POST(request: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const existingCount = await prisma.affiliateLink.count({
    where: { userId: session.user.id, isActive: true },
  })

  if (existingCount >= 5) {
    return NextResponse.json({ error: 'Maximum 5 active links allowed' }, { status: 400 })
  }

  let code = generateAffiliateCode()
  let attempts = 0
  while (attempts < 5) {
    const existing = await prisma.affiliateLink.findUnique({ where: { code } })
    if (!existing) break
    code = generateAffiliateCode()
    attempts++
  }

  const link = await prisma.affiliateLink.create({
    data: {
      userId: session.user.id,
      code,
    },
  })

  return NextResponse.json({ link }, { status: 201 })
}
