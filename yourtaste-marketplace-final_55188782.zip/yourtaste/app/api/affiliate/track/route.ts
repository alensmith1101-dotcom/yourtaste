import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function POST(request: NextRequest) {
  try {
    const { code } = await request.json()
    if (!code || typeof code !== 'string') {
      return NextResponse.json({ error: 'Invalid code' }, { status: 400 })
    }

    const link = await prisma.affiliateLink.findUnique({
      where: { code: code.toUpperCase() },
    })

    if (!link || !link.isActive) {
      return NextResponse.json({ error: 'Invalid referral code' }, { status: 404 })
    }

    await prisma.affiliateLink.update({
      where: { id: link.id },
      data: { clicks: { increment: 1 } },
    })

    const response = NextResponse.json({ success: true })

    response.cookies.set('yt_ref', code.toUpperCase(), {
      maxAge: 30 * 24 * 60 * 60,
      path: '/',
      sameSite: 'lax',
      secure: process.env.NODE_ENV === 'production',
    })

    return response
  } catch {
    return NextResponse.json({ error: 'Failed to track click' }, { status: 500 })
  }
}
