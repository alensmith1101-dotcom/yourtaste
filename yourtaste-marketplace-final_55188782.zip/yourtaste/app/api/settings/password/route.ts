import { NextRequest } from 'next/server'
import { hash, compare } from 'bcryptjs'
import { prisma } from '@/lib/prisma'
import { requireAuth, successResponse, errorResponse, handleApiError } from '@/lib/api'

export async function PUT(request: NextRequest) {
  try {
    const user = await requireAuth()
    const { currentPassword, newPassword } = await request.json()

    if (!currentPassword || !newPassword) {
      return errorResponse('Current password and new password are required', 400)
    }

    if (newPassword.length < 8) {
      return errorResponse('New password must be at least 8 characters', 400)
    }

    const dbUser = await prisma.user.findUnique({ where: { id: user.id } })
    if (!dbUser || !dbUser.password) {
      return errorResponse('Account has no password set', 400)
    }

    const isValid = await compare(currentPassword, dbUser.password)
    if (!isValid) {
      return errorResponse('Current password is incorrect', 401)
    }

    const hashedPassword = await hash(newPassword, 10)

    await prisma.user.update({
      where: { id: user.id },
      data: { password: hashedPassword },
    })

    return successResponse({ message: 'Password updated successfully' })
  } catch (error) {
    return handleApiError(error)
  }
}
