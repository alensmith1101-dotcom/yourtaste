import { NextRequest } from 'next/server'
import { z } from 'zod'
import { prisma } from '@/lib/prisma'
import { requireAuth, successResponse, errorResponse, handleApiError } from '@/lib/api'

const addToCartSchema = z.object({ productId: z.string().min(1), quantity: z.number().int().min(1).max(99).default(1), variantId: z.string().optional() })
const updateCartSchema = z.object({ itemId: z.string().min(1), quantity: z.number().int().min(0).max(99) })

export async function GET() {
  try {
    const user = await requireAuth()

    const cartItems = await prisma.cartItem.findMany({
      where: { userId: user.id },
      include: {
        product: {
          include: {
            vendor: { select: { id: true, name: true } },
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    })

    return successResponse(cartItems)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth()
    const body = await request.json()
    const parsed = addToCartSchema.safeParse(body)
    if (!parsed.success) {
      return errorResponse(parsed.error.errors[0].message, 400)
    }
    const { productId, quantity } = parsed.data

    const product = await prisma.product.findUnique({ where: { id: productId } })
    if (!product) {
      return errorResponse('Product not found', 404)
    }

    if (!product.isActive || !product.isPublished) {
      return errorResponse('Product is not available', 400)
    }

    if (product.stockQuantity < quantity) {
      return errorResponse('Insufficient stock', 400)
    }

    const existing = await prisma.cartItem.findUnique({
      where: { userId_productId: { userId: user.id, productId } },
    })

    if (existing) {
      const newQuantity = existing.quantity + quantity
      if (newQuantity > product.stockQuantity) {
        return errorResponse('Insufficient stock', 400)
      }

      const updated = await prisma.cartItem.update({
        where: { id: existing.id },
        data: { quantity: newQuantity },
        include: { product: true },
      })

      return successResponse(updated)
    }

    const cartItem = await prisma.cartItem.create({
      data: { userId: user.id, productId, quantity },
      include: { product: true },
    })

    return successResponse(cartItem, 201)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function PUT(request: NextRequest) {
  try {
    const user = await requireAuth()
    const body = await request.json()
    const parsed = updateCartSchema.safeParse(body)
    if (!parsed.success) {
      return errorResponse(parsed.error.errors[0].message, 400)
    }
    const { itemId, quantity } = parsed.data

    if (quantity < 1) {
      return errorResponse('Quantity must be at least 1', 400)
    }

    const cartItem = await prisma.cartItem.findUnique({
      where: { id: itemId },
      include: { product: true },
    })

    if (!cartItem || cartItem.userId !== user.id) {
      return errorResponse('Cart item not found', 404)
    }

    if (quantity > cartItem.product.stockQuantity) {
      return errorResponse('Insufficient stock', 400)
    }

    const updated = await prisma.cartItem.update({
      where: { id: itemId },
      data: { quantity },
      include: { product: true },
    })

    return successResponse(updated)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const user = await requireAuth()
    const { cartItemId } = await request.json()

    if (!cartItemId) {
      return errorResponse('Cart item ID is required', 400)
    }

    const cartItem = await prisma.cartItem.findUnique({ where: { id: cartItemId } })
    if (!cartItem || cartItem.userId !== user.id) {
      return errorResponse('Cart item not found', 404)
    }

    await prisma.cartItem.delete({ where: { id: cartItemId } })

    return successResponse({ message: 'Item removed from cart' })
  } catch (error) {
    return handleApiError(error)
  }
}
