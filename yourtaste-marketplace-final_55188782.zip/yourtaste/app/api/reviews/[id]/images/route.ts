import { NextRequest } from 'next/server'
import { requireAuth, successResponse, errorResponse, handleApiError } from '@/lib/api'
import { uploadImage, deleteImage } from '@/lib/cloudinary'
import { prisma } from '@/lib/prisma'
import { rateLimiters, getClientIp } from '@/lib/rate-limit'

const MAX_FILE_SIZE = 5 * 1024 * 1024
const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif']
const MAX_IMAGES_PER_REVIEW = 5

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireAuth()

    const ip = getClientIp(request)
    const limit = await rateLimiters.upload(ip)
    if (!limit.success) return limit.response

    const review = await prisma.review.findUnique({
      where: { id: params.id },
      include: { images: true },
    })

    if (!review) {
      return errorResponse('Review not found', 404)
    }

    if (review.userId !== user.id && user.role !== 'ADMIN') {
      return errorResponse('Not authorized to modify this review', 403)
    }

    if (review.images.length >= MAX_IMAGES_PER_REVIEW) {
      return errorResponse(`Maximum ${MAX_IMAGES_PER_REVIEW} images allowed per review`, 400)
    }

    const formData = await request.formData()
    const file = formData.get('file') as File | null

    if (!file) {
      return errorResponse('No file provided', 400)
    }

    if (!ALLOWED_TYPES.includes(file.type)) {
      return errorResponse('Invalid file type. Allowed: JPEG, PNG, WebP, GIF', 400)
    }

    if (file.size > MAX_FILE_SIZE) {
      return errorResponse('File too large. Maximum size is 5MB', 400)
    }

    const buffer = Buffer.from(await file.arrayBuffer())
    const base64 = `data:${file.type};base64,${buffer.toString('base64')}`

    const result = await uploadImage(base64, 'yourtaste/reviews')

    const reviewImage = await prisma.reviewImage.create({
      data: {
        reviewId: params.id,
        url: result.url,
      },
    })

    return successResponse({
      id: reviewImage.id,
      url: reviewImage.url,
      createdAt: reviewImage.createdAt,
    }, 201)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function GET(
  _request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const images = await prisma.reviewImage.findMany({
      where: { reviewId: params.id },
      orderBy: { createdAt: 'asc' },
    })

    return successResponse(images)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireAuth()

    const review = await prisma.review.findUnique({
      where: { id: params.id },
    })

    if (!review) {
      return errorResponse('Review not found', 404)
    }

    if (review.userId !== user.id && user.role !== 'ADMIN') {
      return errorResponse('Not authorized to modify this review', 403)
    }

    const { imageId } = await request.json()

    if (!imageId) {
      return errorResponse('Image ID required', 400)
    }

    const image = await prisma.reviewImage.findUnique({
      where: { id: imageId },
    })

    if (!image || image.reviewId !== params.id) {
      return errorResponse('Image not found', 404)
    }

    const publicId = image.url.split('/').pop()?.split('.')[0]
    if (publicId) {
      try {
        await deleteImage(`yourtaste/reviews/${publicId}`)
      } catch (err) {
        console.error('Failed to delete from Cloudinary:', err)
      }
    }

    await prisma.reviewImage.delete({
      where: { id: imageId },
    })

    return successResponse({ deleted: true })
  } catch (error) {
    return handleApiError(error)
  }
}
