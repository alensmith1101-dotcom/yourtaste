import { NextRequest } from 'next/server'
import { requireAuth, successResponse, errorResponse, handleApiError } from '@/lib/api'
import { savePushSubscription, removePushSubscription } from '@/lib/web-push'

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth()
    const body = await request.json()

    const { subscription } = body as {
      subscription?: {
        endpoint: string
        keys: { p256dh: string; auth: string }
      }
    }

    if (!subscription?.endpoint || !subscription?.keys?.p256dh || !subscription?.keys?.auth) {
      return errorResponse('Invalid push subscription object', 400)
    }

    const userAgent = request.headers.get('user-agent') ?? undefined

    const saved = await savePushSubscription(user.id, subscription, userAgent)

    return successResponse(saved, 201)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function DELETE(request: NextRequest) {
  try {
    await requireAuth()
    const { searchParams } = new URL(request.url)
    const endpoint = searchParams.get('endpoint')

    if (!endpoint) {
      return errorResponse('Endpoint query parameter is required', 400)
    }

    await removePushSubscription(endpoint)

    return successResponse({ message: 'Subscription removed' })
  } catch (error) {
    return handleApiError(error)
  }
}
