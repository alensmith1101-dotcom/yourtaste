import { NextRequest } from 'next/server'
import { requireRole, successResponse, errorResponse, handleApiError } from '@/lib/api'
import { sendPushToUser, sendPushToMany, type PushPayload } from '@/lib/web-push'
import { prisma } from '@/lib/prisma'

export async function POST(request: NextRequest) {
  try {
    const user = await requireRole('ADMIN', 'VENDOR')
    const body = await request.json()

    const { userId, userIds, title, body: message, url, icon, tag, data } = body as {
      userId?: string
      userIds?: string[]
      title?: string
      body?: string
      url?: string
      icon?: string
      tag?: string
      data?: Record<string, unknown>
    }

    if (!title || !message) {
      return errorResponse('Title and body are required', 400)
    }

    const payload: PushPayload = {
      title,
      body: message,
      url: url ?? '/',
      icon: icon ?? '/icons/icon-192x192.png',
      tag,
      data,
    }

    if (user.role === 'VENDOR') {
      const vendor = await prisma.vendor.findUnique({
        where: { ownerId: user.id },
        select: { id: true },
      })

      if (!vendor) {
        return errorResponse('Vendor profile not found', 404)
      }

      const targetIds = userId ? [userId] : userIds ?? []
      if (targetIds.length === 0) {
        return errorResponse('At least one userId is required', 400)
      }

      const orders = await prisma.order.findMany({
        where: {
          vendorId: vendor.id,
          userId: { in: targetIds },
        },
        select: { userId: true },
        distinct: ['userId'],
      })

      const allowedUserIds = new Set(orders.map((o) => o.userId))
      const validIds = targetIds.filter((id) => allowedUserIds.has(id))

      if (validIds.length === 0) {
        return errorResponse('No valid recipients found for your store', 400)
      }

      await sendPushToMany(validIds, payload)
      return successResponse({ sent: validIds.length })
    }

    if (userIds && userIds.length > 0) {
      await sendPushToMany(userIds, payload)
      return successResponse({ sent: userIds.length })
    }

    if (userId) {
      await sendPushToUser(userId, payload)
      return successResponse({ sent: 1 })
    }

    const allUsers = await prisma.pushSubscription.findMany({
      where: { isActive: true },
      select: { userId: true },
      distinct: ['userId'],
    })

    const allUserIds = allUsers.map((s) => s.userId)
    await sendPushToMany(allUserIds, payload)
    return successResponse({ sent: allUserIds.length })
  } catch (error) {
    return handleApiError(error)
  }
}
