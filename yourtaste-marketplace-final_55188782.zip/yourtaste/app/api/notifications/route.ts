import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireAuth, successResponse, errorResponse, paginatedResponse, handleApiError } from '@/lib/api'

export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth()
    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '20')
    const unreadOnly = searchParams.get('unreadOnly') === 'true'
    const skip = (page - 1) * limit

    const where: Record<string, unknown> = { userId: user.id }
    if (unreadOnly) where.isRead = false

    const [notifications, total, unreadCount] = await Promise.all([
      prisma.notification.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      prisma.notification.count({ where }),
      prisma.notification.count({ where: { userId: user.id, isRead: false } }),
    ])

    return paginatedResponse(notifications, total, page, limit)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth()
    const { notificationId } = await request.json()

    if (!notificationId) {
      return errorResponse('Notification ID is required', 400)
    }

    const notification = await prisma.notification.findUnique({
      where: { id: notificationId },
    })

    if (!notification || notification.userId !== user.id) {
      return errorResponse('Notification not found', 404)
    }

    const updated = await prisma.notification.update({
      where: { id: notificationId },
      data: { isRead: true, readAt: new Date() },
    })

    return successResponse(updated)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function PUT(request: NextRequest) {
  try {
    const user = await requireAuth()
    const { markAllRead } = await request.json()

    if (markAllRead) {
      const result = await prisma.notification.updateMany({
        where: { userId: user.id, isRead: false },
        data: { isRead: true, readAt: new Date() },
      })

      return successResponse({ count: result.count, message: `${result.count} notifications marked as read` })
    }

    return errorResponse('Invalid request', 400)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const user = await requireAuth()
    const { notificationId } = await request.json()

    if (!notificationId) {
      return errorResponse('Notification ID is required', 400)
    }

    const notification = await prisma.notification.findUnique({
      where: { id: notificationId },
    })

    if (!notification || notification.userId !== user.id) {
      return errorResponse('Notification not found', 404)
    }

    await prisma.notification.delete({ where: { id: notificationId } })

    return successResponse({ message: 'Notification deleted' })
  } catch (error) {
    return handleApiError(error)
  }
}
