import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireAuth, successResponse, errorResponse, handleApiError } from '@/lib/api'

const DEFAULT_PREFS = {
  emailOrderUpdates: true,
  emailPromotions: false,
  emailNewsletter: true,
  pushOrderUpdates: true,
  pushDeals: true,
  pushPriceDrops: true,
  smsOrderUpdates: true,
}

const ALLOWED_FIELDS = Object.keys(DEFAULT_PREFS) as (keyof typeof DEFAULT_PREFS)[]

export async function GET() {
  try {
    const user = await requireAuth()

    let prefs = await prisma.notificationPreference.findUnique({
      where: { userId: user.id },
    })

    if (!prefs) {
      prefs = await prisma.notificationPreference.create({
        data: {
          userId: user.id,
          ...DEFAULT_PREFS,
        },
      })
    }

    return successResponse(prefs)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function PUT(request: NextRequest) {
  try {
    const user = await requireAuth()
    const body = await request.json()

    const updates: Record<string, boolean> = {}
    for (const key of ALLOWED_FIELDS) {
      if (key in body) {
        if (typeof body[key] !== 'boolean') {
          return errorResponse(`${key} must be a boolean`, 400)
        }
        updates[key] = body[key]
      }
    }

    if (Object.keys(updates).length === 0) {
      return errorResponse('No valid fields to update', 400)
    }

    const prefs = await prisma.notificationPreference.upsert({
      where: { userId: user.id },
      update: updates,
      create: {
        userId: user.id,
        ...DEFAULT_PREFS,
        ...updates,
      },
    })

    return successResponse(prefs)
  } catch (error) {
    return handleApiError(error)
  }
}
