import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import Stripe from 'stripe'
import Razorpay from 'razorpay'
import crypto from 'crypto'
import { CouponService } from '@/lib/coupons'

function getStripe() {
  const key = process.env.STRIPE_SECRET_KEY
  if (!key) {
    throw new Error('STRIPE_SECRET_KEY environment variable is not set')
  }
  return new Stripe(key)
}

const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET || ''
const razorpayWebhookSecret = process.env.RAZORPAY_WEBHOOK_SECRET || ''

function verifyRazorpayWebhookSignature(body: string, signature: string): boolean {
  if (!razorpayWebhookSecret) return false
  const expectedSignature = crypto
    .createHmac('sha256', razorpayWebhookSecret)
    .update(body)
    .digest('hex')
  return expectedSignature === signature
}

async function handleRazorpayWebhook(event: any) {
  const payload = event.payload
  const paymentEntity = payload?.payment?.entity

  if (!paymentEntity) {
    console.error('[Razorpay Webhook] No payment entity in payload')
    return
  }

  const orderId = paymentEntity.notes?.orderId
  if (!orderId) {
    console.error('[Razorpay Webhook] No orderId in payment notes')
    return
  }

  switch (event.event) {
    case 'payment.authorized': {
      const order = await prisma.order.findUnique({ where: { id: orderId } })
      if (!order || order.paymentStatus === 'PAID') break

      await prisma.$transaction(async (tx) => {
        await tx.order.update({
          where: { id: orderId },
          data: { paymentStatus: 'PAID', status: 'CONFIRMED' },
        })

        const orderItems = await tx.orderItem.findMany({ where: { orderId } })
        for (const item of orderItems) {
          await tx.product.update({
            where: { id: item.productId },
            data: { stockQuantity: { decrement: item.quantity } },
          })
        }
      })

      if (order) {
        try {
          await CouponService.earnPointsFromOrder(order.userId, order.id, order.total / 100)
        } catch (err) {
          console.error('[Razorpay Webhook] Failed to award loyalty points:', err)
        }
      }

      console.error(`[Razorpay Webhook] Payment authorized for order ${orderId}`)
      break
    }

    case 'payment.captured': {
      await prisma.order.update({
        where: { id: orderId },
        data: { paymentStatus: 'PAID', status: 'CONFIRMED' },
      }).catch(() => {})
      console.error(`[Razorpay Webhook] Payment captured for order ${orderId}`)
      break
    }

    case 'payment.failed': {
      await prisma.order.update({
        where: { id: orderId },
        data: { paymentStatus: 'FAILED' },
      }).catch(() => {})
      console.error(`[Razorpay Webhook] Payment failed for order ${orderId}`)
      break
    }

    default:
      console.error(`[Razorpay Webhook] Unhandled event: ${event.event}`)
  }
}

export async function POST(request: NextRequest) {
  const body = await request.text()
  const signature = request.headers.get('x-razorpay-signature')
  const stripeSignature = request.headers.get('stripe-signature')

  if (signature && razorpayWebhookSecret) {
    const isValid = verifyRazorpayWebhookSignature(body, signature)
    if (!isValid) {
      return new Response(JSON.stringify({ error: 'Invalid Razorpay signature' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' },
      })
    }

    let event: any
    try {
      event = JSON.parse(body)
    } catch {
      return new Response(JSON.stringify({ error: 'Invalid JSON body' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' },
      })
    }

    const existing = await prisma.webhookEvent.findUnique({
      where: { eventId: `rzp_${event.id || event.event}_${Date.now()}` },
    }).catch(() => null)

    if (existing) {
      return new Response(JSON.stringify({ received: true, duplicate: true }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' },
      })
    }

    try {
      await handleRazorpayWebhook(event)

      await prisma.webhookEvent.create({
        data: {
          eventId: `rzp_${event.id || event.event}_${Date.now()}`,
          eventType: event.event || 'razorpay_webhook',
          data: JSON.stringify({ id: event.id, event: event.event }),
        },
      })

      return new Response(JSON.stringify({ received: true }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' },
      })
    } catch (error) {
      console.error('[Razorpay Webhook] Error processing event:', error)
      return new Response(JSON.stringify({ error: 'Webhook processing failed' }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' },
      })
    }
  }

  if (stripeSignature) {
    if (!signature) {
      // Stripe-only path
    }

    if (!stripeSignature) {
      return new Response(JSON.stringify({ error: 'Missing signature' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' },
      })
    }

    let event: Stripe.Event
    try {
      event = getStripe().webhooks.constructEvent(body, stripeSignature, webhookSecret)
    } catch (err) {
      console.error('Stripe webhook signature verification failed:', err)
      return new Response(JSON.stringify({ error: 'Invalid signature' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' },
      })
    }

    const existing = await prisma.webhookEvent.findUnique({
      where: { eventId: event.id },
    })
    if (existing) {
      return new Response(JSON.stringify({ received: true, duplicate: true }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' },
      })
    }

    try {
      switch (event.type) {
        case 'payment_intent.succeeded': {
          const paymentIntent = event.data.object as Stripe.PaymentIntent
          const orderId = paymentIntent.metadata.orderId

          if (orderId) {
            const order = await prisma.order.findUnique({ where: { id: orderId } })

            await prisma.$transaction(async (tx) => {
              await tx.order.update({
                where: { id: orderId },
                data: { paymentStatus: 'PAID', status: 'CONFIRMED' },
              })

              const orderItems = await tx.orderItem.findMany({ where: { orderId } })
              for (const item of orderItems) {
                await tx.product.update({
                  where: { id: item.productId },
                  data: { stockQuantity: { decrement: item.quantity } },
                })
              }
            })

            if (order) {
              try {
                await CouponService.earnPointsFromOrder(order.userId, order.id, order.total / 100)
              } catch (err) {
                console.error('[Webhook] Failed to award loyalty points:', err)
              }
            }

            console.error(`[Webhook] Payment successful for order ${orderId}`)
          }
          break
        }

        case 'payment_intent.payment_failed': {
          const paymentIntent = event.data.object as Stripe.PaymentIntent
          const orderId = paymentIntent.metadata.orderId
          if (orderId) {
            await prisma.order.update({
              where: { id: orderId },
              data: { paymentStatus: 'FAILED' },
            })
            console.error(`[Webhook] Payment failed for order ${orderId}`)
          }
          break
        }

        case 'charge.refunded': {
          const charge = event.data.object as Stripe.Charge
          const orderId = charge.metadata?.orderId
          if (orderId) {
            const order = await prisma.order.findFirst({ where: { id: orderId } })
            if (order) {
              await prisma.order.update({
                where: { id: order.id },
                data: { paymentStatus: 'REFUNDED', status: 'REFUNDED' },
              })
            }
          }
          break
        }

        case 'charge.dispute.created': {
          console.error('[Webhook] Dispute created - handler not implemented')
          break
        }

        case 'charge.dispute.closed': {
          console.error('[Webhook] Dispute closed - handler not implemented')
          break
        }

        case 'payment_intent.canceled': {
          console.error('[Webhook] Payment intent canceled - handler not implemented')
          break
        }

        default:
          console.error(`[Webhook] Unhandled event type: ${event.type}`)
      }

      await prisma.webhookEvent.create({
        data: {
          eventId: event.id,
          eventType: event.type,
          data: JSON.stringify({ id: event.id, type: event.type }),
        },
      })

      return new Response(JSON.stringify({ received: true }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' },
      })
    } catch (error) {
      console.error('[Webhook] Error processing event:', error)
      return new Response(JSON.stringify({ error: 'Webhook processing failed' }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' },
      })
    }
  }

  return new Response(JSON.stringify({ error: 'No valid webhook signature found' }), {
    status: 400,
    headers: { 'Content-Type': 'application/json' },
  })
}
