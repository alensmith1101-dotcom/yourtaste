import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import Razorpay from 'razorpay'
import { rateLimiters, getClientIp } from '@/lib/rate-limit'
import crypto from 'crypto'

function getRazorpay(): Razorpay {
  const keyId = process.env.RAZORPAY_KEY_ID
  const keySecret = process.env.RAZORPAY_KEY_SECRET
  if (!keyId || !keySecret) {
    throw new Error('Razorpay credentials are not configured')
  }
  return new Razorpay({ key_id: keyId, key_secret: keySecret })
}

export async function POST(request: NextRequest) {
  const ip = getClientIp(request)
  const limited = await rateLimiters.api(ip, 'razorpay-order')
  if (!limited.success) return limited.response

  const session = await getServerSession(authOptions)
  if (!session?.user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  try {
    const { orderId, method } = await request.json()

    if (!orderId) {
      return NextResponse.json({ error: 'Order ID is required' }, { status: 400 })
    }

    const validMethods = ['upi', 'wallet', 'card', 'netbanking']
    const paymentMethod = method || 'upi'
    if (!validMethods.includes(paymentMethod)) {
      return NextResponse.json({ error: 'Invalid payment method' }, { status: 400 })
    }

    const order = await prisma.order.findFirst({
      where: { id: orderId, userId: session.user.id },
      include: { items: true },
    })

    if (!order) {
      return NextResponse.json({ error: 'Order not found' }, { status: 404 })
    }

    if (order.paymentStatus === 'PAID') {
      return NextResponse.json({ error: 'Order already paid' }, { status: 400 })
    }

    const razorpay = getRazorpay()

    const razorpayOrder = await razorpay.orders.create({
      amount: order.total,
      currency: 'INR',
      receipt: `order_${order.orderNumber}`,
      payment_capture: true,
      notes: {
        orderId: order.id,
        orderNumber: order.orderNumber,
        userId: session.user.id,
        userEmail: session.user.email || '',
        method: paymentMethod,
      },
    })

    await prisma.order.update({
      where: { id: orderId },
      data: {
        paymentStatus: 'PROCESSING',
        paymentMethod: paymentMethod === 'upi' ? 'UPI' : paymentMethod === 'wallet' ? 'WALLET' : paymentMethod.toUpperCase(),
      },
    })

    const rzpOrder = razorpayOrder as any

    return NextResponse.json({
      orderId: rzpOrder.id,
      amount: rzpOrder.amount,
      currency: rzpOrder.currency,
      keyId: process.env.RAZORPAY_KEY_ID,
      orderDbId: order.id,
      receipt: rzpOrder.receipt,
    })
  } catch (error) {
    console.error('Razorpay order creation error:', error)
    return NextResponse.json(
      { error: 'Failed to create Razorpay order' },
      { status: 500 }
    )
  }
}
