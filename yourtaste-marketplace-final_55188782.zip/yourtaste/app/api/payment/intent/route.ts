import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireAuth, successResponse, errorResponse, handleApiError } from '@/lib/api'
import Stripe from 'stripe'

function getStripe() {
  const key = process.env.STRIPE_SECRET_KEY
  if (!key) {
    throw new Error('STRIPE_SECRET_KEY environment variable is not set')
  }
  return new Stripe(key)
}

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth()
    const { orderId } = await request.json()

    if (!orderId) {
      return errorResponse('Order ID is required', 400)
    }

    const order = await prisma.order.findUnique({
      where: { id: orderId },
      include: { items: { include: { product: true } } },
    })

    if (!order) {
      return errorResponse('Order not found', 404)
    }

    if (order.userId !== user.id && user.role !== 'ADMIN') {
      return errorResponse('Not authorized to pay for this order', 403)
    }

    if (order.paymentStatus === 'COMPLETED' || order.paymentStatus === 'PAID') {
      return errorResponse('Order is already paid', 400)
    }

    if (order.status === 'CANCELLED') {
      return errorResponse('Order has been cancelled', 400)
    }

    const amountCents = Math.round(order.total * 100)

    if (amountCents <= 0) {
      return errorResponse('Invalid order total', 400)
    }

    const paymentIntent = await getStripe().paymentIntents.create({
      amount: amountCents,
      currency: 'usd',
      metadata: {
        orderId: order.id,
        orderNumber: order.orderNumber || order.id,
        userId: user.id,
      },
      receipt_email: user.email!,
    })

    await prisma.order.update({
      where: { id: order.id },
      data: { paymentStatus: 'PROCESSING' },
    })

    return successResponse({
      clientSecret: paymentIntent.client_secret,
      paymentIntentId: paymentIntent.id,
      amount: amountCents,
    })
  } catch (error) {
    return handleApiError(error)
  }
}
