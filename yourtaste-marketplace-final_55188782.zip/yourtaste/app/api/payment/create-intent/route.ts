import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import Stripe from 'stripe'
import { rateLimiters, getClientIp } from '@/lib/rate-limit'

function getStripe() {
  const key = process.env.STRIPE_SECRET_KEY
  if (!key) {
    throw new Error('STRIPE_SECRET_KEY environment variable is not set')
  }
  return new Stripe(key)
}

export async function POST(request: NextRequest) {
  const ip = getClientIp(request)
  const limited = await rateLimiters.api(ip, 'create-intent')
  if (!limited.success) return limited.response

  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  try {
    const { orderId } = await request.json()
    if (!orderId) return NextResponse.json({ error: 'Order ID required' }, { status: 400 })

    const order = await prisma.order.findFirst({
      where: { id: orderId, userId: session.user.id },
      include: { items: true },
    })
    if (!order) return NextResponse.json({ error: 'Order not found' }, { status: 404 })
    if (order.paymentStatus === 'PAID') return NextResponse.json({ error: 'Order already paid' }, { status: 400 })

    const stripe = getStripe()
    const paymentIntent = await stripe.paymentIntents.create({
      amount: order.total,
      currency: 'inr', // Default to INR
      metadata: { orderId: order.id, userId: session.user.id },
    })

    return NextResponse.json({ clientSecret: paymentIntent.client_secret, orderId: order.id })
  } catch (error) {
    console.error('Payment intent error:', error)
    return NextResponse.json({ error: 'Failed to create payment intent' }, { status: 500 })
  }
}
