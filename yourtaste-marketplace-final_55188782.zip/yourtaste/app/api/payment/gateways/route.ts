import { successResponse, handleApiError } from '@/lib/api'

export async function GET() {
  try {
    const gateways = [
      { id: 'stripe', name: 'Credit/Debit Card', enabled: true },
      { id: 'razorpay', name: 'UPI / Net Banking', enabled: true },
      { id: 'cod', name: 'Cash on Delivery', enabled: true },
    ]

    return successResponse(gateways)
  } catch (error) {
    return handleApiError(error)
  }
}
