import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireVendor, successResponse, errorResponse, paginatedResponse, handleApiError } from '@/lib/api'
import { productSchema } from '@/lib/validations'
import { rateLimiters, getClientIp } from '@/lib/rate-limit'

export async function GET(request: NextRequest) {
  try {
    const ip = getClientIp(request)
    const limited = await rateLimiters.api(ip, 'products')
    if (!limited.success) return limited.response

    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '20')
    const search = searchParams.get('search') || ''
    const categoryId = searchParams.get('categoryId')
    const vendorId = searchParams.get('vendorId')
    const minPrice = searchParams.get('minPrice')
    const maxPrice = searchParams.get('maxPrice')
    const sortBy = searchParams.get('sortBy') || 'createdAt'
    const sortOrder = searchParams.get('sortOrder') || 'desc'

    const skip = (page - 1) * limit

    const where: Record<string, unknown> = {
      isPublished: true,
      isActive: true,
    }

    if (search) {
      where.OR = [
        { name: { contains: search } },
        { description: { contains: search } },
      ]
    }

    if (categoryId) where.categoryId = categoryId
    if (vendorId) where.vendorId = vendorId

    if (minPrice || maxPrice) {
      const priceCondition: Record<string, number> = {}
      if (minPrice) priceCondition.gte = parseInt(minPrice)
      if (maxPrice) priceCondition.lte = parseInt(maxPrice)
      where.priceCents = priceCondition
    }

    const validSortFields = ['createdAt', 'priceCents', 'name', 'averageRating']
    const orderField = validSortFields.includes(sortBy) ? sortBy : 'createdAt'
    const order = sortOrder === 'asc' ? 'asc' : 'desc'

    const [products, total] = await Promise.all([
      prisma.product.findMany({
        where,
        include: {
          vendor: { select: { id: true, name: true, slug: true } },
          category: { select: { id: true, name: true, slug: true } },
        },
        orderBy: { [orderField]: order },
        skip,
        take: limit,
      }),
      prisma.product.count({ where }),
    ])

    return paginatedResponse(products, total, page, limit)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await requireVendor()
    const body = await request.json()
    const validation = productSchema.safeParse(body)

    if (!validation.success) {
      return errorResponse(validation.error.errors[0].message, 400)
    }

    const data = validation.data

    const vendor = await prisma.vendor.findUnique({ where: { ownerId: user.id } })
    if (!vendor) {
      return errorResponse('Vendor profile not found', 404)
    }

    const existingSku = await prisma.product.findUnique({ where: { sku: data.sku } })
    if (existingSku) {
      return errorResponse('SKU already exists', 409)
    }

    const slug = data.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') + '-' + Date.now()

    const product = await prisma.product.create({
      data: {
        name: data.name,
        slug,
        description: data.description,
        priceCents: data.priceCents,
        originalPriceCents: data.originalPriceCents,
        currency: data.currency,
        sku: data.sku,
        stockQuantity: data.stockQuantity,
        images: JSON.stringify(data.images),
        tags: JSON.stringify(data.tags),
        isActive: data.isActive,
        isPublished: data.isPublished,
        categoryId: data.categoryId,
        vendorId: vendor.id,
      },
      include: {
        vendor: { select: { id: true, name: true } },
        category: true,
      },
    })

    return successResponse(product, 201)
  } catch (error) {
    return handleApiError(error)
  }
}
