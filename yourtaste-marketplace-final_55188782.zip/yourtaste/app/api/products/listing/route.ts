import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

const PAGE_SIZE = 12

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const page = Math.max(1, parseInt(searchParams.get('page') || '1'))
  const search = searchParams.get('search') || ''
  const category = searchParams.get('category') || ''
  const sort = searchParams.get('sort') || 'newest'
  const minPrice = searchParams.get('minPrice') ? parseInt(searchParams.get('minPrice')!) : undefined
  const maxPrice = searchParams.get('maxPrice') ? parseInt(searchParams.get('maxPrice')!) : undefined
  const minRating = searchParams.get('minRating') ? parseFloat(searchParams.get('minRating')!) : undefined
  const vendorSlugs = searchParams.get('vendor')?.split(',').filter(Boolean) || []

  function getOrderBy(sort: string) {
    switch (sort) {
      case 'price_asc':
        return { priceCents: 'asc' as const }
      case 'price_desc':
        return { priceCents: 'desc' as const }
      case 'rating':
        return { averageRating: 'desc' as const }
      case 'popularity':
        return { totalReviews: 'desc' as const }
      default:
        return { createdAt: 'desc' as const }
    }
  }

  const where: Record<string, unknown> = {
    isActive: true,
    isPublished: true,
  }

  if (search) {
    where.OR = [
      { name: { contains: search } },
      { description: { contains: search } },
    ]
  }

  if (category) {
    where.category = { slug: category }
  }

  if (minPrice !== undefined) {
    where.priceCents = { ...(where.priceCents as Record<string, number> || {}), gte: minPrice * 100 }
  }

  if (maxPrice !== undefined) {
    where.priceCents = { ...(where.priceCents as Record<string, number> || {}), lte: maxPrice * 100 }
  }

  if (minRating !== undefined) {
    where.averageRating = { gte: minRating }
  }

  if (vendorSlugs.length > 0) {
    where.vendor = { slug: { in: vendorSlugs } }
  }

  const products = await prisma.product.findMany({
    where,
    include: {
      vendor: { select: { name: true, slug: true } },
      category: { select: { name: true, slug: true } },
    },
    orderBy: getOrderBy(sort),
    skip: (page - 1) * PAGE_SIZE,
    take: PAGE_SIZE,
  })

  const serialized = products.map((p) => ({
    ...p,
    createdAt: p.createdAt.toISOString(),
    updatedAt: p.updatedAt.toISOString(),
  }))

  return NextResponse.json({ products: serialized })
}
