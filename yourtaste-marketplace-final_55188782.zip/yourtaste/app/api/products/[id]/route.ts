import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireAuth, requireVendor, successResponse, errorResponse, handleApiError } from '@/lib/api'
import { productSchema } from '@/lib/validations'

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const product = await prisma.product.findUnique({
      where: { id: params.id },
      include: {
        vendor: { select: { id: true, name: true, slug: true, logo: true, rating: true } },
        category: true,
        reviews: {
          include: { user: { select: { id: true, name: true } } },
          orderBy: { createdAt: 'desc' },
          take: 20,
        },
      },
    })

    if (!product) {
      return errorResponse('Product not found', 404)
    }

    return successResponse(product)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireVendor()
    const body = await request.json()
    const validation = productSchema.safeParse(body)

    if (!validation.success) {
      return errorResponse(validation.error.errors[0].message, 400)
    }

    const product = await prisma.product.findUnique({ where: { id: params.id } })
    if (!product) {
      return errorResponse('Product not found', 404)
    }

    if (user.role !== 'ADMIN') {
      const vendor = await prisma.vendor.findUnique({ where: { ownerId: user.id } })
      if (!vendor || product.vendorId !== vendor.id) {
        return errorResponse('You do not own this product', 403)
      }
    }

    const data = validation.data
    const updateData: Record<string, unknown> = {
      name: data.name,
      description: data.description,
      priceCents: data.priceCents,
      originalPriceCents: data.originalPriceCents,
      currency: data.currency,
      sku: data.sku,
      stockQuantity: data.stockQuantity,
      images: JSON.stringify(data.images),
      tags: JSON.stringify(data.tags),
      isActive: data.isActive,
      isPublished: data.isPublished,
    }

    if (data.categoryId !== undefined) {
      updateData.categoryId = data.categoryId
    }

    const updated = await prisma.product.update({
      where: { id: params.id },
      data: updateData,
      include: {
        vendor: { select: { id: true, name: true } },
        category: true,
      },
    })

    return successResponse(updated)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireVendor()

    const product = await prisma.product.findUnique({ where: { id: params.id } })
    if (!product) {
      return errorResponse('Product not found', 404)
    }

    if (user.role !== 'ADMIN') {
      const vendor = await prisma.vendor.findUnique({ where: { ownerId: user.id } })
      if (!vendor || product.vendorId !== vendor.id) {
        return errorResponse('You do not own this product', 403)
      }
    }

    await prisma.product.delete({ where: { id: params.id } })

    return successResponse({ message: 'Product deleted successfully' })
  } catch (error) {
    return handleApiError(error)
  }
}
