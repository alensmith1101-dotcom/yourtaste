import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireAuth, successResponse, errorResponse, handleApiError } from '@/lib/api'
import { sanitizeText } from '@/lib/sanitize'

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string; qid: string } }
) {
  try {
    const user = await requireAuth()
    const body = await request.json()
    const { answer } = body

    if (!answer || answer.trim().length === 0) {
      return errorResponse('Answer is required', 400)
    }

    if (answer.length > 2000) {
      return errorResponse('Answer must be less than 2000 characters', 400)
    }

    const question = await prisma.productQuestion.findUnique({
      where: { id: params.qid },
      include: {
        product: {
          include: {
            vendor: { select: { ownerId: true } },
          },
        },
      },
    })

    if (!question) {
      return errorResponse('Question not found', 404)
    }

    if (question.product.id !== params.id) {
      return errorResponse('Question does not belong to this product', 400)
    }

    const isVendorAnswer = question.product.vendor.ownerId === user.id

    const safeAnswer = sanitizeText(answer.trim())

    const newAnswer = await prisma.productAnswer.create({
      data: {
        questionId: params.qid,
        userId: user.id,
        answer: safeAnswer,
        isVendorAnswer,
      },
      include: {
        user: { select: { id: true, name: true } },
      },
    })

    if (!question.isAnswered) {
      await prisma.productQuestion.update({
        where: { id: params.qid },
        data: { isAnswered: true },
      })
    }

    if (!isVendorAnswer) {
      await prisma.notification.create({
        data: {
          userId: question.userId,
          type: 'QUESTION_ANSWERED',
          title: 'Your Question Was Answered',
          message: `Someone answered your question about "${question.product.name}": ${safeAnswer.slice(0, 100)}...`,
          productId: question.product.id,
        },
      })
    }

    return successResponse(newAnswer, 201)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string; qid: string } }
) {
  try {
    const user = await requireAuth()
    const { answerId } = await request.json()

    if (!answerId) {
      return errorResponse('Answer ID is required', 400)
    }

    const answer = await prisma.productAnswer.findUnique({
      where: { id: answerId },
    })

    if (!answer || answer.questionId !== params.qid) {
      return errorResponse('Answer not found', 404)
    }

    const existingUpvote = await prisma.answerUpvote.findUnique({
      where: {
        answerId_userId: {
          answerId,
          userId: user.id,
        },
      },
    })

    if (existingUpvote) {
      await prisma.answerUpvote.delete({
        where: { id: existingUpvote.id },
      })

      await prisma.productAnswer.update({
        where: { id: answerId },
        data: { upvotes: { decrement: 1 } },
      })

      return successResponse({ upvoted: false, upvotes: answer.upvotes - 1 })
    }

    await prisma.answerUpvote.create({
      data: {
        answerId,
        userId: user.id,
      },
    })

    await prisma.productAnswer.update({
      where: { id: answerId },
      data: { upvotes: { increment: 1 } },
    })

    return successResponse({ upvoted: true, upvotes: answer.upvotes + 1 })
  } catch (error) {
    return handleApiError(error)
  }
}
