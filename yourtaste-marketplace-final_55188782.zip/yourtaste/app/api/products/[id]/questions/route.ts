import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireAuth, successResponse, errorResponse, paginatedResponse, handleApiError } from '@/lib/api'
import { sanitizeText } from '@/lib/sanitize'

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '20')
    const search = searchParams.get('search') || ''
    const skip = (page - 1) * limit

    const product = await prisma.product.findUnique({ where: { id: params.id } })
    if (!product) {
      return errorResponse('Product not found', 404)
    }

    const where: Record<string, unknown> = { productId: params.id }
    if (search) {
      where.question = { contains: search, mode: 'insensitive' }
    }

    const [questions, total] = await Promise.all([
      prisma.productQuestion.findMany({
        where,
        include: {
          user: { select: { id: true, name: true } },
          answers: {
            include: {
              user: { select: { id: true, name: true } },
            },
            orderBy: [
              { isVendorAnswer: 'desc' },
              { upvotes: 'desc' },
              { createdAt: 'asc' },
            ],
          },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      prisma.productQuestion.count({ where }),
    ])

    return paginatedResponse(questions, total, page, limit)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireAuth()
    const body = await request.json()
    const { question } = body

    if (!question || question.trim().length === 0) {
      return errorResponse('Question is required', 400)
    }

    if (question.length > 1000) {
      return errorResponse('Question must be less than 1000 characters', 400)
    }

    const product = await prisma.product.findUnique({
      where: { id: params.id },
      include: { vendor: { select: { ownerId: true } } },
    })

    if (!product) {
      return errorResponse('Product not found', 404)
    }

    const safeQuestion = sanitizeText(question.trim())

    const newQuestion = await prisma.productQuestion.create({
      data: {
        productId: params.id,
        userId: user.id,
        question: safeQuestion,
      },
      include: {
        user: { select: { id: true, name: true } },
      },
    })

    await prisma.product.update({
      where: { id: params.id },
      data: {
        totalQuestions: { increment: 1 },
      },
    })

    await prisma.notification.create({
      data: {
        userId: product.vendor.ownerId,
        type: 'NEW_QUESTION',
        title: 'New Question on Your Product',
        message: `${user.name || 'A customer'} asked a question about "${product.name}": ${safeQuestion.slice(0, 100)}...`,
        productId: params.id,
        vendorId: product.vendorId,
      },
    })

    return successResponse(newQuestion, 201)
  } catch (error) {
    return handleApiError(error)
  }
}
