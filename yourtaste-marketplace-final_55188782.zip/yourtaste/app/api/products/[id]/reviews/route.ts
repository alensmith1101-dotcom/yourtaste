import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireAuth, successResponse, errorResponse, paginatedResponse, handleApiError } from '@/lib/api'
import { reviewSchema } from '@/lib/validations'
import { sanitizeText } from '@/lib/sanitize'

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '20')
    const skip = (page - 1) * limit

    const product = await prisma.product.findUnique({ where: { id: params.id } })
    if (!product) {
      return errorResponse('Product not found', 404)
    }

    const [reviews, total] = await Promise.all([
      prisma.review.findMany({
        where: { productId: params.id },
        include: { user: { select: { id: true, name: true, email: true } } },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      prisma.review.count({ where: { productId: params.id } }),
    ])

    const reviewerIds = reviews.map((r) => r.userId)

    const verifiedOrders = await prisma.orderItem.findMany({
      where: {
        productId: params.id,
        order: {
          userId: { in: reviewerIds },
          status: 'DELIVERED',
        },
      },
      select: {
        order: { select: { userId: true } },
      },
    })

    const verifiedUserIds = new Set(verifiedOrders.map((o) => o.order.userId))

    const reviewsWithVerification = reviews.map((review) => ({
      ...review,
      isVerifiedPurchase: verifiedUserIds.has(review.userId),
    }))

    return paginatedResponse(reviewsWithVerification, total, page, limit)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireAuth()
    const body = await request.json()
    const validation = reviewSchema.safeParse(body)

    if (!validation.success) {
      return errorResponse(validation.error.errors[0].message, 400)
    }

    const product = await prisma.product.findUnique({ where: { id: params.id } })
    if (!product) {
      return errorResponse('Product not found', 404)
    }

    // Check if user has purchased this product
    const hasPurchased = await prisma.orderItem.findFirst({
      where: {
        productId: params.id,
        order: {
          userId: user.id,
          paymentStatus: 'PAID',
        },
      },
    })

    if (!hasPurchased) {
      return errorResponse('You can only review products you have purchased', 403)
    }

    const existingReview = await prisma.review.findFirst({
      where: { userId: user.id, productId: params.id },
    })
    if (existingReview) {
      return errorResponse('You have already reviewed this product', 409)
    }

    const { rating, comment } = validation.data
    const safeComment = comment ? sanitizeText(comment) : null

    const review = await prisma.review.create({
      data: {
        userId: user.id,
        productId: params.id,
        rating,
        comment: safeComment,
      },
      include: { user: { select: { id: true, name: true, email: true } } },
    })

    // Update product rating
    const reviewStats = await prisma.review.aggregate({
      where: { productId: params.id },
      _avg: { rating: true },
      _count: true,
    })

    await prisma.product.update({
      where: { id: params.id },
      data: {
        averageRating: reviewStats._avg.rating ?? 0,
        totalReviews: reviewStats._count,
      },
    })

    return successResponse(review, 201)
  } catch (error) {
    return handleApiError(error)
  }
}
