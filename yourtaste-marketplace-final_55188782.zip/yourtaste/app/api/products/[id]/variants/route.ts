import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireVendor, successResponse, errorResponse, handleApiError } from '@/lib/api'

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const variants = await prisma.productVariant.findMany({
      where: { productId: params.id, isActive: true },
      orderBy: { createdAt: 'asc' },
    })

    return successResponse(variants)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireVendor()
    const body = await request.json()
    const { name, value, sku, priceCents, compareAtPriceCents, stockQuantity, images, attributes } = body

    if (!name || !value || !sku || priceCents === undefined) {
      return errorResponse('name, value, sku, and priceCents are required', 400)
    }

    const product = await prisma.product.findUnique({ where: { id: params.id } })
    if (!product) return errorResponse('Product not found', 404)

    if (user.role !== 'ADMIN') {
      const vendor = await prisma.vendor.findUnique({ where: { ownerId: user.id } })
      if (!vendor || product.vendorId !== vendor.id) {
        return errorResponse('You do not own this product', 403)
      }
    }

    const existingSku = await prisma.productVariant.findFirst({
      where: { productId: params.id, sku },
    })
    if (existingSku) return errorResponse('SKU already exists for this product', 409)

    const variant = await prisma.productVariant.create({
      data: {
        productId: params.id,
        name,
        value,
        sku,
        priceCents,
        compareAtPriceCents: compareAtPriceCents || null,
        stockQuantity: stockQuantity || 0,
        images: images ? JSON.stringify(images) : '[]',
        attributes: attributes ? JSON.stringify(attributes) : '{}',
      },
    })

    return successResponse(variant, 201)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireVendor()
    const body = await request.json()
    const { variantId, ...data } = body

    if (!variantId) return errorResponse('variantId is required', 400)

    const product = await prisma.product.findUnique({ where: { id: params.id } })
    if (!product) return errorResponse('Product not found', 404)

    if (user.role !== 'ADMIN') {
      const vendor = await prisma.vendor.findUnique({ where: { ownerId: user.id } })
      if (!vendor || product.vendorId !== vendor.id) {
        return errorResponse('You do not own this product', 403)
      }
    }

    const existingVariant = await prisma.productVariant.findFirst({
      where: { id: variantId, productId: params.id },
    })
    if (!existingVariant) {
      return errorResponse('Variant not found for this product', 404)
    }

    const updateData: Record<string, unknown> = {}
    if (data.name !== undefined) updateData.name = data.name
    if (data.value !== undefined) updateData.value = data.value
    if (data.sku !== undefined) updateData.sku = data.sku
    if (data.priceCents !== undefined) updateData.priceCents = data.priceCents
    if (data.compareAtPriceCents !== undefined) updateData.compareAtPriceCents = data.compareAtPriceCents
    if (data.stockQuantity !== undefined) updateData.stockQuantity = data.stockQuantity
    if (data.images !== undefined) updateData.images = JSON.stringify(data.images)
    if (data.attributes !== undefined) updateData.attributes = JSON.stringify(data.attributes)
    if (data.isActive !== undefined) updateData.isActive = data.isActive

    const variant = await prisma.productVariant.update({
      where: { id: variantId },
      data: updateData,
    })

    return successResponse(variant)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireVendor()
    const { searchParams } = new URL(request.url)
    const variantId = searchParams.get('variantId')

    if (!variantId) return errorResponse('variantId is required', 400)

    const product = await prisma.product.findUnique({ where: { id: params.id } })
    if (!product) return errorResponse('Product not found', 404)

    if (user.role !== 'ADMIN') {
      const vendor = await prisma.vendor.findUnique({ where: { ownerId: user.id } })
      if (!vendor || product.vendorId !== vendor.id) {
        return errorResponse('You do not own this product', 403)
      }
    }

    await prisma.productVariant.delete({ where: { id: variantId } })

    return successResponse({ message: 'Variant deleted' })
  } catch (error) {
    return handleApiError(error)
  }
}
