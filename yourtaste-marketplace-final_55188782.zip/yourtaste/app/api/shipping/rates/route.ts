import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { rateLimiters, getClientIp } from '@/lib/rate-limit'

export async function GET(request: NextRequest) {
  const ip = getClientIp(request)
  const limited = await rateLimiters.api(ip, 'shipping-rates')
  if (!limited.success) return limited.response

  const { searchParams } = new URL(request.url)
  const toZip = searchParams.get('toZip')
  const weight = parseFloat(searchParams.get('weight') || '1')
  const subtotal = parseFloat(searchParams.get('subtotal') || '0')

  if (!toZip) return NextResponse.json({ error: 'Destination ZIP required' }, { status: 400 })

  const customRates = await prisma.shippingRate.findMany({
    where: {
      toZip: { startsWith: toZip.slice(0, 3) },
      isActive: true,
      weight: { gte: weight },
    },
    orderBy: { rate: 'asc' },
    take: 5,
  })

  const defaultRates = [
    { id: 'standard', name: 'Standard Shipping', price: subtotal >= 49900 ? 0 : 4900, estimatedDays: '5-7', description: 'Delivered in 5-7 business days' },
    { id: 'express', name: 'Express Shipping', price: subtotal >= 99900 ? 9900 : 14900, estimatedDays: '2-3', description: 'Delivered in 2-3 business days' },
    { id: 'overnight', name: 'Overnight Shipping', price: 29900, estimatedDays: '1', description: 'Next business day delivery' },
  ]

  const dbRates = customRates.map(r => ({
    id: r.id,
    name: r.carrier || 'Custom Rate',
    price: r.rate,
    estimatedDays: r.estimatedDays || '3-5',
    description: `${r.method || 'Standard'} via ${r.carrier || 'courier'}`,
  }))

  return NextResponse.json({ rates: [...dbRates, ...defaultRates] })
}
