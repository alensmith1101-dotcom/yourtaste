import { NextRequest } from 'next/server'
import { z } from 'zod'
import { prisma } from '@/lib/prisma'
import { requireAuth, successResponse, errorResponse, paginatedResponse, parsePagination, handleApiError } from '@/lib/api'

const returnItemSchema = z.object({
  orderItemId: z.string().min(1),
  quantity: z.number().int().min(1),
})
const returnSchema = z.object({
  orderId: z.string().min(1),
  type: z.enum(['RETURN', 'REFUND', 'EXCHANGE']),
  reason: z.string().min(5, 'Reason must be at least 5 characters'),
  items: z.array(returnItemSchema).min(1),
  customerComments: z.string().optional(),
})

export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth()
    const { searchParams } = new URL(request.url)
    const { page, limit, skip } = parsePagination(searchParams)
    const status = searchParams.get('status')

    const where: Record<string, unknown> = { userId: user.id }
    if (status) where.status = status

    const [returns, total] = await Promise.all([
      prisma.returnRequest.findMany({
        where,
        include: {
          order: {
            select: { orderNumber: true, total: true },
          },
          vendor: { select: { name: true } },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      prisma.returnRequest.count({ where }),
    ])

    return paginatedResponse(returns, total, page, limit)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth()
    const body = await request.json()
    const parsed = returnSchema.safeParse(body)
    if (!parsed.success) {
      return errorResponse(parsed.error.errors[0].message, 400)
    }
    const { orderId, type, reason, items, customerComments } = parsed.data
    const { customReason, contactPreference } = body

    const order = await prisma.order.findUnique({
      where: { id: orderId },
      include: { items: true },
    })

    if (!order) return errorResponse('Order not found', 404)
    if (order.userId !== user.id) return errorResponse('Access denied', 403)
    if (order.paymentStatus !== 'PAID' && order.paymentStatus !== 'COMPLETED') {
      return errorResponse('Order must be paid to request a return', 400)
    }

    // Calculate total return amount
    const orderItemMap = new Map(order.items.map((i) => [i.id, i]))
    let totalAmount = 0
    for (const item of items) {
      const orderItem = orderItemMap.get(item.orderItemId)
      if (orderItem) {
        totalAmount += orderItem.priceCents * item.quantity
      }
    }

    const returnNumber = `RTN-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`

    const returnRequest = await prisma.returnRequest.create({
      data: {
        returnNumber,
        orderId,
        userId: user.id,
        vendorId: order.vendorId,
        type,
        reason,
        customReason: customReason || null,
        items: JSON.stringify(items),
        customerComments: customerComments || null,
        contactPreference: contactPreference || null,
        totalAmount,
        status: 'REQUESTED',
      },
    })

    return successResponse(returnRequest, 201)
  } catch (error) {
    return handleApiError(error)
  }
}
