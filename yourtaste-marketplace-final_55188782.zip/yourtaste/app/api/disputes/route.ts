import { NextRequest } from 'next/server'
import { z } from 'zod'
import { prisma } from '@/lib/prisma'
import { requireAuth, successResponse, errorResponse, paginatedResponse, parsePagination, handleApiError } from '@/lib/api'

const disputeSchema = z.object({
  orderId: z.string().min(1),
  type: z.enum(['PRODUCT', 'SHIPPING', 'PAYMENT', 'SERVICE', 'OTHER']),
  reason: z.string().min(10, 'Reason must be at least 10 characters'),
  description: z.string().min(20, 'Description must be at least 20 characters'),
})

export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth()
    const { searchParams } = new URL(request.url)
    const { page, limit, skip } = parsePagination(searchParams)
    const status = searchParams.get('status')

    const where: Record<string, unknown> = {}

    if (user.role === 'ADMIN') {
      // Admin sees all disputes
    } else if (user.role === 'VENDOR') {
      const vendor = await prisma.vendor.findUnique({ where: { ownerId: user.id } })
      if (!vendor) return errorResponse('Vendor profile not found', 404)
      where.vendorId = vendor.id
    } else {
      where.userId = user.id
    }

    if (status) where.status = status

    const [disputes, total] = await Promise.all([
      prisma.dispute.findMany({
        where,
        include: {
          order: {
            select: { orderNumber: true, total: true, status: true },
          },
          user: { select: { name: true, email: true } },
          vendor: { select: { name: true } },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      prisma.dispute.count({ where }),
    ])

    return paginatedResponse(disputes, total, page, limit)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth()
    const body = await request.json()
    const parsed = disputeSchema.safeParse(body)
    if (!parsed.success) {
      return errorResponse(parsed.error.errors[0].message, 400)
    }
    const { orderId, type, reason, description } = parsed.data

    const order = await prisma.order.findUnique({
      where: { id: orderId },
    })

    if (!order) return errorResponse('Order not found', 404)
    if (order.userId !== user.id) return errorResponse('Access denied', 403)

    const dispute = await prisma.dispute.create({
      data: {
        orderId,
        userId: user.id,
        vendorId: order.vendorId,
        reason,
        description: description || null,
        status: 'OPEN',
      },
    })

    return successResponse(dispute, 201)
  } catch (error) {
    return handleApiError(error)
  }
}
