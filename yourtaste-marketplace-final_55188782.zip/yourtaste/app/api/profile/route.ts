import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireAuth, successResponse, errorResponse, handleApiError } from '@/lib/api'
import { sanitizeHtml } from '@/lib/sanitize'

export async function GET() {
  try {
    const user = await requireAuth()

    const profile = await prisma.user.findUnique({
      where: { id: user.id },
      select: {
        id: true,
        email: true,
        name: true,
        phone: true,
        address: true,
        role: true,
        isActive: true,
        twoFactorEnabled: true,
        createdAt: true,
        vendor: {
          select: { id: true, name: true, slug: true, isApproved: true },
        },
      },
    })

    if (!profile) {
      return errorResponse('User not found', 404)
    }

    return successResponse(profile)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function PUT(request: NextRequest) {
  try {
    const user = await requireAuth()
    const body = await request.json()
    const { name, phone, email } = body

    const updateData: Record<string, unknown> = {}
    if (name !== undefined) updateData.name = sanitizeHtml(name.trim())
    if (phone !== undefined) updateData.phone = phone

    if (email !== undefined && email !== user.email) {
      const existing = await prisma.user.findUnique({ where: { email } })
      if (existing) {
        return errorResponse('Email already in use', 409)
      }
      updateData.email = email
    }

    const updated = await prisma.user.update({
      where: { id: user.id },
      data: updateData,
      select: {
        id: true,
        email: true,
        name: true,
        phone: true,
        role: true,
      },
    })

    return successResponse(updated)
  } catch (error) {
    return handleApiError(error)
  }
}

export async function DELETE() {
  try {
    const user = await requireAuth()
    await prisma.user.update({ where: { id: user.id }, data: { isActive: false, deletedAt: new Date() } })
    return successResponse({ success: true, message: 'Account scheduled for deletion' })
  } catch (error) {
    return handleApiError(error)
  }
}
