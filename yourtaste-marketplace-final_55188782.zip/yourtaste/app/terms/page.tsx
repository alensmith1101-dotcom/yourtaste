export const dynamic = 'force-dynamic'
export default function TermsPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-orange-600 to-amber-600 text-white py-16">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Terms of Service</h1>
          <p className="text-xl text-orange-100">
            Last updated: June 19, 2026
          </p>
        </div>
      </section>

      <div className="container mx-auto px-4 md:px-6 py-12">
        <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-sm border border-gray-200 p-8 md:p-12">
          <div className="prose prose-lg max-w-none">
            <p className="text-gray-600 mb-6">
              Welcome to YourTaste. These Terms of Service govern your use of our platform and services. By accessing or using YourTaste, you agree to be bound by these terms.
            </p>

            <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">1. Acceptance of Terms</h2>
            <p className="text-gray-600 mb-6">
              By creating an account or using our services, you agree to these Terms of Service and our Privacy Policy. If you do not agree to these terms, you may not use our platform.
            </p>

            <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">2. Eligibility</h2>
            <p className="text-gray-600 mb-6">
              You must be at least 18 years old to use YourTaste. By using our services, you represent and warrant that you have the legal capacity to enter into a binding agreement.
            </p>

            <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">3. Account Registration</h2>
            <p className="text-gray-600 mb-4">
              To use certain features, you must create an account. You agree to:
            </p>
            <ul className="list-disc list-inside text-gray-600 space-y-2 mb-6">
              <li>Provide accurate and complete information</li>
              <li>Maintain the security of your password</li>
              <li>Promptly update any changes to your information</li>
              <li>Notify us immediately of any unauthorized use</li>
            </ul>

            <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">4. Products and Orders</h2>
            <p className="text-gray-600 mb-4">
              Our platform connects buyers with independent vendors. Each vendor is responsible for:
            </p>
            <ul className="list-disc list-inside text-gray-600 space-y-2 mb-6">
              <li>Product quality and accuracy of descriptions</li>
              <li>Pricing and availability</li>
              <li>Fulfillment and shipping</li>
              <li>Customer service for their products</li>
            </ul>
            <p className="text-gray-600 mb-6">
              We act as a marketplace facilitator and are not responsible for vendor products or services.
            </p>

            <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">5. Payment and Pricing</h2>
            <p className="text-gray-600 mb-6">
              All prices are listed in USD. We accept various payment methods as displayed at checkout. You agree to pay all charges at the prices listed when placing an order.
            </p>

            <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">6. Shipping and Delivery</h2>
            <p className="text-gray-600 mb-6">
              Shipping times and costs vary by vendor and location. We are not responsible for delays caused by carriers or customs. Risk of loss passes to you upon delivery.
            </p>

            <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">7. Returns and Refunds</h2>
            <p className="text-gray-600 mb-6">
              Return policies vary by vendor. Please review each vendor&apos;s return policy before purchasing. We facilitate the return process but are not responsible for vendor compliance.
            </p>

            <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">8. Prohibited Conduct</h2>
            <p className="text-gray-600 mb-4">
              You agree not to:
            </p>
            <ul className="list-disc list-inside text-gray-600 space-y-2 mb-6">
              <li>Violate any laws or regulations</li>
              <li>Infringe on intellectual property rights</li>
              <li>Post false, misleading, or fraudulent content</li>
              <li>Harass, abuse, or harm others</li>
              <li>Attempt to gain unauthorized access to our systems</li>
              <li>Use the platform for competitive purposes</li>
            </ul>

            <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">9. Intellectual Property</h2>
            <p className="text-gray-600 mb-6">
              All content on YourTaste (excluding vendor content) is owned by us and protected by copyright, trademark, and other laws. You may not copy, modify, or distribute our content without permission.
            </p>

            <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">10. Vendor Content</h2>
            <p className="text-gray-600 mb-6">
              Vendors retain ownership of their product listings and content. By posting content, vendors grant us a license to display and promote their products on our platform.
            </p>

            <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">11. Limitation of Liability</h2>
            <p className="text-gray-600 mb-6">
              YourTaste is provided &quot;as is&quot; without warranties. We are not liable for any indirect, incidental, or consequential damages. Our total liability is limited to the amount you paid us in the past 12 months.
            </p>

            <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">12. Indemnification</h2>
            <p className="text-gray-600 mb-6">
              You agree to indemnify and hold harmless YourTaste from any claims, damages, or expenses arising from your use of the platform or violation of these terms.
            </p>

            <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">13. Termination</h2>
            <p className="text-gray-600 mb-6">
              We may terminate or suspend your account at any time for violation of these terms. Upon termination, your right to use the platform ceases immediately.
            </p>

            <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">14. Governing Law</h2>
            <p className="text-gray-600 mb-6">
              These terms are governed by the laws of the State of California, without regard to conflict of law principles.
            </p>

            <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">15. Changes to Terms</h2>
            <p className="text-gray-600 mb-6">
              We may modify these terms at any time. We will notify you of significant changes via email or platform notification. Continued use constitutes acceptance of modified terms.
            </p>

            <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">16. Contact Information</h2>
            <p className="text-gray-600 mb-6">
              For questions about these Terms of Service, please contact us at:
            </p>
            <div className="bg-gray-50 p-6 rounded-lg mb-6">
              <p className="text-gray-900 font-semibold mb-2">YourTaste Legal Team</p>
              <p className="text-gray-600">Email: {process.env.NEXT_PUBLIC_LEGAL_EMAIL || 'legal@yourtaste.com'}</p>
              <p className="text-gray-600">Phone: +1 (555) 123-4567</p>
              <p className="text-gray-600">Address: 123 Market Street, San Francisco, CA 94105</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
