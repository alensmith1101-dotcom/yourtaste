"use client"

export const dynamic = 'force-dynamic'

import Link from "next/link"
import Image from "next/image"
import { Minus, Plus, Trash2, ShoppingBag, ArrowRight, Heart, Gift, Truck } from "lucide-react"
import { useCart } from "@/components/providers/CartProvider"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { formatPrice } from "@/lib/utils"
import { useState } from "react"
import toast from 'react-hot-toast'

export default function CartPage() {
  const { items, removeFromCart, updateQuantity, totalCents, itemCount } = useCart()
  const [couponCode, setCouponCode] = useState("")
  const [giftWrap, setGiftWrap] = useState(false)
  const [discount, setDiscount] = useState(0)

  const subtotalCents = totalCents
  const taxCents = 0 // Tax calculated at checkout based on shipping address
  const shippingThreshold = 49900 // ₹499 in cents
  const shippingCents = subtotalCents >= shippingThreshold ? 0 : 4900
  const giftWrapCents = giftWrap ? 499 : 0
  const orderTotalCents = subtotalCents + taxCents + shippingCents + giftWrapCents - discount

  const applyCoupon = async () => {
    if (!couponCode.trim()) return
    try {
      const res = await fetch('/api/coupons', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: couponCode }),
      })
      const data = await res.json()
      if (data.valid) {
        setDiscount(data.discount)
        toast.success('Coupon applied!')
      } else {
        toast.error(data.error || 'Invalid coupon')
      }
    } catch (err) {
      console.error('Failed to validate coupon:', err)
      toast.error('Failed to validate coupon')
    }
  }

  const saveForLater = async (productId: string) => {
    try {
      await fetch('/api/wishlist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ productId }),
      })
      removeFromCart(productId)
    } catch (err) {
      console.error('Failed to save for later:', err)
    }
  }
  
  // Calculate progress towards free shipping
  const shippingProgress = Math.min((subtotalCents / shippingThreshold) * 100, 100)
  const remainingForFreeShipping = shippingThreshold - subtotalCents

  if (items.length === 0) {
    return (
      <div className="mx-auto flex min-h-[calc(100vh-4rem)] max-w-7xl flex-col items-center justify-center px-4 py-16">
        <div className="flex h-24 w-24 items-center justify-center rounded-full bg-gray-100">
          <ShoppingBag className="h-12 w-12 text-gray-400" />
        </div>
        <h1 className="mt-6 text-2xl font-bold text-gray-900">
          Your cart is empty
        </h1>
        <p className="mt-2 text-gray-500">
          Looks like you haven&apos;t added anything to your cart yet.
        </p>
        <Link href="/products" className="mt-6">
          <Button size="lg">
            Start Shopping
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </Link>
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <h1 className="text-3xl font-bold text-gray-900">
        Shopping Cart
        <span className="ml-2 text-lg font-normal text-gray-500">
          ({itemCount} item{itemCount !== 1 ? "s" : ""})
        </span>
      </h1>

      {/* Free Shipping Progress Bar */}
      {subtotalCents < shippingThreshold && (
        <div className="mt-6 rounded-lg border border-orange-200 bg-orange-50 p-4">
          <div className="flex items-center gap-2 mb-2">
            <Truck className="h-5 w-5 text-orange-600" />
            <p className="text-sm font-medium text-gray-900">
              Add {formatPrice(remainingForFreeShipping)} more for <span className="text-orange-600">FREE shipping!</span>
            </p>
          </div>
          <div className="w-full bg-orange-200 rounded-full h-2">
            <div
              className="bg-orange-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${shippingProgress}%` }}
            />
          </div>
          <p className="text-xs text-gray-600 mt-1">
            {Math.round(shippingProgress)}% towards free shipping
          </p>
        </div>
      )}

      {subtotalCents >= shippingThreshold && (
        <div className="mt-6 rounded-lg border border-green-200 bg-green-50 p-4">
          <div className="flex items-center gap-2">
            <Truck className="h-5 w-5 text-green-600" />
            <p className="text-sm font-medium text-green-900">
              ✓ You qualify for <span className="font-bold">FREE shipping!</span>
            </p>
          </div>
        </div>
      )}

      <div className="mt-8 grid grid-cols-1 gap-8 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <div className="space-y-4">
            {items.map((item) => (
              <Card key={item.id}>
                <CardContent className="flex items-center gap-4 p-4 sm:p-6">
                  <div className="h-20 w-20 shrink-0 overflow-hidden rounded-lg bg-gray-100 sm:h-24 sm:w-24">
                    {item.image ? (
                      <Image
                        src={item.image}
                        alt={item.name}
                        width={96}
                        height={96}
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center">
                        <ShoppingBag className="h-8 w-8 text-gray-300" />
                      </div>
                    )}
                  </div>
                  <div className="flex flex-1 flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                    <div>
                      <Link
                        href={item.slug ? `/products/${item.slug}` : "#"}
                        className="font-medium text-gray-900 hover:text-orange-600"
                      >
                        {item.name}
                      </Link>
                      <p className="mt-1 text-sm font-semibold text-gray-900">
                        {formatPrice(item.priceCents)}
                      </p>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="flex items-center rounded-lg border border-gray-200">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() =>
                            updateQuantity(item.id, item.quantity - 1)
                          }
                        >
                          <Minus className="h-3 w-3" />
                        </Button>
                        <span className="w-10 text-center text-sm font-medium">
                          {item.quantity}
                        </span>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() =>
                            updateQuantity(item.id, item.quantity + 1)
                          }
                        >
                          <Plus className="h-3 w-3" />
                        </Button>
                      </div>
                      <p className="w-20 text-right text-sm font-semibold text-gray-900">
                        {formatPrice(item.priceCents * item.quantity)}
                      </p>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-gray-400 hover:text-red-500"
                        onClick={() => removeFromCart(item.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-gray-400 hover:text-orange-500"
                        onClick={() => saveForLater(item.id)}
                      >
                        <Heart className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <div>
          <Card className="sticky top-24">
            <CardHeader>
              <CardTitle className="text-lg">Order Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {/* Coupon Code */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">Coupon Code</label>
                <div className="flex gap-2">
                  <Input
                    type="text"
                    placeholder="Enter coupon code"
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value)}
                    className="flex-1"
                  />
                  <Button variant="outline" size="sm" onClick={applyCoupon}>
                    Apply
                  </Button>
                </div>
              </div>

              {/* Gift Wrap Option */}
              <div className="flex items-center gap-2 p-3 border border-gray-200 rounded-lg">
                <input
                  type="checkbox"
                  id="giftWrap"
                  checked={giftWrap}
                  onChange={(e) => setGiftWrap(e.target.checked)}
                  className="h-4 w-4 rounded border-gray-300 text-orange-600 focus:ring-orange-500"
                />
                <label htmlFor="giftWrap" className="flex-1 cursor-pointer">
                  <div className="flex items-center gap-2">
                    <Gift className="h-4 w-4 text-orange-600" />
                    <span className="text-sm font-medium text-gray-900">Add gift wrap</span>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">+{formatPrice(giftWrapCents)}</p>
                </label>
              </div>

              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Subtotal</span>
                <span className="font-medium">{formatPrice(subtotalCents)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Shipping</span>
                <span className="font-medium">
                  {shippingCents === 0 ? (
                    <span className="text-green-600">Free</span>
                  ) : (
                    formatPrice(shippingCents)
                  )}
                </span>
              </div>
              {giftWrap && (
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Gift Wrap</span>
                  <span className="font-medium">{formatPrice(giftWrapCents)}</span>
                </div>
              )}
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Tax</span>
                <span className="font-medium text-gray-500">Calculated at checkout</span>
              </div>
              {discount > 0 && (
                <div className="flex justify-between text-sm">
                  <span className="text-green-600">Discount</span>
                  <span className="font-medium text-green-600">-{formatPrice(discount)}</span>
                </div>
              )}
              <div className="border-t pt-3">
                <div className="flex justify-between">
                  <span className="text-base font-semibold text-gray-900">
                    Total
                  </span>
                  <span className="text-base font-bold text-gray-900">
                    {formatPrice(orderTotalCents)}
                  </span>
                </div>
              </div>
              {shippingCents > 0 && (
                <p className="text-xs text-gray-500">
                  Free shipping on orders over $50
                </p>
              )}
            </CardContent>
            <CardFooter>
              <Link href="/checkout" className="w-full">
                <Button className="w-full" size="lg">
                  Proceed to Checkout
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}
