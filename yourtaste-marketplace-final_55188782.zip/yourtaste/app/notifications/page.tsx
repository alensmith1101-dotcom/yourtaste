"use client"

export const dynamic = 'force-dynamic'

import { useState, useEffect, useCallback } from "react"
import {
  Bell,
  Check,
  CheckCheck,
  Package,
  Tag,
  Info,
  Loader2,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Card,
  CardContent,
} from "@/components/ui/card"
import { formatDate } from "@/lib/utils"

interface Notification {
  id: string
  type: string
  title: string | null
  message: string
  isRead: boolean
  createdAt: string
  orderId: string | null
  productId: string | null
}

const TYPE_CONFIG: Record<string, { icon: typeof Bell; color: string; label: string }> = {
  ORDER: { icon: Package, color: "bg-blue-100 text-blue-700 hover:bg-blue-100", label: "Order" },
  PROMO: { icon: Tag, color: "bg-orange-100 text-orange-700 hover:bg-orange-100", label: "Promo" },
  SYSTEM: { icon: Info, color: "bg-gray-100 text-gray-700 hover:bg-gray-100", label: "System" },
}

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [loading, setLoading] = useState(true)
  const [markingAll, setMarkingAll] = useState(false)

  const fetchNotifications = useCallback(async () => {
    try {
      const res = await fetch("/api/notifications")
      if (res.ok) {
        const data = await res.json()
        setNotifications(data)
      }
    } catch (err) {
      console.error('Failed to fetch notifications:', err)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchNotifications()
    const interval = setInterval(fetchNotifications, 30000)
    return () => clearInterval(interval)
  }, [fetchNotifications])

  async function handleMarkAsRead(id: string) {
    try {
      const res = await fetch("/api/notifications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ notificationId: id }),
      })
      if (res.ok) {
        setNotifications((prev) =>
          prev.map((n) =>
            n.id === id ? { ...n, isRead: true } : n
          )
        )
      }
    } catch (err) {
      console.error('Failed to mark notification as read:', err)
    }
  }

  async function handleMarkAllAsRead() {
    setMarkingAll(true)
    try {
      const res = await fetch("/api/notifications", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ markAllRead: true }),
      })
      if (res.ok) {
        setNotifications((prev) =>
          prev.map((n) => ({ ...n, isRead: true }))
        )
      }
    } catch (err) {
      console.error('Failed to mark all notifications as read:', err)
    } finally {
      setMarkingAll(false)
    }
  }

  const unreadCount = notifications.filter((n) => !n.isRead).length

  if (loading) {
    return (
      <div className="mx-auto flex min-h-[calc(100vh-4rem)] max-w-3xl items-center justify-center px-4">
        <Loader2 className="h-8 w-8 animate-spin text-orange-600" />
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Notifications</h1>
          <p className="mt-2 text-gray-600">
            {unreadCount > 0
              ? `You have ${unreadCount} unread notification${unreadCount !== 1 ? "s" : ""}`
              : "You're all caught up"}
          </p>
        </div>
        {unreadCount > 0 && (
          <Button
            variant="outline"
            onClick={handleMarkAllAsRead}
            disabled={markingAll}
          >
            {markingAll ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <CheckCheck className="mr-2 h-4 w-4" />
            )}
            Mark all as read
          </Button>
        )}
      </div>

      {notifications.length > 0 ? (
        <div className="mt-8 space-y-3">
          {notifications.map((notification) => {
            const config = TYPE_CONFIG[notification.type] || TYPE_CONFIG.SYSTEM
            const Icon = config.icon
            return (
              <Card
                key={notification.id}
                className={`transition-all ${
                  !notification.isRead
                    ? "border-orange-200 bg-orange-50/30"
                    : ""
                }`}
              >
                <CardContent className="flex items-start gap-4 p-5">
                  <div
                    className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full ${
                      notification.isRead ? "bg-gray-100" : "bg-orange-100"
                    }`}
                  >
                    <Icon
                      className={`h-5 w-5 ${
                        notification.isRead
                          ? "text-gray-400"
                          : "text-orange-600"
                      }`}
                    />
                  </div>
                  <div className="flex-1 space-y-1">
                    <div className="flex items-center gap-2">
                      {notification.title && (
                        <p
                          className={`text-sm ${
                            notification.isRead
                              ? "text-gray-700"
                              : "font-semibold text-gray-900"
                          }`}
                        >
                          {notification.title}
                        </p>
                      )}
                      <Badge
                        className={`${config.color} text-[10px]`}
                      >
                        {config.label}
                      </Badge>
                    </div>
                    <p
                      className={`text-sm ${
                        notification.isRead
                          ? "text-gray-500"
                          : "text-gray-700"
                      }`}
                    >
                      {notification.message}
                    </p>
                    <p className="text-xs text-gray-400">
                      {formatDate(notification.createdAt)}
                    </p>
                  </div>
                  {!notification.isRead && (
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 shrink-0"
                      onClick={() => handleMarkAsRead(notification.id)}
                    >
                      <Check className="h-4 w-4" />
                    </Button>
                  )}
                </CardContent>
              </Card>
            )
          })}
        </div>
      ) : (
        <div className="mt-16 flex flex-col items-center text-center">
          <div className="flex h-24 w-24 items-center justify-center rounded-full bg-gray-100">
            <Bell className="h-12 w-12 text-gray-400" />
          </div>
          <h2 className="mt-6 text-xl font-semibold text-gray-900">
            No notifications
          </h2>
          <p className="mt-2 text-gray-500">
            You don&apos;t have any notifications yet.
          </p>
        </div>
      )}
    </div>
  )
}
