"use client"

export const dynamic = 'force-dynamic'

import { useState, useEffect, useCallback } from "react"
import Link from "next/link"
import Image from "next/image"
import { Heart, ShoppingCart, Trash2, ShoppingBag, Plus, Share2, Copy, Check, Edit2, X, ChevronDown } from "lucide-react"
import { useCart } from "@/components/providers/CartProvider"
import { formatPrice } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Card,
  CardContent,
} from "@/components/ui/card"

interface WishlistProduct {
  id: string
  name: string
  slug: string
  priceCents: number
  images: string
  vendor: { name: string; slug: string }
}

interface WishlistItemData {
  id: string
  productId: string
  product: WishlistProduct
}

interface Wishlist {
  id: string
  name: string
  isDefault: boolean
  shareToken: string | null
  itemCount: number
}

function parseImages(images: string): string[] {
  try {
    const parsed = JSON.parse(images)
    return Array.isArray(parsed) ? parsed : []
  } catch (err) {
    console.error('Failed to parse images:', err)
    return []
  }
}

export default function WishlistPage() {
  const [wishlists, setWishlists] = useState<Wishlist[]>([])
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [items, setItems] = useState<WishlistItemData[]>([])
  const [loading, setLoading] = useState(true)
  const [itemsLoading, setItemsLoading] = useState(false)
  const { addToCart } = useCart()
  const [showCreate, setShowCreate] = useState(false)
  const [newName, setNewName] = useState('')
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editName, setEditName] = useState('')
  const [shareLink, setShareLink] = useState<string | null>(null)
  const [copied, setCopied] = useState(false)
  const [moveItemId, setMoveItemId] = useState<string | null>(null)

  const fetchWishlists = useCallback(async () => {
    try {
      const res = await fetch("/api/wishlists")
      if (res.ok) {
        const data = await res.json()
        if (data.success) {
          setWishlists(data.data)
          if (!selectedId && data.data.length > 0) {
            setSelectedId(data.data[0].id)
          }
        }
      }
    } catch (err) {
      console.error('Failed to fetch wishlists:', err)
    }
  }, [selectedId])

  const fetchItems = useCallback(async (wishlistId: string) => {
    setItemsLoading(true)
    try {
      const res = await fetch(`/api/wishlists/${wishlistId}/items`)
      if (res.ok) {
        const data = await res.json()
        if (data.success) setItems(data.data)
      }
    } catch (err) {
      console.error('Failed to fetch items:', err)
    } finally {
      setItemsLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchWishlists().then(() => setLoading(false))
  }, [fetchWishlists])

  useEffect(() => {
    if (selectedId) fetchItems(selectedId)
  }, [selectedId, fetchItems])

  async function handleRemove(productId: string) {
    if (!selectedId) return
    try {
      const res = await fetch(`/api/wishlists/${selectedId}/items?productId=${productId}`, {
        method: "DELETE",
      })
      if (res.ok) {
        setItems((prev) => prev.filter((i) => i.productId !== productId))
        setWishlists((prev) =>
          prev.map((w) =>
            w.id === selectedId ? { ...w, itemCount: w.itemCount - 1 } : w
          )
        )
      }
    } catch (err) {
      console.error('Failed to remove from wishlist:', err)
    }
  }

  async function handleCreateWishlist() {
    if (!newName.trim()) return
    try {
      const res = await fetch("/api/wishlists", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: newName.trim() }),
      })
      if (res.ok) {
        setNewName("")
        setShowCreate(false)
        await fetchWishlists()
      }
    } catch (err) {
      console.error('Failed to create wishlist:', err)
    }
  }

  async function handleRename(id: string) {
    if (!editName.trim()) return
    try {
      await fetch("/api/wishlists", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, name: editName.trim() }),
      })
      setEditingId(null)
      setEditName("")
      await fetchWishlists()
    } catch (err) {
      console.error('Failed to rename wishlist:', err)
    }
  }

  async function handleDelete(id: string) {
    try {
      const res = await fetch(`/api/wishlists?id=${id}`, { method: "DELETE" })
      if (res.ok) {
        if (selectedId === id) {
          const remaining = wishlists.filter((w) => w.id !== id)
          setSelectedId(remaining.length > 0 ? remaining[0].id : null)
        }
        await fetchWishlists()
      }
    } catch (err) {
      console.error('Failed to delete wishlist:', err)
    }
  }

  async function handleShare(id: string) {
    try {
      const res = await fetch(`/api/wishlists/${id}/items`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "share" }),
      })
      const data = await res.json()
      if (data.success && data.data.shareToken) {
        const link = `${window.location.origin}/wishlist/shared/${data.data.shareToken}`
        setShareLink(link)
      }
    } catch (err) {
      console.error('Failed to share wishlist:', err)
    }
  }

  function handleCopyLink() {
    if (!shareLink) return
    navigator.clipboard.writeText(shareLink)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  async function handleMoveToWishlist(productId: string, targetWishlistId: string) {
    if (!selectedId) return
    try {
      await fetch(`/api/wishlists/${targetWishlistId}/items`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ productId, fromWishlistId: selectedId }),
      })
      setItems((prev) => prev.filter((i) => i.productId !== productId))
      setMoveItemId(null)
      await fetchWishlists()
    } catch (err) {
      console.error('Failed to move item:', err)
    }
  }

  function handleAddToCart(product: WishlistProduct) {
    addToCart({
      id: product.id,
      name: product.name,
      priceCents: product.priceCents,
      image: parseImages(product.images)[0],
      slug: product.slug,
    })
  }

  const selectedWishlist = wishlists.find((w) => w.id === selectedId)

  if (loading) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold text-gray-900">My Wishlists</h1>
        <div className="mt-8 flex gap-8">
          <div className="w-64 space-y-2">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="h-10 animate-pulse rounded bg-gray-200" />
            ))}
          </div>
          <div className="flex-1">
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {Array.from({ length: 3 }).map((_, i) => (
                <Card key={i} className="animate-pulse">
                  <div className="aspect-square bg-gray-200" />
                  <CardContent className="p-4">
                    <div className="h-4 w-3/4 rounded bg-gray-200" />
                    <div className="mt-2 h-4 w-1/2 rounded bg-gray-200" />
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <h1 className="text-3xl font-bold text-gray-900">My Wishlists</h1>

      <div className="mt-8 flex flex-col gap-8 lg:flex-row">
        <div className="w-full lg:w-64 lg:flex-shrink-0">
          <div className="rounded-lg border bg-white p-3">
            <div className="mb-2 flex items-center justify-between">
              <h2 className="text-sm font-semibold text-gray-700">Wishlists</h2>
              <button
                onClick={() => setShowCreate(!showCreate)}
                className="rounded p-1 text-gray-400 hover:bg-gray-100 hover:text-gray-600"
              >
                <Plus className="h-4 w-4" />
              </button>
            </div>

            {showCreate && (
              <div className="mb-3 flex items-center gap-1">
                <Input
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleCreateWishlist()}
                  placeholder="Name..."
                  className="h-8 text-sm"
                  autoFocus
                />
                <button onClick={handleCreateWishlist} className="rounded p-1 text-green-600 hover:bg-green-50">
                  <Check className="h-4 w-4" />
                </button>
                <button onClick={() => { setShowCreate(false); setNewName('') }} className="rounded p-1 text-gray-400 hover:bg-gray-100">
                  <X className="h-4 w-4" />
                </button>
              </div>
            )}

            <div className="space-y-1">
              {wishlists.map((w) => (
                <div key={w.id} className="group">
                  {editingId === w.id ? (
                    <div className="flex items-center gap-1 rounded-md bg-gray-50 px-2 py-1.5">
                      <Input
                        value={editName}
                        onChange={(e) => setEditName(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleRename(w.id)}
                        className="h-7 text-sm"
                        autoFocus
                      />
                      <button onClick={() => handleRename(w.id)} className="rounded p-0.5 text-green-600 hover:bg-green-50">
                        <Check className="h-3.5 w-3.5" />
                      </button>
                      <button onClick={() => setEditingId(null)} className="rounded p-0.5 text-gray-400 hover:bg-gray-100">
                        <X className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => setSelectedId(w.id)}
                      className={`flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-sm transition-colors ${
                        selectedId === w.id
                          ? 'bg-orange-50 text-orange-700 font-medium'
                          : 'text-gray-700 hover:bg-gray-50'
                      }`}
                    >
                      <Heart className={`h-4 w-4 flex-shrink-0 ${selectedId === w.id ? 'text-orange-600' : 'text-gray-400'}`} />
                      <span className="flex-1 truncate">{w.name}</span>
                      <span className="text-xs text-gray-400">{w.itemCount}</span>
                      <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100">
                        <button
                          onClick={(e) => { e.stopPropagation(); handleShare(w.id) }}
                          className="rounded p-0.5 text-gray-400 hover:text-blue-600"
                          title="Share"
                        >
                          <Share2 className="h-3.5 w-3.5" />
                        </button>
                        <button
                          onClick={(e) => { e.stopPropagation(); setEditingId(w.id); setEditName(w.name) }}
                          className="rounded p-0.5 text-gray-400 hover:text-gray-600"
                          title="Rename"
                        >
                          <Edit2 className="h-3.5 w-3.5" />
                        </button>
                        {!w.isDefault && (
                          <button
                            onClick={(e) => { e.stopPropagation(); handleDelete(w.id) }}
                            className="rounded p-0.5 text-gray-400 hover:text-red-600"
                            title="Delete"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        )}
                      </div>
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          {shareLink && (
            <div className="mt-3 rounded-lg border bg-blue-50 p-3">
              <p className="text-xs font-medium text-blue-700">Share link:</p>
              <div className="mt-1 flex items-center gap-1">
                <code className="flex-1 truncate rounded bg-white px-2 py-1 text-xs text-blue-600">
                  {shareLink}
                </code>
                <button onClick={handleCopyLink} className="rounded p-1 text-blue-600 hover:bg-blue-100">
                  {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                </button>
              </div>
              <button onClick={() => setShareLink(null)} className="mt-1 text-xs text-blue-500 hover:underline">
                Close
              </button>
            </div>
          )}
        </div>

        <div className="flex-1">
          {!selectedWishlist ? (
            <div className="flex flex-col items-center justify-center py-16">
              <div className="flex h-24 w-24 items-center justify-center rounded-full bg-gray-100">
                <Heart className="h-12 w-12 text-gray-400" />
              </div>
              <h2 className="mt-6 text-xl font-bold text-gray-900">No wishlists yet</h2>
              <p className="mt-2 text-gray-500">Create a wishlist to start saving products.</p>
            </div>
          ) : itemsLoading ? (
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 xl:grid-cols-3">
              {Array.from({ length: 3 }).map((_, i) => (
                <Card key={i} className="animate-pulse">
                  <div className="aspect-square bg-gray-200" />
                  <CardContent className="p-4">
                    <div className="h-4 w-3/4 rounded bg-gray-200" />
                    <div className="mt-2 h-4 w-1/2 rounded bg-gray-200" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : items.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16">
              <div className="flex h-24 w-24 items-center justify-center rounded-full bg-gray-100">
                <Heart className="h-12 w-12 text-gray-400" />
              </div>
              <h2 className="mt-6 text-xl font-bold text-gray-900">
                &quot;{selectedWishlist.name}&quot; is empty
              </h2>
              <p className="mt-2 text-gray-500">Save products you love to this wishlist.</p>
              <Link href="/products" className="mt-6">
                <Button size="lg">Browse Products</Button>
              </Link>
            </div>
          ) : (
            <>
              <div className="mb-4 flex items-center justify-between">
                <h2 className="text-lg font-semibold text-gray-900">
                  {selectedWishlist.name}
                  <span className="ml-2 text-sm font-normal text-gray-500">
                    ({items.length} item{items.length !== 1 ? "s" : ""})
                  </span>
                </h2>
              </div>

              <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 xl:grid-cols-3">
                {items.map((item) => {
                  const product = item.product
                  const images = parseImages(product.images)
                  return (
                    <Card key={item.id} className="overflow-hidden">
                      <Link href={`/products/${product.slug}`}>
                        <div className="aspect-square overflow-hidden bg-gray-100">
                          {images[0] ? (
                            <Image
                              src={images[0]}
                              alt={product.name}
                              width={300}
                              height={300}
                              className="h-full w-full object-cover transition-transform duration-300 hover:scale-105"
                            />
                          ) : (
                            <div className="flex h-full w-full items-center justify-center">
                              <ShoppingBag className="h-12 w-12 text-gray-300" />
                            </div>
                          )}
                        </div>
                      </Link>
                      <CardContent className="p-4">
                        <p className="text-xs font-medium text-orange-600">
                          {product.vendor.name}
                        </p>
                        <Link href={`/products/${product.slug}`}>
                          <h3 className="mt-1 line-clamp-1 text-sm font-semibold text-gray-900 hover:text-orange-600">
                            {product.name}
                          </h3>
                        </Link>
                        <p className="mt-2 text-lg font-bold text-gray-900">
                          {formatPrice(product.priceCents)}
                        </p>

                        {moveItemId === item.id ? (
                          <div className="mt-3 space-y-1">
                            <p className="text-xs text-gray-500">Move to:</p>
                            {wishlists
                              .filter((w) => w.id !== selectedId)
                              .map((w) => (
                                <button
                                  key={w.id}
                                  onClick={() => handleMoveToWishlist(product.id, w.id)}
                                  className="flex w-full items-center gap-2 rounded px-2 py-1 text-left text-sm hover:bg-gray-50"
                                >
                                  <Heart className="h-3 w-3 text-gray-400" />
                                  {w.name}
                                </button>
                              ))}
                            <button
                              onClick={() => setMoveItemId(null)}
                              className="text-xs text-gray-500 hover:underline"
                            >
                              Cancel
                            </button>
                          </div>
                        ) : (
                          <div className="mt-3 flex gap-2">
                            <Button
                              size="sm"
                              className="flex-1"
                              onClick={() => handleAddToCart(product)}
                            >
                              <ShoppingCart className="mr-1 h-3 w-3" />
                              Add to Cart
                            </Button>
                            {wishlists.length > 1 && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => setMoveItemId(item.id)}
                                title="Move to another wishlist"
                              >
                                <ChevronDown className="h-3 w-3" />
                              </Button>
                            )}
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleRemove(product.id)}
                              className="text-red-500 hover:bg-red-50 hover:text-red-600"
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
