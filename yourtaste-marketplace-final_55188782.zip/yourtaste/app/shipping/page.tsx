export const dynamic = 'force-dynamic'
import { Truck, Clock, MapPin, Package } from "lucide-react"

export default function ShippingPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-orange-600 to-amber-600 text-white py-16">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Shipping Information</h1>
          <p className="text-xl text-orange-100">
            Fast, reliable delivery to your doorstep
          </p>
        </div>
      </section>

      <div className="container mx-auto px-4 md:px-6 py-12">
        <div className="max-w-4xl mx-auto">
          {/* Shipping Options */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Shipping Options</h2>
            <div className="space-y-6">
              <div className="flex items-start gap-4 pb-6 border-b border-gray-200">
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Truck className="h-6 w-6 text-orange-600" />
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Standard Shipping</h3>
                  <p className="text-gray-600 mb-2">5-7 business days</p>
                  <p className="text-2xl font-bold text-gray-900">$5.99</p>
                  <p className="text-sm text-gray-500 mt-1">Free on orders over $50</p>
                </div>
              </div>

              <div className="flex items-start gap-4 pb-6 border-b border-gray-200">
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Clock className="h-6 w-6 text-orange-600" />
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Express Shipping</h3>
                  <p className="text-gray-600 mb-2">2-3 business days</p>
                  <p className="text-2xl font-bold text-gray-900">$12.99</p>
                  <p className="text-sm text-gray-500 mt-1">Available for most locations</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Package className="h-6 w-6 text-green-600" />
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Free Shipping</h3>
                  <p className="text-gray-600 mb-2">5-7 business days</p>
                  <p className="text-2xl font-bold text-green-600">FREE</p>
                  <p className="text-sm text-gray-500 mt-1">On all orders over $50</p>
                </div>
              </div>
            </div>
          </div>

          {/* Delivery Areas */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Delivery Areas</h2>
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <MapPin className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">United States</h3>
                <p className="text-gray-600 mb-4">
                  We currently ship to all 50 states, including Alaska and Hawaii. 
                  Some remote areas may have extended delivery times.
                </p>
                <p className="text-sm text-gray-500">
                  <strong>Note:</strong> International shipping will be available in the future.
                </p>
              </div>
            </div>
          </div>

          {/* Order Processing */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Order Processing</h2>
            <div className="space-y-4">
              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-orange-600 text-white rounded-full flex items-center justify-center flex-shrink-0 font-bold">
                  1
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-1">Order Confirmation</h3>
                  <p className="text-gray-600">You&apos;ll receive an email confirmation within minutes of placing your order.</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-orange-600 text-white rounded-full flex items-center justify-center flex-shrink-0 font-bold">
                  2
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-1">Processing</h3>
                  <p className="text-gray-600">Orders are processed within 1-2 business days. You&apos;ll receive a shipping notification with tracking information.</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-orange-600 text-white rounded-full flex items-center justify-center flex-shrink-0 font-bold">
                  3
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-1">Shipping</h3>
                  <p className="text-gray-600">Your order is shipped and you can track its progress using the provided tracking number.</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-orange-600 text-white rounded-full flex items-center justify-center flex-shrink-0 font-bold">
                  4
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-1">Delivery</h3>
                  <p className="text-gray-600">Your order arrives at your doorstep. Signature may be required for high-value items.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Tracking */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Order Tracking</h2>
            <p className="text-gray-600 mb-4">
              Once your order ships, you&apos;ll receive a tracking number via email. You can track your order in several ways:
            </p>
            <ul className="list-disc list-inside text-gray-600 space-y-2 mb-4">
              <li>Log into your account and go to &quot;My Orders&quot;</li>
              <li>Click the tracking link in your shipping confirmation email</li>
              <li>Visit the carrier&apos;s website directly with your tracking number</li>
            </ul>
            <p className="text-sm text-gray-500">
              <strong>Note:</strong> Tracking information may take 24-48 hours to update after shipment.
            </p>
          </div>

          {/* Special Instructions */}
          <div className="bg-orange-50 border border-orange-200 rounded-lg p-8">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Special Delivery Instructions</h2>
            <p className="text-gray-600 mb-4">
              Need special delivery arrangements? You can add delivery instructions during checkout, such as:
            </p>
            <ul className="list-disc list-inside text-gray-600 space-y-2 mb-4">
              <li>Leave at door / back door</li>
              <li>Deliver to specific location</li>
              <li>Require signature</li>
              <li>Delivery instructions for apartment buildings</li>
            </ul>
            <p className="text-sm text-gray-500">
              <strong>Note:</strong> Special instructions are not guaranteed and may not be available for all carriers.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
