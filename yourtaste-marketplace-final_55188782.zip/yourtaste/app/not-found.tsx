'use client'

import Link from "next/link"
import { Home, Search, ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function NotFound() {
  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center bg-gray-50 px-4">
      <div className="max-w-md text-center">
        <div className="mb-8">
          <div className="text-9xl font-bold text-orange-600 mb-4">404</div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Page Not Found</h1>
          <p className="text-gray-600 mb-8">
            Oops! The page you&apos;re looking for doesn&apos;t exist or has been moved.
          </p>
        </div>

        <div className="space-y-4">
          <Link href="/">
            <Button className="w-full bg-orange-600 hover:bg-orange-700">
              <Home className="h-4 w-4 mr-2" />
              Go to Homepage
            </Button>
          </Link>

          <Link href="/products">
            <Button variant="outline" className="w-full">
              <Search className="h-4 w-4 mr-2" />
              Browse Products
            </Button>
          </Link>

          <button
            onClick={() => window.history.back()}
            className="w-full text-sm text-gray-600 hover:text-orange-600 transition-colors"
          >
            <ArrowLeft className="h-4 w-4 inline mr-1" />
            Go Back
          </button>
        </div>

        <div className="mt-12 pt-8 border-t border-gray-200">
          <p className="text-sm text-gray-500 mb-4">Looking for something specific?</p>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <Link href="/deals" className="text-orange-600 hover:text-orange-700">
              Today&apos;s Deals
            </Link>
            <Link href="/faq" className="text-orange-600 hover:text-orange-700">
              Help Center
            </Link>
            <Link href="/contact" className="text-orange-600 hover:text-orange-700">
              Contact Us
            </Link>
            <Link href="/support" className="text-orange-600 hover:text-orange-700">
              Support
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
