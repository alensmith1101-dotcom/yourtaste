'use client'

export const dynamic = 'force-dynamic'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import toast from 'react-hot-toast'

export default function GiftCardsPage() {
  const { data: session } = useSession()
  const router = useRouter()
  const [cards, setCards] = useState<any[]>([])
  const [code, setCode] = useState('')
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (!session) router.push('/auth/signin')
    else fetch('/api/gift-cards').then(r => r.json()).then(d => setCards(d.cards || []))
  }, [session, router])

  const handleRedeem = async () => {
    if (!code.trim()) return
    setLoading(true)
    try {
      const res = await fetch('/api/gift-cards', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ code }) })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      toast.success(data.message)
      setCode('')
      fetch('/api/gift-cards').then(r => r.json()).then(d => setCards(d.cards || []))
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Failed') } finally { setLoading(false) }
  }

  if (!session) return null
  return (
    <div className="mx-auto max-w-2xl px-4 py-8">
      <h1 className="mb-8 text-2xl font-bold">Gift Cards</h1>
      <div className="mb-8 rounded-xl border bg-gradient-to-r from-purple-50 to-pink-50 p-6">
        <h2 className="mb-3 text-lg font-semibold">Redeem a Gift Card</h2>
        <div className="flex gap-3">
          <input type="text" value={code} onChange={e => setCode(e.target.value.toUpperCase())} placeholder="Enter gift card code" className="flex-1 rounded-lg border px-4 py-2.5 font-mono text-sm uppercase tracking-wider" />
          <button onClick={handleRedeem} disabled={loading || code.length < 8} className="rounded-lg bg-purple-600 px-6 py-2.5 text-sm font-semibold text-white hover:bg-purple-700 disabled:opacity-50">{loading ? 'Redeeming...' : 'Redeem'}</button>
        </div>
      </div>
      {cards.length > 0 && (
        <div><h2 className="mb-4 text-lg font-semibold">Your Gift Cards</h2>
          <div className="space-y-3">{cards.map((card: any) => (
            <div key={card.id} className="flex items-center justify-between rounded-lg border p-4">
              <div><div className="font-mono text-sm">{card.code}</div><div className="text-xs text-gray-500">{card.redeemedAt ? 'Redeemed' : 'Available'}</div></div>
              <div className="text-lg font-bold">₹{(card.balance / 100).toFixed(2)}</div>
            </div>
          ))}</div>
        </div>
      )}
    </div>
  )
}
