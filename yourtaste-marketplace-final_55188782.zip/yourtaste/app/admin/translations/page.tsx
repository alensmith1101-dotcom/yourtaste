"use client"

export const dynamic = 'force-dynamic'

import { useEffect, useState } from "react"
import { Languages, Globe } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface Language {
  code: string
  name: string
  progress: number
  totalKeys: number
  translatedKeys: number
  status: string
}

const CONTENT_TYPES = ["all", "ui", "products", "emails", "notifications"]

export default function AdminTranslations() {
  const [languages, setLanguages] = useState<Language[]>([])
  const [loading, setLoading] = useState(true)
  const [contentType, setContentType] = useState("all")

  useEffect(() => {
    async function fetchTranslations() {
      try {
        const res = await fetch("/api/admin/translations")
        if (res.ok) {
          setLanguages(await res.json())
        }
      } catch (err) {
        console.error("Failed to fetch translations:", err)
      } finally {
        setLoading(false)
      }
    }
    fetchTranslations()
  }, [])

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="rounded-lg bg-primary/10 p-2">
            <Languages className="h-6 w-6 text-primary" />
          </div>
          <div>
            <h1 className="text-3xl font-bold">Translations</h1>
            <p className="text-muted-foreground">
              Manage platform language translations
            </p>
          </div>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        {CONTENT_TYPES.map((type) => (
          <Button
            key={type}
            variant={contentType === type ? "default" : "outline"}
            size="sm"
            onClick={() => setContentType(type)}
          >
            {type.charAt(0).toUpperCase() + type.slice(1)}
          </Button>
        ))}
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {loading
          ? [...Array(6)].map((_, i) => (
              <Card key={i}>
                <CardContent className="flex items-center gap-4 p-6">
                  <div className="h-10 w-10 animate-pulse rounded-full bg-muted" />
                  <div className="flex-1 space-y-2">
                    <div className="h-4 w-32 animate-pulse rounded bg-muted" />
                    <div className="h-3 w-full animate-pulse rounded bg-muted" />
                  </div>
                </CardContent>
              </Card>
            ))
          : languages.map((lang) => (
              <Card key={lang.code}>
                <CardContent className="p-6">
                  <div className="flex items-center gap-4">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                      <Globe className="h-5 w-5 text-primary" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{lang.name}</p>
                          <p className="text-xs text-muted-foreground">
                            {lang.code.toUpperCase()}
                          </p>
                        </div>
                        <Badge
                          variant={
                            lang.status === "complete"
                              ? "default"
                              : lang.status === "in-progress"
                                ? "secondary"
                                : "outline"
                          }
                        >
                          {lang.status === "complete"
                            ? "Complete"
                            : lang.status === "in-progress"
                              ? "In Progress"
                              : "Not Started"}
                        </Badge>
                      </div>
                      <div className="mt-3">
                        <div className="flex items-center justify-between text-xs text-muted-foreground">
                          <span>
                            {lang.translatedKeys} / {lang.totalKeys} keys
                          </span>
                          <span>{lang.progress}%</span>
                        </div>
                        <div className="mt-1 h-2 w-full overflow-hidden rounded-full bg-muted">
                          <div
                            className="h-full rounded-full bg-primary transition-all"
                            style={{ width: `${lang.progress}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
      </div>
    </div>
  )
}
