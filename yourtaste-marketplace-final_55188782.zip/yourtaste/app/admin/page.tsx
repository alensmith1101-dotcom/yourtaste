export const dynamic = 'force-dynamic'

import {
  Users,
  Store,
  ShoppingCart,
  DollarSign,
  ArrowUpRight,
  TrendingUp,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { prisma } from "@/lib/prisma"
import { AdminCharts } from "@/components/admin/AdminCharts"

async function getStats() {
  const [userCount, vendorCount, orderCount, revenueResult] = await Promise.all([
    prisma.user.count(),
    prisma.vendor.count(),
    prisma.order.count(),
    prisma.order.aggregate({
      _sum: { total: true },
      where: { status: "DELIVERED" },
    }),
  ])

  const recentOrders = await prisma.order.findMany({
    take: 5,
    orderBy: { createdAt: "desc" },
    include: { user: { select: { name: true, email: true } } },
  })

  return {
    userCount,
    vendorCount,
    orderCount,
    totalRevenue: revenueResult._sum.total ?? 0,
    recentOrders: recentOrders.map((o) => ({
      id: o.id,
      orderNumber: o.orderNumber,
      customer: o.user.name || o.user.email,
      total: o.total,
      status: o.status,
      createdAt: o.createdAt.toISOString(),
    })),
  }
}

export default async function AdminDashboard() {
  const stats = await getStats()

  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const date = new Date()
    date.setDate(date.getDate() - (6 - i))
    return date.toISOString().split('T')[0]
  })

  const revenueByDay = await Promise.all(
    last7Days.map(async (date) => {
      const start = new Date(date)
      const end = new Date(date)
      end.setHours(23, 59, 59)
      const result = await prisma.order.aggregate({
        where: { createdAt: { gte: start, lte: end }, paymentStatus: 'PAID' },
        _sum: { total: true },
        _count: true,
      })
      return { date: date.slice(5), revenue: result._sum.total || 0, orders: result._count }
    })
  )

  const ordersByStatus = await prisma.order.groupBy({
    by: ['status'],
    _count: true,
  })

  const statusData = ordersByStatus.map(o => ({ name: o.status, value: o._count }))

  const statCards = [
    {
      title: "Total Users",
      value: stats.userCount.toLocaleString(),
      icon: Users,
      color: "text-blue-600",
      bg: "bg-blue-50",
      link: "/admin/users",
    },
    {
      title: "Active Vendors",
      value: stats.vendorCount.toLocaleString(),
      icon: Store,
      color: "text-purple-600",
      bg: "bg-purple-50",
      link: "/admin/vendors",
    },
    {
      title: "Total Orders",
      value: stats.orderCount.toLocaleString(),
      icon: ShoppingCart,
      color: "text-green-600",
      bg: "bg-green-50",
      link: "/admin/orders",
    },
    {
      title: "Total Revenue",
      value: `₹${(stats.totalRevenue / 100).toLocaleString()}`,
      icon: DollarSign,
      color: "text-emerald-600",
      bg: "bg-emerald-50",
      link: "/admin/analytics",
    },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Admin Dashboard</h1>
        <p className="text-muted-foreground">
          Platform overview and management
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {statCards.map((stat) => (
          <Link key={stat.title} href={stat.link}>
            <Card className="transition-shadow hover:shadow-md">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  {stat.title}
                </CardTitle>
                <div className={`rounded-lg p-2 ${stat.bg}`}>
                  <stat.icon className={`h-4 w-4 ${stat.color}`} />
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold">{stat.value}</p>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      <AdminCharts revenueData={revenueByDay} statusData={statusData} />

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Recent Orders
            </CardTitle>
            <Button variant="ghost" size="sm" asChild>
              <Link href="/admin/orders">
                View all
                <ArrowUpRight className="ml-1 h-3 w-3" />
              </Link>
            </Button>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="pb-3 text-left font-medium text-muted-foreground">
                      Order
                    </th>
                    <th className="pb-3 text-left font-medium text-muted-foreground">
                      Customer
                    </th>
                    <th className="pb-3 text-left font-medium text-muted-foreground">
                      Total
                    </th>
                    <th className="pb-3 text-left font-medium text-muted-foreground">
                      Status
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {stats.recentOrders.map((order) => (
                    <tr key={order.id} className="border-b last:border-0">
                      <td className="py-3 font-medium">{order.orderNumber}</td>
                      <td className="py-3">{order.customer}</td>
                      <td className="py-3">₹{(order.total / 100).toFixed(2)}</td>
                      <td className="py-3">
                        <Badge
                          variant={
                            order.status === "DELIVERED"
                              ? "default"
                              : order.status === "CANCELLED"
                                ? "destructive"
                                : "secondary"
                          }
                        >
                          {order.status}
                        </Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Quick Links</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {[
              { label: "Manage Users", href: "/admin/users" },
              { label: "Review Vendors", href: "/admin/vendors" },
              { label: "Platform Settings", href: "/admin/settings" },
              { label: "Content Moderation", href: "/admin/content" },
              { label: "Manage Coupons", href: "/admin/coupons" },
              { label: "Manage FAQs", href: "/admin/faqs" },
            ].map((link) => (
              <Button
                key={link.href}
                variant="ghost"
                className="w-full justify-start"
                asChild
              >
                <Link href={link.href}>
                  <ArrowUpRight className="mr-2 h-4 w-4" />
                  {link.label}
                </Link>
              </Button>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
