"use client"

export const dynamic = 'force-dynamic'

import { useEffect, useState } from "react"
import { Plus, Ticket, ToggleLeft, ToggleRight } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"

interface Coupon {
  id: string
  code: string
  type: string
  value: number
  usageLimit: number
  usedCount: number
  active: boolean
  expiresAt: string
}

export default function AdminCoupons() {
  const [coupons, setCoupons] = useState<Coupon[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [creating, setCreating] = useState(false)
  const [form, setForm] = useState({
    code: "",
    type: "percentage",
    value: "",
    usageLimit: "",
    expiresAt: "",
  })

  useEffect(() => {
    async function fetchCoupons() {
      try {
        const res = await fetch("/api/admin/coupons")
        if (res.ok) {
          setCoupons(await res.json())
        }
      } catch (err) {
        console.error("Failed to fetch coupons:", err)
      } finally {
        setLoading(false)
      }
    }
    fetchCoupons()
  }, [])

  function handleChange(
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }))
  }

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault()
    setCreating(true)
    try {
      const res = await fetch("/api/admin/coupons", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          value: parseFloat(form.value),
          usageLimit: parseInt(form.usageLimit) || null,
        }),
      })
      if (res.ok) {
        const coupon = await res.json()
        setCoupons((prev) => [...prev, coupon])
        setShowForm(false)
        setForm({ code: "", type: "percentage", value: "", usageLimit: "", expiresAt: "" })
      }
    } catch (err) {
      console.error("Failed to create coupon:", err)
    } finally {
      setCreating(false)
    }
  }

  async function handleToggle(couponId: string, currentActive: boolean) {
    try {
      const res = await fetch(`/api/admin/coupons/${couponId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ active: !currentActive }),
      })
      if (res.ok) {
        setCoupons((prev) =>
          prev.map((c) =>
            c.id === couponId ? { ...c, active: !currentActive } : c
          )
        )
      }
    } catch (err) {
      console.error("Failed to toggle coupon:", err)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Coupons</h1>
          <p className="text-muted-foreground">
            Create and manage discount codes
          </p>
        </div>
        <Button onClick={() => setShowForm(!showForm)}>
          <Plus className="mr-2 h-4 w-4" />
          Create Coupon
        </Button>
      </div>

      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>New Coupon</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleCreate} className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Code</label>
                  <Input
                    name="code"
                    placeholder="SAVE20"
                    value={form.code}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Type</label>
                  <select
                    name="type"
                    value={form.type}
                    onChange={handleChange}
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    <option value="percentage">Percentage (%)</option>
                    <option value="fixed">Fixed Amount ($)</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Value</label>
                  <Input
                    name="value"
                    type="number"
                    step="0.01"
                    min="0"
                    placeholder="20"
                    value={form.value}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Usage Limit</label>
                  <Input
                    name="usageLimit"
                    type="number"
                    min="0"
                    placeholder="Unlimited"
                    value={form.usageLimit}
                    onChange={handleChange}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Expires At</label>
                  <Input
                    name="expiresAt"
                    type="date"
                    value={form.expiresAt}
                    onChange={handleChange}
                  />
                </div>
              </div>
              <div className="flex justify-end gap-3">
                <Button
                  variant="outline"
                  type="button"
                  onClick={() => setShowForm(false)}
                >
                  Cancel
                </Button>
                <Button type="submit" disabled={creating}>
                  {creating ? "Creating..." : "Create Coupon"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardContent className="p-0">
          {loading ? (
            <div className="space-y-3 p-6">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-12 animate-pulse rounded bg-muted" />
              ))}
            </div>
          ) : coupons.length === 0 ? (
            <div className="flex flex-col items-center gap-4 py-16">
              <div className="rounded-full bg-muted p-4">
                <Ticket className="h-8 w-8 text-muted-foreground" />
              </div>
              <p className="text-muted-foreground">No coupons created yet.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-muted/50">
                    <th className="px-6 py-3 text-left font-medium text-muted-foreground">
                      Code
                    </th>
                    <th className="px-6 py-3 text-left font-medium text-muted-foreground">
                      Type
                    </th>
                    <th className="px-6 py-3 text-left font-medium text-muted-foreground">
                      Value
                    </th>
                    <th className="px-6 py-3 text-left font-medium text-muted-foreground">
                      Usage
                    </th>
                    <th className="px-6 py-3 text-left font-medium text-muted-foreground">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left font-medium text-muted-foreground">
                      Expires
                    </th>
                    <th className="px-6 py-3 text-right font-medium text-muted-foreground">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {coupons.map((coupon) => (
                    <tr key={coupon.id} className="border-b last:border-0">
                      <td className="px-6 py-4">
                        <code className="rounded bg-muted px-2 py-1 font-mono text-sm font-bold">
                          {coupon.code}
                        </code>
                      </td>
                      <td className="px-6 py-4 capitalize">{coupon.type}</td>
                      <td className="px-6 py-4 font-medium">
                        {coupon.type === "percentage"
                          ? `${coupon.value}%`
                          : `$${coupon.value.toFixed(2)}`}
                      </td>
                      <td className="px-6 py-4">
                        {coupon.usedCount}
                        {coupon.usageLimit ? ` / ${coupon.usageLimit}` : ""}
                      </td>
                      <td className="px-6 py-4">
                        <Badge variant={coupon.active ? "default" : "secondary"}>
                          {coupon.active ? "Active" : "Inactive"}
                        </Badge>
                      </td>
                      <td className="px-6 py-4 text-muted-foreground">
                        {coupon.expiresAt
                          ? new Date(coupon.expiresAt).toLocaleDateString()
                          : "Never"}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex justify-end">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleToggle(coupon.id, coupon.active)}
                          >
                            {coupon.active ? (
                              <ToggleRight className="mr-1 h-4 w-4 text-green-600" />
                            ) : (
                              <ToggleLeft className="mr-1 h-4 w-4" />
                            )}
                            {coupon.active ? "Deactivate" : "Activate"}
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
