'use client'

export const dynamic = 'force-dynamic'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import toast from 'react-hot-toast'
import { Plus, Edit2, Trash2 } from 'lucide-react'

interface Faq {
  id: string
  question: string
  answer: string
  category: string
  order: number
  isActive: boolean
}

export default function AdminFaqsPage() {
  const { data: session } = useSession()
  const router = useRouter()
  const [faqs, setFaqs] = useState<Faq[]>([])
  const [showForm, setShowForm] = useState(false)
  const [editingFaq, setEditingFaq] = useState<Faq | null>(null)
  const [form, setForm] = useState({ question: '', answer: '', category: 'general', order: 0, isActive: true })

  useEffect(() => {
    if (!session) router.push('/auth/signin')
    else fetchFaqs()
  }, [session, router])

  const fetchFaqs = async () => {
    try {
      const res = await fetch('/api/admin/faqs')
      const data = await res.json()
      setFaqs(data.faqs || [])
    } catch (err) {
      console.error('Failed to fetch FAQs:', err)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const method = editingFaq ? 'PUT' : 'POST'
      const res = await fetch('/api/admin/faqs', {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, id: editingFaq?.id })
      })
      if (!res.ok) throw new Error('Failed to save FAQ')
      toast.success(editingFaq ? 'FAQ updated' : 'FAQ created')
      setShowForm(false)
      setEditingFaq(null)
      setForm({ question: '', answer: '', category: 'general', order: 0, isActive: true })
      fetchFaqs()
    } catch (err) {
      toast.error('Failed to save FAQ')
    }
  }

  const handleEdit = (faq: Faq) => {
    setEditingFaq(faq)
    setForm({ question: faq.question, answer: faq.answer, category: faq.category, order: faq.order, isActive: faq.isActive })
    setShowForm(true)
  }

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this FAQ?')) return
    try {
      await fetch(`/api/admin/faqs?id=${id}`, { method: 'DELETE' })
      toast.success('FAQ deleted')
      fetchFaqs()
    } catch (err) {
      toast.error('Failed to delete FAQ')
    }
  }

  if (!session) return null

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Manage FAQs</h1>
        <button onClick={() => { setShowForm(true); setEditingFaq(null); setForm({ question: '', answer: '', category: 'general', order: 0, isActive: true }) }} className="px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 flex items-center gap-2">
          <Plus className="w-4 h-4" /> Add FAQ
        </button>
      </div>

      {showForm && (
        <div className="bg-white border border-gray-200 rounded-lg p-6 mb-6">
          <h2 className="text-lg font-semibold mb-4">{editingFaq ? 'Edit FAQ' : 'New FAQ'}</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Question</label>
              <input type="text" value={form.question} onChange={e => setForm({ ...form, question: e.target.value })} required className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Answer</label>
              <textarea value={form.answer} onChange={e => setForm({ ...form, answer: e.target.value })} required rows={4} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500" />
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">Category</label>
                <select value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500">
                  <option value="general">General</option>
                  <option value="orders">Orders</option>
                  <option value="shipping">Shipping</option>
                  <option value="returns">Returns</option>
                  <option value="payments">Payments</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Order</label>
                <input type="number" value={form.order} onChange={e => setForm({ ...form, order: parseInt(e.target.value) })} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500" />
              </div>
              <div className="flex items-end">
                <label className="flex items-center gap-2">
                  <input type="checkbox" checked={form.isActive} onChange={e => setForm({ ...form, isActive: e.target.checked })} className="w-4 h-4" />
                  <span className="text-sm">Active</span>
                </label>
              </div>
            </div>
            <div className="flex gap-2">
              <button type="submit" className="px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700">
                {editingFaq ? 'Update' : 'Create'}
              </button>
              <button type="button" onClick={() => { setShowForm(false); setEditingFaq(null) }} className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Question</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Category</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Order</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Status</th>
              <th className="px-4 py-3 text-right text-sm font-medium text-gray-700">Actions</th>
            </tr>
          </thead>
          <tbody>
            {faqs.map(faq => (
              <tr key={faq.id} className="border-b hover:bg-gray-50">
                <td className="px-4 py-3 text-sm">{faq.question}</td>
                <td className="px-4 py-3 text-sm capitalize">{faq.category}</td>
                <td className="px-4 py-3 text-sm">{faq.order}</td>
                <td className="px-4 py-3 text-sm">
                  <span className={`px-2 py-1 rounded-full text-xs ${faq.isActive ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'}`}>
                    {faq.isActive ? 'Active' : 'Inactive'}
                  </span>
                </td>
                <td className="px-4 py-3 text-right">
                  <button onClick={() => handleEdit(faq)} className="p-2 text-blue-600 hover:bg-blue-50 rounded">
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button onClick={() => handleDelete(faq.id)} className="p-2 text-red-600 hover:bg-red-50 rounded">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </td>
              </tr>
            ))}
            {faqs.length === 0 && (
              <tr>
                <td colSpan={5} className="px-4 py-8 text-center text-gray-500">No FAQs yet</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}
