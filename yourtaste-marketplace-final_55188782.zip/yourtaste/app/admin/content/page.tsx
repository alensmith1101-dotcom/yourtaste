"use client"

export const dynamic = 'force-dynamic'

import { useEffect, useState } from "react"
import { FileText, CheckCircle, XCircle, AlertTriangle } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface ContentReview {
  id: string
  type: string
  title: string
  submittedBy: string
  status: string
  createdAt: string
}

interface ReportStats {
  totalReports: number
  pendingReviews: number
  approvedThisMonth: number
  rejectedThisMonth: number
}

export default function AdminContent() {
  const [reviews, setReviews] = useState<ContentReview[]>([])
  const [reportStats, setReportStats] = useState<ReportStats>({
    totalReports: 0,
    pendingReviews: 0,
    approvedThisMonth: 0,
    rejectedThisMonth: 0,
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchContent() {
      try {
        const res = await fetch("/api/admin/content")
        if (res.ok) {
          const data = await res.json()
          setReviews(data.reviews || [])
          setReportStats(data.reportStats || reportStats)
        }
      } catch (err) {
        console.error("Failed to fetch content:", err)
      } finally {
        setLoading(false)
      }
    }
    fetchContent()
  }, [])

  async function handleAction(reviewId: string, action: "approve" | "reject") {
    try {
      const res = await fetch(`/api/admin/content/${reviewId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action }),
      })
      if (res.ok) {
        setReviews((prev) =>
          prev.map((r) =>
            r.id === reviewId
              ? { ...r, status: action === "approve" ? "approved" : "rejected" }
              : r
          )
        )
      }
    } catch (err) {
      console.error("Failed to update review:", err)
    }
  }

  const pending = reviews.filter((r) => r.status === "pending")

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Content Moderation</h1>
        <p className="text-muted-foreground">
          Review and moderate user-submitted content
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Reports
            </CardTitle>
            <AlertTriangle className="h-4 w-4 text-amber-600" />
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{reportStats.totalReports}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Pending Reviews
            </CardTitle>
            <FileText className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{reportStats.pendingReviews}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Approved (Month)
            </CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{reportStats.approvedThisMonth}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Rejected (Month)
            </CardTitle>
            <XCircle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{reportStats.rejectedThisMonth}</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Pending Reviews
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="space-y-3">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-14 animate-pulse rounded bg-muted" />
              ))}
            </div>
          ) : pending.length === 0 ? (
            <div className="flex flex-col items-center gap-4 py-12">
              <CheckCircle className="h-12 w-12 text-green-500" />
              <p className="font-medium">All caught up!</p>
              <p className="text-sm text-muted-foreground">
                No pending content reviews at this time.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {pending.map((review) => (
                <div
                  key={review.id}
                  className="flex items-center justify-between rounded-lg border p-4"
                >
                  <div className="flex items-center gap-4">
                    <Badge variant="secondary">{review.type}</Badge>
                    <div>
                      <p className="font-medium">{review.title}</p>
                      <p className="text-sm text-muted-foreground">
                        by {review.submittedBy} &middot;{" "}
                        {new Date(review.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleAction(review.id, "approve")}
                      className="text-green-600"
                    >
                      <CheckCircle className="mr-1 h-4 w-4" />
                      Approve
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleAction(review.id, "reject")}
                      className="text-destructive"
                    >
                      <XCircle className="mr-1 h-4 w-4" />
                      Reject
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
