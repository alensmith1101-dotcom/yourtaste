"use client"

export const dynamic = 'force-dynamic'

import { useState, Suspense } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { signIn } from "next-auth/react"
import Link from "next/link"
import {
  Shield,
  Loader2,
  AlertTriangle,
  Keyboard,
  ArrowLeft,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"

export default function TwoFactorVerifyPage() {
  return (
    <Suspense
      fallback={
        <div className="flex items-center justify-center min-h-[60vh]">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
      }
    >
      <TwoFactorVerifyForm />
    </Suspense>
  )
}

function TwoFactorVerifyForm() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const email = searchParams.get("email") || ""
  const callbackUrl = searchParams.get("callbackUrl") || "/"

  const [token, setToken] = useState("")
  const [backupCode, setBackupCode] = useState("")
  const [useBackupCode, setUseBackupCode] = useState(false)
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError("")

    if (!email) {
      setError("Session expired. Please sign in again.")
      return
    }

    if (!useBackupCode && (!token || token.length !== 6)) {
      setError("Please enter a valid 6-digit code")
      return
    }

    if (useBackupCode && !backupCode) {
      setError("Please enter a backup code")
      return
    }

    setLoading(true)
    try {
      const password = sessionStorage.getItem(`2fa_password_${email}`)
      if (!password) {
        setError("Session expired. Please sign in again.")
        router.push("/auth/signin")
        return
      }

      const res = await fetch("/api/auth/2fa/login-verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email,
          password,
          token: useBackupCode ? undefined : token,
          backupCode: useBackupCode ? backupCode : undefined,
        }),
      })

      const data = await res.json()

      if (!res.ok) {
        setError(data.error || "Verification failed")
        setLoading(false)
        return
      }

      sessionStorage.removeItem(`2fa_password_${email}`)

      await signIn("credentials", {
        redirect: false,
        email,
        password,
      })

      router.push(callbackUrl)
      router.refresh()
    } catch {
      setError("An unexpected error occurred")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center bg-gray-50 px-4 py-12">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1 text-center">
          <div className="mx-auto mb-2 flex h-12 w-12 items-center justify-center rounded-full bg-orange-100">
            <Shield className="h-6 w-6 text-orange-600" />
          </div>
          <CardTitle className="text-2xl font-bold">
            Two-Factor Authentication
          </CardTitle>
          <CardDescription>
            {useBackupCode
              ? "Enter one of your backup codes to sign in"
              : "Enter the 6-digit code from your authenticator app"}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <div className="flex items-center gap-2 rounded-md bg-red-50 p-3 text-sm text-red-600">
              <AlertTriangle className="h-4 w-4 shrink-0" />
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {!useBackupCode ? (
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">
                  Authentication Code
                </label>
                <Input
                  value={token}
                  onChange={(e) =>
                    setToken(e.target.value.replace(/\D/g, "").slice(0, 6))
                  }
                  placeholder="000000"
                  className="font-mono text-center text-2xl tracking-[0.5em]"
                  maxLength={6}
                  autoFocus
                  required
                />
              </div>
            ) : (
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">
                  Backup Code
                </label>
                <Input
                  value={backupCode}
                  onChange={(e) => setBackupCode(e.target.value)}
                  placeholder="XXXX-XXXX"
                  className="font-mono text-center text-lg tracking-wider"
                  autoFocus
                  required
                />
              </div>
            )}

            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Verifying...
                </>
              ) : (
                "Verify"
              )}
            </Button>
          </form>

          <div className="text-center">
            <button
              type="button"
              onClick={() => {
                setUseBackupCode(!useBackupCode)
                setError("")
                setToken("")
                setBackupCode("")
              }}
              className="inline-flex items-center gap-1 text-sm text-orange-600 hover:text-orange-700"
            >
              <Keyboard className="h-3 w-3" />
              {useBackupCode
                ? "Use authenticator code instead"
                : "Use a backup code"}
            </button>
          </div>
        </CardContent>
        <CardFooter className="justify-center">
          <Link
            href="/auth/signin"
            className="inline-flex items-center gap-1 text-sm text-gray-500 hover:text-gray-700"
          >
            <ArrowLeft className="h-3 w-3" />
            Back to sign in
          </Link>
        </CardFooter>
      </Card>
    </div>
  )
}
