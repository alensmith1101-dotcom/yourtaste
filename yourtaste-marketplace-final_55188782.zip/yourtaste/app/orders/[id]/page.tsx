export const dynamic = 'force-dynamic'

import Link from "next/link"
import Image from "next/image"
import { notFound } from "next/navigation"
import { getServerSession } from "next-auth"
import { redirect } from "next/navigation"
import {
  Package,
  MapPin,
  CreditCard,
  ChevronRight,
} from "lucide-react"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { formatPrice, formatDate } from "@/lib/utils"
import { Badge } from "@/components/ui/badge"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { OrderTrackingTimeline } from "@/components/shared/OrderTrackingTimeline"

const STATUS_STYLES: Record<string, string> = {
  PENDING: "bg-yellow-100 text-yellow-700 hover:bg-yellow-100",
  CONFIRMED: "bg-blue-100 text-blue-700 hover:bg-blue-100",
  PROCESSING: "bg-purple-100 text-purple-700 hover:bg-purple-100",
  SHIPPED: "bg-indigo-100 text-indigo-700 hover:bg-indigo-100",
  DELIVERED: "bg-green-100 text-green-700 hover:bg-green-100",
  CANCELLED: "bg-red-100 text-red-700 hover:bg-red-100",
  REFUNDED: "bg-gray-100 text-gray-700 hover:bg-gray-100",
}

const TIMELINE_STEPS = [
  { status: "PENDING", label: "Order Placed" },
  { status: "CONFIRMED", label: "Order Confirmed" },
  { status: "PROCESSING", label: "Processing" },
  { status: "SHIPPED", label: "Shipped" },
  { status: "OUT_FOR_DELIVERY", label: "Out for Delivery" },
  { status: "DELIVERED", label: "Delivered" },
]

function parseImages(images: string): string[] {
  try {
    const parsed = JSON.parse(images)
    return Array.isArray(parsed) ? parsed : []
  } catch (err) {
    console.error('Failed to parse images:', err)
    return []
  }
}

function parseAddress(address: string | null) {
  if (!address) return null
  try {
    return JSON.parse(address)
  } catch (err) {
    console.error('Failed to parse address:', err)
    return null
  }
}

interface OrderDetailPageProps {
  params: { id: string }
}

export default async function OrderDetailPage({ params }: OrderDetailPageProps) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.email) redirect("/auth/signin")

  const user = await prisma.user.findUnique({
    where: { email: session.user.email },
  })
  if (!user) redirect("/auth/signin")

  const order = await prisma.order.findFirst({
    where: { id: params.id, userId: user.id },
    include: {
      items: {
        include: {
          product: {
            select: { name: true, images: true, slug: true },
          },
        },
      },
      tracking: {
        orderBy: { timestamp: "desc" },
      },
      statusHistory: {
        orderBy: { createdAt: "asc" },
      },
    },
  })

  if (!order) notFound()

  const shippingAddress = parseAddress(order.shippingAddress)
  const billingAddress = parseAddress(order.billingAddress)

  const effectiveStatus = order.status === 'SHIPPED' && order.tracking.some(t => t.status === 'OUT_FOR_DELIVERY')
    ? 'OUT_FOR_DELIVERY'
    : order.status

  const timelineSteps = TIMELINE_STEPS.map((step) => {
    const trackingEntry = order.tracking.find((t) => t.status === step.status)
    const historyEntry = order.statusHistory.find((h) => h.toStatus === step.status)
    return {
      status: step.status,
      label: step.label,
      timestamp: trackingEntry?.timestamp.toISOString() ?? historyEntry?.createdAt.toISOString() ?? (step.status === 'PENDING' ? order.createdAt.toISOString() : null),
      description: trackingEntry?.description ?? null,
      location: trackingEntry?.location ?? null,
    }
  })

  const statusHistoryData = order.statusHistory.map((h) => ({
    fromStatus: h.fromStatus,
    toStatus: h.toStatus,
    createdAt: h.createdAt.toISOString(),
  }))

  const deliveryAttempts = order.tracking.filter(
    (t) => t.status === 'DELIVERY_ATTEMPT' || t.description?.toLowerCase().includes('delivery attempt')
  ).length

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8">
      <nav className="mb-6 flex items-center gap-2 text-sm text-gray-500">
        <Link href="/orders" className="hover:text-gray-700">
          My Orders
        </Link>
        <ChevronRight className="h-3 w-3" />
        <span className="text-gray-900">#{order.orderNumber}</span>
      </nav>

      <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">
            Order #{order.orderNumber}
          </h1>
          <p className="mt-1 text-sm text-gray-500">
            Placed on {formatDate(order.createdAt)}
          </p>
        </div>
        <Badge
          className={`${
            STATUS_STYLES[order.status] || "bg-gray-100 text-gray-700"
          } text-sm`}
        >
          {order.status}
        </Badge>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Package className="h-5 w-5 text-orange-600" />
                Order Items
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {order.items.map((item) => {
                const images = parseImages(item.product.images)
                return (
                  <div
                    key={item.id}
                    className="flex items-center gap-4 rounded-lg border border-gray-100 p-3"
                  >
                    <div className="h-16 w-16 shrink-0 overflow-hidden rounded-lg bg-gray-100">
                      {images[0] ? (
                        <Image
                          src={images[0]}
                          alt={item.product.name}
                          width={64}
                          height={64}
                          className="h-full w-full object-cover"
                        />
                      ) : (
                        <div className="flex h-full w-full items-center justify-center">
                          <Package className="h-6 w-6 text-gray-300" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1">
                      <Link
                        href={`/products/${item.product.slug}`}
                        className="font-medium text-gray-900 hover:text-orange-600"
                      >
                        {item.product.name}
                      </Link>
                      <p className="text-sm text-gray-500">
                        Qty: {item.quantity} x {formatPrice(item.priceCents)}
                      </p>
                    </div>
                    <p className="font-semibold text-gray-900">
                      {formatPrice(item.priceCents * item.quantity)}
                    </p>
                  </div>
                )
              })}
            </CardContent>
          </Card>

          {order.status !== "CANCELLED" && (
            <OrderTrackingTimeline
              steps={timelineSteps}
              currentStatus={effectiveStatus}
              trackingNumber={order.trackingNumber}
              shippingCarrier={order.shippingCarrier}
              estimatedDelivery={order.estimatedDelivery?.toISOString() ?? null}
              deliveredAt={order.deliveredAt?.toISOString() ?? null}
              shippingAddress={shippingAddress}
              createdAt={order.createdAt.toISOString()}
              statusHistory={statusHistoryData}
              deliveryAttempts={deliveryAttempts}
            />
          )}
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Subtotal</span>
                <span>{formatPrice(order.subtotal)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Shipping</span>
                <span>
                  {order.shippingCost === 0
                    ? "Free"
                    : formatPrice(order.shippingCost)}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Tax</span>
                <span>{formatPrice(order.tax)}</span>
              </div>
              {order.discount > 0 && (
                <div className="flex justify-between text-sm">
                  <span className="text-green-600">Discount</span>
                  <span className="text-green-600">
                    -{formatPrice(order.discount)}
                  </span>
                </div>
              )}
              <div className="border-t pt-2">
                <div className="flex justify-between">
                  <span className="font-semibold">Total</span>
                  <span className="font-bold">
                    {formatPrice(order.total)}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          {shippingAddress && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <MapPin className="h-5 w-5 text-orange-600" />
                  Shipping Address
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">
                  {shippingAddress.fullName}
                </p>
                <p className="text-sm text-gray-600">{shippingAddress.street}</p>
                <p className="text-sm text-gray-600">
                  {shippingAddress.city}, {shippingAddress.state}{" "}
                  {shippingAddress.zipCode}
                </p>
                {shippingAddress.phone && (
                  <p className="mt-2 text-sm text-gray-600">
                    {shippingAddress.phone}
                  </p>
                )}
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <CreditCard className="h-5 w-5 text-orange-600" />
                Payment
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-1">
                <p className="text-sm text-gray-600">
                  Method: {order.paymentMethod || "N/A"}
                </p>
                <p className="text-sm text-gray-600">
                  Status:{" "}
                  <Badge
                    className={
                      order.paymentStatus === "PAID"
                        ? "bg-green-100 text-green-700 hover:bg-green-100"
                        : "bg-yellow-100 text-yellow-700 hover:bg-yellow-100"
                    }
                  >
                    {order.paymentStatus}
                  </Badge>
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
