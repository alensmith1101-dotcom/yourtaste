export const dynamic = 'force-dynamic'

import Link from "next/link"
import Image from "next/image"
import { Package, ChevronRight } from "lucide-react"
import { getServerSession } from "next-auth"
import { redirect } from "next/navigation"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { formatPrice, formatDate } from "@/lib/utils"
import { Badge } from "@/components/ui/badge"
import {
  Card,
  CardContent,
} from "@/components/ui/card"

const STATUS_STYLES: Record<string, string> = {
  PENDING: "bg-yellow-100 text-yellow-700 hover:bg-yellow-100",
  CONFIRMED: "bg-blue-100 text-blue-700 hover:bg-blue-100",
  PROCESSING: "bg-purple-100 text-purple-700 hover:bg-purple-100",
  SHIPPED: "bg-indigo-100 text-indigo-700 hover:bg-indigo-100",
  DELIVERED: "bg-green-100 text-green-700 hover:bg-green-100",
  CANCELLED: "bg-red-100 text-red-700 hover:bg-red-100",
  REFUNDED: "bg-gray-100 text-gray-700 hover:bg-gray-100",
}

export default async function OrdersPage() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.email) redirect("/auth/signin")

  const user = await prisma.user.findUnique({
    where: { email: session.user.email },
  })
  if (!user) redirect("/auth/signin")

  const orders = await prisma.order.findMany({
    where: { userId: user.id },
    include: {
      items: {
        include: {
          product: { select: { name: true, images: true } },
        },
        take: 3,
      },
    },
    orderBy: { createdAt: "desc" },
  })

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8">
      <h1 className="text-3xl font-bold text-gray-900">My Orders</h1>
      <p className="mt-2 text-gray-600">
        Track and manage your orders
      </p>

      {orders.length > 0 ? (
        <div className="mt-8 space-y-4">
          {orders.map((order) => (
            <Link key={order.id} href={`/orders/${order.id}`}>
              <Card className="transition-all hover:shadow-md">
                <CardContent className="p-6">
                  <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                    <div className="space-y-1">
                      <div className="flex items-center gap-3">
                        <p className="font-semibold text-gray-900">
                          Order #{order.orderNumber}
                        </p>
                        <Badge
                          className={
                            STATUS_STYLES[order.status] ||
                            "bg-gray-100 text-gray-700 hover:bg-gray-100"
                          }
                        >
                          {order.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-500">
                        Placed on {formatDate(order.createdAt)}
                      </p>
                    </div>
                    <div className="flex items-center gap-4">
                      <p className="text-lg font-bold text-gray-900">
                        {formatPrice(order.total)}
                      </p>
                      <ChevronRight className="h-5 w-5 text-gray-400" />
                    </div>
                  </div>
                  {order.items.length > 0 && (
                    <div className="mt-4 flex items-center gap-2 border-t pt-4">
                      <div className="flex -space-x-2">
                        {order.items.slice(0, 3).map((item, i) => {
                          let images: string[] = []
                          try {
                            images = JSON.parse(item.product.images)
                          } catch (err) {
                            console.error('Failed to parse product images:', err)
                          }
                          return (
                            <div
                              key={i}
                              className="h-10 w-10 overflow-hidden rounded-full border-2 border-white bg-gray-100"
                            >
                              {images[0] ? (
                                <Image
                                  src={images[0]}
                                  alt={item.product.name}
                                  width={40}
                                  height={40}
                                  className="h-full w-full object-cover"
                                />
                              ) : (
                                <div className="flex h-full w-full items-center justify-center">
                                  <Package className="h-4 w-4 text-gray-300" />
                                </div>
                              )}
                            </div>
                          )
                        })}
                      </div>
                      <span className="text-sm text-gray-500">
                        {order.items.length} item{order.items.length !== 1 ? "s" : ""}
                        {order.items.length >= 3 ? "+" : ""}
                      </span>
                    </div>
                  )}
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      ) : (
        <div className="mt-16 flex flex-col items-center text-center">
          <div className="flex h-24 w-24 items-center justify-center rounded-full bg-gray-100">
            <Package className="h-12 w-12 text-gray-400" />
          </div>
          <h2 className="mt-6 text-xl font-semibold text-gray-900">
            No orders yet
          </h2>
          <p className="mt-2 text-gray-500">
            When you place orders, they will appear here.
          </p>
          <Link
            href="/products"
            className="mt-6 inline-flex items-center rounded-lg bg-orange-600 px-6 py-3 text-sm font-semibold text-white hover:bg-orange-700"
          >
            Start Shopping
          </Link>
        </div>
      )}
    </div>
  )
}
