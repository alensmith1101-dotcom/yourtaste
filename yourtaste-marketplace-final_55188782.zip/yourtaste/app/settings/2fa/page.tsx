"use client"

export const dynamic = 'force-dynamic'

import { useState, useEffect } from "react"
import Image from "next/image"
import {
  Shield,
  ShieldCheck,
  ShieldOff,
  Loader2,
  CheckCircle,
  AlertTriangle,
  Copy,
  Eye,
  EyeOff,
  Download,
  QrCode,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import Link from "next/link"

export default function TwoFactorSettingsPage() {
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(false)
  const [loading, setLoading] = useState(true)
  const [setupLoading, setSetupLoading] = useState(false)
  const [verifyLoading, setVerifyLoading] = useState(false)
  const [disableLoading, setDisableLoading] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")

  const [secret, setSecret] = useState("")
  const [qrCode, setQrCode] = useState("")
  const [showSecret, setShowSecret] = useState(false)
  const [verifyToken, setVerifyToken] = useState("")
  const [backupCodes, setBackupCodes] = useState<string[]>([])
  const [showBackupCodes, setShowBackupCodes] = useState(false)
  const [codesCopied, setCodesCopied] = useState(false)

  const [disableToken, setDisableToken] = useState("")
  const [disablePassword, setDisablePassword] = useState("")
  const [showDisableSection, setShowDisableSection] = useState(false)

  useEffect(() => {
    fetchStatus()
  }, [])

  async function fetchStatus() {
    try {
      const res = await fetch("/api/profile")
      if (res.ok) {
        const data = await res.json()
        setTwoFactorEnabled(data.twoFactorEnabled || false)
      }
    } catch {
    } finally {
      setLoading(false)
    }
  }

  async function handleSetup() {
    setError("")
    setSuccess("")
    setSetupLoading(true)
    try {
      const res = await fetch("/api/auth/2fa/setup", { method: "POST" })
      const data = await res.json()

      if (!res.ok) {
        setError(data.error || "Failed to set up 2FA")
        setSetupLoading(false)
        return
      }

      setSecret(data.secret)
      setQrCode(data.qrCode)
    } catch {
      setError("An unexpected error occurred")
    } finally {
      setSetupLoading(false)
    }
  }

  async function handleVerify() {
    if (!verifyToken || verifyToken.length !== 6) {
      setError("Please enter a valid 6-digit code")
      return
    }

    setError("")
    setSuccess("")
    setVerifyLoading(true)
    try {
      const res = await fetch("/api/auth/2fa/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token: verifyToken }),
      })
      const data = await res.json()

      if (!res.ok) {
        setError(data.error || "Verification failed")
        setVerifyLoading(false)
        return
      }

      if (data.backupCodes) {
        setBackupCodes(data.backupCodes)
        setShowBackupCodes(true)
      }

      setTwoFactorEnabled(true)
      setSuccess("Two-factor authentication has been enabled!")
      setSecret("")
      setQrCode("")
      setVerifyToken("")
    } catch {
      setError("An unexpected error occurred")
    } finally {
      setVerifyLoading(false)
    }
  }

  async function handleDisable() {
    if (!disableToken || disableToken.length !== 6) {
      setError("Please enter a valid 6-digit code")
      return
    }
    if (!disablePassword) {
      setError("Please enter your password")
      return
    }

    setError("")
    setSuccess("")
    setDisableLoading(true)
    try {
      const res = await fetch("/api/auth/2fa/disable", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token: disableToken, password: disablePassword }),
      })
      const data = await res.json()

      if (!res.ok) {
        setError(data.error || "Failed to disable 2FA")
        setDisableLoading(false)
        return
      }

      setTwoFactorEnabled(false)
      setSuccess("Two-factor authentication has been disabled")
      setShowDisableSection(false)
      setDisableToken("")
      setDisablePassword("")
    } catch {
      setError("An unexpected error occurred")
    } finally {
      setDisableLoading(false)
    }
  }

  function copyBackupCodes() {
    const text = backupCodes.join("\n")
    navigator.clipboard.writeText(text)
    setCodesCopied(true)
    setTimeout(() => setCodesCopied(false), 2000)
  }

  function downloadBackupCodes() {
    const text = `YourTaste Backup Codes\nGenerated: ${new Date().toLocaleDateString()}\n\n${backupCodes.join("\n")}\n\nKeep these codes safe. Each code can only be used once.`
    const blob = new Blob([text], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "yourtaste-backup-codes.txt"
    a.click()
    URL.revokeObjectURL(url)
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-8 w-8 animate-spin text-orange-600" />
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="flex items-center gap-3">
        <Link
          href="/settings"
          className="text-sm text-gray-500 hover:text-gray-700"
        >
          &larr; Settings
        </Link>
      </div>

      <h1 className="mt-4 text-3xl font-bold text-gray-900">
        Two-Factor Authentication
      </h1>
      <p className="mt-2 text-gray-600">
        Add an extra layer of security to your account
      </p>

      <div className="mt-8 space-y-6">
        {error && (
          <div className="flex items-center gap-2 rounded-md bg-red-50 p-3 text-sm text-red-600">
            <AlertTriangle className="h-4 w-4 shrink-0" />
            {error}
          </div>
        )}
        {success && (
          <div className="flex items-center gap-2 rounded-md bg-green-50 p-3 text-sm text-green-600">
            <CheckCircle className="h-4 w-4 shrink-0" />
            {success}
          </div>
        )}

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              {twoFactorEnabled ? (
                <ShieldCheck className="h-5 w-5 text-green-600" />
              ) : (
                <Shield className="h-5 w-5 text-orange-600" />
              )}
              {twoFactorEnabled ? "2FA is Enabled" : "Enable 2FA"}
            </CardTitle>
            <CardDescription>
              {twoFactorEnabled
                ? "Your account is protected with two-factor authentication"
                : "Protect your account with a time-based verification code from your authenticator app"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {!twoFactorEnabled && !secret && (
              <Button onClick={handleSetup} disabled={setupLoading}>
                {setupLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Setting up...
                  </>
                ) : (
                  <>
                    <QrCode className="mr-2 h-4 w-4" />
                    Set Up 2FA
                  </>
                )}
              </Button>
            )}

            {!twoFactorEnabled && secret && (
              <div className="space-y-6">
                <div className="space-y-4">
                  <h3 className="font-medium text-gray-900">
                    Step 1: Scan QR Code
                  </h3>
                  <p className="text-sm text-gray-600">
                    Scan this QR code with your authenticator app (Google
                    Authenticator, Authy, etc.)
                  </p>
                  {qrCode && (
                    <div className="flex justify-center rounded-lg border border-gray-200 bg-white p-4">
                      <Image src={qrCode} alt="2FA QR Code" width={192} height={192} />
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <h3 className="font-medium text-gray-900">
                    Or enter this secret key manually:
                  </h3>
                  <div className="flex items-center gap-2">
                    <code className="flex-1 rounded-md bg-gray-100 px-3 py-2 font-mono text-sm break-all">
                      {showSecret ? secret : "•••• •••• •••• •••• •••• •••• •••• ••••"}
                    </code>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowSecret(!showSecret)}
                    >
                      {showSecret ? (
                        <EyeOff className="h-4 w-4" />
                      ) : (
                        <Eye className="h-4 w-4" />
                      )}
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        navigator.clipboard.writeText(secret)
                      }}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <div className="space-y-3">
                  <h3 className="font-medium text-gray-900">
                    Step 2: Verify Setup
                  </h3>
                  <p className="text-sm text-gray-600">
                    Enter the 6-digit code from your authenticator app to confirm
                  </p>
                  <div className="flex gap-2">
                    <Input
                      value={verifyToken}
                      onChange={(e) =>
                        setVerifyToken(e.target.value.replace(/\D/g, "").slice(0, 6))
                      }
                      placeholder="000000"
                      className="max-w-[200px] font-mono text-center text-lg tracking-widest"
                      maxLength={6}
                    />
                    <Button onClick={handleVerify} disabled={verifyLoading}>
                      {verifyLoading ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        "Verify & Enable"
                      )}
                    </Button>
                  </div>
                </div>
              </div>
            )}

            {twoFactorEnabled && !showDisableSection && (
              <div className="space-y-4">
                <div className="rounded-md bg-green-50 p-3">
                  <div className="flex items-center gap-2 text-sm text-green-700">
                    <ShieldCheck className="h-4 w-4" />
                    Your account is secured with two-factor authentication
                  </div>
                </div>
                <Button
                  variant="destructive"
                  onClick={() => setShowDisableSection(true)}
                >
                  <ShieldOff className="mr-2 h-4 w-4" />
                  Disable 2FA
                </Button>
              </div>
            )}

            {twoFactorEnabled && showDisableSection && (
              <div className="space-y-4">
                <div className="rounded-md bg-yellow-50 p-3">
                  <div className="flex items-center gap-2 text-sm text-yellow-700">
                    <AlertTriangle className="h-4 w-4" />
                    Disabling 2FA will make your account less secure
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700">
                      Password
                    </label>
                    <Input
                      type="password"
                      value={disablePassword}
                      onChange={(e) => setDisablePassword(e.target.value)}
                      placeholder="Enter your password"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700">
                      Verification Code
                    </label>
                    <Input
                      value={disableToken}
                      onChange={(e) =>
                        setDisableToken(
                          e.target.value.replace(/\D/g, "").slice(0, 6)
                        )
                      }
                      placeholder="Enter 6-digit code"
                      className="max-w-[200px] font-mono text-center"
                      maxLength={6}
                    />
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="destructive"
                      onClick={handleDisable}
                      disabled={disableLoading}
                    >
                      {disableLoading ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      ) : (
                        "Disable 2FA"
                      )}
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => {
                        setShowDisableSection(false)
                        setDisableToken("")
                        setDisablePassword("")
                      }}
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {showBackupCodes && backupCodes.length > 0 && (
          <Card className="border-orange-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <CheckCircle className="h-5 w-5 text-green-600" />
                Save Your Backup Codes
              </CardTitle>
              <CardDescription>
                These codes can be used to access your account if you lose your
                authenticator device. Each code can only be used once.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-2 rounded-lg bg-gray-50 p-4">
                {backupCodes.map((code, index) => (
                  <code
                    key={index}
                    className="rounded bg-white px-3 py-2 text-center font-mono text-sm shadow-sm"
                  >
                    {code}
                  </code>
                ))}
              </div>
              <div className="flex gap-2">
                <Button variant="outline" onClick={copyBackupCodes}>
                  {codesCopied ? (
                    <>
                      <CheckCircle className="mr-2 h-4 w-4 text-green-600" />
                      Copied!
                    </>
                  ) : (
                    <>
                      <Copy className="mr-2 h-4 w-4" />
                      Copy Codes
                    </>
                  )}
                </Button>
                <Button variant="outline" onClick={downloadBackupCodes}>
                  <Download className="mr-2 h-4 w-4" />
                  Download
                </Button>
              </div>
              <p className="text-xs text-red-600">
                Store these codes in a safe place. They will not be shown again.
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
