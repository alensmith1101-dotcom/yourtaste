"use client"

export const dynamic = 'force-dynamic'

import { useState, useEffect, useCallback } from "react"
import {
  Mail,
  Smartphone,
  MessageSquare,
  Loader2,
  CheckCircle,
  ArrowLeft,
  Package,
  Tag,
  Newspaper,
  Bell,
  TrendingDown,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import Link from "next/link"

interface NotificationPrefs {
  emailOrderUpdates: boolean
  emailPromotions: boolean
  emailNewsletter: boolean
  pushOrderUpdates: boolean
  pushDeals: boolean
  pushPriceDrops: boolean
  smsOrderUpdates: boolean
}

const DEFAULT_PREFS: NotificationPrefs = {
  emailOrderUpdates: true,
  emailPromotions: false,
  emailNewsletter: true,
  pushOrderUpdates: true,
  pushDeals: true,
  pushPriceDrops: true,
  smsOrderUpdates: true,
}

function Toggle({
  checked,
  onChange,
  disabled,
}: {
  checked: boolean
  onChange: (val: boolean) => void
  disabled?: boolean
}) {
  return (
    <label className="relative inline-flex cursor-pointer items-center">
      <input
        type="checkbox"
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
        disabled={disabled}
        className="peer sr-only"
      />
      <div className="h-6 w-11 rounded-full bg-gray-200 after:absolute after:left-[2px] after:top-[2px] after:h-5 after:w-5 after:rounded-full after:border after:border-gray-300 after:bg-white after:transition-all after:content-[''] peer-checked:bg-orange-600 peer-checked:after:translate-x-full peer-checked:after:border-white peer-focus:ring-2 peer-focus:ring-orange-500 peer-focus:ring-offset-2 peer-disabled:opacity-50 peer-disabled:cursor-not-allowed" />
    </label>
  )
}

export default function NotificationPreferencesPage() {
  const [prefs, setPrefs] = useState<NotificationPrefs>(DEFAULT_PREFS)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState<string | null>(null)
  const [savedFields, setSavedFields] = useState<Set<string>>(new Set())

  const fetchPrefs = useCallback(async () => {
    try {
      const res = await fetch("/api/notifications/preferences")
      if (res.ok) {
        const { data } = await res.json()
        setPrefs({
          emailOrderUpdates: data.emailOrderUpdates,
          emailPromotions: data.emailPromotions,
          emailNewsletter: data.emailNewsletter,
          pushOrderUpdates: data.pushOrderUpdates,
          pushDeals: data.pushDeals,
          pushPriceDrops: data.pushPriceDrops,
          smsOrderUpdates: data.smsOrderUpdates,
        })
      }
    } catch (err) {
      console.error("Failed to load preferences:", err)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchPrefs()
  }, [fetchPrefs])

  async function updatePref(key: keyof NotificationPrefs, value: boolean) {
    setPrefs((prev) => ({ ...prev, [key]: value }))
    setSaving(key)
    setSavedFields((prev) => {
      const next = new Set(prev)
      next.delete(key)
      return next
    })

    try {
      const res = await fetch("/api/notifications/preferences", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ [key]: value }),
      })

      if (!res.ok) {
        setPrefs((prev) => ({ ...prev, [key]: !value }))
      } else {
        setSavedFields((prev) => new Set(prev).add(key))
        setTimeout(() => {
          setSavedFields((prev) => {
            const next = new Set(prev)
            next.delete(key)
            return next
          })
        }, 2000)
      }
    } catch {
      setPrefs((prev) => ({ ...prev, [key]: !value }))
    } finally {
      setSaving(null)
    }
  }

  if (loading) {
    return (
      <div className="mx-auto flex max-w-2xl items-center justify-center px-4 py-16">
        <Loader2 className="h-6 w-6 animate-spin text-orange-600" />
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-8 sm:px-6 lg:px-8">
      <Link
        href="/settings"
        className="mb-6 inline-flex items-center gap-1 text-sm text-gray-500 hover:text-gray-700"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to Settings
      </Link>

      <h1 className="text-3xl font-bold text-gray-900">
        Notification Preferences
      </h1>
      <p className="mt-2 text-gray-600">
        Choose how and when you want to be notified
      </p>

      <div className="mt-8 space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Mail className="h-5 w-5 text-orange-600" />
              Email Notifications
            </CardTitle>
            <CardDescription>
              Notifications sent to your email address
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {[
              {
                key: "emailOrderUpdates" as const,
                icon: Package,
                label: "Order Updates",
                desc: "Order confirmations, shipping status, delivery confirmations, and return updates",
              },
              {
                key: "emailPromotions" as const,
                icon: Tag,
                label: "Promotions & Deals",
                desc: "Special offers, discount codes, flash sales, and vendor promotions",
              },
              {
                key: "emailNewsletter" as const,
                icon: Newspaper,
                label: "Newsletter",
                desc: "Weekly digest with new arrivals, trending products, and marketplace highlights",
              },
            ].map((item) => (
              <div
                key={item.key}
                className="flex items-center justify-between rounded-lg border border-gray-100 p-3"
              >
                <div className="flex items-start gap-3">
                  <item.icon className="mt-0.5 h-4 w-4 text-gray-400" />
                  <div>
                    <p className="text-sm font-medium text-gray-900">
                      {item.label}
                    </p>
                    <p className="text-xs text-gray-500">{item.desc}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {savedFields.has(item.key) && (
                    <CheckCircle className="h-4 w-4 text-green-500" />
                  )}
                  {saving === item.key ? (
                    <Loader2 className="h-4 w-4 animate-spin text-gray-400" />
                  ) : (
                    <Toggle
                      checked={prefs[item.key]}
                      onChange={(val) => updatePref(item.key, val)}
                    />
                  )}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Smartphone className="h-5 w-5 text-orange-600" />
              Push Notifications
            </CardTitle>
            <CardDescription>
              Real-time notifications on your device
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {[
              {
                key: "pushOrderUpdates" as const,
                icon: Package,
                label: "Order Updates",
                desc: "Instant alerts for order status changes, shipping updates, and delivery notifications",
              },
              {
                key: "pushDeals" as const,
                icon: Bell,
                label: "Deal Alerts",
                desc: "Be the first to know about flash sales, limited-time offers, and new deals",
              },
              {
                key: "pushPriceDrops" as const,
                icon: TrendingDown,
                label: "Price Drops on Wishlist",
                desc: "Get notified when items on your wishlist drop in price",
              },
            ].map((item) => (
              <div
                key={item.key}
                className="flex items-center justify-between rounded-lg border border-gray-100 p-3"
              >
                <div className="flex items-start gap-3">
                  <item.icon className="mt-0.5 h-4 w-4 text-gray-400" />
                  <div>
                    <p className="text-sm font-medium text-gray-900">
                      {item.label}
                    </p>
                    <p className="text-xs text-gray-500">{item.desc}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {savedFields.has(item.key) && (
                    <CheckCircle className="h-4 w-4 text-green-500" />
                  )}
                  {saving === item.key ? (
                    <Loader2 className="h-4 w-4 animate-spin text-gray-400" />
                  ) : (
                    <Toggle
                      checked={prefs[item.key]}
                      onChange={(val) => updatePref(item.key, val)}
                    />
                  )}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <MessageSquare className="h-5 w-5 text-orange-600" />
              SMS Notifications
            </CardTitle>
            <CardDescription>
              Text messages sent to your phone number
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {[
              {
                key: "smsOrderUpdates" as const,
                icon: Package,
                label: "Order Updates",
                desc: "Important order status changes via text message including shipping and delivery alerts",
              },
            ].map((item) => (
              <div
                key={item.key}
                className="flex items-center justify-between rounded-lg border border-gray-100 p-3"
              >
                <div className="flex items-start gap-3">
                  <item.icon className="mt-0.5 h-4 w-4 text-gray-400" />
                  <div>
                    <p className="text-sm font-medium text-gray-900">
                      {item.label}
                    </p>
                    <p className="text-xs text-gray-500">{item.desc}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {savedFields.has(item.key) && (
                    <CheckCircle className="h-4 w-4 text-green-500" />
                  )}
                  {saving === item.key ? (
                    <Loader2 className="h-4 w-4 animate-spin text-gray-400" />
                  ) : (
                    <Toggle
                      checked={prefs[item.key]}
                      onChange={(val) => updatePref(item.key, val)}
                    />
                  )}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
