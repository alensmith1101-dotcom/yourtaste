'use client'

export const dynamic = 'force-dynamic'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import toast from 'react-hot-toast'

export default function LoyaltyPage() {
  const { data: session } = useSession()
  const router = useRouter()
  const [data, setData] = useState<any>(null)
  const [redeemAmount, setRedeemAmount] = useState(100)

  useEffect(() => {
    if (!session) router.push('/auth/signin')
    else fetch('/api/loyalty').then(r => r.json()).then(setData)
  }, [session, router])

  const handleRedeem = async () => {
    try {
      const res = await fetch('/api/loyalty', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pointsToRedeem: redeemAmount }),
      })
      const result = await res.json()
      if (!res.ok) throw new Error(result.error)
      toast.success(`Redeemed ${redeemAmount} points!`)
      fetch('/api/loyalty').then(r => r.json()).then(setData)
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed')
    }
  }

  if (!data) return <div className="p-8 text-center">Loading...</div>
  const tierColors: Record<string, string> = { BRONZE: 'text-amber-700', SILVER: 'text-gray-400', GOLD: 'text-yellow-500', PLATINUM: 'text-purple-500' }
  const progress = data.nextTier ? (data.points / data.nextTier.points) * 100 : 100

  return (
    <div className="mx-auto max-w-2xl px-4 py-8">
      <h1 className="mb-8 text-2xl font-bold">Loyalty Rewards</h1>
      <div className="mb-6 rounded-xl border bg-gradient-to-r from-orange-50 to-amber-50 p-6">
        <div className="mb-2 text-sm text-gray-500">Your Tier</div>
        <div className={`text-3xl font-bold ${tierColors[data.tier]}`}>{data.tier}</div>
        <div className="mt-4 text-4xl font-bold">{data.points.toLocaleString()} <span className="text-lg text-gray-500">points</span></div>
        {data.nextTier && (
          <div className="mt-4">
            <div className="mb-1 flex justify-between text-sm text-gray-500"><span>Progress to {data.nextTier.name}</span><span>{data.points.toLocaleString()} / {data.nextTier.points.toLocaleString()}</span></div>
            <div className="h-2 rounded-full bg-gray-200"><div className="h-2 rounded-full bg-orange-500" style={{ width: `${Math.min(progress, 100)}%` }} /></div>
          </div>
        )}
      </div>
      <div className="mb-6 grid grid-cols-3 gap-4">
        <div className="rounded-lg border p-4 text-center"><div className="text-2xl font-bold">{data.totalOrders}</div><div className="text-xs text-gray-500">Orders</div></div>
        <div className="rounded-lg border p-4 text-center"><div className="text-2xl font-bold">₹{Math.floor(data.points / 100)}</div><div className="text-xs text-gray-500">Redeemable</div></div>
        <div className="rounded-lg border p-4 text-center"><div className="text-2xl font-bold">1%</div><div className="text-xs text-gray-500">Cashback</div></div>
      </div>
      <div className="rounded-xl border p-6">
        <h2 className="mb-4 text-lg font-semibold">Redeem Points</h2>
        <p className="mb-4 text-sm text-gray-500">100 points = ₹1 discount</p>
        <div className="flex items-center gap-4">
          <input type="number" value={redeemAmount} onChange={e => setRedeemAmount(Number(e.target.value))} min={100} step={100} max={data.points} className="w-32 rounded-lg border px-4 py-2 text-sm" />
          <button onClick={handleRedeem} disabled={redeemAmount > data.points || redeemAmount < 100} className="rounded-lg bg-orange-600 px-6 py-2 text-sm font-semibold text-white hover:bg-orange-700 disabled:opacity-50">Redeem</button>
        </div>
      </div>
    </div>
  )
}
