"use client"

export const dynamic = 'force-dynamic'

import { useState } from "react"
import Link from "next/link"
import { 
  Package, 
  CreditCard, 
  Truck, 
  RotateCcw, 
  User, 
  Store, 
  HelpCircle,
  MessageCircle,
  Phone,
  Mail
} from "lucide-react"

const SUPPORT_EMAIL = process.env.NEXT_PUBLIC_SUPPORT_EMAIL || 'support@yourtaste.com'

export default function SupportPage() {
  const [searchQuery, setSearchQuery] = useState("")

  const supportCategories = [
    {
      icon: Package,
      title: "Orders & Delivery",
      description: "Track orders, change delivery address, delivery issues",
      href: "/faq#orders",
      color: "bg-blue-100 text-blue-600",
    },
    {
      icon: CreditCard,
      title: "Payments & Billing",
      description: "Payment methods, refunds, billing questions",
      href: "/faq#payments",
      color: "bg-green-100 text-green-600",
    },
    {
      icon: Truck,
      title: "Shipping",
      description: "Shipping options, tracking, international delivery",
      href: "/shipping",
      color: "bg-purple-100 text-purple-600",
    },
    {
      icon: RotateCcw,
      title: "Returns & Refunds",
      description: "Return policy, refund status, damaged items",
      href: "/returns",
      color: "bg-orange-100 text-orange-600",
    },
    {
      icon: User,
      title: "Account Settings",
      description: "Profile, password, preferences, notifications",
      href: "/faq#account",
      color: "bg-pink-100 text-pink-600",
    },
    {
      icon: Store,
      title: "Vendor Support",
      description: "Become a vendor, vendor dashboard, payouts",
      href: "/vendor/register",
      color: "bg-indigo-100 text-indigo-600",
    },
  ]

  const helpArticles = [
    { text: "How do I track my order?", href: "/faq", keywords: "track order delivery" },
    { text: "What is your return policy?", href: "/faq", keywords: "return refund policy" },
    { text: "How do I reset my password?", href: "/faq", keywords: "reset password account login" },
    { text: "What payment methods do you accept?", href: "/faq", keywords: "payment methods credit card" },
    { text: "How do I become a vendor?", href: "/faq", keywords: "vendor seller register" },
    { text: "When will I receive my refund?", href: "/faq", keywords: "refund money back" },
  ]

  const filteredArticles = searchQuery.trim()
    ? helpArticles.filter(
        (a) =>
          a.text.toLowerCase().includes(searchQuery.toLowerCase()) ||
          a.keywords.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : helpArticles

  const filteredCategories = searchQuery.trim()
    ? supportCategories.filter(
        (c) =>
          c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          c.description.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : supportCategories

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-orange-600 to-amber-600 text-white py-16">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Support Center</h1>
          <p className="text-xl text-orange-100 mb-8">
            How can we help you today?
          </p>
          <div className="max-w-2xl mx-auto">
            <div className="relative">
              <input
                type="text"
                placeholder="Search for help articles..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full px-6 py-4 pl-12 text-gray-900 rounded-lg shadow-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
              <HelpCircle className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
            </div>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 md:px-6 py-12">
        {/* Support Categories */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {filteredCategories.map((category, index) => {
            const Icon = category.icon
            return (
              <Link
                key={index}
                href={category.href}
                className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow"
              >
                <div className={`w-12 h-12 ${category.color} rounded-lg flex items-center justify-center mb-4`}>
                  <Icon className="h-6 w-6" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{category.title}</h3>
                <p className="text-gray-600 text-sm">{category.description}</p>
              </Link>
            )
          })}
        </div>

        {/* Quick Links */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Popular Help Articles</h2>
          <div className="grid md:grid-cols-2 gap-4">
            {filteredArticles.map((article, index) => (
              <a key={index} href={article.href} className="flex items-center gap-3 p-4 hover:bg-gray-50 rounded-lg transition-colors">
                <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center">
                  <HelpCircle className="h-4 w-4 text-orange-600" />
                </div>
                <span className="text-gray-700">{article.text}</span>
              </a>
            ))}
            {filteredArticles.length === 0 && (
              <p className="col-span-2 text-center text-gray-500 py-4">No articles match your search.</p>
            )}
          </div>
        </div>

        {/* Contact Options */}
        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 text-center">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <MessageCircle className="h-8 w-8 text-blue-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Live Chat</h3>
            <p className="text-gray-600 text-sm mb-4">
              Chat with our support team in real-time
            </p>
            <Link href="/contact">
              <button className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                Coming Soon
              </button>
            </Link>
            <p className="text-xs text-gray-500 mt-2">Available 24/7</p>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Mail className="h-8 w-8 text-green-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Email Support</h3>
            <p className="text-gray-600 text-sm mb-4">
              Get help via email within 24 hours
            </p>
            <a
              href={`mailto:${SUPPORT_EMAIL}`}
              className="w-full inline-block px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
            >
              Send Email
            </a>
            <p className="text-xs text-gray-500 mt-2">Response within 24 hours</p>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 text-center">
            <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Phone className="h-8 w-8 text-purple-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Phone Support</h3>
            <p className="text-gray-600 text-sm mb-4">
              Speak directly with our team
            </p>
            <a
              href="tel:+15551234567"
              className="w-full inline-block px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
            >
              Call Now
            </a>
            <p className="text-xs text-gray-500 mt-2">Mon-Fri, 8am-6pm PST</p>
          </div>
        </div>
      </div>
    </div>
  )
}
