export const dynamic = 'force-dynamic'

import Link from "next/link"
import { Zap, Clock, Shield, Tag } from "lucide-react"
import { prisma } from "@/lib/prisma"
import { DealCard } from "@/components/shared/DealCard"
import { NewsletterSignup } from "@/components/shared/NewsletterSignup"
import { CountdownTimer } from "@/components/shared/CountdownTimer"

function getDealStatus(deal: { isActive: boolean; endsAt: Date; stockLimit: number; soldCount: number }): string {
  const now = new Date()
  if (!deal.isActive) return 'EXPIRED'
  if (deal.endsAt < now) return 'EXPIRED'
  if (deal.stockLimit > 0 && deal.soldCount >= deal.stockLimit) return 'SOLD_OUT'
  const hoursLeft = (deal.endsAt.getTime() - now.getTime()) / 3600000
  if (hoursLeft < 2) return 'ENDING_SOON'
  return 'ACTIVE'
}

export default async function DealsPage() {
  const now = new Date()

  const deals = await prisma.deal.findMany({
    where: {
      isActive: true,
      startsAt: { lte: now },
      endsAt: { gte: now },
      product: { isActive: true, isPublished: true },
    },
    include: {
      product: {
        select: {
          id: true,
          name: true,
          slug: true,
          priceCents: true,
          originalPriceCents: true,
          images: true,
          stockQuantity: true,
          vendor: { select: { name: true, slug: true } },
        },
      },
    },
    orderBy: { endsAt: 'asc' },
  })

  const enriched = deals.map((deal) => ({
    ...deal,
    dealPrice: Math.round(deal.product.priceCents * (1 - deal.discountPercent / 100)),
    status: getDealStatus(deal),
  }))

  const activeDeals = enriched.filter((d) => d.status === 'ACTIVE' || d.status === 'ENDING_SOON')
  const endingSoonDeals = enriched.filter((d) => d.status === 'ENDING_SOON')
  const soldOutDeals = enriched.filter((d) => d.status === 'SOLD_OUT')

  const nextEnd = deals.length > 0 ? deals.sort((a, b) => a.endsAt.getTime() - b.endsAt.getTime())[0].endsAt : null

  return (
    <div className="min-h-screen bg-gray-50">
      <section className="relative overflow-hidden bg-gradient-to-br from-red-600 via-orange-600 to-amber-500 py-16 text-white">
        <div className="absolute inset-0 bg-[url('/grid.svg')] bg-center opacity-10 [mask-image:linear-gradient(180deg,white,rgba(255,255,255,0))]" />
        <div className="relative mx-auto max-w-7xl px-4 text-center sm:px-6 lg:px-8">
          <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-white/30 bg-white/10 px-4 py-1.5 text-sm font-medium backdrop-blur-sm">
            <Zap className="h-4 w-4" />
            Flash Sales
          </div>
          <h1 className="text-4xl font-bold tracking-tight sm:text-5xl lg:text-6xl">
            Today&apos;s Deals
          </h1>
          <p className="mx-auto mt-4 max-w-xl text-lg text-red-100">
            Limited-time offers on your favorite products. Grab them before they&apos;re gone!
          </p>
          {nextEnd && (
            <div className="mt-8 flex flex-col items-center gap-2">
              <p className="text-sm text-red-200">Next deal ends in</p>
              <div className="flex items-center gap-2 rounded-xl border border-white/20 bg-white/10 px-6 py-3 backdrop-blur-sm">
                <Clock className="h-5 w-5" />
                <CountdownTimer targetDate={nextEnd.toISOString()} />
              </div>
            </div>
          )}
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="mb-8 flex items-center gap-3 rounded-xl border border-orange-200 bg-gradient-to-r from-orange-50 to-amber-50 p-5">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-100">
            <Shield className="h-5 w-5 text-orange-600" />
          </div>
          <div>
            <h2 className="font-semibold text-gray-900">Deal Guarantee</h2>
            <p className="text-sm text-gray-600">All deals are verified and prices are locked during the sale period.</p>
          </div>
        </div>

        {activeDeals.length > 0 && (
          <section className="mb-12">
            <div className="mb-6 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-100">
                  <Zap className="h-5 w-5 text-red-600" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">Live Deals</h2>
                  <p className="text-sm text-gray-600">{activeDeals.length} deals available</p>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {activeDeals.map((deal) => (
                <DealCard key={deal.id} deal={deal} />
              ))}
            </div>
          </section>
        )}

        {soldOutDeals.length > 0 && (
          <section className="mb-12">
            <div className="mb-6 flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gray-100">
                <Tag className="h-5 w-5 text-gray-500" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-900">Sold Out</h2>
                <p className="text-sm text-gray-600">These deals have ended</p>
              </div>
            </div>
            <div className="grid grid-cols-1 gap-6 opacity-60 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {soldOutDeals.map((deal) => (
                <DealCard key={deal.id} deal={deal} />
              ))}
            </div>
          </section>
        )}

        {enriched.length === 0 && (
          <div className="py-20 text-center">
            <div className="mx-auto flex h-24 w-24 items-center justify-center rounded-full bg-gray-100">
              <Tag className="h-12 w-12 text-gray-400" />
            </div>
            <h2 className="mt-6 text-2xl font-bold text-gray-900">No deals available right now</h2>
            <p className="mt-2 text-gray-600">Check back later for new deals and discounts!</p>
            <Link
              href="/products"
              className="mt-6 inline-flex items-center gap-2 rounded-lg bg-orange-600 px-6 py-3 text-sm font-semibold text-white transition hover:bg-orange-700"
            >
              Browse All Products
            </Link>
          </div>
        )}

        <div className="mt-12 overflow-hidden rounded-2xl bg-gradient-to-r from-orange-500 to-amber-500 p-8 text-center text-white">
          <h2 className="text-2xl font-bold">Never Miss a Deal!</h2>
          <p className="mt-2 text-orange-100">Subscribe to our newsletter and get notified about exclusive deals</p>
          <div className="mt-6">
            <NewsletterSignup />
          </div>
        </div>
      </div>
    </div>
  )
}
