export const dynamic = 'force-dynamic'
import { Shield, Users, Target, Award } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-orange-600 to-amber-600 text-white py-20">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">About YourTaste</h1>
          <p className="text-xl text-orange-100 max-w-2xl mx-auto">
            Connecting artisans with food lovers since 2024
          </p>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-16">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Mission</h2>
            <p className="text-lg text-gray-600 leading-relaxed mb-8">
              YourTaste was born from a simple idea: everyone deserves access to authentic, 
              handcrafted foods and artisanal products. We connect passionate local vendors 
              with customers who appreciate quality, tradition, and the stories behind every product.
            </p>
            <p className="text-lg text-gray-600 leading-relaxed">
              Whether it&apos;s homemade sauces, baked goods, or specialty ingredients, we believe 
              in supporting small businesses and bringing unique flavors to your doorstep.
            </p>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">Our Values</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="h-8 w-8 text-orange-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Quality First</h3>
              <p className="text-gray-600">
                Every vendor is vetted to ensure the highest quality standards
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="h-8 w-8 text-orange-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Community</h3>
              <p className="text-gray-600">
                Supporting local artisans and small businesses
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Target className="h-8 w-8 text-orange-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Transparency</h3>
              <p className="text-gray-600">
                Clear pricing, honest descriptions, no hidden fees
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="h-8 w-8 text-orange-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Excellence</h3>
              <p className="text-gray-600">
                Committed to exceptional customer experience
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gray-900 text-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid md:grid-cols-3 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-orange-500 mb-2">500+</div>
              <div className="text-gray-400">Local Vendors</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-orange-500 mb-2">10,000+</div>
              <div className="text-gray-400">Happy Customers</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-orange-500 mb-2">50,000+</div>
              <div className="text-gray-400">Products Delivered</div>
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-16">
        <div className="container mx-auto px-4 md:px-6">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">Meet Our Team</h2>
          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="w-32 h-32 bg-gradient-to-br from-orange-400 to-amber-400 rounded-full mx-auto mb-4"></div>
              <h3 className="text-xl font-semibold text-gray-900">Sarah Johnson</h3>
              <p className="text-orange-600 mb-2">CEO & Founder</p>
              <p className="text-gray-600 text-sm">
                Passionate about food and community building
              </p>
            </div>
            <div className="text-center">
              <div className="w-32 h-32 bg-gradient-to-br from-orange-400 to-amber-400 rounded-full mx-auto mb-4"></div>
              <h3 className="text-xl font-semibold text-gray-900">Michael Chen</h3>
              <p className="text-orange-600 mb-2">CTO</p>
              <p className="text-gray-600 text-sm">
                Building the platform that connects artisans worldwide
              </p>
            </div>
            <div className="text-center">
              <div className="w-32 h-32 bg-gradient-to-br from-orange-400 to-amber-400 rounded-full mx-auto mb-4"></div>
              <h3 className="text-xl font-semibold text-gray-900">Emily Rodriguez</h3>
              <p className="text-orange-600 mb-2">Head of Vendor Relations</p>
              <p className="text-gray-600 text-sm">
                Helping small businesses grow and succeed
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
