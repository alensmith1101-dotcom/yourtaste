export const dynamic = 'force-dynamic'

import Link from "next/link"
import Image from "next/image"
import type { Metadata } from "next"
import { notFound } from "next/navigation"
import { Store, Star, Package, MapPin, ShoppingBag } from "lucide-react"
import { prisma } from "@/lib/prisma"
import { formatPrice } from "@/lib/utils"
import {
  Card,
  CardContent,
} from "@/components/ui/card"

function parseImages(images: string): string[] {
  try {
    const parsed = JSON.parse(images)
    return Array.isArray(parsed) ? parsed : []
  } catch (err) {
    console.error('Failed to parse images:', err)
    return []
  }
}

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const vendor = await prisma.vendor.findUnique({
    where: { slug: params.slug, isApproved: true, isActive: true },
    select: { name: true, description: true, logo: true, banner: true, rating: true, totalRatings: true },
  })
  if (!vendor) return { title: 'Store Not Found' }

  return {
    title: `${vendor.name} | YourTaste`,
    description: vendor.description?.slice(0, 160) || `${vendor.name} store on YourTaste marketplace`,
    openGraph: {
      title: vendor.name,
      description: vendor.description?.slice(0, 160) || `${vendor.name} store on YourTaste marketplace`,
      images: vendor.logo ? [{ url: vendor.logo }] : [],
      type: 'website',
    },
    twitter: {
      card: 'summary_large_image',
      title: vendor.name,
      description: vendor.description?.slice(0, 160) || `${vendor.name} store on YourTaste marketplace`,
    },
  }
}

interface VendorStorePageProps {
  params: { slug: string }
}

export default async function VendorStorePage({ params }: VendorStorePageProps) {
  const vendor = await prisma.vendor.findUnique({
    where: { slug: params.slug },
    include: {
      products: {
        where: { isActive: true, isPublished: true },
        orderBy: { createdAt: "desc" },
      },
    },
  })

  if (!vendor || !vendor.isApproved || !vendor.isActive) {
    notFound()
  }

  return (
    <div className="flex flex-col">
      <div className="relative">
        <div className="h-48 bg-gradient-to-br from-orange-200 to-amber-200 sm:h-64">
          {vendor.banner && (
            <Image
              src={vendor.banner}
              alt={vendor.name}
              fill
              sizes="100vw"
              className="object-cover"
            />
          )}
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent" />
      </div>

      <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="-mt-16 flex flex-col items-start gap-6 sm:flex-row sm:items-end">
          <div className="relative flex h-28 w-28 items-center justify-center overflow-hidden rounded-2xl border-4 border-white bg-white shadow-lg">
            {vendor.logo ? (
              <Image
                src={vendor.logo}
                alt={vendor.name}
                fill
                sizes="112px"
                className="object-cover"
              />
            ) : (
              <Store className="h-12 w-12 text-orange-500" />
            )}
          </div>
          <div className="flex-1 pb-2">
            <h1 className="text-3xl font-bold text-gray-900">{vendor.name}</h1>
            {vendor.description && (
              <p className="mt-2 max-w-2xl text-gray-600">
                {vendor.description}
              </p>
            )}
            <div className="mt-3 flex flex-wrap items-center gap-4">
              <div className="flex items-center gap-1">
                <Star className="h-5 w-5 fill-amber-400 text-amber-400" />
                <span className="text-sm font-medium text-gray-700">
                  {vendor.rating.toFixed(1)}
                </span>
                <span className="text-sm text-gray-400">
                  ({vendor.totalRatings} ratings)
                </span>
              </div>
              {vendor.address && (
                <div className="flex items-center gap-1 text-sm text-gray-500">
                  <MapPin className="h-4 w-4" />
                  {vendor.address}
                </div>
              )}
              <div className="flex items-center gap-1 text-sm text-gray-500">
                <Package className="h-4 w-4" />
                {vendor.products.length} products
              </div>
            </div>
          </div>
        </div>

        <div className="mt-12 pb-16">
          <h2 className="mb-8 text-2xl font-bold text-gray-900">
            Products
          </h2>

          {vendor.products.length > 0 ? (
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {vendor.products.map((product) => {
                const images = parseImages(product.images)
                const discount = product.originalPriceCents
                  ? Math.round(
                      ((product.originalPriceCents - product.priceCents) /
                        product.originalPriceCents) *
                        100
                    )
                  : 0

                return (
                  <Link
                    key={product.id}
                    href={`/products/${product.slug}`}
                    className="group"
                  >
                    <Card className="overflow-hidden transition-all hover:shadow-lg">
                      <div className="relative aspect-square overflow-hidden bg-gray-100">
                        {images.length > 0 ? (
                          <Image
                            src={images[0]}
                            alt={product.name}
                            fill
                            sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
                            className="object-cover transition-transform duration-300 group-hover:scale-105"
                          />
                        ) : (
                          <div className="flex h-full w-full items-center justify-center">
                            <ShoppingBag className="h-12 w-12 text-gray-300" />
                          </div>
                        )}
                        {discount > 0 && (
                          <span className="absolute left-3 top-3 rounded-full bg-red-500 px-2.5 py-0.5 text-xs font-semibold text-white">
                            -{discount}%
                          </span>
                        )}
                      </div>
                      <CardContent className="p-4">
                        <h3 className="line-clamp-1 text-sm font-semibold text-gray-900 group-hover:text-orange-600">
                          {product.name}
                        </h3>
                        <div className="mt-2 flex items-center gap-1">
                          <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                          <span className="text-xs font-medium text-gray-700">
                            {product.averageRating.toFixed(1)}
                          </span>
                          <span className="text-xs text-gray-400">
                            ({product.totalReviews})
                          </span>
                        </div>
                        <div className="mt-3 flex items-baseline gap-2">
                          <span className="text-lg font-bold text-gray-900">
                            {formatPrice(product.priceCents)}
                          </span>
                          {product.originalPriceCents && (
                            <span className="text-sm text-gray-400 line-through">
                              {formatPrice(product.originalPriceCents)}
                            </span>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                )
              })}
            </div>
          ) : (
            <div className="rounded-2xl border-2 border-dashed border-gray-200 py-16 text-center">
              <ShoppingBag className="mx-auto h-12 w-12 text-gray-300" />
              <h3 className="mt-4 text-lg font-medium text-gray-900">
                No products yet
              </h3>
              <p className="mt-2 text-sm text-gray-500">
                This vendor hasn&apos;t listed any products yet.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
