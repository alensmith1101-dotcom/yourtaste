'use client'

export const dynamic = 'force-dynamic'

import { useState, useEffect, useCallback } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import toast from 'react-hot-toast'
import {
  Link2,
  Copy,
  Check,
  Facebook,
  Twitter,
  Mail,
  TrendingUp,
  MousePointerClick,
  DollarSign,
  Users,
  RefreshCw,
} from 'lucide-react'

const APP_URL = process.env.NEXT_PUBLIC_APP_URL || 'https://yourtaste.com'

export default function AffiliatePage() {
  const { data: session } = useSession()
  const router = useRouter()
  const [links, setLinks] = useState<any[]>([])
  const [stats, setStats] = useState<any>(null)
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null)
  const [loading, setLoading] = useState(true)
  const [creating, setCreating] = useState(false)

  const fetchData = useCallback(async () => {
    try {
      const [linksRes, statsRes] = await Promise.all([
        fetch('/api/affiliate'),
        fetch('/api/affiliate/stats'),
      ])
      if (linksRes.ok) {
        const linksData = await linksRes.json()
        setLinks(linksData.links || [])
      }
      if (statsRes.ok) {
        const statsData = await statsRes.json()
        setStats(statsData)
      }
    } catch {
      toast.error('Failed to load affiliate data')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    if (!session) router.push('/auth/signin')
    else fetchData()
  }, [session, router, fetchData])

  const createLink = async () => {
    setCreating(true)
    try {
      const res = await fetch('/api/affiliate', { method: 'POST' })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      toast.success('Referral link created!')
      fetchData()
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to create link')
    } finally {
      setCreating(false)
    }
  }

  const copyLink = (code: string, index: number) => {
    const url = `${APP_URL}?ref=${code}`
    navigator.clipboard.writeText(url)
    setCopiedIndex(index)
    toast.success('Link copied!')
    setTimeout(() => setCopiedIndex(null), 2000)
  }

  const shareUrl = (code: string) => {
    const url = `${APP_URL}?ref=${code}`
    const text = `Shop amazing products on YourTaste! Use my link:`
    return { url, text }
  }

  if (loading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <RefreshCw className="h-6 w-6 animate-spin text-orange-600" />
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Affiliate Program</h1>
          <p className="mt-1 text-sm text-gray-500">Earn 5% commission on every order through your referral link</p>
        </div>
        <button
          onClick={fetchData}
          className="rounded-lg border p-2 text-gray-500 hover:bg-gray-50"
          title="Refresh"
        >
          <RefreshCw className="h-4 w-4" />
        </button>
      </div>

      {stats && (
        <div className="mb-8 grid grid-cols-2 gap-4 sm:grid-cols-4">
          <div className="rounded-xl border bg-gradient-to-br from-blue-50 to-blue-100 p-5">
            <div className="flex items-center gap-2 text-blue-600">
              <MousePointerClick className="h-4 w-4" />
              <span className="text-xs font-medium">Clicks</span>
            </div>
            <div className="mt-2 text-2xl font-bold text-gray-900">{stats.totalClicks.toLocaleString()}</div>
          </div>
          <div className="rounded-xl border bg-gradient-to-br from-green-50 to-green-100 p-5">
            <div className="flex items-center gap-2 text-green-600">
              <Users className="h-4 w-4" />
              <span className="text-xs font-medium">Conversions</span>
            </div>
            <div className="mt-2 text-2xl font-bold text-gray-900">{stats.totalConversions}</div>
          </div>
          <div className="rounded-xl border bg-gradient-to-br from-orange-50 to-orange-100 p-5">
            <div className="flex items-center gap-2 text-orange-600">
              <DollarSign className="h-4 w-4" />
              <span className="text-xs font-medium">Earned</span>
            </div>
            <div className="mt-2 text-2xl font-bold text-gray-900">₹{(stats.totalEarned / 100).toFixed(0)}</div>
          </div>
          <div className="rounded-xl border bg-gradient-to-br from-purple-50 to-purple-100 p-5">
            <div className="flex items-center gap-2 text-purple-600">
              <TrendingUp className="h-4 w-4" />
              <span className="text-xs font-medium">Conv. Rate</span>
            </div>
            <div className="mt-2 text-2xl font-bold text-gray-900">{stats.conversionRate.toFixed(1)}%</div>
          </div>
        </div>
      )}

      {stats && stats.pendingPayout > 0 && (
        <div className="mb-8 rounded-xl border border-orange-200 bg-orange-50 p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-orange-800">Pending Payout</p>
              <p className="text-2xl font-bold text-orange-900">₹{(stats.pendingPayout / 100).toFixed(2)}</p>
              <p className="mt-1 text-xs text-orange-600">
                Minimum payout: ₹{(stats.minPayout / 100).toFixed(0)}
              </p>
            </div>
            {stats.canWithdraw && (
              <button className="rounded-lg bg-orange-600 px-4 py-2 text-sm font-semibold text-white hover:bg-orange-700">
                Request Payout
              </button>
            )}
          </div>
        </div>
      )}

      <div className="mb-8 rounded-xl border p-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-gray-900">Your Referral Links</h2>
          <button
            onClick={createLink}
            disabled={creating || links.length >= 5}
            className="rounded-lg bg-orange-600 px-4 py-2 text-sm font-semibold text-white hover:bg-orange-700 disabled:opacity-50"
          >
            {creating ? 'Creating...' : '+ New Link'}
          </button>
        </div>

        {links.length === 0 ? (
          <div className="py-8 text-center">
            <Link2 className="mx-auto h-10 w-10 text-gray-300" />
            <p className="mt-3 text-sm text-gray-500">No referral links yet. Create one to start earning!</p>
          </div>
        ) : (
          <div className="space-y-3">
            {links.map((link: any, index: number) => {
              const refUrl = `${APP_URL}?ref=${link.code}`
              return (
                <div key={link.id} className="flex flex-col gap-3 rounded-lg border p-4 sm:flex-row sm:items-center sm:justify-between">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <code className="rounded bg-gray-100 px-2 py-0.5 text-sm font-mono font-semibold text-orange-700">
                        {link.code}
                      </code>
                      <span className="text-xs text-gray-400">|</span>
                      <span className="text-xs text-gray-500">{link.clicks} clicks</span>
                      <span className="text-xs text-gray-400">|</span>
                      <span className="text-xs text-gray-500">{link.conversions} conversions</span>
                      <span className="text-xs text-gray-400">|</span>
                      <span className="text-xs font-medium text-green-600">₹{(link.commissionEarned / 100).toFixed(2)}</span>
                    </div>
                    <p className="mt-1 truncate text-xs text-gray-400">{refUrl}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => copyLink(link.code, index)}
                      className="rounded-lg border p-2 text-gray-500 hover:bg-gray-50 hover:text-gray-700"
                      title="Copy link"
                    >
                      {copiedIndex === index ? <Check className="h-4 w-4 text-green-600" /> : <Copy className="h-4 w-4" />}
                    </button>
                    <a
                      href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(refUrl)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="rounded-lg border p-2 text-blue-600 hover:bg-blue-50"
                      title="Share on Facebook"
                    >
                      <Facebook className="h-4 w-4" />
                    </a>
                    <a
                      href={`https://twitter.com/intent/tweet?url=${encodeURIComponent(refUrl)}&text=${encodeURIComponent('Shop amazing products on YourTaste!')}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="rounded-lg border p-2 text-sky-500 hover:bg-sky-50"
                      title="Share on Twitter"
                    >
                      <Twitter className="h-4 w-4" />
                    </a>
                    <a
                      href={`mailto:?subject=${encodeURIComponent('Check out YourTaste!')}&body=${encodeURIComponent(`Shop amazing products: ${refUrl}`)}`}
                      className="rounded-lg border p-2 text-gray-500 hover:bg-gray-50"
                      title="Share via Email"
                    >
                      <Mail className="h-4 w-4" />
                    </a>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>

      {stats?.recentConversions?.length > 0 && (
        <div className="mb-8 rounded-xl border p-6">
          <h2 className="mb-4 text-lg font-semibold text-gray-900">Recent Conversions</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b text-left text-xs text-gray-500">
                  <th className="pb-2 font-medium">Date</th>
                  <th className="pb-2 font-medium">Code</th>
                  <th className="pb-2 font-medium">Order Total</th>
                  <th className="pb-2 font-medium">Commission</th>
                  <th className="pb-2 font-medium">Status</th>
                </tr>
              </thead>
              <tbody>
                {stats.recentConversions.map((c: any) => (
                  <tr key={c.id} className="border-b last:border-0">
                    <td className="py-3 text-gray-600">{new Date(c.createdAt).toLocaleDateString()}</td>
                    <td className="py-3 font-mono text-xs text-orange-700">{c.link.code}</td>
                    <td className="py-3 text-gray-900">₹{(c.orderTotal / 100).toFixed(2)}</td>
                    <td className="py-3 font-medium text-green-600">₹{(c.commission / 100).toFixed(2)}</td>
                    <td className="py-3">
                      <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${
                        c.status === 'PAID' ? 'bg-green-100 text-green-700' :
                        c.status === 'CONFIRMED' ? 'bg-blue-100 text-blue-700' :
                        'bg-yellow-100 text-yellow-700'
                      }`}>
                        {c.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {stats?.payoutHistory?.length > 0 && (
        <div className="rounded-xl border p-6">
          <h2 className="mb-4 text-lg font-semibold text-gray-900">Payout History</h2>
          <div className="space-y-2">
            {stats.payoutHistory.map((p: any) => (
              <div key={p.id} className="flex items-center justify-between rounded-lg border p-3">
                <div>
                  <p className="text-sm font-medium text-gray-900">₹{(p.commission / 100).toFixed(2)}</p>
                  <p className="text-xs text-gray-500">{new Date(p.paidAt || p.createdAt).toLocaleDateString()}</p>
                </div>
                <span className="rounded-full bg-green-100 px-2 py-0.5 text-xs font-medium text-green-700">
                  {p.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
