'use client'

export const dynamic = 'force-dynamic'

import { useState, useEffect, useCallback } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { loadStripe } from '@stripe/stripe-js'
import { Elements, PaymentElement, useStripe, useElements } from '@stripe/react-stripe-js'
import toast from 'react-hot-toast'
import Image from 'next/image'
import { MapPin, CreditCard, Banknote, Plus, Check, ShieldCheck, Truck, Smartphone, Wallet, Loader2 } from 'lucide-react'

declare global {
  interface Window {
    Razorpay: any
  }
}

const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY || '')

function CheckoutForm({ clientSecret, orderId }: { clientSecret: string; orderId: string }) {
  const stripe = useStripe()
  const elements = useElements()
  const router = useRouter()
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!stripe || !elements) return
    setLoading(true)
    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: { return_url: `${window.location.origin}/orders/${orderId}?payment=success` },
    })
    if (error) {
      toast.error(error.message || 'Payment failed')
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <PaymentElement />
      <button type="submit" disabled={!stripe || loading} className="w-full rounded-lg bg-orange-600 px-6 py-3.5 text-base font-semibold text-white hover:bg-orange-700 disabled:opacity-50 transition-colors">
        {loading ? 'Processing...' : `Pay ₹${'...'}`}
      </button>
      <div className="flex items-center justify-center gap-2 text-xs text-gray-500">
        <ShieldCheck className="h-4 w-4" />
        <span>Secure payment powered by Stripe</span>
      </div>
    </form>
  )
}

interface CartItem {
  id: string
  productId: string
  quantity: number
  product: {
    id: string
    name: string
    slug: string
    priceCents: number
    originalPriceCents: number | null
    images: string
  }
}

interface SavedAddress {
  id: string
  title: string
  fullName: string
  street: string
  city: string
  state: string
  zipCode: string
  country: string
  phone: string | null
}

export default function CheckoutPage() {
  const { data: session } = useSession()
  const router = useRouter()
  const [cartItems, setCartItems] = useState<CartItem[]>([])
  const [clientSecret, setClientSecret] = useState<string | null>(null)
  const [orderId, setOrderId] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const [paymentMethod, setPaymentMethod] = useState<'stripe' | 'cod' | 'upi' | 'wallet'>('upi')
  const [address, setAddress] = useState({ fullName: '', street: '', city: '', state: '', zipCode: '', phone: '' })
  const [savedAddresses, setSavedAddresses] = useState<SavedAddress[]>([])
  const [selectedAddressId, setSelectedAddressId] = useState<string | null>(null)
  const [showNewAddress, setShowNewAddress] = useState(false)
  const [shippingRates, setShippingRates] = useState<any[]>([])
  const [selectedShipping, setSelectedShipping] = useState<string>('standard')
  const [shippingLoading, setShippingLoading] = useState(false)
  const [cartSubtotal, setCartSubtotal] = useState(0)
  const [discount] = useState(0)
  const [razorpayProcessing, setRazorpayProcessing] = useState(false)

  useEffect(() => {
    if (!session) { router.push('/auth/signin'); return }
    
    fetch('/api/cart').then(r => r.json()).then(data => {
      const items = data.items || []
      setCartItems(items)
      const subtotal = items.reduce((sum: number, item: CartItem) => sum + (item.product?.priceCents || 0) * item.quantity, 0)
      setCartSubtotal(subtotal)
    }).catch(() => {})

    fetch('/api/addresses').then(r => r.json()).then(data => {
      const addresses = data.addresses || []
      setSavedAddresses(addresses)
      if (addresses.length > 0) {
        const defaultAddr = addresses.find((a: SavedAddress) => a.title === 'Default') || addresses[0]
        setSelectedAddressId(defaultAddr.id)
        fillAddress(defaultAddr)
      }
    }).catch(() => {})
  }, [session])

  const fillAddress = (addr: SavedAddress) => {
    setAddress({
      fullName: addr.fullName,
      street: addr.street,
      city: addr.city,
      state: addr.state,
      zipCode: addr.zipCode,
      phone: addr.phone || '',
    })
  }

  const handleAddressSelect = (addrId: string) => {
    setSelectedAddressId(addrId)
    setShowNewAddress(false)
    const addr = savedAddresses.find(a => a.id === addrId)
    if (addr) fillAddress(addr)
  }

  const fetchShippingRates = async (zip: string, subtotal: number) => {
    if (zip.length < 3) return
    setShippingLoading(true)
    try {
      const res = await fetch(`/api/shipping/rates?toZip=${zip}&subtotal=${subtotal}`)
      const data = await res.json()
      setShippingRates(data.rates || [])
    } catch (err) {
      console.error('Failed to fetch shipping rates:', err)
    } finally {
      setShippingLoading(false)
    }
  }

  useEffect(() => {
    if (address.zipCode.length >= 3) {
      fetchShippingRates(address.zipCode, cartSubtotal)
    }
  }, [address.zipCode])

  const selectedShippingCost = shippingRates.find((r: any) => (r.id || r.name) === selectedShipping)?.price || 0
  const orderTotal = cartSubtotal + selectedShippingCost - discount

  const handleRazorpayPayment = useCallback(async (createdOrderId: string, dbOrderId: string) => {
    if (!window.Razorpay) {
      toast.error('Razorpay SDK failed to load. Please check your internet connection.')
      return
    }

    setRazorpayProcessing(true)

    try {
      const method = paymentMethod === 'wallet' ? 'wallet' : 'upi'
      const res = await fetch('/api/payment/razorpay', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orderId: dbOrderId, method }),
      })

      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Failed to initiate payment')

      const options = {
        key: data.keyId,
        amount: data.amount,
        currency: data.currency,
        name: 'YourTaste',
        description: `Order ${createdOrderId}`,
        order_id: data.orderId,
        handler: async function (response: any) {
          try {
            const verifyRes = await fetch('/api/payment/razorpay/verify', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                razorpay_order_id: response.razorpay_order_id,
                razorpay_payment_id: response.razorpay_payment_id,
                razorpay_signature: response.razorpay_signature,
                orderId: dbOrderId,
              }),
            })

            const verifyData = await verifyRes.json()

            if (verifyRes.ok && verifyData.success) {
              toast.success('Payment successful!')
              router.push(`/orders/${dbOrderId}?payment=success`)
            } else {
              toast.error(verifyData.error || 'Payment verification failed')
              router.push(`/orders/${dbOrderId}?payment=failed`)
            }
          } catch (err) {
            toast.error('Payment verification error')
            router.push(`/orders/${dbOrderId}?payment=error`)
          } finally {
            setRazorpayProcessing(false)
          }
        },
        prefill: {
          name: address.fullName,
          email: session?.user?.email || '',
          contact: address.phone || '',
        },
        theme: {
          color: '#ea580c',
        },
        modal: {
          ondismiss: function () {
            setRazorpayProcessing(false)
          },
        },
        method: {
          upi: method === 'upi',
          wallet: method === 'wallet',
          card: false,
          netbanking: false,
        },
      }

      const rzp = new window.Razorpay(options)

      rzp.on('payment.failed', function (response: any) {
        toast.error(response.error?.description || 'Payment failed')
        setRazorpayProcessing(false)
        fetch(`/api/orders/${dbOrderId}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ paymentStatus: 'FAILED' }),
        }).catch(() => {})
      })

      rzp.open()
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Payment initiation failed')
      setRazorpayProcessing(false)
    }
  }, [paymentMethod, address, session, router])

  const handlePlaceOrder = async () => {
    if (!address.fullName || !address.street || !address.city || !address.state || !address.zipCode) {
      toast.error('Please fill in all address fields')
      return
    }
    try {
      const paymentMethodLabel = paymentMethod === 'cod' ? 'COD'
        : paymentMethod === 'upi' ? 'UPI'
        : paymentMethod === 'wallet' ? 'WALLET'
        : 'STRIPE'

      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          shippingAddress: address,
          billingAddress: address,
          paymentMethod: paymentMethodLabel,
          shippingMethod: selectedShipping,
          shippingCost: selectedShippingCost,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Failed to create order')

      const createdOrder = data.data
      const dbOrderId = Array.isArray(createdOrder) ? createdOrder[0].id : createdOrder.id
      setOrderId(dbOrderId)

      if (paymentMethod === 'cod') {
        toast.success('Order placed! Pay on delivery.')
        router.push(`/orders/${dbOrderId}`)
        return
      }

      if (paymentMethod === 'upi' || paymentMethod === 'wallet') {
        await handleRazorpayPayment(dbOrderId, dbOrderId)
        return
      }

      const intentRes = await fetch('/api/payment/create-intent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orderId: dbOrderId }),
      })
      const intentData = await intentRes.json()
      if (intentData.clientSecret) {
        setClientSecret(intentData.clientSecret)
      } else {
        throw new Error('Failed to initialize payment')
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Something went wrong')
    } finally {
      setLoading(false)
    }
  }

  const parseImages = (images: string): string[] => {
    try { return JSON.parse(images) } catch (err) { console.error('Failed to parse images:', err); return images ? [images] : [] }
  }

  if (!session) return null

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="mb-8 text-2xl font-bold">Checkout</h1>
      <div className="grid gap-8 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
          {/* Shipping Address */}
          <div className="rounded-xl border bg-white p-6">
            <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold">
              <MapPin className="h-5 w-5 text-orange-600" />
              Shipping Address
            </h2>
            
            {savedAddresses.length > 0 && (
              <div className="mb-4 grid gap-3 sm:grid-cols-2">
                {savedAddresses.map(addr => (
                  <button
                    key={addr.id}
                    onClick={() => handleAddressSelect(addr.id)}
                    className={`rounded-lg border-2 p-3 text-left transition-all ${
                      selectedAddressId === addr.id && !showNewAddress
                        ? 'border-orange-500 bg-orange-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="text-sm font-medium">{addr.title || 'Home'}</div>
                        <div className="mt-1 text-xs text-gray-600">{addr.fullName}</div>
                        <div className="text-xs text-gray-500">{addr.street}, {addr.city}, {addr.state} {addr.zipCode}</div>
                        {addr.phone && <div className="text-xs text-gray-500 mt-1">Phone: {addr.phone}</div>}
                      </div>
                      {selectedAddressId === addr.id && !showNewAddress && (
                        <Check className="h-5 w-5 text-orange-600 shrink-0" />
                      )}
                    </div>
                  </button>
                ))}
                <button
                  onClick={() => { setShowNewAddress(true); setSelectedAddressId(null) }}
                  className={`rounded-lg border-2 border-dashed p-3 text-center transition-all ${
                    showNewAddress ? 'border-orange-500 bg-orange-50 text-orange-600' : 'border-gray-300 text-gray-500 hover:border-gray-400'
                  }`}
                >
                  <Plus className="mx-auto h-5 w-5 mb-1" />
                  <span className="text-xs font-medium">New Address</span>
                </button>
              </div>
            )}

            {(showNewAddress || savedAddresses.length === 0) && (
              <div className="space-y-3">
                <input type="text" placeholder="Full Name" value={address.fullName} onChange={e => setAddress(p => ({ ...p, fullName: e.target.value }))} className="w-full rounded-lg border px-4 py-2.5 text-sm focus:border-orange-500 focus:outline-none" />
                <input type="text" placeholder="Street Address" value={address.street} onChange={e => setAddress(p => ({ ...p, street: e.target.value }))} className="w-full rounded-lg border px-4 py-2.5 text-sm focus:border-orange-500 focus:outline-none" />
                <div className="grid grid-cols-2 gap-3">
                  <input type="text" placeholder="City" value={address.city} onChange={e => setAddress(p => ({ ...p, city: e.target.value }))} className="rounded-lg border px-4 py-2.5 text-sm focus:border-orange-500 focus:outline-none" />
                  <input type="text" placeholder="State" value={address.state} onChange={e => setAddress(p => ({ ...p, state: e.target.value }))} className="rounded-lg border px-4 py-2.5 text-sm focus:border-orange-500 focus:outline-none" />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <input type="text" placeholder="ZIP / PIN Code" value={address.zipCode} onChange={e => setAddress(p => ({ ...p, zipCode: e.target.value }))} className="rounded-lg border px-4 py-2.5 text-sm focus:border-orange-500 focus:outline-none" />
                  <input type="tel" placeholder="Phone" value={address.phone} onChange={e => setAddress(p => ({ ...p, phone: e.target.value }))} className="rounded-lg border px-4 py-2.5 text-sm focus:border-orange-500 focus:outline-none" />
                </div>
              </div>
            )}
          </div>

          {/* Shipping Method */}
          {shippingRates.length > 0 && (
            <div className="rounded-xl border bg-white p-6">
              <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold">
                <Truck className="h-5 w-5 text-orange-600" />
                Shipping Method
              </h2>
              {shippingLoading ? (
                <p className="text-sm text-gray-500">Loading shipping rates...</p>
              ) : (
                <div className="space-y-2">
                  {shippingRates.map((rate: any) => (
                    <label key={rate.id || rate.name} className="flex cursor-pointer items-center justify-between rounded-lg border p-3 hover:bg-gray-50 transition-colors">
                      <div className="flex items-center gap-3">
                        <input type="radio" name="shipping" value={rate.id || rate.name} checked={selectedShipping === (rate.id || rate.name)} onChange={() => setSelectedShipping(rate.id || rate.name)} className="text-orange-600" />
                        <div>
                          <div className="text-sm font-medium">{rate.name}</div>
                          <div className="text-xs text-gray-500">{rate.estimatedDays} business days</div>
                        </div>
                      </div>
                      <div className="text-sm font-semibold">{rate.price === 0 ? <span className="text-green-600">FREE</span> : `₹${(rate.price / 100).toFixed(2)}`}</div>
                    </label>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Payment Method */}
          <div className="rounded-xl border bg-white p-6">
            <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold">
              <CreditCard className="h-5 w-5 text-orange-600" />
              Payment Method
            </h2>
            <div className="space-y-2">
              <label className={`flex cursor-pointer items-center justify-between rounded-lg border-2 p-4 transition-all ${paymentMethod === 'upi' ? 'border-orange-500 bg-orange-50' : 'border-gray-200 hover:border-gray-300'}`}>
                <div className="flex items-center gap-3">
                  <input type="radio" name="payment" value="upi" checked={paymentMethod === 'upi'} onChange={() => setPaymentMethod('upi')} className="text-orange-600" />
                  <Smartphone className="h-5 w-5 text-gray-600" />
                  <div>
                    <div className="text-sm font-medium">UPI</div>
                    <div className="text-xs text-gray-500">Google Pay, PhonePe, Paytm, BHIM UPI</div>
                  </div>
                </div>
                <div className="flex gap-1">
                  {['GPay', 'PhonePe', 'Paytm', 'BHIM'].map(brand => (
                    <span key={brand} className="rounded bg-gray-100 px-1.5 py-0.5 text-[10px] font-bold text-gray-500">{brand}</span>
                  ))}
                </div>
              </label>
              <label className={`flex cursor-pointer items-center justify-between rounded-lg border-2 p-4 transition-all ${paymentMethod === 'wallet' ? 'border-orange-500 bg-orange-50' : 'border-gray-200 hover:border-gray-300'}`}>
                <div className="flex items-center gap-3">
                  <input type="radio" name="payment" value="wallet" checked={paymentMethod === 'wallet'} onChange={() => setPaymentMethod('wallet')} className="text-orange-600" />
                  <Wallet className="h-5 w-5 text-gray-600" />
                  <div>
                    <div className="text-sm font-medium">Wallet</div>
                    <div className="text-xs text-gray-500">Paytm Wallet, PhonePe Wallet, Amazon Pay</div>
                  </div>
                </div>
                <div className="flex gap-1">
                  {['Paytm', 'PhonePe', 'Amazon Pay'].map(brand => (
                    <span key={brand} className="rounded bg-gray-100 px-1.5 py-0.5 text-[10px] font-bold text-gray-500">{brand}</span>
                  ))}
                </div>
              </label>
              <label className={`flex cursor-pointer items-center justify-between rounded-lg border-2 p-4 transition-all ${paymentMethod === 'stripe' ? 'border-orange-500 bg-orange-50' : 'border-gray-200 hover:border-gray-300'}`}>
                <div className="flex items-center gap-3">
                  <input type="radio" name="payment" value="stripe" checked={paymentMethod === 'stripe'} onChange={() => setPaymentMethod('stripe')} className="text-orange-600" />
                  <CreditCard className="h-5 w-5 text-gray-600" />
                  <div>
                    <div className="text-sm font-medium">Credit / Debit Card</div>
                    <div className="text-xs text-gray-500">Visa, Mastercard, RuPay, Amex</div>
                  </div>
                </div>
                <div className="flex gap-1">
                  {['VISA', 'MC', 'RuPay'].map(brand => (
                    <span key={brand} className="rounded bg-gray-100 px-1.5 py-0.5 text-[10px] font-bold text-gray-500">{brand}</span>
                  ))}
                </div>
              </label>
              <label className={`flex cursor-pointer items-center justify-between rounded-lg border-2 p-4 transition-all ${paymentMethod === 'cod' ? 'border-orange-500 bg-orange-50' : 'border-gray-200 hover:border-gray-300'}`}>
                <div className="flex items-center gap-3">
                  <input type="radio" name="payment" value="cod" checked={paymentMethod === 'cod'} onChange={() => setPaymentMethod('cod')} className="text-orange-600" />
                  <Banknote className="h-5 w-5 text-gray-600" />
                  <div>
                    <div className="text-sm font-medium">Cash on Delivery</div>
                    <div className="text-xs text-gray-500">Pay when you receive your order</div>
                  </div>
                </div>
              </label>
            </div>
          </div>
        </div>

        {/* Right: Order Summary */}
        <div className="lg:col-span-1">
          <div className="sticky top-8 rounded-xl border bg-white p-6">
            <h2 className="mb-4 text-lg font-semibold">Order Summary</h2>
            
            <div className="max-h-64 space-y-3 overflow-y-auto mb-4">
              {cartItems.map(item => {
                const images = parseImages(item.product?.images || '')
                return (
                  <div key={item.id} className="flex gap-3">
                    <div className="relative h-14 w-14 shrink-0 overflow-hidden rounded-lg bg-gray-100">
                      {images[0] ? (
                        <Image src={images[0]} alt={item.product?.name || ''} fill className="object-cover" sizes="56px" />
                      ) : (
                        <div className="flex h-full items-center justify-center text-gray-400 text-xs">No img</div>
                      )}
                      <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-orange-600 text-[10px] font-bold text-white">{item.quantity}</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium truncate">{item.product?.name || 'Product'}</div>
                      <div className="text-xs text-gray-500">
                        ₹{(item.product?.priceCents / 100).toFixed(2)} × {item.quantity}
                      </div>
                    </div>
                    <div className="text-sm font-semibold shrink-0">
                      ₹{((item.product?.priceCents * item.quantity) / 100).toFixed(2)}
                    </div>
                  </div>
                )
              })}
              {cartItems.length === 0 && (
                <p className="text-sm text-gray-500 text-center py-4">Your cart is empty</p>
              )}
            </div>

            <div className="space-y-2 border-t pt-4">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Subtotal ({cartItems.length} items)</span>
                <span>₹{(cartSubtotal / 100).toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Shipping</span>
                <span>{selectedShippingCost === 0 ? <span className="text-green-600 font-medium">FREE</span> : `₹${(selectedShippingCost / 100).toFixed(2)}`}</span>
              </div>
              {discount > 0 && (
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Discount</span>
                  <span className="text-green-600">-₹{(discount / 100).toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Tax</span>
                <span className="text-gray-500 text-xs">Calculated at next step</span>
              </div>
              <div className="border-t pt-2 flex justify-between text-base font-bold">
                <span>Total</span>
                <span className="text-orange-600">₹{(orderTotal / 100).toFixed(2)}</span>
              </div>
            </div>

            <div className="mt-6">
              {!clientSecret ? (
                <button
                  onClick={handlePlaceOrder}
                  disabled={loading || cartItems.length === 0 || razorpayProcessing}
                  className="w-full rounded-lg bg-orange-600 px-6 py-3.5 text-base font-semibold text-white hover:bg-orange-700 disabled:opacity-50 transition-colors flex items-center justify-center gap-2"
                >
                  {razorpayProcessing ? (
                    <>
                      <Loader2 className="h-5 w-5 animate-spin" />
                      Opening Payment...
                    </>
                  ) : loading ? (
                    'Creating Order...'
                  ) : (
                    `Place Order • ₹${(orderTotal / 100).toFixed(2)}`
                  )}
                </button>
              ) : (
                <Elements stripe={stripePromise} options={{ clientSecret }}>
                  <CheckoutForm clientSecret={clientSecret} orderId={orderId!} />
                </Elements>
              )}
            </div>

            <div className="mt-4 flex items-center justify-center gap-4 text-xs text-gray-500">
              <span className="flex items-center gap-1"><ShieldCheck className="h-3.5 w-3.5" /> Secure</span>
              <span className="flex items-center gap-1"><Truck className="h-3.5 w-3.5" /> Fast Delivery</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
