export const dynamic = 'force-dynamic'
import { RotateCcw, CheckCircle, AlertCircle, Package } from "lucide-react"

export default function ReturnsPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-orange-600 to-amber-600 text-white py-16">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Returns & Refunds</h1>
          <p className="text-xl text-orange-100">
            Easy returns, hassle-free refunds
          </p>
        </div>
      </section>

      <div className="container mx-auto px-4 md:px-6 py-12">
        <div className="max-w-4xl mx-auto">
          {/* Return Policy */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8 mb-8">
            <div className="flex items-start gap-4 mb-6">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-2">30-Day Return Policy</h2>
                <p className="text-gray-600">
                  We offer a 30-day return policy for most items. If you&apos;re not satisfied with your purchase, 
                  you can return it within 30 days of delivery for a full refund.
                </p>
              </div>
            </div>
          </div>

          {/* Eligibility */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Return Eligibility</h2>
            <p className="text-gray-600 mb-4">To be eligible for a return, your item must:</p>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                <span className="text-gray-600">Be unused and in the same condition you received it</span>
              </li>
              <li className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                <span className="text-gray-600">Be in the original packaging</span>
              </li>
              <li className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                <span className="text-gray-600">Have the receipt or proof of purchase</span>
              </li>
              <li className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                <span className="text-gray-600">Be returned within 30 days of delivery</span>
              </li>
            </ul>

            <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
              <div className="flex items-start gap-3">
                <AlertCircle className="h-5 w-5 text-yellow-600 mt-0.5 flex-shrink-0" />
                <div>
                  <h3 className="font-semibold text-gray-900 mb-1">Non-Returnable Items</h3>
                  <p className="text-sm text-gray-600">
                    Certain items cannot be returned, including perishable goods, custom products, 
                    and items marked as &quot;final sale&quot;. Please check the product description for specific return policies.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Return Process */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">How to Return an Item</h2>
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-orange-600 text-white rounded-full flex items-center justify-center flex-shrink-0 font-bold">
                  1
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-1">Initiate Return</h3>
                  <p className="text-gray-600">
                    Log into your account, go to &quot;My Orders&quot;, select the order, and click &quot;Return Item&quot;. 
                    Fill out the return form with the reason for return.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-orange-600 text-white rounded-full flex items-center justify-center flex-shrink-0 font-bold">
                  2
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-1">Receive Return Label</h3>
                  <p className="text-gray-600">
                    Once your return is approved, we&apos;ll email you a prepaid return shipping label. 
                    Print the label and attach it to your package.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-orange-600 text-white rounded-full flex items-center justify-center flex-shrink-0 font-bold">
                  3
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-1">Ship the Item</h3>
                  <p className="text-gray-600">
                    Package the item securely in its original packaging (if possible) and drop it off 
                    at the specified carrier location.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-orange-600 text-white rounded-full flex items-center justify-center flex-shrink-0 font-bold">
                  4
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-1">Receive Refund</h3>
                  <p className="text-gray-600">
                    Once we receive and inspect the returned item, we&apos;ll process your refund within 5-7 business days. 
                    The refund will be issued to your original payment method.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Refund Information */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Refund Information</h2>
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Refund Timeline</h3>
                <p className="text-gray-600">
                  Once we receive your returned item, refunds are processed within 5-7 business days. 
                  The time it takes for the refund to appear in your account depends on your payment method:
                </p>
                <ul className="list-disc list-inside text-gray-600 space-y-1 mt-2 ml-4">
                  <li>Credit/Debit Cards: 3-5 business days</li>
                  <li>PayPal: 1-2 business days</li>
                  <li>Bank Transfer: 5-7 business days</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Refund Amount</h3>
                <p className="text-gray-600">
                  You&apos;ll receive a full refund of the item price. Original shipping costs are non-refundable 
                  unless the return is due to our error (wrong item, defective product, etc.).
                </p>
              </div>
            </div>
          </div>

          {/* Damaged/Defective Items */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8 mb-8">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <AlertCircle className="h-6 w-6 text-red-600" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-900 mb-2">Damaged or Defective Items</h2>
                <p className="text-gray-600 mb-4">
                  If you received a damaged or defective item, please contact us immediately at{" "}
                  <a href={`mailto:${process.env.NEXT_PUBLIC_SUPPORT_EMAIL || 'support@yourtaste.com'}`} className="text-orange-600 hover:text-orange-700">
                    {process.env.NEXT_PUBLIC_SUPPORT_EMAIL || 'support@yourtaste.com'}
                  </a>
                  . We&apos;ll arrange for a replacement or full refund, including return shipping costs.
                </p>
                <p className="text-sm text-gray-500">
                  Please include photos of the damage when contacting us to expedite the process.
                </p>
              </div>
            </div>
          </div>

          {/* Contact Support */}
          <div className="bg-orange-50 border border-orange-200 rounded-lg p-8 text-center">
            <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <RotateCcw className="h-8 w-8 text-orange-600" />
            </div>
            <h2 className="text-xl font-bold text-gray-900 mb-2">Need Help with a Return?</h2>
            <p className="text-gray-600 mb-4">
              Our support team is here to help you with the return process.
            </p>
            <a
              href="/contact"
              className="inline-block px-6 py-3 bg-orange-600 text-white rounded-lg font-medium hover:bg-orange-700 transition-colors"
            >
              Contact Support
            </a>
          </div>
        </div>
      </div>
    </div>
  )
}
