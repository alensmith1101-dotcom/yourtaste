export const dynamic = 'force-dynamic'

import Link from "next/link"
import Image from "next/image"
import type { Metadata } from "next"
import { notFound } from "next/navigation"
import {
  Star,
  ShoppingBag,
  Truck,
  Shield,
  RotateCcw,
  ChevronRight,
  Share2,
  Heart,
  Facebook,
  Twitter,
  Mail,
} from "lucide-react"
import { prisma } from "@/lib/prisma"
import { formatPrice, formatDate } from "@/lib/utils"
import { Badge } from "@/components/ui/badge"
import {
  Card,
  CardContent,
} from "@/components/ui/card"
import { AddToCartButton } from "@/components/shared/AddToCartButton"
import { WishlistButton } from "@/components/shared/WishlistButton"
import { VariantSelector } from "@/components/shared/VariantSelector"
import { AddAllToCartButton } from "@/components/shared/AddAllToCartButton"
import { EmiCalculator } from "@/components/shared/EmiCalculator"
import { ImageGallery } from "@/components/shared/ImageGallery"
import { PincodeChecker } from "@/components/shared/PincodeChecker"
import { ProductTabs } from "@/components/shared/ProductTabs"
import { VerifiedBadge } from "@/components/shared/VerifiedBadge"
import { ReviewForm } from "@/components/shared/ReviewForm"
import { ReviewImageGallery } from "@/components/shared/ReviewImageGallery"
import { TrackProductView } from "@/components/shared/TrackProductView"
import { RecentlyViewed } from "@/components/shared/RecentlyViewed"
import { ProductQA } from "@/components/shared/ProductQA"
import { AffiliateTracker } from "@/components/shared/AffiliateTracker"

function parseImages(images: string): string[] {
  try {
    const parsed = JSON.parse(images)
    return Array.isArray(parsed) ? parsed : []
  } catch (err) {
    console.error('Failed to parse images:', err)
    return []
  }
}

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const product = await prisma.product.findUnique({
    where: { slug: params.slug, isPublished: true },
    select: { name: true, description: true, images: true, priceCents: true },
  })
  if (!product) return { title: 'Product Not Found' }

  const images = (() => { try { return JSON.parse(product.images) } catch (err) { console.error('Failed to parse images:', err); return [] } })()

  return {
    title: `${product.name} | YourTaste`,
    description: product.description?.slice(0, 160) || product.name,
    openGraph: {
      title: product.name,
      description: product.description?.slice(0, 160) || product.name,
      images: images.slice(0, 3).map((url: string) => ({ url })),
      type: 'website',
    },
    twitter: {
      card: 'summary_large_image',
      title: product.name,
      description: product.description?.slice(0, 160) || product.name,
    },
  }
}

interface ProductPageProps {
  params: { slug: string }
}

export default async function ProductPage({ params }: ProductPageProps) {
  const product = await prisma.product.findUnique({
    where: { slug: params.slug },
    include: {
      vendor: { select: { id: true, name: true, slug: true, logo: true } },
      category: { select: { name: true, slug: true } },
      reviews: {
        include: {
          user: { select: { name: true } },
          images: { orderBy: { createdAt: 'asc' } },
        },
        orderBy: { createdAt: "desc" },
        take: 10,
      },
      variants: {
        where: { isActive: true },
        orderBy: { createdAt: 'asc' },
      },
    },
  })

  if (!product || !product.isActive || !product.isPublished) {
    notFound()
  }

  const images = parseImages(product.images)

  const reviewerIds = product.reviews.map((r) => r.userId)
  const verifiedOrders = reviewerIds.length > 0
    ? await prisma.orderItem.findMany({
        where: {
          productId: product.id,
          order: {
            userId: { in: reviewerIds },
            status: 'DELIVERED',
          },
        },
        select: {
          order: { select: { userId: true } },
        },
      })
    : []
  const verifiedUserIds = new Set(verifiedOrders.map((o) => o.order.userId))

  const [relatedProducts, recommendations] = await Promise.all([
    prisma.product.findMany({
      where: {
        isActive: true,
        isPublished: true,
        categoryId: product.categoryId || undefined,
        id: { not: product.id },
      },
      include: {
        vendor: { select: { name: true, slug: true } },
      },
      orderBy: { createdAt: "desc" },
      take: 4,
    }),
    prisma.productRecommendation.findMany({
      where: { sourceProductId: product.id },
      include: {
        targetProduct: {
          include: { vendor: { select: { name: true, slug: true } } },
        },
      },
      orderBy: { score: 'desc' },
      take: 4,
    }),
  ])

  const discount = product.originalPriceCents
    ? Math.round(
        ((product.originalPriceCents - product.priceCents) /
          product.originalPriceCents) *
          100
      )
    : 0

  // JSON-LD structured data for SEO
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'Product',
    name: product.name,
    description: product.description || product.name,
    image: images[0] || '',
    sku: product.sku,
    brand: { '@type': 'Brand', name: product.vendor.name },
    offers: {
      '@type': 'Offer',
      price: (product.priceCents / 100).toFixed(2),
      priceCurrency: product.currency,
      availability: product.stockQuantity > 0 ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock',
      seller: { '@type': 'Organization', name: product.vendor.name },
    },
    aggregateRating: product.totalReviews > 0 ? {
      '@type': 'AggregateRating',
      ratingValue: product.averageRating.toFixed(1),
      reviewCount: product.totalReviews,
    } : undefined,
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <TrackProductView
        product={{
          id: product.id,
          slug: product.slug,
          name: product.name,
          priceCents: product.priceCents,
          originalPriceCents: product.originalPriceCents,
          images: product.images,
          averageRating: product.averageRating,
          totalReviews: product.totalReviews,
          vendorName: product.vendor.name,
        }}
      />
      <AffiliateTracker />
      <nav className="mb-6 flex items-center gap-2 text-sm text-gray-500">
        <Link href="/" className="hover:text-gray-700">
          Home
        </Link>
        <ChevronRight className="h-3 w-3" />
        <Link href="/products" className="hover:text-gray-700">
          Products
        </Link>
        <ChevronRight className="h-3 w-3" />
        {product.category && (
          <>
            <Link
              href={`/products?category=${product.category.slug}`}
              className="hover:text-gray-700"
            >
              {product.category.name}
            </Link>
            <ChevronRight className="h-3 w-3" />
          </>
        )}
        <span className="text-gray-900">{product.name}</span>
      </nav>

      <div className="grid grid-cols-1 gap-10 lg:grid-cols-2">
        <div className="space-y-4">
          <ImageGallery images={images} productName={product.name} />
        </div>

        <div className="space-y-6">
          <div>
            <Link
              href={`/store/${product.vendor.slug}`}
              className="text-sm font-medium text-orange-600 hover:text-orange-700"
            >
              {product.vendor.name}
            </Link>
            <h1 className="mt-2 text-3xl font-bold text-gray-900">
              {product.name}
            </h1>
            <div className="mt-3 flex items-center gap-3">
              <div className="flex items-center gap-1">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star
                    key={i}
                    className={`h-5 w-5 ${
                      i < Math.round(product.averageRating)
                        ? "fill-amber-400 text-amber-400"
                        : "text-gray-200"
                    }`}
                  />
                ))}
              </div>
              <span className="text-sm font-medium text-gray-700">
                {product.averageRating.toFixed(1)}
              </span>
              <span className="text-sm text-gray-500">
                ({product.totalReviews} reviews)
              </span>
            </div>
          </div>

          <div className="flex items-baseline gap-3">
            <span className="text-3xl font-bold text-gray-900">
              {formatPrice(product.priceCents)}
            </span>
            {product.originalPriceCents && (
              <>
                <span className="text-xl text-gray-400 line-through">
                  {formatPrice(product.originalPriceCents)}
                </span>
                <Badge className="bg-red-100 text-red-700 hover:bg-red-100">
                  -{discount}%
                </Badge>
              </>
            )}
          </div>

          <EmiCalculator priceCents={product.priceCents} />

          {product.description && (
            <p className="leading-relaxed text-gray-600">
              {product.description}
            </p>
          )}

          <div className="flex items-center gap-2">
            {product.stockQuantity > 0 ? (
              <>
                <Badge className="bg-green-100 text-green-700 hover:bg-green-100">
                  In Stock ({product.stockQuantity})
                </Badge>
                {product.stockQuantity <= 5 && (
                  <span className="text-sm font-medium text-red-600">
                    Only {product.stockQuantity} left - order soon!
                  </span>
                )}
              </>
            ) : (
              <Badge className="bg-red-100 text-red-700 hover:bg-red-100">
                Out of Stock
              </Badge>
            )}
          </div>

          {/* Product Variants */}
          {product.variants.length > 0 && (
            <VariantSelector
              variants={product.variants.map((v) => ({
                id: v.id,
                name: v.name,
                value: v.value,
                priceCents: v.priceCents,
                stockQuantity: v.stockQuantity,
              }))}
            />
          )}

          <AddToCartButton
            productId={product.id}
            disabled={product.stockQuantity === 0}
          />

          {/* Buy Now Button */}
          <Link
            href={`/checkout?productId=${product.id}&quantity=1`}
            className={`w-full rounded-lg bg-orange-600 px-6 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-offset-2 ${product.stockQuantity === 0 ? 'opacity-50 cursor-not-allowed pointer-events-none' : ''}`}
          >
            Buy Now
          </Link>

          {/* Wishlist Button */}
          <WishlistButton productId={product.id} />

          {/* Delivery Check */}
          <PincodeChecker />

          {/* Share Buttons */}
          <div className="flex items-center gap-2">
            <Share2 className="h-4 w-4 text-gray-500" />
            <span className="text-sm text-gray-600">Share:</span>
            <a
              href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(`${process.env.NEXT_PUBLIC_APP_URL || 'https://yourtaste.com'}/products/${product.slug}`)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="rounded-full bg-blue-600 p-1.5 text-white transition hover:bg-blue-700"
              aria-label="Share on Facebook"
            >
              <Facebook className="h-3.5 w-3.5" />
            </a>
            <a
              href={`https://twitter.com/intent/tweet?url=${encodeURIComponent(`${process.env.NEXT_PUBLIC_APP_URL || 'https://yourtaste.com'}/products/${product.slug}`)}&text=${encodeURIComponent(product.name)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="rounded-full bg-sky-500 p-1.5 text-white transition hover:bg-sky-600"
              aria-label="Share on Twitter"
            >
              <Twitter className="h-3.5 w-3.5" />
            </a>
            <a
              href={`mailto:?subject=${encodeURIComponent(product.name)}&body=${encodeURIComponent(`Check out this product: ${process.env.NEXT_PUBLIC_APP_URL || 'https://yourtaste.com'}/products/${product.slug}`)}`}
              className="rounded-full bg-gray-600 p-1.5 text-white transition hover:bg-gray-700"
              aria-label="Share via Email"
            >
              <Mail className="h-3.5 w-3.5" />
            </a>
          </div>

          <div className="grid grid-cols-3 gap-4 rounded-lg border border-gray-200 p-4">
            <div className="flex flex-col items-center gap-2 text-center">
              <Truck className="h-5 w-5 text-orange-600" />
              <span className="text-xs text-gray-600">Free Shipping</span>
            </div>
            <div className="flex flex-col items-center gap-2 text-center">
              <Shield className="h-5 w-5 text-orange-600" />
              <span className="text-xs text-gray-600">Secure Payment</span>
            </div>
            <div className="flex flex-col items-center gap-2 text-center">
              <RotateCcw className="h-5 w-5 text-orange-600" />
              <span className="text-xs text-gray-600">30-Day Returns</span>
            </div>
          </div>
        </div>
      </div>

      {/* Product Tabs */}
      <section className="mt-16">
        <ProductTabs tabs={[
          {
            id: 'description',
            label: 'Description',
            content: (
              <div className="prose prose-sm max-w-none text-gray-600">
                {product.description || 'No description available.'}
              </div>
            ),
          },
          {
            id: 'specifications',
            label: 'Specifications',
            content: (
              <Card>
                <CardContent className="p-0">
                  <table className="w-full">
                    <tbody>
                      <tr className="border-b">
                        <td className="bg-gray-50 px-4 py-3 text-sm font-medium text-gray-700">Brand</td>
                        <td className="px-4 py-3 text-sm text-gray-600">{product.vendor.name}</td>
                      </tr>
                      <tr className="border-b">
                        <td className="bg-gray-50 px-4 py-3 text-sm font-medium text-gray-700">Category</td>
                        <td className="px-4 py-3 text-sm text-gray-600">{product.category?.name || 'N/A'}</td>
                      </tr>
                      {product.sku && (
                        <tr className="border-b">
                          <td className="bg-gray-50 px-4 py-3 text-sm font-medium text-gray-700">SKU</td>
                          <td className="px-4 py-3 text-sm text-gray-600">{product.sku}</td>
                        </tr>
                      )}
                      <tr className="border-b">
                        <td className="bg-gray-50 px-4 py-3 text-sm font-medium text-gray-700">Availability</td>
                        <td className="px-4 py-3 text-sm text-gray-600">
                          {product.stockQuantity > 0 ? `In Stock (${product.stockQuantity} available)` : 'Out of Stock'}
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </CardContent>
              </Card>
            ),
          },
          {
            id: 'reviews',
            label: `Reviews (${product.totalReviews})`,
            content: (
              <div className="space-y-6">
                {product.reviews.length > 0 ? (
                  <>
                    <Card className="mb-6">
                      <CardContent className="p-6">
                        <div className="flex items-start gap-8">
                          <div className="text-center">
                            <div className="text-5xl font-bold text-gray-900">
                              {product.averageRating.toFixed(1)}
                            </div>
                            <div className="mt-2 flex items-center justify-center gap-1">
                              {Array.from({ length: 5 }).map((_, i) => (
                                <Star
                                  key={i}
                                  className={`h-5 w-5 ${
                                    i < Math.round(product.averageRating)
                                      ? "fill-amber-400 text-amber-400"
                                      : "text-gray-200"
                                  }`}
                                />
                              ))}
                            </div>
                            <p className="mt-1 text-sm text-gray-500">
                              {product.totalReviews} reviews
                            </p>
                          </div>
                          <div className="flex-1 space-y-2">
                            {[5, 4, 3, 2, 1].map((stars) => {
                              const count = product.reviews.filter(r => r.rating === stars).length
                              const percentage = product.totalReviews > 0 ? (count / product.totalReviews) * 100 : 0
                              return (
                                <div key={stars} className="flex items-center gap-2">
                                  <span className="w-12 text-sm text-gray-600">{stars} star</span>
                                  <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                                    <div
                                      className="h-full bg-amber-400 rounded-full transition-all"
                                      style={{ width: `${percentage}%` }}
                                    />
                                  </div>
                                  <span className="w-12 text-sm text-gray-500 text-right">
                                    {count}
                                  </span>
                                </div>
                              )
                            })}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    <div className="space-y-4">
                      {product.reviews.map((review) => (
                        <Card key={review.id}>
                          <CardContent className="p-6">
                            <div className="flex items-start justify-between">
                              <div>
                                <p className="font-medium text-gray-900">
                                  {review.user.name || "Anonymous"}
                                </p>
                                <div className="mt-1 flex items-center gap-2">
                                  <div className="flex items-center gap-1">
                                    {Array.from({ length: 5 }).map((_, i) => (
                                      <Star
                                        key={i}
                                        className={`h-4 w-4 ${
                                          i < review.rating
                                            ? "fill-amber-400 text-amber-400"
                                            : "text-gray-200"
                                        }`}
                                      />
                                    ))}
                                  </div>
                                  {verifiedUserIds.has(review.userId) && (
                                    <VerifiedBadge />
                                  )}
                                </div>
                              </div>
                              <span className="text-sm text-gray-500">
                                {formatDate(review.createdAt)}
                              </span>
                            </div>
                            {review.comment && (
                              <p className="mt-3 text-sm text-gray-600">
                                {review.comment}
                              </p>
                            )}
                            {review.images.length > 0 && (
                              <ReviewImageGallery
                                images={review.images.map(img => ({ url: img.url }))}
                                reviewerName={review.user.name || undefined}
                              />
                            )}
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </>
                ) : (
                  <p className="text-center text-gray-500 py-8">No reviews yet. Be the first to review this product!</p>
                )}
                <ReviewForm productId={product.id} />
              </div>
            ),
          },
          {
            id: 'questions',
            label: `Q&A (${product.totalQuestions})`,
            content: <ProductQA productId={product.id} initialQuestionCount={product.totalQuestions} />,
          },
        ]} />
      </section>

      <RecentlyViewed />

      {/* Frequently Bought Together */}
      {relatedProducts.length > 2 && (
        <section className="mt-16">
          <h2 className="mb-6 text-2xl font-bold text-gray-900">
            Frequently Bought Together
          </h2>
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-wrap items-center gap-4">
                {/* Main Product */}
                <div className="flex items-center gap-3">
                  <div className="relative h-20 w-20 overflow-hidden rounded-lg bg-gray-100">
                    {images.length > 0 ? (
                      <Image
                        src={images[0]}
                        alt={product.name}
                        fill
                        className="object-cover"
                      />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center">
                        <ShoppingBag className="h-8 w-8 text-gray-300" />
                      </div>
                    )}
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900 line-clamp-1">{product.name}</p>
                    <p className="text-sm font-bold text-gray-900">{formatPrice(product.priceCents)}</p>
                  </div>
                </div>

                {/* Plus Sign */}
                <span className="text-2xl font-bold text-gray-400">+</span>

                {/* Related Products */}
                {relatedProducts.slice(0, 2).map((rp, index) => {
                  const rpImages = parseImages(rp.images)
                  return (
                    <div key={rp.id} className="flex items-center gap-3">
                      <div className="relative h-20 w-20 overflow-hidden rounded-lg bg-gray-100">
                        {rpImages.length > 0 ? (
                          <Image
                            src={rpImages[0]}
                            alt={rp.name}
                            fill
                            className="object-cover"
                          />
                        ) : (
                          <div className="flex h-full w-full items-center justify-center">
                            <ShoppingBag className="h-8 w-8 text-gray-300" />
                          </div>
                        )}
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-900 line-clamp-1">{rp.name}</p>
                        <p className="text-sm font-bold text-gray-900">{formatPrice(rp.priceCents)}</p>
                      </div>
                      {index < 1 && <span className="text-2xl font-bold text-gray-400">+</span>}
                    </div>
                  )
                })}

                {/* Total Price */}
                <div className="ml-auto">
                  <p className="text-sm text-gray-600">Total Price:</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {formatPrice(
                      product.priceCents +
                      relatedProducts.slice(0, 2).reduce((sum, rp) => sum + rp.priceCents, 0)
                    )}
                  </p>
                  <AddAllToCartButton productIds={[product.id, ...relatedProducts.slice(0, 2).map((rp) => rp.id)]} />
                </div>
              </div>
            </CardContent>
          </Card>
        </section>
      )}

      {recommendations.length > 0 && (
        <section className="mt-16">
          <h2 className="mb-6 text-2xl font-bold text-gray-900">
            Recommended For You
          </h2>
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {recommendations.map((rec) => {
              const rp = rec.targetProduct
              const rpImages = parseImages(rp.images)
              return (
                <Link
                  key={rp.id}
                  href={`/products/${rp.slug}`}
                  className="group"
                >
                  <Card className="overflow-hidden transition-all hover:shadow-lg">
                    <div className="relative aspect-square overflow-hidden bg-gray-100">
                      {rpImages.length > 0 ? (
                        <Image
                          src={rpImages[0]}
                          alt={rp.name}
                          fill
                          sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
                          className="object-cover transition-transform duration-300 group-hover:scale-105"
                        />
                      ) : (
                        <div className="flex h-full w-full items-center justify-center">
                          <ShoppingBag className="h-12 w-12 text-gray-300" />
                        </div>
                      )}
                    </div>
                    <CardContent className="p-4">
                      <p className="text-xs font-medium text-orange-600">{rp.vendor.name}</p>
                      <h3 className="mt-1 line-clamp-1 text-sm font-semibold text-gray-900">{rp.name}</h3>
                      <p className="mt-2 text-lg font-bold text-gray-900">{formatPrice(rp.priceCents)}</p>
                    </CardContent>
                  </Card>
                </Link>
              )
            })}
          </div>
        </section>
      )}

      {relatedProducts.length > 0 && (
        <section className="mt-16">
          <h2 className="mb-6 text-2xl font-bold text-gray-900">
            Related Products
          </h2>
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {relatedProducts.map((rp) => {
              const rpImages = parseImages(rp.images)
              return (
                <Link
                  key={rp.id}
                  href={`/products/${rp.slug}`}
                  className="group"
                >
                  <Card className="overflow-hidden transition-all hover:shadow-lg">
                    <div className="relative aspect-square overflow-hidden bg-gray-100">
                      {rpImages.length > 0 ? (
                        <Image
                          src={rpImages[0]}
                          alt={rp.name}
                          fill
                          sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
                          className="object-cover transition-transform duration-300 group-hover:scale-105"
                        />
                      ) : (
                        <div className="flex h-full w-full items-center justify-center">
                          <ShoppingBag className="h-12 w-12 text-gray-300" />
                        </div>
                      )}
                    </div>
                    <CardContent className="p-4">
                      <p className="text-xs font-medium text-orange-600">
                        {rp.vendor.name}
                      </p>
                      <h3 className="mt-1 line-clamp-1 text-sm font-semibold text-gray-900">
                        {rp.name}
                      </h3>
                      <div className="mt-2 flex items-center gap-1">
                        <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                        <span className="text-xs font-medium text-gray-700">
                          {rp.averageRating.toFixed(1)}
                        </span>
                      </div>
                      <p className="mt-2 text-lg font-bold text-gray-900">
                        {formatPrice(rp.priceCents)}
                      </p>
                    </CardContent>
                  </Card>
                </Link>
              )
            })}
          </div>
        </section>
      )}

      {/* Sticky Mobile Buy Bar */}
      {product.stockQuantity > 0 && (
        <div className="fixed bottom-0 left-0 right-0 z-40 border-t bg-white p-3 shadow-lg md:hidden">
          <div className="flex items-center gap-3">
            <div className="flex-1">
              <div className="text-lg font-bold text-orange-600">{formatPrice(product.priceCents)}</div>
              {product.originalPriceCents && product.originalPriceCents > product.priceCents && (
                <div className="text-xs text-gray-500 line-through">{formatPrice(product.originalPriceCents)}</div>
              )}
            </div>
            <AddToCartButton
              productId={product.id}
              disabled={product.stockQuantity === 0}
            />
            <Link
              href={`/checkout?productId=${product.id}&quantity=1`}
              className="rounded-lg bg-orange-600 px-4 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-orange-700"
            >
              Buy Now
            </Link>
          </div>
        </div>
      )}
    </div>
  )
}
