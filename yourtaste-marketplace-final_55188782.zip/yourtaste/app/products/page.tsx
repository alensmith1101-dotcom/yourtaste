export const dynamic = 'force-dynamic'

import Link from "next/link"
import { Search, Star, X } from "lucide-react"
import { prisma } from "@/lib/prisma"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { VendorFilter } from "@/components/shared/VendorFilter"
import { PriceRangeSlider } from "@/components/shared/PriceRangeSlider"
import { ProductsClient } from "@/components/shared/ProductsClient"

const PAGE_SIZE = 12

function getOrderBy(sort: string) {
  switch (sort) {
    case "price_asc":
      return { priceCents: "asc" as const }
    case "price_desc":
      return { priceCents: "desc" as const }
    case "rating":
      return { averageRating: "desc" as const }
    case "popularity":
      return { totalReviews: "desc" as const }
    default:
      return { createdAt: "desc" as const }
  }
}

interface ProductsPageProps {
  searchParams: {
    search?: string
    category?: string
    sort?: string
    page?: string
    minPrice?: string
    maxPrice?: string
    minRating?: string
    vendor?: string
  }
}

export default async function ProductsPage({ searchParams }: ProductsPageProps) {
  const search = searchParams.search || ""
  const category = searchParams.category || ""
  const sort = searchParams.sort || "newest"
  const page = Math.max(1, parseInt(searchParams.page || "1"))
  const minPrice = searchParams.minPrice ? parseInt(searchParams.minPrice) : undefined
  const maxPrice = searchParams.maxPrice ? parseInt(searchParams.maxPrice) : undefined
  const minRating = searchParams.minRating ? parseFloat(searchParams.minRating) : undefined
  const vendorSlugs = searchParams.vendor ? searchParams.vendor.split(',').filter(Boolean) : []

  const [categories, vendors, productsCount] = await Promise.all([
    prisma.category.findMany({
      orderBy: { name: "asc" },
    }),
    prisma.vendor.findMany({
      where: { isApproved: true, isActive: true },
      orderBy: { name: "asc" },
    }),
    prisma.product.count({
      where: {
        isActive: true,
        isPublished: true,
        ...(search
          ? {
              OR: [
                { name: { contains: search } },
                { description: { contains: search } },
              ],
            }
          : {}),
        ...(category
          ? {
              category: {
                slug: category,
              },
            }
          : {}),
        ...(minPrice !== undefined
          ? {
              priceCents: {
                gte: minPrice * 100,
              },
            }
          : {}),
        ...(maxPrice !== undefined
          ? {
              priceCents: {
                lte: maxPrice * 100,
              },
            }
          : {}),
        ...(minRating !== undefined
          ? {
              averageRating: {
                gte: minRating,
              },
            }
          : {}),
        ...(vendorSlugs.length > 0
          ? {
              vendor: {
                slug: {
                  in: vendorSlugs,
                },
              },
            }
          : {}),
      },
    }),
  ])

  const totalPages = Math.ceil(productsCount / PAGE_SIZE)

  const products = await prisma.product.findMany({
    where: {
      isActive: true,
      isPublished: true,
      ...(search
        ? {
            OR: [
              { name: { contains: search } },
              { description: { contains: search } },
            ],
          }
        : {}),
      ...(category
        ? {
            category: {
              slug: category,
            },
          }
        : {}),
      ...(minPrice !== undefined
        ? {
            priceCents: {
              gte: minPrice * 100,
            },
          }
        : {}),
      ...(maxPrice !== undefined
        ? {
            priceCents: {
              lte: maxPrice * 100,
            },
          }
        : {}),
      ...(minRating !== undefined
        ? {
            averageRating: {
              gte: minRating,
            },
          }
        : {}),
      ...(vendorSlugs.length > 0
        ? {
            vendor: {
              slug: {
                in: vendorSlugs,
              },
            },
          }
        : {}),
    },
    include: {
      vendor: { select: { name: true, slug: true } },
      category: { select: { name: true, slug: true } },
    },
    orderBy: getOrderBy(sort),
    skip: (page - 1) * PAGE_SIZE,
    take: PAGE_SIZE,
  })

  const categoryLabels: Record<string, string> = {}
  categories.forEach((c) => { categoryLabels[c.slug] = c.name })

  const vendorLabels: Record<string, string> = {}
  vendors.forEach((v) => { vendorLabels[v.slug] = v.name })

  const hasActiveFilters = !!(search || category || minPrice || maxPrice || minRating || vendorSlugs.length > 0)

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">All Products</h1>
      </div>

      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <form className="flex flex-1 items-center gap-2" action="/products" method="GET">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
            <Input
              name="search"
              placeholder="Search products..."
              defaultValue={search}
              className="pl-10"
            />
          </div>
          {category && <input type="hidden" name="category" value={category} />}
          {sort !== "newest" && <input type="hidden" name="sort" value={sort} />}
          <Button type="submit" variant="secondary">
            Search
          </Button>
        </form>
      </div>

      <div className="flex flex-col gap-8 lg:flex-row">
        <aside className="w-full shrink-0 lg:w-64">
          <div className="rounded-lg border border-gray-200 bg-white p-4">
            <h2 className="mb-4 text-sm font-semibold text-gray-900">Filters</h2>

            <div className="mb-6">
              <h3 className="mb-2 text-xs font-medium text-gray-700">Categories</h3>
              <ul className="space-y-1">
                <li>
                  <Link
                    href="/products"
                    className={`block rounded-md px-3 py-2 text-sm transition ${
                      !category
                        ? "bg-orange-50 font-medium text-orange-700"
                        : "text-gray-600 hover:bg-gray-50"
                    }`}
                  >
                    All Categories
                  </Link>
                </li>
                {categories.map((cat) => (
                  <li key={cat.id}>
                    <Link
                      href={`/products?category=${cat.slug}${search ? `&search=${encodeURIComponent(search)}` : ""}`}
                      className={`block rounded-md px-3 py-2 text-sm transition ${
                        category === cat.slug
                          ? "bg-orange-50 font-medium text-orange-700"
                          : "text-gray-600 hover:bg-gray-50"
                      }`}
                    >
                      {cat.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            <div className="mb-6">
              <h3 className="mb-2 text-xs font-medium text-gray-700">Brand / Vendor</h3>
              <VendorFilter
                vendors={vendors.map(v => ({ id: v.id, name: v.name, slug: v.slug }))}
                selectedVendors={vendorSlugs}
              />
            </div>

            <div className="mb-6">
              <h3 className="mb-2 text-xs font-medium text-gray-700">Price Range</h3>
              <PriceRangeSlider
                min={0}
                max={10000}
                defaultMin={minPrice}
                defaultMax={maxPrice}
                currencySymbol="₹"
              />
            </div>

            <div className="mb-6">
              <h3 className="mb-2 text-xs font-medium text-gray-700">Minimum Rating</h3>
              <div className="space-y-1">
                {[4, 3, 2, 1].map((rating) => {
                  const params = new URLSearchParams()
                  if (search) params.set("search", search)
                  if (category) params.set("category", category)
                  if (sort !== "newest") params.set("sort", sort)
                  if (minPrice !== undefined) params.set("minPrice", minPrice.toString())
                  if (maxPrice !== undefined) params.set("maxPrice", maxPrice.toString())
                  if (vendorSlugs.length > 0) params.set("vendor", vendorSlugs.join(','))
                  params.set("minRating", rating.toString())
                  return (
                    <Link
                      key={rating}
                      href={`/products?${params.toString()}`}
                      className={`flex items-center gap-2 rounded-md px-3 py-2 text-sm transition ${
                        minRating === rating
                          ? "bg-orange-50 font-medium text-orange-700"
                          : "text-gray-600 hover:bg-gray-50"
                      }`}
                    >
                      <div className="flex items-center gap-0.5">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star
                            key={i}
                            className={`h-3 w-3 ${
                              i < rating ? "fill-amber-400 text-amber-400" : "text-gray-300"
                            }`}
                          />
                        ))}
                      </div>
                      <span>& Up</span>
                    </Link>
                  )
                })}
              </div>
            </div>

            {hasActiveFilters && (
              <Link href="/products" className="block">
                <Button variant="outline" size="sm" className="w-full">
                  <X className="mr-2 h-3 w-3" />
                  Clear All Filters
                </Button>
              </Link>
            )}
          </div>
        </aside>

        <div className="flex-1">
          <ProductsClient
            products={products}
            totalProducts={productsCount}
            currentPage={page}
            totalPages={totalPages}
            sort={sort}
            search={search}
            category={category}
            minPrice={minPrice}
            maxPrice={maxPrice}
            minRating={minRating}
            vendorSlugs={vendorSlugs}
            categoryLabels={categoryLabels}
            vendorLabels={vendorLabels}
          />
        </div>
      </div>
    </div>
  )
}
