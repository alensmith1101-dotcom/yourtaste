import { prisma } from '@/lib/prisma';

export type SortOption = 'relevance' | 'price_asc' | 'price_desc' | 'rating_desc' | 'newest' | 'name_asc' | 'name_desc';

export interface SearchFilters {
  categoryIds?: string[];
  vendorIds?: string[];
  minPrice?: number;
  maxPrice?: number;
  minRating?: number;
  inStock?: boolean;
  tags?: string[];
}

export interface SearchParams {
  query: string;
  page?: number;
  limit?: number;
  sortBy?: SortOption;
  filters?: SearchFilters;
  userId?: string;
  sessionId?: string;
}

export interface SearchResult {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  images: string;
  priceCents: number;
  originalPriceCents: number | null;
  currency: string;
  sku: string;
  stockQuantity: number;
  averageRating: number;
  totalReviews: number;
  vendorId: string;
  categoryId: string | null;
  tags: string;
  vendorName: string;
  categoryName: string | null;
}

export interface FacetValue {
  value: string;
  label: string;
  count: number;
}

export interface FacetGroup {
  field: string;
  label: string;
  values: FacetValue[];
}

export interface PaginationMeta {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
  hasNext: boolean;
  hasPrev: boolean;
}

export interface SearchResponse {
  results: SearchResult[];
  facets: FacetGroup[];
  pagination: PaginationMeta;
  query: string;
  sortBy: SortOption;
  suggestions: string[];
}

export interface SearchSuggestionResult {
  query: string;
  suggestions: string[];
  trending: string[];
}

const DEFAULT_LIMIT = 20;
const MAX_LIMIT = 100;

const facetCache = new Map<string, { data: any; expiry: number }>();

export class EnhancedSearchService {
  static async search(params: SearchParams): Promise<SearchResponse> {
    const {
      query,
      page = 1,
      limit = DEFAULT_LIMIT,
      sortBy = 'relevance',
      filters = {},
      userId,
      sessionId,
    } = params;

    const safeLimit = Math.min(Math.max(limit, 1), MAX_LIMIT);
    const safePage = Math.max(page, 1);
    const skip = (safePage - 1) * safeLimit;

    const where = await this.buildWhereClause(query, filters);
    const orderBy = this.buildOrderBy(sortBy);

    const [results, total, facets, suggestions] = await Promise.all([
      prisma.product.findMany({
        where,
        orderBy,
        skip,
        take: safeLimit,
        include: {
          vendor: { select: { id: true, name: true } },
          category: { select: { id: true, name: true } },
        },
      }),
      prisma.product.count({ where }),
      this.buildFacets(query, filters),
      this.getQuerySuggestions(query),
    ]);

    const mappedResults: SearchResult[] = results.map((p) => ({
      id: p.id,
      name: p.name,
      slug: p.slug,
      description: p.description,
      images: p.images,
      priceCents: p.priceCents,
      originalPriceCents: p.originalPriceCents,
      currency: p.currency,
      sku: p.sku,
      stockQuantity: p.stockQuantity,
      averageRating: p.averageRating,
      totalReviews: p.totalReviews,
      vendorId: p.vendorId,
      categoryId: p.categoryId,
      tags: p.tags,
      vendorName: p.vendor.name,
      categoryName: p.category?.name ?? null,
    }));

    const totalPages = Math.ceil(total / safeLimit);

    const response: SearchResponse = {
      results: mappedResults,
      facets,
      pagination: {
        page: safePage,
        limit: safeLimit,
        total,
        totalPages,
        hasNext: safePage < totalPages,
        hasPrev: safePage > 1,
      },
      query,
      sortBy,
      suggestions,
    };

    this.trackSearchAnalytics(query, userId, sessionId, total, filters, sortBy).catch(() => {});

    return response;
  }

  private static async buildWhereClause(query: string, filters: SearchFilters) {
    const conditions: Record<string, unknown>[] = [
      { isPublished: true },
      { isActive: true },
    ];

    if (query.trim()) {
      const expandedTerms = await this.expandQuery(query);
      if (expandedTerms.length > 1) {
        conditions.push({
          AND: expandedTerms.map((term) => ({
            OR: [
              { name: { contains: term, mode: 'insensitive' } },
              { description: { contains: term, mode: 'insensitive' } },
              { sku: { contains: term, mode: 'insensitive' } },
            ],
          })),
        });
      } else {
        const term = expandedTerms[0];
        conditions.push({
          OR: [
            { name: { contains: term, mode: 'insensitive' } },
            { description: { contains: term, mode: 'insensitive' } },
            { sku: { contains: term, mode: 'insensitive' } },
          ],
        });
      }
    }

    if (filters.categoryIds && filters.categoryIds.length > 0) {
      conditions.push({ categoryId: { in: filters.categoryIds } });
    }

    if (filters.vendorIds && filters.vendorIds.length > 0) {
      conditions.push({ vendorId: { in: filters.vendorIds } });
    }

    if (filters.minPrice !== undefined || filters.maxPrice !== undefined) {
      const priceCondition: Record<string, number> = {};
      if (filters.minPrice !== undefined) priceCondition.gte = filters.minPrice;
      if (filters.maxPrice !== undefined) priceCondition.lte = filters.maxPrice;
      conditions.push({ priceCents: priceCondition });
    }

    if (filters.minRating !== undefined && filters.minRating > 0) {
      conditions.push({ averageRating: { gte: filters.minRating } });
    }

    if (filters.inStock === true) {
      conditions.push({ stockQuantity: { gt: 0 } });
    }

    if (filters.tags && filters.tags.length > 0) {
      for (const tag of filters.tags) {
        conditions.push({ tags: { contains: tag } });
      }
    }

    return { AND: conditions };
  }

  private static buildOrderBy(sortBy: SortOption) {
    switch (sortBy) {
      case 'price_asc':
        return [{ priceCents: 'asc' as const }];
      case 'price_desc':
        return [{ priceCents: 'desc' as const }];
      case 'rating_desc':
        return [{ averageRating: 'desc' as const }, { totalReviews: 'desc' as const }];
      case 'newest':
        return [{ createdAt: 'desc' as const }];
      case 'name_asc':
        return [{ name: 'asc' as const }];
      case 'name_desc':
        return [{ name: 'desc' as const }];
      case 'relevance':
      default:
        return [{ averageRating: 'desc' as const }, { totalReviews: 'desc' as const }, { createdAt: 'desc' as const }];
    }
  }

  private static async buildFacets(query: string, filters: SearchFilters): Promise<FacetGroup[]> {
    const cacheKey = `facets:${query}:${JSON.stringify(filters)}`;
    const cached = facetCache.get(cacheKey);
    if (cached && cached.expiry > Date.now()) return cached.data as FacetGroup[];

    const baseWhere: Record<string, unknown>[] = [
      { isPublished: true },
      { isActive: true },
    ];

    if (query.trim()) {
      baseWhere.push({
        OR: [
          { name: { contains: query.trim() } },
          { description: { contains: query.trim() } },
        ],
      });
    }

    const baseCondition = { AND: baseWhere };

    const [categories, vendors, categoryFacets, vendorFacets, priceRange, ratingFacets, inStockCount, totalCount] = await Promise.all([
      prisma.category.findMany({
        select: { id: true, name: true },
      }),
      prisma.vendor.findMany({
        where: { isActive: true, isApproved: true },
        select: { id: true, name: true },
      }),
      prisma.product.groupBy({
        by: ['categoryId'],
        where: baseCondition,
        _count: { id: true },
      }),
      prisma.product.groupBy({
        by: ['vendorId'],
        where: baseCondition,
        _count: { id: true },
      }),
      prisma.product.aggregate({
        where: baseCondition,
        _min: { priceCents: true },
        _max: { priceCents: true },
      }),
      prisma.product.groupBy({
        by: ['averageRating'],
        where: baseCondition,
        _count: { id: true },
      }),
      prisma.product.count({
        where: { ...baseCondition, stockQuantity: { gt: 0 } },
      }),
      prisma.product.count({
        where: baseCondition,
      }),
    ]);

    const categoryMap = new Map(categories.map((c) => [c.id, c.name]));
    const vendorMap = new Map(vendors.map((v) => [v.id, v.name]));

    const categoryFacet: FacetGroup = {
      field: 'category',
      label: 'Category',
      values: categoryFacets
        .filter((f) => f.categoryId)
        .map((f) => ({ value: f.categoryId!, label: categoryMap.get(f.categoryId!) ?? f.categoryId!, count: f._count.id }))
        .sort((a, b) => b.count - a.count),
    };

    const vendorFacet: FacetGroup = {
      field: 'vendor',
      label: 'Vendor',
      values: vendorFacets
        .map((f) => ({ value: f.vendorId, label: vendorMap.get(f.vendorId) ?? f.vendorId, count: f._count.id }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 20),
    };

    const minPrice = priceRange._min.priceCents ?? 0;
    const maxPrice = priceRange._max.priceCents ?? 0;

    const priceFacet: FacetGroup = {
      field: 'price',
      label: 'Price',
      values: [
        { value: `${minPrice}-${maxPrice}`, label: `${(minPrice / 100).toFixed(2)} - ${(maxPrice / 100).toFixed(2)}`, count: totalCount },
      ],
    };

    const ratingBuckets: Record<string, number> = { '4': 0, '3': 0, '2': 0, '1': 0 };
    for (const f of ratingFacets) {
      const rating = f.averageRating;
      if (rating >= 4) ratingBuckets['4'] += f._count.id;
      else if (rating >= 3) ratingBuckets['3'] += f._count.id;
      else if (rating >= 2) ratingBuckets['2'] += f._count.id;
      else if (rating > 0) ratingBuckets['1'] += f._count.id;
    }

    const ratingFacet: FacetGroup = {
      field: 'rating',
      label: 'Rating',
      values: Object.entries(ratingBuckets)
        .filter(([, count]) => count > 0)
        .map(([value, count]) => ({ value, label: `${value}+ stars`, count })),
    };

    const availabilityFacet: FacetGroup = {
      field: 'availability',
      label: 'Availability',
      values: [
        { value: 'in_stock', label: 'In Stock', count: inStockCount },
        { value: 'out_of_stock', label: 'Out of Stock', count: totalCount - inStockCount },
      ],
    };

    const result = [categoryFacet, vendorFacet, priceFacet, ratingFacet, availabilityFacet];
    facetCache.set(cacheKey, { data: result, expiry: Date.now() + 60000 });
    return result;
  }

  private static async expandQuery(query: string): Promise<string[]> {
    const words = query.toLowerCase().split(/\s+/).filter(Boolean)
    const expanded = new Set<string>(words)

    for (const word of words) {
      const synonym = await prisma.searchSynonym.findUnique({ where: { word } })
      if (synonym) {
        try {
          const synonyms = JSON.parse(synonym.synonyms) as string[]
          synonyms.forEach(s => expanded.add(s.toLowerCase()))
        } catch (err) { console.error('Failed to parse synonyms:', err) }
      }
    }

    return [...expanded]
  }

  private static async getQuerySuggestions(query: string): Promise<string[]> {
    if (!query.trim()) return [];

    const suggestions = await prisma.searchSuggestion.findMany({
      where: { query: { contains: query.trim().toLowerCase() } },
      orderBy: { priority: 'desc' },
      take: 5,
      select: { query: true },
    });

    return suggestions.map((s) => s.query);
  }

  static async getSearchSuggestions(query: string): Promise<SearchSuggestionResult> {
    const [suggestions, trending] = await Promise.all([
      query.trim()
        ? prisma.searchSuggestion.findMany({
            where: { query: { contains: query.trim().toLowerCase() } },
            orderBy: { priority: 'desc' },
            take: 8,
            select: { query: true },
          })
        : Promise.resolve([]),
      prisma.searchSuggestion.findMany({
        where: { isTrending: true },
        orderBy: { priority: 'desc' },
        take: 10,
        select: { query: true },
      }),
    ]);

    return {
      query,
      suggestions: suggestions.map((s) => s.query),
      trending: trending.map((t) => t.query),
    };
  }

  static async getTrendingQueries(limit: number = 10): Promise<string[]> {
    const trending = await prisma.searchSuggestion.findMany({
      where: { isTrending: true },
      orderBy: { priority: 'desc' },
      take: limit,
      select: { query: true },
    });
    return trending.map((t) => t.query);
  }

  static async addSearchSuggestion(query: string, resultsCount: number, isTrending: boolean = false) {
    const normalized = query.trim().toLowerCase();
    if (!normalized) return null;

    return prisma.searchSuggestion.upsert({
      where: { query: normalized },
      update: { resultsCount, updatedAt: new Date() },
      create: { query: normalized, resultsCount, isTrending },
    });
  }

  static async updateTrendingQueries() {
    const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);

    const recentQueries = await prisma.searchQuery.groupBy({
      by: ['query'],
      where: { createdAt: { gte: sevenDaysAgo } },
      _count: { id: true },
      orderBy: { _count: { id: 'desc' } },
      take: 20,
    });

    const topQueries = recentQueries.map((q) => q.query.toLowerCase().trim()).filter(Boolean);

    await prisma.searchSuggestion.updateMany({
      data: { isTrending: false },
    });

    for (const query of topQueries.slice(0, 10)) {
      await prisma.searchSuggestion.upsert({
        where: { query },
        update: { isTrending: true, priority: { increment: 1 } },
        create: { query, isTrending: true, priority: 1 },
      });
    }
  }

  static async getSynonyms(word: string): Promise<string[]> {
    const record = await prisma.searchSynonym.findUnique({ where: { word: word.toLowerCase() } });
    if (!record) return [];
    try {
      return JSON.parse(record.synonyms);
    } catch (err) {
      console.error('Failed to parse synonyms:', err)
      return record.synonyms.split(',').map((s) => s.trim()).filter(Boolean);
    }
  }

  static async addSynonym(word: string, synonyms: string[]) {
    return prisma.searchSynonym.upsert({
      where: { word: word.toLowerCase() },
      update: { synonyms: JSON.stringify(synonyms) },
      create: { word: word.toLowerCase(), synonyms: JSON.stringify(synonyms) },
    });
  }

  private static async trackSearchAnalytics(
    query: string,
    userId: string | undefined,
    sessionId: string | undefined,
    resultsCount: number,
    filters: SearchFilters,
    sortBy: SortOption,
  ) {
    await prisma.searchQuery.create({
      data: {
        query,
        type: 'PRODUCT',
        userId: userId ?? null,
        sessionId: sessionId ?? null,
        resultsCount,
        filters: JSON.stringify(filters),
        sortBy,
      },
    });
  }

  static async trackSearchClick(searchQueryId: string, productId: string, position: number) {
    await prisma.searchResultAnalytics.create({
      data: {
        searchQueryId,
        productId,
        position,
        clicked: true,
      },
    });
  }

  static async getSearchAnalytics(days: number = 7) {
    const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);

    const queries = await prisma.searchQuery.findMany({
      where: { createdAt: { gte: since } },
      orderBy: { createdAt: 'desc' },
    });

    const queryCounts = new Map<string, number>();
    for (const q of queries) {
      queryCounts.set(q.query, (queryCounts.get(q.query) ?? 0) + 1);
    }

    const topQueries = [...queryCounts.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, 20)
      .map(([query, count]) => ({ query, count }));

    const zeroResultQueries = queries.filter((q) => q.resultsCount === 0);
    const zeroResultCounts = new Map<string, number>();
    for (const q of zeroResultQueries) {
      zeroResultCounts.set(q.query, (zeroResultCounts.get(q.query) ?? 0) + 1);
    }
    const topZeroResults = [...zeroResultCounts.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([query, count]) => ({ query, count }));

    return {
      totalSearches: queries.length,
      uniqueQueries: queryCounts.size,
      topQueries,
      topZeroResultQueries: topZeroResults,
      avgResults: queries.length > 0 ? queries.reduce((s, q) => s + q.resultsCount, 0) / queries.length : 0,
    };
  }

  static async getProductInteractions(productId: string, type?: string, limit: number = 50) {
    const where: Record<string, unknown> = { productId };
    if (type) where.type = type;

    return prisma.productInteraction.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: limit,
    });
  }

  static async trackProductInteraction(
    productId: string,
    type: string,
    userId?: string,
    sessionId?: string,
    meta?: { duration?: number; source?: string },
  ) {
    return prisma.productInteraction.create({
      data: {
        productId,
        type,
        userId: userId ?? null,
        sessionId: sessionId ?? null,
        duration: meta?.duration,
        source: meta?.source,
      },
    });
  }
}
