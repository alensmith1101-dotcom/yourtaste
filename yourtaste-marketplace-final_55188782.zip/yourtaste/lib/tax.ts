import { prisma } from '@/lib/prisma'

export class TaxService {
  static async calculateTax(
    subtotalCents: number,
    shippingAddress: {
      country: string
      state?: string
      city?: string
      zipCode?: string
    }
  ): Promise<{ taxAmount: number; taxRate: number; breakdown: any[] }> {
    const state = shippingAddress.state ?? undefined
    const city = shippingAddress.city ?? undefined
    const zipCode = shippingAddress.zipCode ?? undefined

    const taxRates = await prisma.taxRate.findMany({
      where: {
        isActive: true,
        country: shippingAddress.country,
        OR: [
          { state: null, city: null, zipCode: null },
          ...(state ? [{ state, city: null, zipCode: null }] : []),
          ...(state && city ? [{ state, city, zipCode: null }] : []),
          ...(state && city && zipCode ? [{ state, city, zipCode }] : []),
        ],
      },
      orderBy: [{ state: 'asc' }, { city: 'asc' }, { zipCode: 'asc' }],
    })

    let totalRate = 0
    const breakdown: any[] = []

    for (const rate of taxRates) {
      // Tax rates are stored in basis points (e.g., 1000 = 10%, 500 = 5%)
      const rateValue = rate.rate / 10000
      totalRate += rateValue
      breakdown.push({
        name: rate.name,
        rate: rateValue,
        amount: Math.round(subtotalCents * rateValue),
      })
    }

    const taxAmount = Math.round(subtotalCents * totalRate)

    return {
      taxAmount,
      taxRate: totalRate,
      breakdown,
    }
  }
}

const GST_SLABS = [5, 12, 18, 28] as const
type GstSlab = typeof GST_SLABS[number]
export function getGstSlab(ratePercent: number): GstSlab {
  return GST_SLABS.reduce((prev, curr) => Math.abs(curr - ratePercent) < Math.abs(prev - ratePercent) ? curr : prev)
}
export function calculateGst(amountCents: number, slab: GstSlab) {
  const taxAmount = Math.round(amountCents * (slab / 100))
  return { cgst: Math.round(taxAmount / 2), sgst: Math.ceil(taxAmount / 2), igst: taxAmount, total: taxAmount }
}
