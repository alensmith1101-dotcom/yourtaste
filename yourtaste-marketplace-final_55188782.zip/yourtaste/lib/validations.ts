import { z } from 'zod'

const NAME_MAX = 100
const DESCRIPTION_MAX = 5000
const COMMENT_MAX = 2000
const NOTES_MAX = 1000
const URL_MAX = 2048

export const registerSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters').max(NAME_MAX, 'Name is too long'),
  email: z.string().email('Invalid email address').max(255),
  password: z.string()
    .min(8, 'Password must be at least 8 characters')
    .max(128, 'Password is too long')
    .regex(/[A-Z]/, 'Password must contain at least one uppercase letter')
    .regex(/[a-z]/, 'Password must contain at least one lowercase letter')
    .regex(/[0-9]/, 'Password must contain at least one number'),
  phone: z.string().max(20).regex(/^[+]?[\d\s\-()]*$/, 'Invalid phone number').optional(),
})

export const loginSchema = z.object({
  email: z.string().email('Invalid email address').max(255),
  password: z.string().min(1, 'Password is required').max(128),
})

export const productSchema = z.object({
  name: z.string().min(1, 'Product name is required').max(NAME_MAX),
  description: z.string().max(DESCRIPTION_MAX).optional(),
  priceCents: z.number().int('Price must be an integer (cents)').min(0, 'Price must be positive').max(999999999),
  originalPriceCents: z.number().int().min(0).max(999999999).optional(),
  currency: z.string().max(3).default('INR'),
  sku: z.string().min(1, 'SKU is required').max(100),
  stockQuantity: z.number().int().min(0).max(999999).default(0),
  categoryId: z.string().max(100).optional(),
  images: z.array(z.string().url('Invalid image URL').max(URL_MAX)).max(20, 'Maximum 20 images').default([]),
  tags: z.array(z.string().max(50)).max(20, 'Maximum 20 tags').default([]),
  isActive: z.boolean().default(true),
  isPublished: z.boolean().default(true),
})

export const orderSchema = z.object({
  items: z.array(z.object({
    productId: z.string().max(100),
    quantity: z.number().int().min(1).max(100),
  })).min(1, 'At least one item is required').max(50, 'Maximum 50 items per order'),
  shippingAddress: z.object({
    fullName: z.string().max(NAME_MAX),
    phone: z.string().max(20).optional(),
    street: z.string().max(500),
    city: z.string().max(100),
    state: z.string().max(100),
    zipCode: z.string().max(20),
    country: z.string().max(2).default('IN'),
  }),
  billingAddress: z.object({
    fullName: z.string().max(NAME_MAX),
    phone: z.string().max(20).optional(),
    street: z.string().max(500),
    city: z.string().max(100),
    state: z.string().max(100),
    zipCode: z.string().max(20),
    country: z.string().max(2).default('IN'),
  }).optional(),
  paymentMethod: z.enum(['STRIPE', 'UPI', 'COD', 'WALLET']).optional(),
  couponCode: z.string().max(50).optional(),
  notes: z.string().max(NOTES_MAX).optional(),
})

export const reviewSchema = z.object({
  rating: z.number().int().min(1, 'Rating must be at least 1').max(5, 'Rating must be at most 5'),
  comment: z.string().max(COMMENT_MAX).optional(),
})

export const addressSchema = z.object({
  title: z.string().min(1, 'Title is required').max(NAME_MAX),
  fullName: z.string().min(1, 'Full name is required').max(NAME_MAX),
  phone: z.string().max(20).regex(/^[+]?[\d\s\-()]*$/, 'Invalid phone number').optional(),
  street: z.string().min(1, 'Street is required').max(500),
  city: z.string().min(1, 'City is required').max(100),
  state: z.string().min(1, 'State is required').max(100),
  zipCode: z.string().min(1, 'ZIP code is required').max(20),
  country: z.string().max(2).default('IN'),
  isDefault: z.boolean().default(false),
})

export const couponSchema = z.object({
  code: z.string().min(1, 'Code is required').max(50),
  name: z.string().min(1, 'Name is required').max(NAME_MAX),
  description: z.string().max(DESCRIPTION_MAX).optional(),
  type: z.enum(['PERCENTAGE', 'FIXED_AMOUNT', 'FREE_SHIPPING', 'BUY_X_GET_Y']),
  discountValue: z.number().min(0),
  maxDiscountAmount: z.number().min(0).optional(),
  minOrderAmount: z.number().min(0).optional(),
  usageLimit: z.number().int().min(0).optional(),
  userUsageLimit: z.number().int().min(1).default(1),
  validFrom: z.coerce.date(),
  validTo: z.coerce.date().optional(),
})

export const vendorRegistrationSchema = z.object({
  name: z.string().min(2, 'Store name is required').max(NAME_MAX),
  description: z.string().max(DESCRIPTION_MAX).optional(),
  contact: z.string().max(500).optional(),
  address: z.string().max(500).optional(),
  slug: z.string().max(100).regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, 'Slug must be lowercase alphanumeric with hyphens').optional(),
})

export const profileUpdateSchema = z.object({
  name: z.string().min(2).max(NAME_MAX).optional(),
  phone: z.string().max(20).regex(/^[+]?[\d\s\-()]*$/, 'Invalid phone number').optional(),
  email: z.string().email().max(255).optional(),
})

export const passwordChangeSchema = z.object({
  currentPassword: z.string().min(1, 'Current password is required'),
  newPassword: z.string()
    .min(8, 'Password must be at least 8 characters')
    .max(128)
    .regex(/[A-Z]/, 'Password must contain at least one uppercase letter')
    .regex(/[a-z]/, 'Password must contain at least one lowercase letter')
    .regex(/[0-9]/, 'Password must contain at least one number'),
})

export const searchSchema = z.object({
  query: z.string().max(200).optional(),
  q: z.string().max(200).optional(),
  category: z.string().max(100).optional(),
  minPrice: z.number().min(0).optional(),
  maxPrice: z.number().min(0).optional(),
  sort: z.enum(['newest', 'price_asc', 'price_desc', 'rating', 'popular']).optional(),
  page: z.number().int().min(1).default(1),
  limit: z.number().int().min(1).max(100).default(20),
})

export type RegisterInput = z.infer<typeof registerSchema>
export type LoginInput = z.infer<typeof loginSchema>
export type ProductInput = z.infer<typeof productSchema>
export type OrderInput = z.infer<typeof orderSchema>
export type ReviewInput = z.infer<typeof reviewSchema>
export type AddressInput = z.infer<typeof addressSchema>
export type CouponInput = z.infer<typeof couponSchema>
export type VendorRegistrationInput = z.infer<typeof vendorRegistrationSchema>
export type ProfileUpdateInput = z.infer<typeof profileUpdateSchema>
export type PasswordChangeInput = z.infer<typeof passwordChangeSchema>
export const profileSchema = profileUpdateSchema
export const passwordSchema = passwordChangeSchema

export type SearchInput = z.infer<typeof searchSchema>
