import { v2 as cloudinary } from 'cloudinary'

let configured = false

function ensureConfig() {
  if (configured) return
  const cloudName = process.env.CLOUDINARY_CLOUD_NAME
  const apiKey = process.env.CLOUDINARY_API_KEY
  const apiSecret = process.env.CLOUDINARY_API_SECRET
  if (!cloudName || !apiKey || !apiSecret) {
    throw new Error('Missing Cloudinary environment variables: CLOUDINARY_CLOUD_NAME, CLOUDINARY_API_KEY, CLOUDINARY_API_SECRET')
  }
  cloudinary.config({ cloud_name: cloudName, api_key: apiKey, api_secret: apiSecret })
  configured = true
}

interface UploadResult {
  url: string
  publicId: string
  width: number
  height: number
  format: string
}

export async function uploadImage(
  file: string | Buffer,
  folder: string = 'yourtaste'
): Promise<UploadResult> {
  ensureConfig()
  let result
  if (Buffer.isBuffer(file)) {
    const base64 = file.toString('base64')
    const mimeType = 'image/jpeg'
    result = await cloudinary.uploader.upload(
      `data:${mimeType};base64,${base64}`,
      {
        folder,
        resource_type: 'image',
        transformation: [
          { quality: 'auto:good' },
          { fetch_format: 'auto' },
        ],
      }
    )
  } else {
    result = await cloudinary.uploader.upload(
      file,
      {
        folder,
        resource_type: 'image',
        transformation: [
          { quality: 'auto:good' },
          { fetch_format: 'auto' },
        ],
      }
    )
  }

  return {
    url: result.secure_url,
    publicId: result.public_id,
    width: result.width,
    height: result.height,
    format: result.format,
  }
}

export async function deleteImage(publicId: string): Promise<void> {
  ensureConfig()
  await cloudinary.uploader.destroy(publicId)
}

export function getOptimizedUrl(url: string, options?: {
  width?: number
  height?: number
  crop?: string
  quality?: string | number
}): string {
  const { width, height, crop = 'fill', quality = 'auto:good' } = options || {}

  const transforms: string[] = [`q_${quality}`, 'f_auto']
  if (width) transforms.push(`w_${width}`)
  if (height) transforms.push(`h_${height}`)
  if (width || height) transforms.push(`c_${crop}`)

  const parts = url.split('/upload/')
  if (parts.length === 2) {
    return `${parts[0]}/upload/${transforms.join(',')}/${parts[1]}`
  }

  return url
}

export { cloudinary }
