import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { AppError } from '@/lib/errors'
import { randomUUID } from 'crypto'

export async function getSession() {
  return await getServerSession(authOptions)
}

export async function getCurrentUser() {
  const session = await getSession()
  if (!session?.user) return null
  return session.user
}

export async function requireAuth() {
  const user = await getCurrentUser()
  if (!user) {
    throw new AppError('Authentication required', 401)
  }
  return user
}

export async function requireRole(...roles: string[]) {
  const user = await requireAuth()
  if (!roles.includes(user.role)) {
    throw new AppError('Insufficient permissions', 403)
  }
  return user
}

export async function requireAdmin() {
  return requireRole('ADMIN')
}

export async function requireVendor() {
  return requireRole('VENDOR', 'ADMIN')
}

export function successResponse<T>(data: T, status: number = 200) {
  return NextResponse.json({ success: true, data }, { status })
}

export function errorResponse(message: string, status: number = 500) {
  return NextResponse.json({ success: false, error: message }, { status })
}

export function paginatedResponse<T>(data: T[], total: number, page: number, limit: number) {
  return NextResponse.json({
    success: true,
    data,
    pagination: {
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit),
      hasNext: page * limit < total,
      hasPrevious: page > 1,
    },
  })
}

/**
 * Parse pagination params with safe defaults and max cap
 */
export function parsePagination(searchParams: URLSearchParams, maxLimit = 100) {
  const page = Math.max(1, parseInt(searchParams.get('page') || '1') || 1)
  const limit = Math.min(maxLimit, Math.max(1, parseInt(searchParams.get('limit') || '20') || 20))
  const skip = (page - 1) * limit
  return { page, limit, skip }
}

export function handleApiError(error: unknown) {
  const requestId = randomUUID()

  if (error instanceof AppError) {
    console.error(`[API] ${requestId} - ${error.statusCode} ${error.message}`)
    return errorResponse(error.message, error.statusCode)
  }

  // Log full error details server-side for debugging
  console.error(`[API] ${requestId} - Internal error:`, error)

  // Return generic message to client - never leak internal details
  if (process.env.NODE_ENV === 'production') {
    return errorResponse('An unexpected error occurred. Please try again later.', 500)
  }

  // In development, show error message for debugging
  if (error instanceof Error) {
    return errorResponse(error.message, 500)
  }

  return errorResponse('An unexpected error occurred', 500)
}
