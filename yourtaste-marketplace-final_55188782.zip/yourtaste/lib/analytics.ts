import { prisma } from '@/lib/prisma';

export interface DateRange {
  startDate: Date;
  endDate: Date;
}

export interface TrackEventInput {
  type: string;
  userId?: string;
  sessionId: string;
  ipAddress?: string;
  userAgent?: string;
  referer?: string;
  page?: string;
  properties?: Record<string, unknown>;
  productId?: string;
  categoryId?: string;
  vendorId?: string;
  orderId?: string;
  revenue?: number;
  quantity?: number;
  currency?: string;
  country?: string;
  city?: string;
  region?: string;
  deviceType?: string;
  browser?: string;
  os?: string;
}

export interface DashboardOverview {
  totalRevenue: number;
  totalOrders: number;
  totalVisitors: number;
  totalPageViews: number;
  newUsers: number;
  conversionRate: number;
  avgOrderValue: number;
  revenueChange: number;
  ordersChange: number;
  visitorsChange: number;
}

export interface TrafficMetrics {
  totalPageViews: number;
  uniqueVisitors: number;
  bounceRate: number;
  avgSessionDuration: number;
  topPages: { page: string; views: number }[];
  topReferrers: { referer: string; count: number }[];
  deviceBreakdown: { deviceType: string; count: number }[];
  browserBreakdown: { browser: string; count: number }[];
}

export interface EcommerceMetrics {
  totalRevenue: number;
  totalOrders: number;
  avgOrderValue: number;
  conversionRate: number;
  topProducts: { productId: string; name: string; revenue: number; quantity: number }[];
  topCategories: { categoryId: string; name: string; revenue: number; orders: number }[];
  topVendors: { vendorId: string; name: string; revenue: number; orders: number }[];
  paymentMethods: { method: string; count: number; total: number }[];
}

export interface FunnelStage {
  stage: string;
  count: number;
  percentage: number;
  dropoff: number;
}

export interface CohortEntry {
  cohortMonth: string;
  monthOffset: number;
  userCount: number;
  revenue: number;
  orders: number;
}

export interface GeoMetric {
  country: string;
  orders: number;
  revenue: number;
}

export interface RealtimeMetrics {
  activeUsers: number;
  activeSessions: number;
  todayRevenue: number;
  todayOrders: number;
  recentEvents: { type: string; page: string | null; timestamp: Date }[];
}

export interface VendorAnalyticsData {
  revenue: number;
  orders: number;
  productsSold: number;
  views: number;
  topProducts: { productId: string; name: string; revenue: number; quantity: number }[];
  dailyTrend: { date: string; revenue: number; orders: number }[];
}

export class AnalyticsService {
  static async trackEvent(input: TrackEventInput) {
    return prisma.analyticsEvent.create({
      data: {
        type: input.type,
        userId: input.userId,
        sessionId: input.sessionId,
        ipAddress: input.ipAddress,
        userAgent: input.userAgent,
        referer: input.referer,
        page: input.page,
        properties: input.properties ? JSON.stringify(input.properties) : null,
        productId: input.productId,
        categoryId: input.categoryId,
        vendorId: input.vendorId,
        orderId: input.orderId,
        revenue: input.revenue,
        quantity: input.quantity,
        currency: input.currency,
        country: input.country,
        city: input.city,
        region: input.region,
        deviceType: input.deviceType,
        browser: input.browser,
        os: input.os,
      },
    });
  }

  static async trackPageView(userId: string | undefined, sessionId: string, page: string, meta?: Partial<TrackEventInput>) {
    return this.trackEvent({
      type: 'page_view',
      userId,
      sessionId,
      page,
      ...meta,
    });
  }

  static async trackProductView(userId: string | undefined, sessionId: string, productId: string, meta?: Partial<TrackEventInput>) {
    return this.trackEvent({
      type: 'product_view',
      userId,
      sessionId,
      productId,
      ...meta,
    });
  }

  static async trackAddToCart(userId: string | undefined, sessionId: string, productId: string, quantity: number, meta?: Partial<TrackEventInput>) {
    return this.trackEvent({
      type: 'add_to_cart',
      userId,
      sessionId,
      productId,
      quantity,
      ...meta,
    });
  }

  static async trackCheckout(userId: string | undefined, sessionId: string, orderId: string, revenue: number, meta?: Partial<TrackEventInput>) {
    return this.trackEvent({
      type: 'checkout',
      userId,
      sessionId,
      orderId,
      revenue,
      ...meta,
    });
  }

  static async trackPayment(userId: string | undefined, sessionId: string, orderId: string, revenue: number, meta?: Partial<TrackEventInput>) {
    return this.trackEvent({
      type: 'payment',
      userId,
      sessionId,
      orderId,
      revenue,
      ...meta,
    });
  }

  static async trackSearch(userId: string | undefined, sessionId: string, query: string, resultsCount: number) {
    return this.trackEvent({
      type: 'search',
      userId,
      sessionId,
      properties: { query, resultsCount },
    });
  }

  static async getDashboardOverview(range: DateRange, compareRange?: DateRange): Promise<DashboardOverview> {
    const [currentDaily, previousDaily] = await Promise.all([
      prisma.dailyAnalytics.findMany({
        where: { date: { gte: range.startDate, lte: range.endDate } },
      }),
      compareRange
        ? prisma.dailyAnalytics.findMany({
            where: { date: { gte: compareRange.startDate, lte: compareRange.endDate } },
          })
        : Promise.resolve([]),
    ]);

    const aggregate = (rows: { totalRevenue: number; totalOrders: number; totalVisitors: number; totalPageViews: number; newUsers: number; conversionRate: number; avgOrderValue: number }[]) => {
      const totalRevenue = rows.reduce((s, r) => s + r.totalRevenue, 0);
      const totalOrders = rows.reduce((s, r) => s + r.totalOrders, 0);
      const totalVisitors = rows.reduce((s, r) => s + r.totalVisitors, 0);
      const totalPageViews = rows.reduce((s, r) => s + r.totalPageViews, 0);
      const newUsers = rows.reduce((s, r) => s + r.newUsers, 0);
      const avgConversion = rows.length ? rows.reduce((s, r) => s + r.conversionRate, 0) / rows.length : 0;
      const avgOrderValue = rows.length ? rows.reduce((s, r) => s + r.avgOrderValue, 0) / rows.length : 0;
      return { totalRevenue, totalOrders, totalVisitors, totalPageViews, newUsers, conversionRate: avgConversion, avgOrderValue };
    };

    const current = aggregate(currentDaily);
    const previous = aggregate(previousDaily);

    const pctChange = (curr: number, prev: number) => (prev === 0 ? (curr > 0 ? 100 : 0) : ((curr - prev) / prev) * 100);

    return {
      ...current,
      revenueChange: pctChange(current.totalRevenue, previous.totalRevenue),
      ordersChange: pctChange(current.totalOrders, previous.totalOrders),
      visitorsChange: pctChange(current.totalVisitors, previous.totalVisitors),
    };
  }

  static async getTrafficMetrics(range: DateRange): Promise<TrafficMetrics> {
    const where = { timestamp: { gte: range.startDate, lte: range.endDate } };

    const [totalPageViews, topPages, topReferrers, deviceBreakdown, browserBreakdown, uniqueBySession, uniqueByUser] = await Promise.all([
      prisma.analyticsEvent.count({
        where: { ...where, page: { not: null } },
      }),
      prisma.analyticsEvent.groupBy({
        by: ['page'],
        where: { ...where, page: { not: null } },
        _count: { _all: true },
      }),
      prisma.analyticsEvent.groupBy({
        by: ['referer'],
        where,
        _count: { _all: true },
      }),
      prisma.analyticsEvent.groupBy({
        by: ['deviceType'],
        where,
        _count: { _all: true },
      }),
      prisma.analyticsEvent.groupBy({
        by: ['browser'],
        where,
        _count: { _all: true },
      }),
      prisma.analyticsEvent.findMany({
        where,
        select: { sessionId: true },
        distinct: ['sessionId'],
      }),
      prisma.analyticsEvent.findMany({
        where: { ...where, userId: { not: null } },
        select: { userId: true },
        distinct: ['userId'],
      }),
    ]);

    const sessionIds = new Set(uniqueBySession.map((e) => `s:${e.sessionId}`))
    const userIds = new Set(uniqueByUser.map((e) => `u:${e.userId!}`))
    const uniqueVisitors = new Set([...sessionIds, ...userIds]).size

    const totalSessions = uniqueBySession.length || 1
    const sessionsByPage = new Map<string, number>()
    for (const event of await prisma.analyticsEvent.findMany({
      where,
      select: { sessionId: true, page: true },
    })) {
      if (event.sessionId && event.page) {
        sessionsByPage.set(event.sessionId, (sessionsByPage.get(event.sessionId) || 0) + 1)
      }
    }
    const bouncedSessions = [...sessionsByPage.values()].filter(count => count === 1).length
    const bounceRate = Math.round((bouncedSessions / totalSessions) * 100)

    const sessionTimes = new Map<string, { first: number; last: number }>()
    for (const event of await prisma.analyticsEvent.findMany({
      where,
      select: { sessionId: true, timestamp: true },
      orderBy: { timestamp: 'asc' },
      take: 5000,
    })) {
      if (!event.sessionId) continue
      const ts = event.timestamp.getTime()
      const existing = sessionTimes.get(event.sessionId)
      if (!existing) {
        sessionTimes.set(event.sessionId, { first: ts, last: ts })
      } else {
        existing.last = ts
      }
    }
    const durations = [...sessionTimes.values()]
      .map(s => s.last - s.first)
      .filter(d => d > 0)
    const avgSessionDuration = durations.length > 0
      ? Math.round(durations.reduce((a, b) => a + b, 0) / durations.length / 1000)
      : 0

    return {
      totalPageViews,
      uniqueVisitors,
      bounceRate,
      avgSessionDuration,
      topPages: (topPages as any[]).sort((a: any, b: any) => ((b._count as any)?._all ?? 0) - ((a._count as any)?._all ?? 0)).slice(0, 10).map((p: any) => ({ page: p.page ?? 'unknown', views: (p._count as any)?._all ?? 0 })),
      topReferrers: (topReferrers as any[]).sort((a: any, b: any) => ((b._count as any)?._all ?? 0) - ((a._count as any)?._all ?? 0)).slice(0, 10).map((r: any) => ({ referer: r.referer ?? 'direct', count: (r._count as any)?._all ?? 0 })),
      deviceBreakdown: deviceBreakdown.map((d) => ({ deviceType: d.deviceType ?? 'unknown', count: (d._count as any)._all ?? 0 })),
      browserBreakdown: browserBreakdown.map((b) => ({ browser: b.browser ?? 'unknown', count: (b._count as any)._all ?? 0 })),
    };
  }

  static async getEcommerceMetrics(range: DateRange): Promise<EcommerceMetrics> {
    const orderWhere = { createdAt: { gte: range.startDate, lte: range.endDate }, paymentStatus: 'PAID' as const };

    const [revenueResult, visitorsResult, topProductsRaw, topCategoriesRaw, topVendorsRaw, paymentMethodsRaw] = await Promise.all([
      prisma.order.aggregate({
        where: orderWhere,
        _sum: { total: true },
        _count: true,
        _avg: { total: true },
      }),
      prisma.dailyAnalytics.aggregate({
        where: { date: { gte: range.startDate, lte: range.endDate } },
        _sum: { totalVisitors: true },
      }),
      prisma.orderItem.groupBy({
        by: ['productId'],
        where: { order: orderWhere },
        _sum: { priceCents: true, quantity: true },
        orderBy: { _sum: { priceCents: 'desc' } },
        take: 10,
      }),
      prisma.orderItem.groupBy({
        by: ['productId'],
        where: { order: orderWhere },
        _sum: { priceCents: true, quantity: true },
        _count: { _all: true },
        orderBy: { _sum: { priceCents: 'desc' } },
        take: 10,
      }),
      prisma.order.groupBy({
        by: ['vendorId'],
        where: orderWhere,
        _sum: { total: true },
        _count: { _all: true },
        orderBy: { _sum: { total: 'desc' } },
        take: 10,
      }),
      prisma.order.groupBy({
        by: ['paymentMethod'],
        where: orderWhere,
        _sum: { total: true },
        _count: { _all: true },
      }),
    ]);

    const totalRevenue = revenueResult._sum.total ?? 0;
    const totalOrders = revenueResult._count;
    const avgOrderValue = revenueResult._avg.total ?? 0;
    const totalVisitors = visitorsResult._sum.totalVisitors ?? 0;
    const conversionRate = totalVisitors > 0 ? (totalOrders / totalVisitors) * 100 : 0;

    const productIds = topProductsRaw.map((p) => p.productId);
    const products = productIds.length > 0
      ? await prisma.product.findMany({ where: { id: { in: productIds } }, select: { id: true, name: true, categoryId: true } })
      : [];
    const productMap = new Map(products.map((p) => [p.id, p]));

    const topProducts = topProductsRaw.map((p) => ({
      productId: p.productId,
      name: productMap.get(p.productId)?.name ?? '',
      revenue: (p._sum.priceCents ?? 0) / 100,
      quantity: p._sum.quantity ?? 0,
    }));

    const categoryRevenue = new Map<string, { name: string; revenue: number; orders: number }>();
    for (const item of topCategoriesRaw) {
      const product = productMap.get(item.productId);
      const catId = product?.categoryId ?? 'uncategorized';
      const existing = categoryRevenue.get(catId) ?? { name: 'Uncategorized', revenue: 0, orders: 0 };
      existing.revenue += (item._sum.priceCents ?? 0) / 100;
      existing.orders += (item._count as any)?._all ?? 0;
      categoryRevenue.set(catId, existing);
    }
    const topCategories = [...categoryRevenue.entries()]
      .map(([categoryId, data]) => ({ categoryId, ...data }))
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 10);

    const vendorIds = topVendorsRaw.map((v) => v.vendorId!).filter(Boolean);
    const vendors = vendorIds.length > 0
      ? await prisma.vendor.findMany({ where: { id: { in: vendorIds } }, select: { id: true, name: true } })
      : [];
    const vendorNameMap = new Map(vendors.map((v) => [v.id, v.name]));
    const topVendors = topVendorsRaw
      .filter((v) => v.vendorId)
      .map((v) => ({
        vendorId: v.vendorId!,
        name: vendorNameMap.get(v.vendorId!) ?? '',
        revenue: v._sum?.total ?? 0,
        orders: (v._count as any)?._all ?? 0,
      }));

    const paymentMethods = paymentMethodsRaw.map((p) => ({
      method: p.paymentMethod ?? 'unknown',
      count: (p._count as any)?._all ?? 0,
      total: p._sum?.total ?? 0,
    }));

    return { totalRevenue, totalOrders, avgOrderValue, conversionRate, topProducts, topCategories, topVendors, paymentMethods };
  }

  static async getUserMetrics(range: DateRange) {
    const [totalUsers, newUsers, activeUsers] = await Promise.all([
      prisma.user.count(),
      prisma.user.count({ where: { createdAt: { gte: range.startDate, lte: range.endDate } } }),
      prisma.user.count({ where: { lastLogin: { gte: range.startDate, lte: range.endDate } } }),
    ]);

    const roleCounts = await prisma.user.groupBy({
      by: ['role'],
      where: { isActive: true },
      _count: { _all: true },
    });

    return { totalUsers, newUsers, activeUsers, roleBreakdown: roleCounts.map((r) => ({ role: r.role, count: r._count._all })) };
  }

  static async getConversionFunnel(range: DateRange): Promise<FunnelStage[]> {
    const funnel = await prisma.conversionFunnel.findMany({
      where: { date: { gte: range.startDate, lte: range.endDate } },
      orderBy: { date: 'asc' },
    });

    const stageMap = new Map<string, number>();
    for (const entry of funnel) {
      stageMap.set(entry.stage, (stageMap.get(entry.stage) ?? 0) + entry.count);
    }

    const stageOrder = ['visit', 'product_view', 'add_to_cart', 'checkout', 'payment', 'purchase'];
    const stages = stageOrder.filter((s) => stageMap.has(s));
    if (stages.length === 0) return [];

    const topCount = stageMap.get(stages[0]) ?? 1;

    return stages.map((stage, i) => {
      const count = stageMap.get(stage) ?? 0;
      const prevCount = i > 0 ? stageMap.get(stages[i - 1]) ?? count : count;
      return {
        stage,
        count,
        percentage: topCount > 0 ? (count / topCount) * 100 : 0,
        dropoff: prevCount > 0 ? ((prevCount - count) / prevCount) * 100 : 0,
      };
    });
  }

  static async getCohortAnalysis(months: number = 6): Promise<CohortEntry[]> {
    const cohorts = await prisma.userCohort.findMany({
      orderBy: [{ cohortMonth: 'desc' }, { monthOffset: 'asc' }],
    });

    return cohorts.map((c) => ({
      cohortMonth: c.cohortMonth.toISOString().slice(0, 7),
      monthOffset: c.monthOffset,
      userCount: c.userCount,
      revenue: c.revenue,
      orders: c.orders,
    }));
  }

  static async getGeographicMetrics(range: DateRange): Promise<GeoMetric[]> {
    const events = await prisma.analyticsEvent.findMany({
      where: {
        timestamp: { gte: range.startDate, lte: range.endDate },
        country: { not: null },
        type: 'payment',
      },
      select: { country: true, revenue: true, orderId: true },
    });

    const geoMap = new Map<string, { orders: number; revenue: number }>();
    for (const e of events) {
      const country = e.country ?? 'Unknown';
      const existing = geoMap.get(country) ?? { orders: 0, revenue: 0 };
      if (e.orderId) existing.orders += 1;
      existing.revenue += e.revenue ?? 0;
      geoMap.set(country, existing);
    }

    return [...geoMap.entries()]
      .map(([country, data]) => ({ country, ...data }))
      .sort((a, b) => b.revenue - a.revenue);
  }

  static async getRealtimeMetrics(): Promise<RealtimeMetrics> {
    const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);

    const [activeEvents, todayOrders, recentEvents] = await Promise.all([
      prisma.analyticsEvent.findMany({
        where: { timestamp: { gte: fiveMinutesAgo } },
        select: { sessionId: true, userId: true },
        take: 1000,
      }),
      prisma.order.count({
        where: { createdAt: { gte: todayStart } },
      }),
      prisma.analyticsEvent.findMany({
        where: { timestamp: { gte: fiveMinutesAgo } },
        select: { type: true, page: true, timestamp: true },
        orderBy: { timestamp: 'desc' },
        take: 20,
      }),
    ]);

    const todayRevenue = await prisma.order.aggregate({
      where: { createdAt: { gte: todayStart }, paymentStatus: 'PAID' as const },
      _sum: { total: true },
    });

    const activeSessions = new Set(activeEvents.map((e) => e.sessionId)).size;
    const activeUsers = new Set(activeEvents.map((e) => e.userId ?? e.sessionId)).size;

    return {
      activeUsers,
      activeSessions,
      todayRevenue: todayRevenue._sum.total ?? 0,
      todayOrders,
      recentEvents: recentEvents.map((e) => ({ type: e.type, page: e.page, timestamp: e.timestamp })),
    };
  }

  static async updateDailyRollup(date: Date) {
    const dayStart = new Date(date);
    dayStart.setHours(0, 0, 0, 0);
    const dayEnd = new Date(date);
    dayEnd.setHours(23, 59, 59, 999);

    const [orders, visitors, events, newUsers] = await Promise.all([
      prisma.order.findMany({
        where: { createdAt: { gte: dayStart, lte: dayEnd }, paymentStatus: 'PAID' as const },
      }),
      prisma.analyticsEvent.findMany({
        where: { timestamp: { gte: dayStart, lte: dayEnd }, type: 'page_view' },
        select: { sessionId: true, userId: true },
      }),
      prisma.analyticsEvent.count({
        where: { timestamp: { gte: dayStart, lte: dayEnd }, type: 'page_view' },
      }),
      prisma.user.count({
        where: { createdAt: { gte: dayStart, lte: dayEnd } },
      }),
    ]);

    const totalRevenue = orders.reduce((s, o) => s + o.total, 0);
    const totalOrders = orders.length;
    const totalVisitors = new Set(visitors.map((v) => v.userId ?? v.sessionId)).size;
    const conversionRate = totalVisitors > 0 ? (totalOrders / totalVisitors) * 100 : 0;
    const avgOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;

    return prisma.dailyAnalytics.upsert({
      where: { date: dayStart },
      update: {
        totalRevenue,
        totalOrders,
        totalVisitors,
        totalPageViews: events,
        newUsers,
        conversionRate,
        avgOrderValue,
      },
      create: {
        date: dayStart,
        totalRevenue,
        totalOrders,
        totalVisitors,
        totalPageViews: events,
        newUsers,
        conversionRate,
        avgOrderValue,
      },
    });
  }

  static async getVendorAnalytics(vendorId: string, range: DateRange): Promise<VendorAnalyticsData> {
    const dailyRows = await prisma.vendorAnalytics.findMany({
      where: { vendorId, date: { gte: range.startDate, lte: range.endDate } },
      orderBy: { date: 'asc' },
    });

    const revenue = dailyRows.reduce((s, r) => s + r.revenue, 0);
    const orders = dailyRows.reduce((s, r) => s + r.orders, 0);
    const productsSold = dailyRows.reduce((s, r) => s + r.productsSold, 0);
    const views = dailyRows.reduce((s, r) => s + r.views, 0);

    const vendorOrders = await prisma.order.findMany({
      where: {
        vendorId,
        createdAt: { gte: range.startDate, lte: range.endDate },
        paymentStatus: 'PAID' as const,
      },
      include: { items: { include: { product: true } } },
    });

    const productRevenue = new Map<string, { name: string; revenue: number; quantity: number }>();
    for (const order of vendorOrders) {
      for (const item of order.items) {
        const existing = productRevenue.get(item.productId) ?? { name: item.product.name, revenue: 0, quantity: 0 };
        existing.revenue += (item.priceCents / 100) * item.quantity;
        existing.quantity += item.quantity;
        productRevenue.set(item.productId, existing);
      }
    }
    const topProducts = [...productRevenue.entries()]
      .map(([productId, data]) => ({ productId, ...data }))
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 10);

    const dailyTrend = dailyRows.map((r) => ({
      date: r.date.toISOString().slice(0, 10),
      revenue: r.revenue,
      orders: r.orders,
    }));

    return { revenue, orders, productsSold, views, topProducts, dailyTrend };
  }

  static async updateVendorDailyRollup(vendorId: string, date: Date) {
    const dayStart = new Date(date);
    dayStart.setHours(0, 0, 0, 0);

    const orders = await prisma.order.findMany({
      where: {
        vendorId,
        createdAt: { gte: dayStart, lte: new Date(dayStart.getTime() + 86400000 - 1) },
        paymentStatus: 'PAID' as const,
      },
      include: { items: true },
    });

    const revenue = orders.reduce((s, o) => s + o.total, 0);
    const productsSold = orders.reduce((s, o) => s + o.items.reduce((is, i) => is + i.quantity, 0), 0);

    const views = await prisma.analyticsEvent.count({
      where: {
        vendorId,
        timestamp: { gte: dayStart, lt: new Date(dayStart.getTime() + 86400000) },
        type: 'product_view',
      },
    });

    return prisma.vendorAnalytics.upsert({
      where: { vendorId_date: { vendorId, date: dayStart } },
      update: { revenue, orders: orders.length, productsSold, views },
      create: { vendorId, date: dayStart, revenue, orders: orders.length, productsSold, views },
    });
  }
}
