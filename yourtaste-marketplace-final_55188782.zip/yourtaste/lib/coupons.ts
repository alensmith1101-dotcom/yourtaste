import { randomBytes } from 'crypto'
import { prisma } from '@/lib/prisma'

type CouponType = 'PERCENTAGE' | 'FIXED_AMOUNT' | 'FREE_SHIPPING' | 'BUY_X_GET_Y'
type DiscountScope = 'GLOBAL' | 'CATEGORY' | 'PRODUCT' | 'VENDOR' | 'USER_SEGMENT'

interface CreateCouponInput {
  code: string
  title?: string
  name?: string
  description?: string
  type: CouponType
  discountValue?: number
  maxDiscountAmount?: number
  minOrderValue?: number
  usageLimit?: number
  userUsageLimit?: number
  buyQuantity?: number
  getQuantity?: number
  getDiscountValue?: number
  startsAt?: Date
  expiresAt?: Date
  scope?: DiscountScope
  applicableProductIds?: string[]
  applicableCategoryIds?: string[]
  applicableVendorIds?: string[]
  excludedProductIds?: string[]
  excludedCategoryIds?: string[]
  excludedVendorIds?: string[]
  targetUserIds?: string[]
  firstOrderOnly?: boolean
  canStackWithOthers?: boolean
  autoApply?: boolean
  vendorId?: string
  createdBy?: string
}

interface ValidateCouponInput {
  code: string
  userId: string
  orderTotal: number
  productIds?: string[]
  categoryIds?: string[]
  vendorId?: string
  appliedCouponCodes?: string[]
}

interface ApplyCouponInput {
  code: string
  userId: string
  orderId: string
  orderTotal: number
  productIds?: string[]
  categoryIds?: string[]
  vendorId?: string
}

interface CreateGiftCardInput {
  initialValue: number
  currency?: string
  recipientEmail?: string
  recipientName?: string
  message?: string
  purchasedBy: string
  purchasedById: string
  expiresAt?: Date
}

interface GiftCardRedemptionInput {
  code: string
  orderId: string
  userId: string
  amount: number
}

interface EarnPointsInput {
  userId: string
  points: number
  type: string
  description?: string
  orderId?: string
  expirationMonths?: number
}

interface RedeemPointsInput {
  userId: string
  points: number
  orderId?: string
  description?: string
}

interface CouponValidationResult {
  valid: boolean
  coupon?: Awaited<ReturnType<typeof prisma.coupon.findUnique>>
  discount: number
  error?: string
}

interface StackingResult {
  canStack: boolean
  totalDiscount: number
  appliedCoupons: Array<{ code: string; discount: number }>
  error?: string
}

function generateGiftCardCode(): string {
  const hex = randomBytes(8).toString('hex').toUpperCase()
  return `GC-${hex.slice(0, 4)}-${hex.slice(4, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}`
}

function parseJsonArray(value: string | null | undefined): string[] {
  if (!value) return []
  try {
    const parsed = JSON.parse(value)
    return Array.isArray(parsed) ? parsed : []
  } catch (err) {
    console.error('Failed to parse coupon rules:', err)
    return []
  }
}

export class CouponService {
  static async create(input: CreateCouponInput) {
    const existing = await prisma.coupon.findUnique({ where: { code: input.code } })
    if (existing) throw new Error(`Coupon code "${input.code}" already exists`)

    return prisma.coupon.create({
      data: {
        code: input.code,
        title: input.title ?? '',
        name: input.name ?? null,
        description: input.description ?? null,
        type: input.type,
        discountValue: input.discountValue ?? null,
        maxDiscountAmount: input.maxDiscountAmount ?? null,
        minOrderValue: input.minOrderValue ?? null,
        usageLimit: input.usageLimit ?? null,
        userUsageLimit: input.userUsageLimit ?? null,
        buyQuantity: input.buyQuantity ?? null,
        getQuantity: input.getQuantity ?? null,
        getDiscountValue: input.getDiscountValue ?? null,
        startsAt: input.startsAt ?? null,
        expiresAt: input.expiresAt ?? null,
        scope: input.scope ?? 'GLOBAL',
        applicableProductIds: input.applicableProductIds ? JSON.stringify(input.applicableProductIds) : null,
        applicableCategoryIds: input.applicableCategoryIds ? JSON.stringify(input.applicableCategoryIds) : null,
        applicableVendorIds: input.applicableVendorIds ? JSON.stringify(input.applicableVendorIds) : null,
        excludedProductIds: input.excludedProductIds ? JSON.stringify(input.excludedProductIds) : null,
        excludedCategoryIds: input.excludedCategoryIds ? JSON.stringify(input.excludedCategoryIds) : null,
        excludedVendorIds: input.excludedVendorIds ? JSON.stringify(input.excludedVendorIds) : null,
        targetUserIds: input.targetUserIds ? JSON.stringify(input.targetUserIds) : null,
        firstOrderOnly: input.firstOrderOnly ?? false,
        canStackWithOthers: input.canStackWithOthers ?? false,
        autoApply: input.autoApply ?? false,
        vendorId: input.vendorId ?? null,
        createdBy: input.createdBy ?? null,
        isActive: true,
      },
    })
  }

  static async getByCode(code: string) {
    return prisma.coupon.findUnique({ where: { code } })
  }

  static async getById(id: string) {
    return prisma.coupon.findUnique({ where: { id } })
  }

  static async update(id: string, data: Partial<CreateCouponInput> & { isActive?: boolean }) {
    const updateData: Record<string, unknown> = {}

    if (data.name !== undefined) updateData.name = data.name
    if (data.title !== undefined) updateData.title = data.title
    if (data.description !== undefined) updateData.description = data.description
    if (data.type !== undefined) updateData.type = data.type
    if (data.discountValue !== undefined) updateData.discountValue = data.discountValue
    if (data.maxDiscountAmount !== undefined) updateData.maxDiscountAmount = data.maxDiscountAmount
    if (data.minOrderValue !== undefined) updateData.minOrderValue = data.minOrderValue
    if (data.usageLimit !== undefined) updateData.usageLimit = data.usageLimit
    if (data.userUsageLimit !== undefined) updateData.userUsageLimit = data.userUsageLimit
    if (data.buyQuantity !== undefined) updateData.buyQuantity = data.buyQuantity
    if (data.getQuantity !== undefined) updateData.getQuantity = data.getQuantity
    if (data.getDiscountValue !== undefined) updateData.getDiscountValue = data.getDiscountValue
    if (data.startsAt !== undefined) updateData.startsAt = data.startsAt
    if (data.expiresAt !== undefined) updateData.expiresAt = data.expiresAt
    if (data.scope !== undefined) updateData.scope = data.scope
    if (data.firstOrderOnly !== undefined) updateData.firstOrderOnly = data.firstOrderOnly
    if (data.canStackWithOthers !== undefined) updateData.canStackWithOthers = data.canStackWithOthers
    if (data.autoApply !== undefined) updateData.autoApply = data.autoApply
    if (data.isActive !== undefined) updateData.isActive = data.isActive

    if (data.applicableProductIds !== undefined) updateData.applicableProductIds = data.applicableProductIds ? JSON.stringify(data.applicableProductIds) : null
    if (data.applicableCategoryIds !== undefined) updateData.applicableCategoryIds = data.applicableCategoryIds ? JSON.stringify(data.applicableCategoryIds) : null
    if (data.applicableVendorIds !== undefined) updateData.applicableVendorIds = data.applicableVendorIds ? JSON.stringify(data.applicableVendorIds) : null
    if (data.excludedProductIds !== undefined) updateData.excludedProductIds = data.excludedProductIds ? JSON.stringify(data.excludedProductIds) : null
    if (data.excludedCategoryIds !== undefined) updateData.excludedCategoryIds = data.excludedCategoryIds ? JSON.stringify(data.excludedCategoryIds) : null
    if (data.excludedVendorIds !== undefined) updateData.excludedVendorIds = data.excludedVendorIds ? JSON.stringify(data.excludedVendorIds) : null
    if (data.targetUserIds !== undefined) updateData.targetUserIds = data.targetUserIds ? JSON.stringify(data.targetUserIds) : null

    return prisma.coupon.update({ where: { id }, data: updateData })
  }

  static async deactivate(id: string) {
    return prisma.coupon.update({ where: { id }, data: { isActive: false } })
  }

  static async list(options?: { vendorId?: string; scope?: DiscountScope; activeOnly?: boolean; limit?: number }) {
    const where: Record<string, unknown> = {}
    if (options?.vendorId) where.vendorId = options.vendorId
    if (options?.scope) where.scope = options.scope
    if (options?.activeOnly) where.isActive = true

    return prisma.coupon.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: options?.limit ?? 100,
    })
  }

  static async validate(input: ValidateCouponInput): Promise<CouponValidationResult> {
    const coupon = await prisma.coupon.findUnique({ where: { code: input.code } })
    if (!coupon) return { valid: false, discount: 0, error: 'Coupon not found' }

    if (!coupon.isActive) return { valid: false, discount: 0, error: 'Coupon is no longer active' }

    const now = new Date()

    if (coupon.startsAt && now < coupon.startsAt) return { valid: false, discount: 0, error: 'Coupon is not yet valid' }
    if (coupon.expiresAt && now > coupon.expiresAt) return { valid: false, discount: 0, error: 'Coupon has expired' }

    if (coupon.usageLimit !== null && coupon.usageCount >= coupon.usageLimit) {
      return { valid: false, discount: 0, error: 'Coupon usage limit reached' }
    }

    if (coupon.userUsageLimit !== null) {
      const userUses = await prisma.userCoupon.count({
        where: { userId: input.userId, couponId: coupon.id },
      })
      if (userUses >= coupon.userUsageLimit) {
        return { valid: false, discount: 0, error: 'You have already used this coupon the maximum number of times' }
      }
    }

    if (coupon.firstOrderOnly) {
      const existingOrders = await prisma.order.count({
        where: { userId: input.userId, paymentStatus: 'PAID' },
      })
      if (existingOrders > 0) return { valid: false, discount: 0, error: 'This coupon is only valid for your first order' }
    }

    if (coupon.targetUserIds) {
      const targetIds = parseJsonArray(coupon.targetUserIds)
      if (targetIds.length > 0 && !targetIds.includes(input.userId)) {
        return { valid: false, discount: 0, error: 'This coupon is not available for your account' }
      }
    }

    if (coupon.minOrderValue !== null && coupon.minOrderValue !== undefined && input.orderTotal < coupon.minOrderValue) {
      return { valid: false, discount: 0, error: `Minimum order value of $${coupon.minOrderValue.toFixed(2)} required` }
    }

    if (coupon.scope === 'PRODUCT' && coupon.applicableProductIds) {
      const allowed = parseJsonArray(coupon.applicableProductIds)
      if (allowed.length > 0 && input.productIds) {
        const hasApplicable = input.productIds.some((id) => allowed.includes(id))
        if (!hasApplicable) return { valid: false, discount: 0, error: 'Coupon does not apply to any products in your order' }
      }
    }

    if (coupon.scope === 'CATEGORY' && coupon.applicableCategoryIds) {
      const allowed = parseJsonArray(coupon.applicableCategoryIds)
      if (allowed.length > 0 && input.categoryIds) {
        const hasApplicable = input.categoryIds.some((id) => allowed.includes(id))
        if (!hasApplicable) return { valid: false, discount: 0, error: 'Coupon does not apply to any categories in your order' }
      }
    }

    if (coupon.scope === 'VENDOR' && coupon.applicableVendorIds) {
      const allowed = parseJsonArray(coupon.applicableVendorIds)
      if (allowed.length > 0 && input.vendorId && !allowed.includes(input.vendorId)) {
        return { valid: false, discount: 0, error: 'Coupon does not apply to this vendor' }
      }
    }

    if (coupon.excludedProductIds && input.productIds) {
      const excluded = parseJsonArray(coupon.excludedProductIds)
      const hasExcluded = input.productIds.some((id) => excluded.includes(id))
      if (hasExcluded) return { valid: false, discount: 0, error: 'Coupon cannot be applied to some products in your order' }
    }

    if (coupon.excludedCategoryIds && input.categoryIds) {
      const excluded = parseJsonArray(coupon.excludedCategoryIds)
      const hasExcluded = input.categoryIds.some((id) => excluded.includes(id))
      if (hasExcluded) return { valid: false, discount: 0, error: 'Coupon cannot be applied to some categories in your order' }
    }

    if (coupon.excludedVendorIds && input.vendorId) {
      const excluded = parseJsonArray(coupon.excludedVendorIds)
      if (excluded.includes(input.vendorId)) return { valid: false, discount: 0, error: 'Coupon cannot be applied to this vendor' }
    }

    const discount = CouponService.calculateDiscount(coupon, input.orderTotal)

    return { valid: true, coupon, discount }
  }

  static calculateDiscount(coupon: {
    type: string
    discountValue: number | null
    maxDiscountAmount: number | null
    buyQuantity: number | null
    getQuantity: number | null
    getDiscountValue: number | null
  }, orderTotal: number): number {
    const effectiveValue = coupon.discountValue ?? 0
    const maxCap = coupon.maxDiscountAmount ?? 0

    let discount = 0

    switch (coupon.type) {
      case 'PERCENTAGE':
        discount = orderTotal * (effectiveValue / 100)
        break
      case 'FIXED_AMOUNT':
        discount = Math.min(effectiveValue, orderTotal)
        break
      case 'FREE_SHIPPING':
        discount = 0
        break
      case 'BUY_X_GET_Y':
        discount = coupon.getDiscountValue ?? 0
        break
      default:
        discount = 0
    }

    if (maxCap > 0 && discount > maxCap) {
      discount = maxCap
    }

    return Math.round(discount * 100) / 100
  }

  static async apply(input: ApplyCouponInput) {
    const validation = await CouponService.validate({
      code: input.code,
      userId: input.userId,
      orderTotal: input.orderTotal,
      productIds: input.productIds,
      categoryIds: input.categoryIds,
      vendorId: input.vendorId,
    })

    if (!validation.valid || !validation.coupon) {
      throw new Error(validation.error ?? 'Coupon validation failed')
    }

    const coupon = validation.coupon

    const [updatedCoupon, userCoupon, usageLog] = await prisma.$transaction([
      prisma.coupon.update({
        where: { id: coupon.id },
        data: { usageCount: { increment: 1 } },
      }),
      prisma.userCoupon.create({
        data: {
          userId: input.userId,
          couponId: coupon.id,
          orderId: input.orderId,
        },
      }),
      prisma.couponUsage.create({
        data: {
          couponId: coupon.id,
          userId: input.userId,
          orderId: input.orderId,
          discount: validation.discount,
        },
      }),
    ])

    await prisma.order.update({
      where: { id: input.orderId },
      data: {
        couponCode: coupon.code,
        discount: validation.discount,
      },
    })

    return { coupon: updatedCoupon, userCoupon, usageLog, discount: validation.discount }
  }

  static async checkStacking(input: ValidateCouponInput & { codes: string[] }): Promise<StackingResult> {
    const appliedCoupons: Array<{ code: string; discount: number }> = []
    let totalDiscount = 0

    for (const code of input.codes) {
      const validation = await CouponService.validate({
        ...input,
        code,
        appliedCouponCodes: input.codes.filter((c) => c !== code),
      })

      if (!validation.valid || !validation.coupon) {
        return { canStack: false, totalDiscount: 0, appliedCoupons: [], error: `Coupon "${code}": ${validation.error}` }
      }

      if (!validation.coupon.canStackWithOthers && input.codes.length > 1) {
        return { canStack: false, totalDiscount: 0, appliedCoupons: [], error: `Coupon "${code}" cannot be combined with other coupons` }
      }

      appliedCoupons.push({ code, discount: validation.discount })
      totalDiscount += validation.discount
    }

    if (totalDiscount > input.orderTotal) {
      totalDiscount = input.orderTotal
    }

    return { canStack: true, totalDiscount: Math.round(totalDiscount * 100) / 100, appliedCoupons }
  }

  static async findAutoApplyCoupons(userId: string, orderTotal: number, productIds?: string[], categoryIds?: string[], vendorId?: string) {
    const autoCoupons = await prisma.coupon.findMany({
      where: { autoApply: true, isActive: true },
    })

    const applicable: Array<{ code: string; discount: number }> = []

    for (const coupon of autoCoupons) {
      const validation = await CouponService.validate({
        code: coupon.code,
        userId,
        orderTotal,
        productIds,
        categoryIds,
        vendorId,
      })

      if (validation.valid) {
        applicable.push({ code: coupon.code, discount: validation.discount })
      }
    }

    applicable.sort((a, b) => b.discount - a.discount)

    return applicable
  }

  static async getUserCoupons(userId: string) {
    return prisma.userCoupon.findMany({
      where: { userId },
      include: { coupon: true },
      orderBy: { usedAt: 'desc' },
    })
  }

  static async getCouponUsageHistory(couponId: string) {
    return prisma.couponUsage.findMany({
      where: { couponId },
      orderBy: { usedAt: 'desc' },
    })
  }

  static async removeCouponFromOrder(orderId: string, userId: string) {
    const order = await prisma.order.findUnique({ where: { id: orderId } })
    if (!order) throw new Error('Order not found')
    if (!order.couponCode) throw new Error('No coupon applied to this order')

    const coupon = await prisma.coupon.findUnique({ where: { code: order.couponCode } })
    if (!coupon) throw new Error('Coupon not found')

    await prisma.$transaction([
      prisma.coupon.update({
        where: { id: coupon.id },
        data: { usageCount: { decrement: 1 } },
      }),
      prisma.userCoupon.deleteMany({
        where: { userId, couponId: coupon.id, orderId },
      }),
      prisma.couponUsage.deleteMany({
        where: { userId, couponId: coupon.id, orderId },
      }),
      prisma.order.update({
        where: { id: orderId },
        data: { couponCode: null, discount: 0 },
      }),
    ])

    return { success: true }
  }

  // ── Gift Cards ──────────────────────────────────────────────

  static async createGiftCard(input: CreateGiftCardInput) {
    const code = generateGiftCardCode()

    return prisma.giftCard.create({
      data: {
        code,
        initialValue: input.initialValue,
        currentBalance: input.initialValue,
        currency: input.currency ?? 'USD',
        recipientEmail: input.recipientEmail ?? null,
        recipientName: input.recipientName ?? null,
        message: input.message ?? null,
        purchasedBy: input.purchasedBy,
        purchasedById: input.purchasedById,
        expiresAt: input.expiresAt ?? null,
        isActive: true,
      },
    })
  }

  static async activateGiftCard(id: string) {
    return prisma.giftCard.update({
      where: { id },
      data: { activatedAt: new Date() },
    })
  }

  static async getGiftCardByCode(code: string) {
    return prisma.giftCard.findUnique({ where: { code } })
  }

  static async checkGiftCardBalance(code: string) {
    const card = await prisma.giftCard.findUnique({ where: { code } })
    if (!card) throw new Error('Gift card not found')
    if (!card.isActive) throw new Error('Gift card is no longer active')
    if (card.expiresAt && new Date() > card.expiresAt) throw new Error('Gift card has expired')

    return { code: card.code, balance: card.currentBalance, currency: card.currency, expiresAt: card.expiresAt }
  }

  static async redeemGiftCard(input: GiftCardRedemptionInput) {
    const card = await prisma.giftCard.findUnique({ where: { code: input.code } })
    if (!card) throw new Error('Gift card not found')
    if (!card.isActive) throw new Error('Gift card is no longer active')
    if (card.expiresAt && new Date() > card.expiresAt) throw new Error('Gift card has expired')

    const updatedCard = await prisma.giftCard.updateMany({
      where: { id: card.id, currentBalance: { gte: input.amount } },
      data: { currentBalance: { decrement: input.amount } },
    })

    if (updatedCard.count === 0) throw new Error('Insufficient gift card balance')

    const refreshedCard = await prisma.giftCard.findUnique({ where: { id: card.id } })
    if (!refreshedCard) throw new Error('Gift card not found')

    const usage = await prisma.giftCardUsage.create({
      data: {
        giftCardId: card.id,
        orderId: input.orderId,
        userId: input.userId,
        amount: input.amount,
      },
    })

    return { giftCard: refreshedCard, usage, remainingBalance: refreshedCard.currentBalance }
  }

  static async getGiftCardHistory(giftCardId: string) {
    return prisma.giftCardUsage.findMany({
      where: { giftCardId },
      orderBy: { usedAt: 'desc' },
    })
  }

  // ── Loyalty Program ─────────────────────────────────────────

  static async getActiveProgram() {
    return prisma.loyaltyProgram.findFirst({
      where: { isActive: true },
    })
  }

  static async getUserPoints(userId: string) {
    return prisma.userLoyaltyPoints.findUnique({
      where: { userId },
    })
  }

  static async ensureUserLoyaltyRecord(userId: string) {
    const existing = await prisma.userLoyaltyPoints.findUnique({ where: { userId } })
    if (existing) return existing

    return prisma.userLoyaltyPoints.create({
      data: {
        userId,
        totalPoints: 0,
        availablePoints: 0,
        lifetimeEarned: 0,
        lifetimeRedeemed: 0,
      },
    })
  }

  static async earnPoints(input: EarnPointsInput) {
    const program = await CouponService.getActiveProgram()
    if (!program) throw new Error('No active loyalty program')

    const loyaltyRecord = await CouponService.ensureUserLoyaltyRecord(input.userId)

    const expiresAt = program.pointsExpirationMonths
      ? new Date(Date.now() + program.pointsExpirationMonths * 30 * 24 * 60 * 60 * 1000)
      : null

    const [updatedLoyalty, transaction] = await prisma.$transaction([
      prisma.userLoyaltyPoints.update({
        where: { userId: input.userId },
        data: {
          totalPoints: { increment: input.points },
          availablePoints: { increment: input.points },
          lifetimeEarned: { increment: input.points },
          lastEarnedAt: new Date(),
        },
      }),
      prisma.loyaltyPointTransaction.create({
        data: {
          userId: input.userId,
          points: input.points,
          type: input.type,
          description: input.description ?? null,
          orderId: input.orderId ?? null,
          expiresAt,
        },
      }),
    ])

    return { loyaltyPoints: updatedLoyalty, transaction, earned: input.points }
  }

  static async earnPointsFromOrder(userId: string, orderId: string, orderTotal: number) {
    const program = await CouponService.getActiveProgram()
    if (!program) throw new Error('No active loyalty program')

    const points = Math.floor(orderTotal * program.pointsPerDollar)

    if (program.maxPointsPerOrder && points > program.maxPointsPerOrder) {
      return CouponService.earnPoints({
        userId,
        points: program.maxPointsPerOrder,
        type: 'ORDER',
        description: `Points earned from order`,
        orderId,
        expirationMonths: program.pointsExpirationMonths ?? undefined,
      })
    }

    return CouponService.earnPoints({
      userId,
      points,
      type: 'ORDER',
      description: `Points earned from order`,
      orderId,
      expirationMonths: program.pointsExpirationMonths ?? undefined,
    })
  }

  static async redeemPoints(input: RedeemPointsInput) {
    const program = await CouponService.getActiveProgram()
    if (!program) throw new Error('No active loyalty program')

    const loyaltyRecord = await prisma.userLoyaltyPoints.findUnique({
      where: { userId: input.userId },
    })
    if (!loyaltyRecord) throw new Error('No loyalty points record found')
    if (loyaltyRecord.availablePoints < input.points) throw new Error('Insufficient points')
    if (input.points < program.minPointsToRedeem) throw new Error(`Minimum ${program.minPointsToRedeem} points required to redeem`)

    const cashValue = input.points * program.pointsRedemptionRate

    const [updatedLoyalty, transaction] = await prisma.$transaction([
      prisma.userLoyaltyPoints.update({
        where: { userId: input.userId },
        data: {
          totalPoints: { decrement: input.points },
          availablePoints: { decrement: input.points },
          lifetimeRedeemed: { increment: input.points },
          lastRedeemedAt: new Date(),
        },
      }),
      prisma.loyaltyPointTransaction.create({
        data: {
          userId: input.userId,
          points: -input.points,
          type: 'REDEMPTION',
          description: input.description ?? 'Points redeemed',
          orderId: input.orderId ?? null,
        },
      }),
    ])

    return {
      loyaltyPoints: updatedLoyalty,
      transaction,
      redeemed: input.points,
      cashValue: Math.round(cashValue * 100) / 100,
    }
  }

  static async getPointTransactions(userId: string, limit = 50) {
    return prisma.loyaltyPointTransaction.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      take: limit,
    })
  }

  static async expirePoints() {
    const now = new Date()
    const expired = await prisma.loyaltyPointTransaction.findMany({
      where: {
        type: { not: 'REDEMPTION' },
        points: { gt: 0 },
        expiresAt: { lte: now },
      },
    })

    const results = []

    for (const txn of expired) {
      const loyaltyRecord = await prisma.userLoyaltyPoints.findUnique({
        where: { userId: txn.userId },
      })
      if (!loyaltyRecord) continue

      const [updatedLoyalty, expiryTxn] = await prisma.$transaction([
        prisma.userLoyaltyPoints.update({
          where: { userId: txn.userId },
          data: {
            totalPoints: { decrement: txn.points },
            availablePoints: { decrement: txn.points },
          },
        }),
        prisma.loyaltyPointTransaction.create({
          data: {
            userId: txn.userId,
            points: -txn.points,
            type: 'EXPIRATION',
            description: 'Points expired',
          },
        }),
      ])

      results.push({ userId: txn.userId, expiredPoints: txn.points, loyaltyPoints: updatedLoyalty, transaction: expiryTxn })
    }

    return results
  }
}
