export interface RecentlyViewedProduct {
  id: string
  slug: string
  name: string
  priceCents: number
  originalPriceCents?: number | null
  images: string
  averageRating: number
  totalReviews: number
  vendorName: string
}

const STORAGE_KEY = 'recently-viewed-products'
const MAX_ITEMS = 10

export function getRecentlyViewed(): RecentlyViewedProduct[] {
  if (typeof window === 'undefined') return []
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return []
    return JSON.parse(raw) as RecentlyViewedProduct[]
  } catch {
    return []
  }
}

export function addRecentlyViewed(product: RecentlyViewedProduct): void {
  if (typeof window === 'undefined') return
  try {
    const items = getRecentlyViewed().filter((item) => item.id !== product.id)
    items.unshift(product)
    if (items.length > MAX_ITEMS) items.length = MAX_ITEMS
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items))
  } catch {}
}

export function clearRecentlyViewed(): void {
  if (typeof window === 'undefined') return
  try {
    localStorage.removeItem(STORAGE_KEY)
  } catch {}
}
