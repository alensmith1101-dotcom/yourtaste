import { prisma } from '@/lib/prisma'

export interface PersonalizedRecommendation {
  id: string
  slug: string
  name: string
  priceCents: number
  originalPriceCents: number | null
  images: string
  averageRating: number
  totalReviews: number
  vendor: { name: string; slug: string }
  reason: string
}

export async function getPersonalizedRecommendations(
  userId: string,
  limit: number = 8
): Promise<PersonalizedRecommendation[]> {
  const [
    recentOrders,
    wishlistItems,
    browsingEvents,
  ] = await Promise.all([
    prisma.order.findMany({
      where: { userId, paymentStatus: 'PAID' },
      include: {
        items: {
          include: {
            product: {
              select: { id: true, categoryId: true, vendorId: true, priceCents: true, name: true },
            },
          },
          take: 5,
        },
      },
      orderBy: { createdAt: 'desc' },
      take: 10,
    }),
    prisma.wishlistItem.findMany({
      where: { wishlist: { userId } },
      include: {
        product: {
          select: { id: true, categoryId: true, vendorId: true, priceCents: true, name: true },
        },
      },
      orderBy: { createdAt: 'desc' },
      take: 20,
    }),
    prisma.analyticsEvent.findMany({
      where: { userId, type: 'PRODUCT_VIEW' },
      orderBy: { timestamp: 'desc' },
      take: 30,
    }),
  ])

  const purchasedProductIds = new Set<string>()
  const purchasedCategoryIds = new Map<string, number>()
  const purchasedVendorIds = new Map<string, number>()
  const purchasedProductNames: string[] = []

  for (const order of recentOrders) {
    for (const item of order.items) {
      purchasedProductIds.add(item.product.id)
      purchasedProductNames.push(item.product.name)
      if (item.product.categoryId) {
        purchasedCategoryIds.set(
          item.product.categoryId,
          (purchasedCategoryIds.get(item.product.categoryId) || 0) + 1
        )
      }
      purchasedVendorIds.set(
        item.product.vendorId,
        (purchasedVendorIds.get(item.product.vendorId) || 0) + 1
      )
    }
  }

  const wishlistVendorIds = new Map<string, number>()
  const wishlistProductNames: string[] = []
  for (const wi of wishlistItems) {
    wishlistProductNames.push(wi.product.name)
    wishlistVendorIds.set(
      wi.product.vendorId,
      (wishlistVendorIds.get(wi.product.vendorId) || 0) + 1
    )
  }

  const viewedProductIds = new Set<string>()
  const viewedPriceRanges: number[] = []
  const viewedProductNames: string[] = []
  for (const event of browsingEvents) {
    if (event.productId) {
      viewedProductIds.add(event.productId)
    }
  }

  const viewedProducts = viewedProductIds.size > 0
    ? await prisma.product.findMany({
        where: { id: { in: Array.from(viewedProductIds) } },
        select: { id: true, name: true, priceCents: true },
      })
    : []

  for (const vp of viewedProducts) {
    viewedPriceRanges.push(vp.priceCents)
    viewedProductNames.push(vp.name)
  }

  const preferredCategoryIds = Array.from(purchasedCategoryIds.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([id]) => id)

  const avgViewedPrice =
    viewedPriceRanges.length > 0
      ? viewedPriceRanges.reduce((a, b) => a + b, 0) / viewedPriceRanges.length
      : null

  const excludeIds = new Set([
    ...purchasedProductIds,
    ...wishlistItems.map((wi) => wi.product.id),
  ])

  const candidates = await prisma.product.findMany({
    where: {
      isActive: true,
      isPublished: true,
      id: { notIn: Array.from(excludeIds) },
      OR: [
        ...(preferredCategoryIds.length > 0
          ? [{ categoryId: { in: preferredCategoryIds } }]
          : []),
        ...(Array.from(wishlistVendorIds.keys()).length > 0
          ? [{ vendorId: { in: Array.from(wishlistVendorIds.keys()) } }]
          : []),
        ...(preferredCategoryIds.length > 0
          ? [{ categoryId: { in: preferredCategoryIds } }]
          : []),
      ],
    },
    include: {
      vendor: { select: { id: true, name: true, slug: true } },
      category: { select: { id: true, name: true } },
    },
    take: 100,
  })

  const scored = candidates.map((candidate) => {
    let score = 0
    let reason = ''

    const categoryWeight = 0.4
    const vendorWeight = 0.3
    const priceWeight = 0.2
    const trendingWeight = 0.1

    if (candidate.categoryId && purchasedCategoryIds.has(candidate.categoryId)) {
      const catCount = purchasedCategoryIds.get(candidate.categoryId) || 0
      score += categoryWeight * Math.min(catCount * 25, 100)
      const purchasedInCat = purchasedProductNames.find((_, i) => {
        const order = recentOrders[i]
        return order?.items.some((item) => item.product.categoryId === candidate.categoryId)
      })
      reason = `Because you purchased "${purchasedInCat || 'a similar item'}"`
    }

    if (wishlistVendorIds.has(candidate.vendorId)) {
      const vendorCount = wishlistVendorIds.get(candidate.vendorId) || 0
      score += vendorWeight * Math.min(vendorCount * 30, 100)
      if (!reason) {
        const wishFromVendor = wishlistProductNames.find((_, i) => {
          const wi = wishlistItems[i]
          return wi?.product.vendorId === candidate.vendorId
        })
        reason = `Because you wishlisted items from ${candidate.vendor.name}`
      }
    }

    if (avgViewedPrice !== null) {
      const priceDiff = Math.abs(candidate.priceCents - avgViewedPrice)
      const priceSimilarity = Math.max(0, 100 - (priceDiff / Math.max(avgViewedPrice, 1)) * 100)
      score += priceWeight * priceSimilarity
      if (!reason) {
        reason = `Because you viewed similar priced items`
      }
    }

    if (preferredCategoryIds.includes(candidate.categoryId || '')) {
      score += trendingWeight * 50
      if (!reason) {
        reason = `Trending in ${candidate.category?.name || 'your preferred categories'}`
      }
    }

    if (!reason) {
      reason = 'Recommended for you'
    }

    return { product: candidate, score, reason }
  })

  scored.sort((a, b) => b.score - a.score)

  return scored.slice(0, limit).map(({ product, reason }) => ({
    id: product.id,
    slug: product.slug,
    name: product.name,
    priceCents: product.priceCents,
    originalPriceCents: product.originalPriceCents,
    images: product.images,
    averageRating: product.averageRating,
    totalReviews: product.totalReviews,
    vendor: product.vendor,
    reason,
  }))
}

export class RecommendationService {
  static async getProductRecommendations(
    productId: string,
    limit: number = 10
  ): Promise<any[]> {
    const recommendations = await prisma.productRecommendation.findMany({
      where: { sourceProductId: productId },
      include: {
        targetProduct: {
          include: {
            vendor: { select: { id: true, name: true, slug: true } },
          },
        },
      },
      orderBy: { score: 'desc' },
      take: limit,
    })

    return recommendations.map((r) => ({
      ...r.targetProduct,
      recommendationType: r.type,
      score: r.score,
    }))
  }

  static async getTrendingProducts(limit: number = 10): Promise<any[]> {
    const trending = await prisma.trendingProduct.findMany({
      where: { period: '7d' },
      orderBy: { score: 'desc' },
      take: limit,
    })

    const productIds = trending.map((t) => t.productId)
    const products = productIds.length > 0
      ? await prisma.product.findMany({
          where: { id: { in: productIds } },
          include: {
            vendor: { select: { id: true, name: true, slug: true } },
          },
        })
      : []

    const productMap = new Map(products.map((p) => [p.id, p]))

    return trending.map((t) => ({
      ...productMap.get(t.productId),
      trendingScore: t.score,
    }))
  }

  static async updateTrendingProducts(): Promise<void> {
    const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)

    const productInteractions = await prisma.productInteraction.groupBy({
      by: ['productId'],
      where: {
        createdAt: { gte: sevenDaysAgo },
      },
      _count: { id: true },
      orderBy: { _count: { id: 'desc' } },
      take: 50,
    })

    const maxCount = productInteractions[0]?._count.id || 1

    await prisma.$transaction(
      productInteractions.map((pi) => {
        const score = (pi._count.id / maxCount) * 100
        return prisma.trendingProduct.upsert({
          where: {
            productId_period: {
              productId: pi.productId,
              period: '7d',
            },
          },
          update: { score, updatedAt: new Date() },
          create: {
            productId: pi.productId,
            score,
            period: '7d',
          },
        })
      })
    )
  }

  static async trackInteraction(
    productId: string,
    type: 'view' | 'add_to_cart' | 'purchase',
    userId?: string,
    sessionId?: string
  ): Promise<void> {
    await prisma.productInteraction.create({
      data: {
        productId,
        type,
        userId: userId || null,
        sessionId: sessionId || null,
      },
    })
  }

  static async generateRecommendations(productId: string): Promise<void> {
    const product = await prisma.product.findUnique({
      where: { id: productId },
      include: {
        category: true,
        vendor: true,
      },
    })

    if (!product) return

    const candidates = await prisma.product.findMany({
      where: {
        id: { not: productId },
        isActive: true,
        isPublished: true,
        OR: [
          { categoryId: product.categoryId },
          { vendorId: product.vendorId },
        ],
      },
      take: 50,
    })

    const recentOrders = await prisma.orderItem.findMany({
      where: {
        order: {
          userId: productId ? undefined : undefined,
          paymentStatus: 'PAID',
          createdAt: { gte: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000) },
        },
      },
      select: { orderId: true, productId: true },
      take: 200,
    })

    const coPurchased = new Map<string, number>()
    const sourceOrders = new Set(
      recentOrders.filter(i => i.productId === productId).map(i => i.orderId)
    )
    for (const item of recentOrders) {
      if (sourceOrders.has(item.orderId) && item.productId !== productId) {
        coPurchased.set(item.productId, (coPurchased.get(item.productId) || 0) + 1)
      }
    }

    const userId: string | undefined = undefined
    const viewedIds = userId
      ? (await prisma.analyticsEvent.findMany({
          where: { userId, type: 'PRODUCT_VIEW' },
          select: { productId: true },
          orderBy: { timestamp: 'desc' },
          take: 20,
        })).map(e => e.productId).filter(Boolean) as string[]
      : []

    const scored = candidates.map((candidate) => {
      let score = 0

      if (candidate.categoryId === product.categoryId) score += 50
      if (candidate.vendorId === product.vendorId) score += 30

      const priceDiff = Math.abs(candidate.priceCents - product.priceCents)
      const priceSimilarity = Math.max(0, 100 - (product.priceCents > 0 ? priceDiff / product.priceCents : 0) * 100)
      score += priceSimilarity * 0.2

      const coScore = coPurchased.get(candidate.id) || 0
      score += coScore * 40

      if (viewedIds.includes(candidate.id)) {
        score += 15
      }

      return { productId: candidate.id, score }
    })

    scored.sort((a, b) => b.score - a.score)

    await prisma.$transaction([
      prisma.productRecommendation.deleteMany({
        where: { sourceProductId: productId },
      }),
      ...(scored.length > 0
        ? [
            prisma.productRecommendation.createMany({
              data: scored.slice(0, 10).map((s) => ({
                sourceProductId: productId,
                targetProductId: s.productId,
                type: 'similar' as const,
                score: s.score,
              })),
            }),
          ]
        : []),
    ])
  }
}
