export interface CsvProductRow {
  name: string
  description: string
  price: number
  originalPrice: number | null
  category: string
  sku: string
  stockQuantity: number
  images: string[]
}

export interface CsvParseResult {
  data: CsvProductRow[]
  errors: CsvParseError[]
}

export interface CsvParseError {
  row: number
  message: string
}

export const CSV_TEMPLATE = `name,description,price,originalPrice,category,sku,stockQuantity,images
"Wireless Headphones","Noise-cancelling bluetooth headphones",4999,6999,"Electronics","WH-001",100,"https://example.com/img1.jpg,https://example.com/img2.jpg"
"Cotton T-Shirt","Comfortable cotton t-shirt",999,1499,"Clothing","TS-001",250,"https://example.com/img3.jpg"
`

function parseCsvLine(line: string): string[] {
  const fields: string[] = []
  let current = ""
  let inQuotes = false

  for (let i = 0; i < line.length; i++) {
    const char = line[i]

    if (inQuotes) {
      if (char === '"') {
        if (i + 1 < line.length && line[i + 1] === '"') {
          current += '"'
          i++
        } else {
          inQuotes = false
        }
      } else {
        current += char
      }
    } else {
      if (char === '"') {
        inQuotes = true
      } else if (char === ',') {
        fields.push(current)
        current = ""
      } else {
        current += char
      }
    }
  }

  fields.push(current)
  return fields
}

function parseImagesField(value: string): string[] {
  if (!value || !value.trim()) return []
  return value
    .split(",")
    .map((url) => url.trim())
    .filter((url) => url.length > 0)
}

export function parseCsv(text: string): CsvParseResult {
  const data: CsvProductRow[] = []
  const errors: CsvParseError[] = []

  const lines = text
    .replace(/\r\n/g, "\n")
    .replace(/\r/g, "\n")
    .split("\n")
    .filter((line) => line.trim().length > 0)

  if (lines.length < 2) {
    return { data: [], errors: [{ row: 0, message: "CSV file is empty or has no data rows" }] }
  }

  const headerLine = lines[0]
  const headers = parseCsvLine(headerLine).map((h) => h.trim().toLowerCase())

  const requiredHeaders = ["name", "description", "price", "sku", "stockquantity"]
  for (const required of requiredHeaders) {
    if (!headers.includes(required)) {
      return {
        data: [],
        errors: [{ row: 1, message: `Missing required column: "${required}". Found columns: ${headers.join(", ")}` }],
      }
    }
  }

  const colIndex: Record<string, number> = {}
  headers.forEach((h, i) => {
    colIndex[h] = i
  })

  for (let i = 1; i < lines.length; i++) {
    const rowNumber = i + 1
    const line = lines[i]

    if (!line.trim()) continue

    const fields = parseCsvLine(line)
    const get = (col: string): string => {
      const idx = colIndex[col]
      if (idx === undefined || idx >= fields.length) return ""
      return fields[idx]?.trim() ?? ""
    }

    const name = get("name")
    const description = get("description")
    const priceStr = get("price")
    const originalPriceStr = get("originalprice")
    const category = get("category")
    const sku = get("sku")
    const stockStr = get("stockquantity")
    const imagesStr = get("images")

    const rowErrors: string[] = []

    if (!name) rowErrors.push("name is required")

    const price = parseFloat(priceStr)
    if (!priceStr || isNaN(price) || price < 0) {
      rowErrors.push("price must be a non-negative number")
    }

    let originalPrice: number | null = null
    if (originalPriceStr) {
      const parsed = parseFloat(originalPriceStr)
      if (isNaN(parsed) || parsed < 0) {
        rowErrors.push("originalPrice must be a non-negative number")
      } else {
        originalPrice = parsed
      }
    }

    if (!sku) rowErrors.push("sku is required")

    const stockQuantity = parseInt(stockStr, 10)
    if (!stockStr || isNaN(stockQuantity) || stockQuantity < 0) {
      rowErrors.push("stockQuantity must be a non-negative integer")
    }

    const images = parseImagesField(imagesStr)

    if (rowErrors.length > 0) {
      errors.push({ row: rowNumber, message: rowErrors.join("; ") })
      continue
    }

    data.push({
      name,
      description,
      price: Math.round(price * 100),
      originalPrice: originalPrice !== null ? Math.round(originalPrice * 100) : null,
      category,
      sku,
      stockQuantity,
      images,
    })
  }

  return { data, errors }
}
