import { cookies } from 'next/headers'
import { randomBytes } from 'crypto'

export const AFFILIATE_COOKIE_NAME = 'yt_ref'
export const AFFILIATE_COOKIE_MAX_AGE = 30 * 24 * 60 * 60
export const DEFAULT_COMMISSION_RATE = 0.05
export const MIN_PAYOUT_CENTS = 100000

export function generateAffiliateCode(): string {
  return randomBytes(4).toString('hex').toUpperCase()
}

export function getAffiliateCodeFromCookie(): string | null {
  const cookieStore = cookies()
  return cookieStore.get(AFFILIATE_COOKIE_NAME)?.value ?? null
}

export function calculateCommission(orderTotalCents: number, rate: number = DEFAULT_COMMISSION_RATE): number {
  return Math.round(orderTotalCents * rate)
}

export function formatCommission(cents: number): string {
  return `₹${(cents / 100).toFixed(2)}`
}
