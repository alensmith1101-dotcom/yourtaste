import nodemailer from 'nodemailer';
import type { Transporter } from 'nodemailer';
import { escapeHtml, sanitizeUrl } from '@/lib/utils';

const SITE_URL = process.env.NEXT_PUBLIC_APP_URL || 'https://yourtaste.com';
const SMTP_HOST = process.env.SMTP_HOST ?? 'localhost';
const SMTP_PORT = parseInt(process.env.SMTP_PORT ?? '587', 10);
const SMTP_USER = process.env.SMTP_USER ?? '';
const SMTP_PASS = process.env.SMTP_PASS ?? '';
const EMAIL_FROM = process.env.EMAIL_FROM ?? 'noreply@yourtaste.com';

let transporterInstance: Transporter | null = null;

function getTransporter(): Transporter {
  if (!transporterInstance) {
    transporterInstance = nodemailer.createTransport({
      host: SMTP_HOST,
      port: SMTP_PORT,
      secure: SMTP_PORT === 465,
      auth: SMTP_USER && SMTP_PASS ? { user: SMTP_USER, pass: SMTP_PASS } : undefined,
    });
  }
  return transporterInstance;
}

export interface SendEmailOptions {
  to: string | string[];
  subject: string;
  html?: string;
  text?: string;
  from?: string;
  replyTo?: string;
  cc?: string | string[];
  bcc?: string | string[];
  attachments?: Array<{
    filename: string;
    content: string | Buffer;
    contentType?: string;
  }>;
}

export interface SendEmailResult {
  messageId: string;
  accepted: string[];
  rejected: string[];
}

export async function sendEmail(options: SendEmailOptions): Promise<SendEmailResult> {
  const transporter = getTransporter();

  const mailOptions: nodemailer.SendMailOptions = {
    from: options.from ?? EMAIL_FROM,
    to: Array.isArray(options.to) ? options.to.join(', ') : options.to,
    subject: options.subject,
    html: options.html,
    text: options.text,
    replyTo: options.replyTo,
    cc: options.cc,
    bcc: options.bcc,
    attachments: options.attachments,
  };

  const info = await transporter.sendMail(mailOptions);

  return {
    messageId: info.messageId,
    accepted: info.accepted.map((a: string) => a.toString()),
    rejected: info.rejected.map((r: string) => r.toString()),
  };
}

export interface BulkEmailEntry {
  to: string;
  subject: string;
  html?: string;
  text?: string;
}

export interface BulkEmailOptions {
  emails: BulkEmailEntry[];
  from?: string;
  rateLimit?: number;
  rateLimitInterval?: number;
  onProgress?: (sent: number, total: number, failed: number) => void;
}

export interface BulkEmailResult {
  total: number;
  sent: number;
  failed: number;
  errors: Array<{ to: string; error: string }>;
}

export async function sendBulkEmails(options: BulkEmailOptions): Promise<BulkEmailResult> {
  const { emails, from, rateLimit = 10, rateLimitInterval = 1000, onProgress } = options;

  const result: BulkEmailResult = { total: emails.length, sent: 0, failed: 0, errors: [] };

  for (let i = 0; i < emails.length; i += rateLimit) {
    const batch = emails.slice(i, i + rateLimit);

    const batchResults = await Promise.allSettled(
      batch.map(async (email) => {
        return sendEmail({
          to: email.to,
          subject: email.subject,
          html: email.html,
          text: email.text,
          from,
        });
      }),
    );

    for (let j = 0; j < batchResults.length; j++) {
      const r = batchResults[j];
      if (r.status === 'fulfilled') {
        result.sent++;
      } else {
        result.failed++;
        result.errors.push({ to: batch[j].to, error: r.reason?.message ?? 'Unknown error' });
      }
    }

    onProgress?.(result.sent, result.total, result.failed);

    if (i + rateLimit < emails.length) {
      await new Promise((resolve) => setTimeout(resolve, rateLimitInterval));
    }
  }

  return result;
}

export async function testEmailConnection(): Promise<{ success: boolean; message: string }> {
  try {
    const transporter = getTransporter();
    await transporter.verify();
    return { success: true, message: 'SMTP connection verified successfully' };
  } catch (error) {
    return {
      success: false,
      message: error instanceof Error ? error.message : 'SMTP connection failed',
    };
  }
}

function baseTemplate(innerHtml: string, title: string): string {
  const safeTitle = escapeHtml(title);
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${safeTitle}</title>
</head>
<body style="margin:0;padding:0;background-color:#f4f4f7;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:#f4f4f7;padding:40px 0;">
    <tr>
      <td align="center">
        <table role="presentation" width="600" cellpadding="0" cellspacing="0" style="background-color:#ffffff;border-radius:8px;overflow:hidden;box-shadow:0 2px 4px rgba(0,0,0,0.1);">
          <tr>
            <td style="background-color:#1a1a2e;padding:24px 40px;text-align:center;">
              <h1 style="margin:0;color:#ffffff;font-size:24px;font-weight:700;letter-spacing:0.5px;">YourTaste</h1>
            </td>
          </tr>
          <tr>
            <td style="padding:40px;">
              ${innerHtml}
            </td>
          </tr>
          <tr>
            <td style="background-color:#f4f4f7;padding:24px 40px;text-align:center;border-top:1px solid #e4e4e7;">
              <p style="margin:0;color:#71717a;font-size:12px;">&copy; ${new Date().getFullYear()} YourTaste. All rights reserved.</p>
              <p style="margin:8px 0 0;color:#a1a1aa;font-size:11px;">You received this email because you have an account on YourTaste.</p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;
}

export interface WelcomeTemplateData {
  userName: string;
  email: string;
  storeUrl?: string;
}

export function welcomeEmailTemplate(data: WelcomeTemplateData): { html: string; text: string; subject: string } {
  const storeUrl = sanitizeUrl(data.storeUrl ?? SITE_URL);
  const safeName = escapeHtml(data.userName);
  const safeEmail = escapeHtml(data.email);

  const html = baseTemplate(
    `<h2 style="margin:0 0 16px;color:#18181b;font-size:22px;">Welcome to YourTaste, ${safeName}!</h2>
    <p style="margin:0 0 16px;color:#3f3f46;font-size:15px;line-height:1.6;">We're thrilled to have you on board. Your account has been created successfully with the email <strong>${safeEmail}</strong>.</p>
    <p style="margin:0 0 24px;color:#3f3f46;font-size:15px;line-height:1.6;">Start exploring thousands of products from amazing vendors and discover your next favorite thing.</p>
    <table role="presentation" cellpadding="0" cellspacing="0" style="margin:0 auto;">
      <tr>
        <td style="background-color:#6366f1;border-radius:6px;padding:12px 32px;">
          <a href="${escapeHtml(storeUrl)}" style="color:#ffffff;text-decoration:none;font-size:15px;font-weight:600;display:inline-block;">Start Shopping</a>
        </td>
      </tr>
    </table>`,
    'Welcome to YourTaste',
  );

  const text = `Welcome to YourTaste, ${data.userName}!\n\nWe're thrilled to have you on board. Your account has been created with ${data.email}.\n\nStart exploring at ${storeUrl}\n\n© ${new Date().getFullYear()} YourTaste. All rights reserved.`;

  return { html, text, subject: 'Welcome to YourTaste!' };
}

export interface OrderItemData {
  name: string;
  quantity: number;
  price: string;
}

export interface OrderConfirmationTemplateData {
  userName: string;
  orderNumber: string;
  orderDate: string;
  items: OrderItemData[];
  subtotal: string;
  tax: string;
  shipping: string;
  total: string;
  shippingAddress: string;
  orderUrl?: string;
}

export function orderConfirmationTemplate(data: OrderConfirmationTemplateData): { html: string; text: string; subject: string } {
  const orderUrl = sanitizeUrl(data.orderUrl ?? `${SITE_URL}/orders/${encodeURIComponent(data.orderNumber)}`);
  const safeName = escapeHtml(data.userName);
  const safeOrderNumber = escapeHtml(data.orderNumber);
  const safeOrderDate = escapeHtml(data.orderDate);
  const safeSubtotal = escapeHtml(data.subtotal);
  const safeTax = escapeHtml(data.tax);
  const safeShipping = escapeHtml(data.shipping);
  const safeTotal = escapeHtml(data.total);
  const safeShippingAddress = escapeHtml(data.shippingAddress);

  const itemRows = data.items
    .map(
      (item) =>
        `<tr>
          <td style="padding:12px 0;border-bottom:1px solid #e4e4e7;color:#3f3f46;font-size:14px;">${escapeHtml(item.name)} &times; ${item.quantity}</td>
          <td style="padding:12px 0;border-bottom:1px solid #e4e4e7;color:#3f3f46;font-size:14px;text-align:right;">${escapeHtml(item.price)}</td>
        </tr>`,
    )
    .join('');

  const html = baseTemplate(
    `<h2 style="margin:0 0 8px;color:#18181b;font-size:22px;">Order Confirmed!</h2>
    <p style="margin:0 0 24px;color:#3f3f46;font-size:15px;">Thank you, ${safeName}. Your order <strong>#${safeOrderNumber}</strong> has been placed on ${safeOrderDate}.</p>
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:24px;">
      ${itemRows}
    </table>
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:24px;">
      <tr><td style="padding:4px 0;color:#71717a;font-size:14px;">Subtotal</td><td style="padding:4px 0;color:#3f3f46;font-size:14px;text-align:right;">${safeSubtotal}</td></tr>
      <tr><td style="padding:4px 0;color:#71717a;font-size:14px;">Tax</td><td style="padding:4px 0;color:#3f3f46;font-size:14px;text-align:right;">${safeTax}</td></tr>
      <tr><td style="padding:4px 0;color:#71717a;font-size:14px;">Shipping</td><td style="padding:4px 0;color:#3f3f46;font-size:14px;text-align:right;">${safeShipping}</td></tr>
      <tr><td style="padding:8px 0 0;border-top:2px solid #18181b;color:#18181b;font-size:16px;font-weight:700;">Total</td><td style="padding:8px 0 0;border-top:2px solid #18181b;color:#18181b;font-size:16px;font-weight:700;text-align:right;">${safeTotal}</td></tr>
    </table>
    <div style="background-color:#f4f4f7;border-radius:6px;padding:16px;margin-bottom:24px;">
      <p style="margin:0 0 4px;color:#71717a;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">Shipping Address</p>
      <p style="margin:0;color:#3f3f46;font-size:14px;line-height:1.5;">${safeShippingAddress}</p>
    </div>
    <table role="presentation" cellpadding="0" cellspacing="0" style="margin:0 auto;">
      <tr>
        <td style="background-color:#6366f1;border-radius:6px;padding:12px 32px;">
          <a href="${escapeHtml(orderUrl)}" style="color:#ffffff;text-decoration:none;font-size:15px;font-weight:600;display:inline-block;">Track Order</a>
        </td>
      </tr>
    </table>`,
    `Order #${data.orderNumber} Confirmed`,
  );

  const itemList = data.items.map((i) => `  - ${i.name} x${i.quantity}: ${i.price}`).join('\n');
  const text = `Order Confirmed!\n\nHi ${data.userName}, your order #${data.orderNumber} has been placed on ${data.orderDate}.\n\nItems:\n${itemList}\n\nSubtotal: ${data.subtotal}\nTax: ${data.tax}\nShipping: ${data.shipping}\nTotal: ${data.total}\n\nShipping Address: ${data.shippingAddress}\n\nTrack your order: ${orderUrl}\n\n© ${new Date().getFullYear()} YourTaste. All rights reserved.`;

  return { html, text, subject: `Order #${data.orderNumber} Confirmed` };
}

export interface ShippingNotificationTemplateData {
  userName: string;
  orderNumber: string;
  carrier: string;
  trackingNumber: string;
  estimatedDelivery: string;
  trackingUrl?: string;
}

export function shippingNotificationTemplate(data: ShippingNotificationTemplateData): { html: string; text: string; subject: string } {
  const trackingUrl = sanitizeUrl(data.trackingUrl ?? `${SITE_URL}/track/${encodeURIComponent(data.trackingNumber)}`);
  const safeName = escapeHtml(data.userName);
  const safeOrderNumber = escapeHtml(data.orderNumber);
  const safeCarrier = escapeHtml(data.carrier);
  const safeTrackingNumber = escapeHtml(data.trackingNumber);
  const safeEstimatedDelivery = escapeHtml(data.estimatedDelivery);

  const html = baseTemplate(
    `<h2 style="margin:0 0 16px;color:#18181b;font-size:22px;">Your Order Has Shipped!</h2>
    <p style="margin:0 0 24px;color:#3f3f46;font-size:15px;line-height:1.6;">Hi ${safeName}, great news! Your order <strong>#${safeOrderNumber}</strong> is on its way.</p>
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:#f4f4f7;border-radius:6px;padding:16px;margin-bottom:24px;">
      <tr>
        <td style="padding:8px 0;">
          <p style="margin:0 0 4px;color:#71717a;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">Carrier</p>
          <p style="margin:0;color:#3f3f46;font-size:15px;font-weight:600;">${safeCarrier}</p>
        </td>
      </tr>
      <tr>
        <td style="padding:8px 0;">
          <p style="margin:0 0 4px;color:#71717a;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">Tracking Number</p>
          <p style="margin:0;color:#3f3f46;font-size:15px;font-weight:600;">${safeTrackingNumber}</p>
        </td>
      </tr>
      <tr>
        <td style="padding:8px 0;">
          <p style="margin:0 0 4px;color:#71717a;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">Estimated Delivery</p>
          <p style="margin:0;color:#3f3f46;font-size:15px;font-weight:600;">${safeEstimatedDelivery}</p>
        </td>
      </tr>
    </table>
    <table role="presentation" cellpadding="0" cellspacing="0" style="margin:0 auto;">
      <tr>
        <td style="background-color:#6366f1;border-radius:6px;padding:12px 32px;">
          <a href="${escapeHtml(trackingUrl)}" style="color:#ffffff;text-decoration:none;font-size:15px;font-weight:600;display:inline-block;">Track Package</a>
        </td>
      </tr>
    </table>`,
    'Your Order Has Shipped',
  );

  const text = `Your Order Has Shipped!\n\nHi ${data.userName}, your order #${data.orderNumber} is on its way.\n\nCarrier: ${data.carrier}\nTracking Number: ${data.trackingNumber}\nEstimated Delivery: ${data.estimatedDelivery}\n\nTrack your package: ${trackingUrl}\n\n© ${new Date().getFullYear()} YourTaste. All rights reserved.`;

  return { html, text, subject: `Order #${data.orderNumber} Has Shipped` };
}

export interface PasswordResetTemplateData {
  userName: string;
  resetUrl: string;
  expiryMinutes?: number;
}

export function passwordResetTemplate(data: PasswordResetTemplateData): { html: string; text: string; subject: string } {
  const expiry = data.expiryMinutes ?? 60;
  const resetUrl = sanitizeUrl(data.resetUrl);
  const safeName = escapeHtml(data.userName);

  const html = baseTemplate(
    `<h2 style="margin:0 0 16px;color:#18181b;font-size:22px;">Reset Your Password</h2>
    <p style="margin:0 0 16px;color:#3f3f46;font-size:15px;line-height:1.6;">Hi ${safeName}, we received a request to reset the password for your account.</p>
    <p style="margin:0 0 24px;color:#3f3f46;font-size:15px;line-height:1.6;">Click the button below to choose a new password. This link will expire in <strong>${expiry} minutes</strong>.</p>
    <table role="presentation" cellpadding="0" cellspacing="0" style="margin:0 auto 24px;">
      <tr>
        <td style="background-color:#6366f1;border-radius:6px;padding:12px 32px;">
          <a href="${escapeHtml(resetUrl)}" style="color:#ffffff;text-decoration:none;font-size:15px;font-weight:600;display:inline-block;">Reset Password</a>
        </td>
      </tr>
    </table>
    <p style="margin:0 0 8px;color:#71717a;font-size:13px;line-height:1.5;">If you didn't request a password reset, you can safely ignore this email. Your password will remain unchanged.</p>
    <p style="margin:0;color:#71717a;font-size:13px;line-height:1.5;">For security, this link can only be used once.</p>`,
    'Reset Your Password',
  );

  const text = `Reset Your Password\n\nHi ${data.userName}, we received a request to reset the password for your account.\n\nClick the link below to choose a new password. This link will expire in ${expiry} minutes.\n\n${resetUrl}\n\nIf you didn't request a password reset, you can safely ignore this email. Your password will remain unchanged.\n\nFor security, this link can only be used once.\n\n© ${new Date().getFullYear()} YourTaste. All rights reserved.`;

  return { html, text, subject: 'Reset Your YourTaste Password' };
}
