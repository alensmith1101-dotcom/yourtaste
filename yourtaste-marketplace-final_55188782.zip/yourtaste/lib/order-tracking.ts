import { randomBytes } from 'crypto'
import { prisma } from '@/lib/prisma'

type CarrierType = 'FEDEX' | 'UPS' | 'USPS' | 'DHL' | 'AMAZON' | 'LOCAL_COURIER'
type ShipmentType = 'STANDARD' | 'EXPRESS' | 'OVERNIGHT' | 'PICKUP' | 'DIGITAL'
type ShipmentStatus =
  | 'CREATED'
  | 'LABEL_GENERATED'
  | 'PICKED_UP'
  | 'IN_TRANSIT'
  | 'OUT_FOR_DELIVERY'
  | 'DELIVERED'
  | 'FAILED_DELIVERY'
  | 'EXCEPTION'
  | 'RETURNED'
  | 'CANCELLED'

type TrackingStatus =
  | 'LABEL_CREATED'
  | 'PICKED_UP'
  | 'IN_TRANSIT'
  | 'ARRIVED_AT_FACILITY'
  | 'DEPARTED_FACILITY'
  | 'OUT_FOR_DELIVERY'
  | 'DELIVERED'
  | 'DELIVERY_ATTEMPT_FAILED'
  | 'EXCEPTION'
  | 'RETURNED_TO_SENDER'
  | 'AVAILABLE_FOR_PICKUP'

type DeliveryConfirmationMethod = 'SIGNATURE' | 'PHOTO' | 'GPS' | 'SELF_REPORTED'
type ExceptionType =
  | 'WEATHER_DELAY'
  | 'ADDRESS_ISSUE'
  | 'CUSTOMS_HOLD'
  | 'DAMAGED'
  | 'LOST'
  | 'REFUSED'
  | 'UNDELIVERABLE'
  | 'NO_ACCESS'
  | 'INCORRECT_LABEL'
  | 'OTHER'

interface ShipmentItemInput {
  productId: string
  name: string
  sku?: string
  quantity: number
  weight?: number
  value?: number
}

interface CreateShipmentInput {
  orderId: string
  vendorId?: string
  carrierType: CarrierType
  carrierName?: string
  shippingMethod: string
  shipmentType?: ShipmentType
  shippingCost?: number
  weight?: number
  dimensions?: { length: number; width: number; height: number; unit: string }
  fromAddress: string
  toAddress: string
  returnAddress?: string
  items: ShipmentItemInput[]
  specialInstructions?: string
  signatureRequired?: boolean
  insuranceAmount?: number
}

interface AddTrackingEventInput {
  shipmentId: string
  vendorId?: string
  userId?: string
  status: TrackingStatus
  location?: string
  locationCode?: string
  coordinates?: { lat: number; lng: number }
  description: string
  eventTime?: Date
  timezone?: string
  source?: string
  carrierEventCode?: string
  carrierDescription?: string
  isException?: boolean
  exceptionType?: ExceptionType
}

interface ConfirmDeliveryInput {
  shipmentId: string
  orderId: string
  userId: string
  vendorId?: string
  deliveredAt: Date
  deliveryLocation?: string
  recipientName?: string
  signatureImage?: string
  deliveryPhoto?: string
  confirmationMethod: DeliveryConfirmationMethod
  gpsCoordinates?: { lat: number; lng: number }
}

interface CreateShippingLabelInput {
  shipmentId: string
  trackingNumber: string
  carrier: string
  labelUrl?: string
  labelData?: string
}

function generateShipmentNumber(): string {
  const prefix = 'SHP'
  const timestamp = Date.now().toString(36).toUpperCase()
  const random = randomBytes(4).toString('hex').toUpperCase().slice(0, 6)
  return `${prefix}-${timestamp}-${random}`
}

function generateTrackingNumber(carrier: CarrierType): string {
  const formats: Record<CarrierType, { prefix: string; length: number }> = {
    FEDEX: { prefix: 'FX', length: 12 },
    UPS: { prefix: '1Z', length: 16 },
    USPS: { prefix: '94', length: 22 },
    DHL: { prefix: 'DHL', length: 10 },
    AMAZON: { prefix: 'TBA', length: 15 },
    LOCAL_COURIER: { prefix: 'LC', length: 10 },
  }

  const format = formats[carrier]
  const remaining = format.length - format.prefix.length
  const random = randomBytes(Math.ceil(remaining / 2)).toString('hex').toUpperCase().slice(0, remaining)
  return format.prefix + random
}

export class OrderTrackingService {
  static async createShipment(input: CreateShipmentInput) {
    const order = await prisma.order.findUnique({
      where: { id: input.orderId },
    })
    if (!order) throw new Error('Order not found')

    const shipmentNumber = generateShipmentNumber()

    let totalItems = 0
    let totalValue = 0
    for (const item of input.items) {
      totalItems += item.quantity
      totalValue += (item.value ?? 0) * item.quantity
    }

    const shipment = await prisma.shipment.create({
      data: {
        orderId: input.orderId,
        vendorId: input.vendorId ?? null,
        shipmentNumber,
        carrierType: input.carrierType,
        carrierName: input.carrierName ?? null,
        shippingMethod: input.shippingMethod,
        shipmentType: input.shipmentType ?? 'STANDARD',
        shippingCost: input.shippingCost ?? 0,
        weight: input.weight ?? null,
        dimensions: input.dimensions ? JSON.stringify(input.dimensions) : null,
        fromAddress: input.fromAddress,
        toAddress: input.toAddress,
        returnAddress: input.returnAddress ?? null,
        items: JSON.stringify(input.items),
        totalItems,
        totalValue,
        specialInstructions: input.specialInstructions ?? null,
        signatureRequired: input.signatureRequired ?? false,
        insuranceAmount: input.insuranceAmount ?? null,
        status: 'CREATED',
      },
    })

    await prisma.orderTracking.create({
      data: {
        orderId: input.orderId,
        status: 'CREATED',
        title: 'Shipment Created',
        description: `Shipment ${shipmentNumber} has been created for your order.`,
      },
    })

    return shipment
  }

  static async generateShippingLabel(input: CreateShippingLabelInput) {
    const shipment = await prisma.shipment.findUnique({
      where: { id: input.shipmentId },
    })
    if (!shipment) throw new Error('Shipment not found')

    const label = await prisma.shippingLabel.create({
      data: {
        shipmentId: input.shipmentId,
        trackingNumber: input.trackingNumber,
        carrier: input.carrier,
        labelUrl: input.labelUrl ?? null,
        labelData: input.labelData ?? null,
        status: 'GENERATED',
      },
    })

    await prisma.shipment.update({
      where: { id: input.shipmentId },
      data: { status: 'LABEL_GENERATED' },
    })

    return label
  }

  static async generateLabelWithTracking(shipmentId: string, carrier: string, labelUrl?: string) {
    const shipment = await prisma.shipment.findUnique({
      where: { id: shipmentId },
    })
    if (!shipment) throw new Error('Shipment not found')

    const trackingNumber = generateTrackingNumber(shipment.carrierType as CarrierType)

    return OrderTrackingService.generateShippingLabel({
      shipmentId,
      trackingNumber,
      carrier,
      labelUrl,
    })
  }

  static async addTrackingEvent(input: AddTrackingEventInput) {
    const shipment = await prisma.shipment.findUnique({
      where: { id: input.shipmentId },
    })
    if (!shipment) throw new Error('Shipment not found')
    if (input.vendorId && shipment.vendorId && shipment.vendorId !== input.vendorId) {
      throw new Error('Not authorized to modify this shipment')
    }

    const statusMap: Record<string, ShipmentStatus> = {
      LABEL_CREATED: 'LABEL_GENERATED',
      PICKED_UP: 'PICKED_UP',
      IN_TRANSIT: 'IN_TRANSIT',
      ARRIVED_AT_FACILITY: 'IN_TRANSIT',
      DEPARTED_FACILITY: 'IN_TRANSIT',
      OUT_FOR_DELIVERY: 'OUT_FOR_DELIVERY',
      DELIVERED: 'DELIVERED',
      DELIVERY_ATTEMPT_FAILED: 'FAILED_DELIVERY',
      EXCEPTION: 'EXCEPTION',
      RETURNED_TO_SENDER: 'RETURNED',
      AVAILABLE_FOR_PICKUP: 'OUT_FOR_DELIVERY',
    }

    const newShipmentStatus = statusMap[input.status]

    // Wrap all mutations in a transaction for data consistency
    const [trackingEvent] = await prisma.$transaction([
      prisma.trackingEvent.create({
        data: {
          shipmentId: input.shipmentId,
          status: input.status,
          location: input.location ?? null,
          locationCode: input.locationCode ?? null,
          coordinates: input.coordinates ? JSON.stringify(input.coordinates) : null,
          description: input.description,
          eventTime: input.eventTime ?? new Date(),
          timezone: input.timezone ?? null,
          source: input.source ?? null,
          carrierEventCode: input.carrierEventCode ?? null,
          carrierDescription: input.carrierDescription ?? null,
          isException: input.isException ?? false,
          exceptionType: input.exceptionType ?? null,
        },
      }),
      // Update shipment status if applicable
      ...(newShipmentStatus
        ? [
            prisma.shipment.update({
              where: { id: input.shipmentId },
              data: {
                status: newShipmentStatus,
                ...(newShipmentStatus === 'PICKED_UP' ? { shippedAt: new Date() } : {}),
                ...(newShipmentStatus === 'DELIVERED' ? { deliveredAt: new Date() } : {}),
              },
            }),
          ]
        : []),
      // Create order tracking entry
      prisma.orderTracking.create({
        data: {
          orderId: shipment.orderId,
          status: input.status,
          title: OrderTrackingService.getTrackingTitle(input.status),
          description: input.description,
          location: input.location ?? null,
        },
      }),
      // Update order status for key milestones
      ...(newShipmentStatus === 'PICKED_UP'
        ? [prisma.order.update({ where: { id: shipment.orderId }, data: { status: 'SHIPPED' } })]
        : []),
      ...(newShipmentStatus === 'DELIVERED'
        ? [prisma.order.update({ where: { id: shipment.orderId }, data: { status: 'DELIVERED', deliveredAt: new Date() } })]
        : []),
    ])

    return trackingEvent
  }

  static async confirmDelivery(input: ConfirmDeliveryInput) {
    const order = await prisma.order.findUnique({ where: { id: input.orderId } })
    if (!order) throw new Error('Order not found')
    if (order.userId !== input.userId) throw new Error('Not authorized to confirm delivery for this order')

    const shipment = await prisma.shipment.findUnique({
      where: { id: input.shipmentId },
    })
    if (!shipment) throw new Error('Shipment not found')
    if (shipment.orderId !== input.orderId) throw new Error('Shipment does not belong to this order')
    if (input.vendorId && shipment.vendorId && shipment.vendorId !== input.vendorId) {
      throw new Error('Not authorized to modify this shipment')
    }

    const [confirmation] = await prisma.$transaction([
      prisma.deliveryConfirmation.create({
        data: {
          shipmentId: input.shipmentId,
          orderId: input.orderId,
          userId: input.userId,
          deliveredAt: input.deliveredAt,
          deliveryLocation: input.deliveryLocation ?? null,
          recipientName: input.recipientName ?? null,
          signatureImage: input.signatureImage ?? null,
          deliveryPhoto: input.deliveryPhoto ?? null,
          confirmationMethod: input.confirmationMethod,
          gpsCoordinates: input.gpsCoordinates ? JSON.stringify(input.gpsCoordinates) : null,
        },
      }),
      prisma.shipment.update({
        where: { id: input.shipmentId },
        data: { status: 'DELIVERED', deliveredAt: input.deliveredAt },
      }),
      prisma.order.update({
        where: { id: input.orderId },
        data: { status: 'DELIVERED', deliveredAt: input.deliveredAt },
      }),
      prisma.orderTracking.create({
        data: {
          orderId: input.orderId,
          status: 'DELIVERED',
          title: 'Delivered',
          description: `Package delivered${input.recipientName ? ` to ${input.recipientName}` : ''}${input.deliveryLocation ? ` at ${input.deliveryLocation}` : ''}. Confirmed via ${input.confirmationMethod}.`,
          location: input.deliveryLocation ?? null,
        },
      }),
    ])

    return confirmation
  }

  static async handleException(shipmentId: string, exceptionType: ExceptionType, description: string, location?: string, vendorId?: string) {
    const shipment = await prisma.shipment.findUnique({
      where: { id: shipmentId },
    })
    if (!shipment) throw new Error('Shipment not found')
    if (vendorId && shipment.vendorId && shipment.vendorId !== vendorId) {
      throw new Error('Not authorized to modify this shipment')
    }

    const event = await prisma.trackingEvent.create({
      data: {
        shipmentId,
        status: 'EXCEPTION',
        location: location ?? null,
        description,
        isException: true,
        exceptionType,
      },
    })

    await prisma.shipment.update({
      where: { id: shipmentId },
      data: { status: 'EXCEPTION' },
    })

    await prisma.orderTracking.create({
      data: {
        orderId: shipment.orderId,
        status: 'EXCEPTION',
        title: `Shipping Exception: ${exceptionType}`,
        description,
        location: location ?? null,
      },
    })

    return event
  }

  static async updateShipmentStatus(shipmentId: string, status: ShipmentStatus) {
    const updateData: Record<string, unknown> = { status }
    if (status === 'PICKED_UP') updateData.shippedAt = new Date()
    if (status === 'DELIVERED') updateData.deliveredAt = new Date()

    return prisma.shipment.update({
      where: { id: shipmentId },
      data: updateData,
    })
  }

  static async getShipment(shipmentId: string) {
    return prisma.shipment.findUnique({
      where: { id: shipmentId },
      include: {
        trackingEvents: { orderBy: { eventTime: 'desc' } },
      },
    })
  }

  static async getShipmentByNumber(shipmentNumber: string) {
    return prisma.shipment.findUnique({
      where: { shipmentNumber },
      include: {
        trackingEvents: { orderBy: { eventTime: 'desc' } },
      },
    })
  }

  static async getShipmentsByOrder(orderId: string) {
    return prisma.shipment.findMany({
      where: { orderId },
      include: {
        trackingEvents: { orderBy: { eventTime: 'desc' }, take: 5 },
      },
      orderBy: { createdAt: 'desc' },
    })
  }

  static async getTrackingEvents(shipmentId: string) {
    return prisma.trackingEvent.findMany({
      where: { shipmentId },
      orderBy: { eventTime: 'desc' },
    })
  }

  static async getOrderTrackingHistory(orderId: string) {
    return prisma.orderTracking.findMany({
      where: { orderId },
      orderBy: { timestamp: 'desc' },
    })
  }

  static async getShippingLabel(shipmentId: string) {
    return prisma.shippingLabel.findFirst({
      where: { shipmentId },
      orderBy: { createdAt: 'desc' },
    })
  }

  static async getDeliveryConfirmation(shipmentId: string) {
    return prisma.deliveryConfirmation.findFirst({
      where: { shipmentId },
      orderBy: { createdAt: 'desc' },
    })
  }

  static async getShippingRates(fromZip: string, toZip: string, weight: number) {
    return prisma.shippingRate.findMany({
      where: {
        fromZip,
        toZip,
        weight: { gte: weight },
        isActive: true,
      },
      orderBy: { rate: 'asc' },
    })
  }

  static async estimateDelivery(shipmentId: string): Promise<{ estimatedDays: number; estimatedDate: Date } | null> {
    const shipment = await prisma.shipment.findUnique({
      where: { id: shipmentId },
    })
    if (!shipment) throw new Error('Shipment not found')

    const estimates: Record<string, number> = {
      STANDARD: 5,
      EXPRESS: 2,
      OVERNIGHT: 1,
      PICKUP: 0,
      DIGITAL: 0,
    }

    const days = estimates[shipment.shipmentType] ?? 5

    const startDate = shipment.shippedAt ?? new Date()
    const estimatedDate = new Date(startDate)
    estimatedDate.setDate(estimatedDate.getDate() + days)

    return { estimatedDays: days, estimatedDate }
  }

  static async cancelShipment(shipmentId: string, vendorId?: string) {
    const shipment = await prisma.shipment.findUnique({
      where: { id: shipmentId },
    })
    if (!shipment) throw new Error('Shipment not found')
    if (vendorId && shipment.vendorId && shipment.vendorId !== vendorId) {
      throw new Error('Not authorized to modify this shipment')
    }

    const cancellableStatuses: ShipmentStatus[] = ['CREATED', 'LABEL_GENERATED']
    if (!cancellableStatuses.includes(shipment.status as ShipmentStatus)) {
      throw new Error(`Cannot cancel shipment in status "${shipment.status}"`)
    }

    const updated = await prisma.shipment.update({
      where: { id: shipmentId },
      data: { status: 'CANCELLED' },
    })

    await prisma.shippingLabel.updateMany({
      where: { shipmentId },
      data: { status: 'VOIDED' },
    })

    return updated
  }

  // ── Private helpers ─────────────────────────────────────────

  private static getTrackingTitle(status: TrackingStatus): string {
    const titles: Record<TrackingStatus, string> = {
      LABEL_CREATED: 'Label Created',
      PICKED_UP: 'Package Picked Up',
      IN_TRANSIT: 'In Transit',
      ARRIVED_AT_FACILITY: 'Arrived at Facility',
      DEPARTED_FACILITY: 'Departed Facility',
      OUT_FOR_DELIVERY: 'Out for Delivery',
      DELIVERED: 'Delivered',
      DELIVERY_ATTEMPT_FAILED: 'Delivery Attempt Failed',
      EXCEPTION: 'Shipping Exception',
      RETURNED_TO_SENDER: 'Returned to Sender',
      AVAILABLE_FOR_PICKUP: 'Available for Pickup',
    }
    return titles[status] ?? status
  }
}
