import { randomBytes } from 'crypto'
import { prisma } from '@/lib/prisma'

type ReturnType = 'REFUND' | 'EXCHANGE' | 'STORE_CREDIT'
type ReturnReason =
  | 'DEFECTIVE'
  | 'NOT_AS_DESCRIBED'
  | 'WRONG_ITEM'
  | 'DAMAGED_IN_SHIPPING'
  | 'CHANGED_MIND'
  | 'NOT_NEEDED'
  | 'BETTER_PRICE_AVAILABLE'
  | 'QUALITY_ISSUE'
  | 'SIZE_FIT_ISSUE'
  | 'ARRIVED_TOO_LATE'
  | 'OTHER'

type ReturnStatus =
  | 'REQUESTED'
  | 'APPROVED'
  | 'REJECTED'
  | 'SHIPPING_LABEL_SENT'
  | 'ITEM_SHIPPED'
  | 'ITEM_RECEIVED'
  | 'INSPECTING'
  | 'REFUND_PROCESSING'
  | 'REFUNDED'
  | 'EXCHANGE_SHIPPED'
  | 'STORE_CREDIT_ISSUED'
  | 'CANCELLED'

type RefundMethod = 'ORIGINAL_PAYMENT' | 'STORE_CREDIT' | 'CHECK' | 'BANK_TRANSFER' | 'PAYPAL'
type RefundStatus = 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'FAILED'
type InspectionResult = 'PASS' | 'FAIL' | 'PARTIAL'

interface ReturnItemInput {
  orderItemId: string
  productId: string
  quantity: number
  reason: ReturnReason | string
  condition?: string
}

interface CreateReturnInput {
  orderId: string
  userId: string
  type: ReturnType
  reason: ReturnReason | string
  customReason?: string
  items: ReturnItemInput[]
  customerComments?: string
  customerImages?: string[]
  contactPreference?: string
  pickupRequested?: boolean
}

interface InspectionInput {
  returnRequestId: string
  result: InspectionResult
  notes?: string
  restockingFeePercent?: number
  approvedRefundAmount?: number
  performedBy: string
}

interface CreateRefundInput {
  orderId: string
  returnRequestId: string
  userId: string
  vendorId?: string
  refundAmount: number
  refundMethod: RefundMethod
  originalPaymentMethod?: string
  originalTransactionId?: string
  originalAmount: number
  items: ReturnItemInput[]
  itemsRefundAmount: number
  shippingRefundAmount?: number
  taxRefundAmount?: number
  feesDeducted?: number
}

interface CreateReturnPolicyInput {
  name: string
  vendorId?: string
  categoryId?: string
  productId?: string
  returnWindowDays?: number
  allowReturns?: boolean
  allowExchanges?: boolean
  requireOriginalPackaging?: boolean
  freeReturnShipping?: boolean
  restockingFee?: number
  acceptedReasons?: string[]
  excludedReasons?: string[]
}

function generateReturnNumber(): string {
  const prefix = 'RTN'
  const timestamp = Date.now().toString(36).toUpperCase()
  const random = randomBytes(3).toString('hex').toUpperCase().slice(0, 4)
  return `${prefix}-${timestamp}-${random}`
}

function parseJsonArray(value: string | null | undefined): string[] {
  if (!value) return []
  try {
    const parsed = JSON.parse(value)
    return Array.isArray(parsed) ? parsed : []
  } catch (err) {
    console.error('Failed to parse return items:', err)
    return []
  }
}

export class ReturnRefundService {
  static async createReturn(input: CreateReturnInput) {
    const order = await prisma.order.findUnique({
      where: { id: input.orderId },
      include: { items: true },
    })
    if (!order) throw new Error('Order not found')
    if (order.userId !== input.userId) throw new Error('Order does not belong to this user')

    const eligibility = await ReturnRefundService.checkEligibility(input.orderId, input.items.map((i) => i.orderItemId))
    if (!eligibility.eligible) throw new Error(eligibility.reason ?? 'Return is not eligible')

    const policy = await ReturnRefundService.getApplicablePolicy(order.vendorId, input.items)
    if (policy && !policy.allowReturns && input.type === 'REFUND') {
      throw new Error('Returns are not allowed for this order')
    }
    if (policy && !policy.allowExchanges && input.type === 'EXCHANGE') {
      throw new Error('Exchanges are not allowed for this order')
    }

    if (policy) {
      const acceptedReasons = parseJsonArray(policy.acceptedReasons)
      if (acceptedReasons.length > 0 && !acceptedReasons.includes(input.reason)) {
        throw new Error(`Reason "${input.reason}" is not accepted for this return`)
      }
      const excludedReasons = parseJsonArray(policy.excludedReasons)
      if (excludedReasons.includes(input.reason)) {
        throw new Error(`Reason "${input.reason}" is excluded for this return`)
      }
    }

    let totalAmountCents = 0
    for (const item of input.items) {
      const orderItem = order.items.find((oi) => oi.id === item.orderItemId)
      if (!orderItem) throw new Error(`Order item ${item.orderItemId} not found`)
      if (item.quantity < 1) throw new Error(`Invalid return quantity for item ${item.orderItemId}`)
      if (item.quantity > orderItem.quantity) throw new Error(`Return quantity (${item.quantity}) exceeds ordered quantity (${orderItem.quantity}) for item ${item.orderItemId}`)
      
      // Check against already-returned quantities
      const existingReturns = await prisma.returnRequest.findMany({
        where: { orderId: input.orderId, status: { notIn: ['REJECTED', 'CLOSED'] } },
      })
      let alreadyReturnedQty = 0
      for (const ret of existingReturns) {
        try {
          const retItems = JSON.parse(ret.items) as Array<{ orderItemId: string; quantity: number }>
          const match = retItems.find((ri) => ri.orderItemId === item.orderItemId)
          if (match) alreadyReturnedQty += match.quantity
        } catch (err) { console.error('Failed to parse return items:', err) }
      }
      if (alreadyReturnedQty + item.quantity > orderItem.quantity) {
        throw new Error(`Cannot return ${item.quantity} more — ${alreadyReturnedQty} already returned out of ${orderItem.quantity} ordered`)
      }
      
      totalAmountCents += orderItem.priceCents * item.quantity
    }

    let totalAmount = totalAmountCents / 100

    if (policy && policy.restockingFee > 0) {
      totalAmount -= totalAmount * (policy.restockingFee / 100)
      totalAmount = Math.round(totalAmount * 100) / 100
    }

    const returnNumber = generateReturnNumber()

    const returnRequest = await prisma.returnRequest.create({
      data: {
        returnNumber,
        orderId: input.orderId,
        userId: input.userId,
        vendorId: order.vendorId ?? null,
        type: input.type,
        reason: input.reason,
        customReason: input.customReason ?? null,
        status: 'REQUESTED',
        items: JSON.stringify(input.items),
        customerComments: input.customerComments ?? null,
        customerImages: input.customerImages ? JSON.stringify(input.customerImages) : null,
        contactPreference: input.contactPreference ?? null,
        pickupRequested: input.pickupRequested ?? false,
        totalAmount,
      },
    })

    await ReturnRefundService.logAction(returnRequest.id, 'CREATED', input.userId, {
      returnNumber,
      type: input.type,
      reason: input.reason,
      itemCount: input.items.length,
      totalAmount,
    })

    return returnRequest
  }

  static async checkEligibility(orderId: string, orderItemIds: string[]) {
    const order = await prisma.order.findUnique({
      where: { id: orderId },
      include: { items: true },
    })
    if (!order) return { eligible: false, reason: 'Order not found' }

    if (order.status === 'CANCELLED') return { eligible: false, reason: 'Order is cancelled' }
    if (order.paymentStatus !== 'PAID') return { eligible: false, reason: 'Order payment is not complete' }

    const existingReturns = await prisma.returnRequest.findMany({
      where: { orderId, status: { notIn: ['REJECTED', 'CANCELLED'] } },
    })
    if (existingReturns.length > 0) {
      const existingItems = existingReturns.flatMap((r) => {
        try {
          return JSON.parse(r.items) as ReturnItemInput[]
        } catch (err) {
          console.error('Failed to parse return items:', err)
          return []
        }
      })
      const alreadyReturned = existingItems.some((ei) => orderItemIds.includes(ei.orderItemId))
      if (alreadyReturned) return { eligible: false, reason: 'Some items already have an active return request' }
    }

    const policy = await ReturnRefundService.getApplicablePolicy(order.vendorId)
    const windowDays = policy?.returnWindowDays ?? 30

    const deliveredDate = order.deliveredAt ?? order.createdAt
    const daysSinceDelivery = Math.floor((Date.now() - deliveredDate.getTime()) / (1000 * 60 * 60 * 24))
    if (daysSinceDelivery > windowDays) {
      return { eligible: false, reason: `Return window of ${windowDays} days has expired` }
    }

    return { eligible: true, reason: null }
  }

  static async getApplicablePolicy(vendorId?: string | null, items?: ReturnItemInput[]) {
    if (items && items.length > 0) {
      const firstItem = items[0]
      const productPolicy = await prisma.returnPolicy.findFirst({
        where: { productId: firstItem.productId, isActive: true },
      })
      if (productPolicy) return productPolicy
    }

    if (vendorId) {
      const vendorPolicy = await prisma.returnPolicy.findFirst({
        where: { vendorId, productId: null, categoryId: null, isActive: true },
      })
      if (vendorPolicy) return vendorPolicy
    }

    const defaultPolicy = await prisma.returnPolicy.findFirst({
      where: { vendorId: null, productId: null, categoryId: null, isActive: true },
    })

    return defaultPolicy
  }

  static async approveReturn(returnRequestId: string, performedBy: string, notes?: string, vendorId?: string) {
    const returnRequest = await prisma.returnRequest.findUnique({
      where: { id: returnRequestId },
    })
    if (!returnRequest) throw new Error('Return request not found')
    if (returnRequest.status !== 'REQUESTED') throw new Error(`Cannot approve return in status "${returnRequest.status}"`)
    if (vendorId && returnRequest.vendorId && returnRequest.vendorId !== vendorId) {
      throw new Error('Not authorized to modify this return request')
    }

    const updated = await prisma.returnRequest.update({
      where: { id: returnRequestId },
      data: { status: 'APPROVED' },
    })

    await ReturnRefundService.logAction(returnRequestId, 'APPROVED', performedBy, { notes })

    return updated
  }

  static async rejectReturn(returnRequestId: string, performedBy: string, reason: string, vendorId?: string) {
    const returnRequest = await prisma.returnRequest.findUnique({
      where: { id: returnRequestId },
    })
    if (!returnRequest) throw new Error('Return request not found')
    if (returnRequest.status !== 'REQUESTED') throw new Error(`Cannot reject return in status "${returnRequest.status}"`)
    if (vendorId && returnRequest.vendorId && returnRequest.vendorId !== vendorId) {
      throw new Error('Not authorized to modify this return request')
    }

    const updated = await prisma.returnRequest.update({
      where: { id: returnRequestId },
      data: { status: 'REJECTED' },
    })

    await ReturnRefundService.logAction(returnRequestId, 'REJECTED', performedBy, { reason })

    return updated
  }

  static async generateShippingLabel(returnRequestId: string, carrier: string, trackingNumber?: string) {
    const returnRequest = await prisma.returnRequest.findUnique({
      where: { id: returnRequestId },
    })
    if (!returnRequest) throw new Error('Return request not found')
    if (returnRequest.status !== 'APPROVED') throw new Error(`Cannot generate label in status "${returnRequest.status}"`)

    const label = await prisma.returnShippingLabel.create({
      data: {
        returnRequestId,
        trackingNumber: trackingNumber ?? null,
        carrier,
        status: 'GENERATED',
      },
    })

    await prisma.returnRequest.update({
      where: { id: returnRequestId },
      data: { status: 'SHIPPING_LABEL_SENT' },
    })

    await ReturnRefundService.logAction(returnRequestId, 'SHIPPING_LABEL_SENT', 'SYSTEM', {
      carrier,
      trackingNumber,
      labelId: label.id,
    })

    return label
  }

  static async markItemShipped(returnRequestId: string, userId: string, trackingNumber?: string) {
    const returnRequest = await prisma.returnRequest.findUnique({
      where: { id: returnRequestId },
    })
    if (!returnRequest) throw new Error('Return request not found')
    if (returnRequest.status !== 'SHIPPING_LABEL_SENT') throw new Error(`Cannot mark shipped in status "${returnRequest.status}"`)

    const updated = await prisma.returnRequest.update({
      where: { id: returnRequestId },
      data: { status: 'ITEM_SHIPPED' },
    })

    if (trackingNumber) {
      await prisma.returnShippingLabel.updateMany({
        where: { returnRequestId },
        data: { trackingNumber },
      })
    }

    await ReturnRefundService.logAction(returnRequestId, 'ITEM_SHIPPED', userId, { trackingNumber })

    return updated
  }

  static async markItemReceived(returnRequestId: string, performedBy: string) {
    const returnRequest = await prisma.returnRequest.findUnique({
      where: { id: returnRequestId },
    })
    if (!returnRequest) throw new Error('Return request not found')
    if (returnRequest.status !== 'ITEM_SHIPPED') throw new Error(`Cannot mark received in status "${returnRequest.status}"`)

    const updated = await prisma.returnRequest.update({
      where: { id: returnRequestId },
      data: { status: 'ITEM_RECEIVED' },
    })

    await ReturnRefundService.logAction(returnRequestId, 'ITEM_RECEIVED', performedBy)

    return updated
  }

  static async startInspection(returnRequestId: string, performedBy: string) {
    const returnRequest = await prisma.returnRequest.findUnique({
      where: { id: returnRequestId },
    })
    if (!returnRequest) throw new Error('Return request not found')
    if (returnRequest.status !== 'ITEM_RECEIVED') throw new Error(`Cannot start inspection in status "${returnRequest.status}"`)

    const updated = await prisma.returnRequest.update({
      where: { id: returnRequestId },
      data: { status: 'INSPECTING' },
    })

    await ReturnRefundService.logAction(returnRequestId, 'INSPECTION_STARTED', performedBy)

    return updated
  }

  static async completeInspection(input: InspectionInput) {
    const returnRequest = await prisma.returnRequest.findUnique({
      where: { id: input.returnRequestId },
    })
    if (!returnRequest) throw new Error('Return request not found')
    if (returnRequest.status !== 'INSPECTING') throw new Error(`Cannot complete inspection in status "${returnRequest.status}"`)

    let newStatus: ReturnStatus
    let refundAmount = returnRequest.totalAmount

    switch (input.result) {
      case 'PASS':
        newStatus = 'REFUND_PROCESSING'
        if (input.approvedRefundAmount !== undefined) refundAmount = input.approvedRefundAmount
        break
      case 'PARTIAL':
        newStatus = 'REFUND_PROCESSING'
        refundAmount = input.approvedRefundAmount ?? returnRequest.totalAmount * 0.5
        break
      case 'FAIL':
        newStatus = 'REJECTED'
        refundAmount = 0
        break
      default:
        throw new Error(`Unknown inspection result: ${input.result}`)
    }

    if (input.restockingFeePercent && input.restockingFeePercent > 0) {
      refundAmount -= refundAmount * (input.restockingFeePercent / 100)
      refundAmount = Math.round(refundAmount * 100) / 100
    }

    const updated = await prisma.returnRequest.update({
      where: { id: input.returnRequestId },
      data: {
        status: newStatus,
        totalAmount: refundAmount,
      },
    })

    await ReturnRefundService.logAction(input.returnRequestId, `INSPECTION_${input.result}`, input.performedBy, {
      result: input.result,
      notes: input.notes,
      restockingFeePercent: input.restockingFeePercent,
      approvedRefundAmount: refundAmount,
    })

    return { returnRequest: updated, refundAmount }
  }

  static async processRefund(input: CreateRefundInput) {
    const returnRequest = await prisma.returnRequest.findUnique({
      where: { id: input.returnRequestId },
    })
    if (!returnRequest) throw new Error('Return request not found')
    if (input.vendorId && returnRequest.vendorId && returnRequest.vendorId !== input.vendorId) {
      throw new Error('Not authorized to process refund for this return request')
    }

    const order = await prisma.order.findUnique({
      where: { id: input.orderId },
    })
    if (!order) throw new Error('Order not found')

    const refund = await prisma.refund.create({
      data: {
        orderId: input.orderId,
        returnRequestId: input.returnRequestId,
        userId: input.userId,
        vendorId: input.vendorId ?? null,
        refundAmount: input.refundAmount,
        refundMethod: input.refundMethod,
        originalPaymentMethod: input.originalPaymentMethod ?? null,
        originalTransactionId: input.originalTransactionId ?? null,
        originalAmount: input.originalAmount,
        items: JSON.stringify(input.items),
        itemsRefundAmount: input.itemsRefundAmount,
        shippingRefundAmount: input.shippingRefundAmount ?? 0,
        taxRefundAmount: input.taxRefundAmount ?? 0,
        feesDeducted: input.feesDeducted ?? 0,
        status: 'PENDING',
      },
    })

    await prisma.returnRequest.update({
      where: { id: input.returnRequestId },
      data: { status: 'REFUND_PROCESSING' },
    })

    await ReturnRefundService.logAction(input.returnRequestId, 'REFUND_INITIATED', 'SYSTEM', {
      refundId: refund.id,
      refundAmount: input.refundAmount,
      refundMethod: input.refundMethod,
    })

    return refund
  }

  static async completeRefund(refundId: string, vendorId?: string) {
    const refund = await prisma.refund.findUnique({
      where: { id: refundId },
    })
    if (!refund) throw new Error('Refund not found')
    if (vendorId && refund.vendorId && refund.vendorId !== vendorId) {
      throw new Error('Not authorized to complete this refund')
    }

    const updatedRefund = await prisma.refund.update({
      where: { id: refundId },
      data: { status: 'COMPLETED', processedAt: new Date() },
    })

    if (refund.returnRequestId) {
      const returnRequest = await prisma.returnRequest.findUnique({
        where: { id: refund.returnRequestId },
      })
      if (returnRequest) {
        let finalStatus: ReturnStatus
        switch (returnRequest.type) {
          case 'EXCHANGE':
            finalStatus = 'EXCHANGE_SHIPPED'
            break
          case 'STORE_CREDIT':
            finalStatus = 'STORE_CREDIT_ISSUED'
            break
          default:
            finalStatus = 'REFUNDED'
        }

        await prisma.returnRequest.update({
          where: { id: refund.returnRequestId },
          data: { status: finalStatus },
        })

        await ReturnRefundService.logAction(refund.returnRequestId, 'REFUND_COMPLETED', 'SYSTEM', {
          refundId,
          refundAmount: refund.refundAmount,
        })
      }
    }

    if (refund.orderId) {
      await prisma.return.updateMany({
        where: { orderId: refund.orderId },
        data: { isRefunded: true, refundAmount: refund.refundAmount },
      })
    }

    return updatedRefund
  }

  static async failRefund(refundId: string, reason: string) {
    const refund = await prisma.refund.update({
      where: { id: refundId },
      data: { status: 'FAILED' },
    })

    if (refund.returnRequestId) {
      await ReturnRefundService.logAction(refund.returnRequestId, 'REFUND_FAILED', 'SYSTEM', {
        refundId,
        reason,
      })
    }

    return refund
  }

  static async cancelReturn(returnRequestId: string, userId: string, reason?: string) {
    const returnRequest = await prisma.returnRequest.findUnique({
      where: { id: returnRequestId },
    })
    if (!returnRequest) throw new Error('Return request not found')

    const cancellableStatuses: ReturnStatus[] = ['REQUESTED', 'APPROVED', 'SHIPPING_LABEL_SENT']
    if (!cancellableStatuses.includes(returnRequest.status as ReturnStatus)) {
      throw new Error(`Cannot cancel return in status "${returnRequest.status}"`)
    }

    const updated = await prisma.returnRequest.update({
      where: { id: returnRequestId },
      data: { status: 'CANCELLED' },
    })

    await ReturnRefundService.logAction(returnRequestId, 'CANCELLED', userId, { reason })

    return updated
  }

  static async getReturnByNumber(returnNumber: string) {
    const returnRequest = await prisma.returnRequest.findUnique({
      where: { returnNumber },
    })
    if (!returnRequest) return null

    const order = await prisma.order.findUnique({
      where: { id: returnRequest.orderId },
      include: { items: { include: { product: true } } },
    })

    return { ...returnRequest, order }
  }

  static async getUserReturns(userId: string) {
    const returns = await prisma.returnRequest.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
    })

    const results = []
    for (const ret of returns) {
      const order = await prisma.order.findUnique({
        where: { id: ret.orderId },
        select: { orderNumber: true, total: true },
      })

      const labels = await prisma.returnShippingLabel.findMany({
        where: { returnRequestId: ret.id },
      })

      results.push({ ...ret, order, shippingLabels: labels })
    }

    return results
  }

  static async getOrderReturns(orderId: string) {
    return prisma.returnRequest.findMany({
      where: { orderId },
      orderBy: { createdAt: 'desc' },
    })
  }

  static async getReturnActions(returnRequestId: string) {
    return prisma.returnAction.findMany({
      where: { returnRequestId },
      orderBy: { createdAt: 'asc' },
    })
  }

  static async getRefundsForOrder(orderId: string) {
    return prisma.refund.findMany({
      where: { orderId },
      orderBy: { createdAt: 'desc' },
    })
  }

  // ── Return Policies ─────────────────────────────────────────

  static async createReturnPolicy(input: CreateReturnPolicyInput) {
    return prisma.returnPolicy.create({
      data: {
        name: input.name,
        vendorId: input.vendorId ?? null,
        categoryId: input.categoryId ?? null,
        productId: input.productId ?? null,
        returnWindowDays: input.returnWindowDays ?? 30,
        allowReturns: input.allowReturns ?? true,
        allowExchanges: input.allowExchanges ?? true,
        requireOriginalPackaging: input.requireOriginalPackaging ?? false,
        freeReturnShipping: input.freeReturnShipping ?? false,
        restockingFee: input.restockingFee ?? 0,
        acceptedReasons: input.acceptedReasons ? JSON.stringify(input.acceptedReasons) : null,
        excludedReasons: input.excludedReasons ? JSON.stringify(input.excludedReasons) : null,
        isActive: true,
      },
    })
  }

  static async updateReturnPolicy(id: string, data: Partial<CreateReturnPolicyInput> & { isActive?: boolean }) {
    const updateData: Record<string, unknown> = {}

    if (data.name !== undefined) updateData.name = data.name
    if (data.returnWindowDays !== undefined) updateData.returnWindowDays = data.returnWindowDays
    if (data.allowReturns !== undefined) updateData.allowReturns = data.allowReturns
    if (data.allowExchanges !== undefined) updateData.allowExchanges = data.allowExchanges
    if (data.requireOriginalPackaging !== undefined) updateData.requireOriginalPackaging = data.requireOriginalPackaging
    if (data.freeReturnShipping !== undefined) updateData.freeReturnShipping = data.freeReturnShipping
    if (data.restockingFee !== undefined) updateData.restockingFee = data.restockingFee
    if (data.isActive !== undefined) updateData.isActive = data.isActive

    if (data.acceptedReasons !== undefined) updateData.acceptedReasons = data.acceptedReasons ? JSON.stringify(data.acceptedReasons) : null
    if (data.excludedReasons !== undefined) updateData.excludedReasons = data.excludedReasons ? JSON.stringify(data.excludedReasons) : null

    return prisma.returnPolicy.update({ where: { id }, data: updateData })
  }

  static async getReturnPolicies(options?: { vendorId?: string }) {
    const where: Record<string, unknown> = { isActive: true }
    if (options?.vendorId) where.vendorId = options.vendorId

    return prisma.returnPolicy.findMany({
      where,
      orderBy: { createdAt: 'desc' },
    })
  }

  // ── Private helpers ─────────────────────────────────────────

  private static async logAction(
    returnRequestId: string,
    actionType: string,
    performedBy: string,
    metadata?: Record<string, unknown>
  ) {
    return prisma.returnAction.create({
      data: {
        returnRequestId,
        actionType,
        performedBy,
        metadata: metadata ? JSON.stringify(metadata) : null,
      },
    })
  }
}
