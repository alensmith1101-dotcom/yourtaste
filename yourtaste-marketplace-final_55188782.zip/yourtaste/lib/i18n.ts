import { cookies } from 'next/headers'
import { prisma } from '@/lib/prisma'

const SUPPORTED_LANGUAGES = [
  'en', 'es', 'fr', 'de', 'it', 'pt',
  'ru', 'ja', 'ko', 'zh', 'ar', 'hi',
] as const

const SUPPORTED_CURRENCIES = [
  'USD', 'EUR', 'GBP', 'JPY', 'CAD', 'AUD',
  'CHF', 'CNY', 'INR', 'BRL', 'MXN', 'KRW',
] as const

const RTL_LANGUAGES = ['ar'] as const

const CACHE_TTL_MS = 5 * 60 * 1000

type SupportedLanguage = (typeof SUPPORTED_LANGUAGES)[number]
type SupportedCurrency = (typeof SUPPORTED_CURRENCIES)[number]

interface CacheEntry<T> {
  data: T
  expiresAt: number
}

interface LanguageInfo {
  code: string
  name: string
  nativeName: string
  flag: string | null
  rtl: boolean
  isActive: boolean
  sortOrder: number
}

interface CurrencyInfo {
  code: string
  name: string
  symbol: string
  symbolPosition: string
  decimalPlaces: number
  exchangeRate: number
  isDefault: boolean
  isActive: boolean
}

interface UserLocaleData {
  language: string
  currency: string
  country: string | null
  timezone: string | null
}

const cache = new Map<string, CacheEntry<unknown>>()

function getCached<T>(key: string): T | null {
  const entry = cache.get(key) as CacheEntry<T> | undefined
  if (!entry) return null
  if (Date.now() > entry.expiresAt) {
    cache.delete(key)
    return null
  }
  return entry.data
}

function setCache<T>(key: string, data: T): void {
  cache.set(key, { data, expiresAt: Date.now() + CACHE_TTL_MS })
}

function clearExpiredCache(): void {
  const now = Date.now()
  for (const [key, entry] of cache) {
    if (now > entry.expiresAt) {
      cache.delete(key)
    }
  }
}

const i18nCleanup = setInterval(() => {
  const now = Date.now()
  for (const [key, entry] of cache.entries()) {
    if (now > entry.expiresAt) cache.delete(key)
  }
}, 5 * 60 * 1000)
i18nCleanup.unref()

export class I18nService {
  static async getAvailableLanguages(): Promise<LanguageInfo[]> {
    const cacheKey = 'i18n:languages'
    const cached = getCached<LanguageInfo[]>(cacheKey)
    if (cached) return cached

    const languages = await prisma.languageConfig.findMany({
      where: { isActive: true },
      orderBy: { sortOrder: 'asc' },
    })

    const result: LanguageInfo[] = languages.map((lang) => ({
      code: lang.code,
      name: lang.name,
      nativeName: lang.nativeName,
      flag: lang.flag,
      rtl: lang.rtl,
      isActive: lang.isActive,
      sortOrder: lang.sortOrder,
    }))

    setCache(cacheKey, result)
    return result
  }

  static async getAvailableCurrencies(): Promise<CurrencyInfo[]> {
    const cacheKey = 'i18n:currencies'
    const cached = getCached<CurrencyInfo[]>(cacheKey)
    if (cached) return cached

    const currencies = await prisma.currencyConfig.findMany({
      where: { isActive: true },
    })

    const result: CurrencyInfo[] = currencies.map((cur) => ({
      code: cur.code,
      name: cur.name,
      symbol: cur.symbol,
      symbolPosition: cur.symbolPosition,
      decimalPlaces: cur.decimalPlaces,
      exchangeRate: cur.exchangeRate,
      isDefault: cur.isDefault,
      isActive: cur.isActive,
    }))

    setCache(cacheKey, result)
    return result
  }

  static async getDefaultCurrency(): Promise<CurrencyInfo | null> {
    const cacheKey = 'i18n:defaultCurrency'
    const cached = getCached<CurrencyInfo | null>(cacheKey)
    if (cached !== null) return cached

    const currency = await prisma.currencyConfig.findFirst({
      where: { isDefault: true, isActive: true },
    })

    if (!currency) return null

    const result: CurrencyInfo = {
      code: currency.code,
      name: currency.name,
      symbol: currency.symbol,
      symbolPosition: currency.symbolPosition,
      decimalPlaces: currency.decimalPlaces,
      exchangeRate: currency.exchangeRate,
      isDefault: currency.isDefault,
      isActive: currency.isActive,
    }

    setCache(cacheKey, result)
    return result
  }

  static getCurrentLocale(): string {
    const cookieStore = cookies()
    const locale = cookieStore.get('locale')?.value
    if (locale && SUPPORTED_LANGUAGES.includes(locale as SupportedLanguage)) {
      return locale
    }
    return 'en'
  }

  static getCurrentCurrency(): string {
    const cookieStore = cookies()
    const currency = cookieStore.get('currency')?.value
    if (currency && SUPPORTED_CURRENCIES.includes(currency as SupportedCurrency)) {
      return currency
    }
    return 'USD'
  }

  static async getUserLocale(userId: string): Promise<UserLocaleData | null> {
    const cacheKey = `i18n:userLocale:${userId}`
    const cached = getCached<UserLocaleData | null>(cacheKey)
    if (cached !== null) return cached

    const userLocale = await prisma.userLocale.findUnique({
      where: { userId },
    })

    if (!userLocale) return null

    const result: UserLocaleData = {
      language: userLocale.language,
      currency: userLocale.currency,
      country: userLocale.country,
      timezone: userLocale.timezone,
    }

    setCache(cacheKey, result)
    return result
  }

  static async setUserLocale(
    userId: string,
    locale: { language?: string; currency?: string; country?: string; timezone?: string }
  ): Promise<UserLocaleData> {
    const existing = await prisma.userLocale.findUnique({
      where: { userId },
    })

    const updated = await prisma.userLocale.upsert({
      where: { userId },
      update: {
        ...(locale.language && { language: locale.language }),
        ...(locale.currency && { currency: locale.currency }),
        ...(locale.country !== undefined && { country: locale.country }),
        ...(locale.timezone !== undefined && { timezone: locale.timezone }),
      },
      create: {
        userId,
        language: locale.language ?? existing?.language ?? 'en',
        currency: locale.currency ?? existing?.currency ?? 'USD',
        country: locale.country ?? existing?.country ?? null,
        timezone: locale.timezone ?? existing?.timezone ?? null,
      },
    })

    const cacheKey = `i18n:userLocale:${userId}`
    cache.delete(cacheKey)

    const result: UserLocaleData = {
      language: updated.language,
      currency: updated.currency,
      country: updated.country,
      timezone: updated.timezone,
    }

    return result
  }

  static async translateContent(
    entityType: string,
    entityId: string,
    language: string,
    field: string
  ): Promise<string | null> {
    const cacheKey = `i18n:translation:${entityType}:${entityId}:${language}:${field}`
    const cached = getCached<string | null>(cacheKey)
    if (cached !== null) return cached

    const translation = await prisma.contentTranslation.findUnique({
      where: {
        entityType_entityId_language_field: {
          entityType,
          entityId,
          language,
          field,
        },
      },
    })

    const value = translation?.value ?? null
    setCache(cacheKey, value)
    return value
  }

  static async translateEntity(
    entityType: string,
    entityId: string,
    language: string
  ): Promise<Record<string, string>> {
    const cacheKey = `i18n:entity:${entityType}:${entityId}:${language}`
    const cached = getCached<Record<string, string>>(cacheKey)
    if (cached) return cached

    const translations = await prisma.contentTranslation.findMany({
      where: {
        entityType,
        entityId,
        language,
      },
    })

    const result: Record<string, string> = {}
    for (const t of translations) {
      result[t.field] = t.value
    }

    setCache(cacheKey, result)
    return result
  }

  static async formatPrice(
    priceCents: number,
    fromCurrency: string,
    toCurrency: string
  ): Promise<string> {
    const currencyConfig = await prisma.currencyConfig.findUnique({
      where: { code: toCurrency },
    })

    if (!currencyConfig) {
      return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: fromCurrency,
      }).format(priceCents / 100)
    }

    // Convert from source cents to base unit, then apply exchange rate for target currency
    const convertedAmount = (priceCents / 100) * currencyConfig.exchangeRate

    const formatted = new Intl.NumberFormat('en-US', {
      minimumFractionDigits: currencyConfig.decimalPlaces,
      maximumFractionDigits: currencyConfig.decimalPlaces,
    }).format(convertedAmount)

    if (currencyConfig.symbolPosition === 'after') {
      return `${formatted}${currencyConfig.symbol}`
    }
    return `${currencyConfig.symbol}${formatted}`
  }

  static formatDate(date: Date | string, locale: string): string {
    const resolvedLocale = SUPPORTED_LANGUAGES.includes(locale as SupportedLanguage)
      ? locale
      : 'en'

    return new Date(date).toLocaleDateString(resolvedLocale, {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    })
  }

  static formatDateTime(date: Date | string, locale: string): string {
    const resolvedLocale = SUPPORTED_LANGUAGES.includes(locale as SupportedLanguage)
      ? locale
      : 'en'

    return new Date(date).toLocaleString(resolvedLocale, {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  static isRtlLanguage(locale: string): boolean {
    return (RTL_LANGUAGES as readonly string[]).includes(locale)
  }

  static getDirection(locale: string): 'rtl' | 'ltr' {
    return I18nService.isRtlLanguage(locale) ? 'rtl' : 'ltr'
  }

  static isSupportedLanguage(code: string): boolean {
    return SUPPORTED_LANGUAGES.includes(code as SupportedLanguage)
  }

  static isSupportedCurrency(code: string): boolean {
    return SUPPORTED_CURRENCIES.includes(code as SupportedCurrency)
  }

  static clearCache(): void {
    cache.clear()
  }

  static clearExpiredEntries(): void {
    clearExpiredCache()
  }
}
