import { NextResponse } from 'next/server'

interface RateLimitConfig {
  windowMs: number
  maxRequests: number
  message?: string
}

const store = new Map<string, { count: number; resetTime: number }>()

const cleanupInterval = setInterval(() => {
  const now = Date.now()
  for (const [key, value] of store.entries()) {
    if (now > value.resetTime) {
      store.delete(key)
    }
  }
}, 5 * 60 * 1000)
cleanupInterval.unref()

const useRedis = !!process.env.UPSTASH_REDIS_REST_URL
let redisStore: any = null

async function getRedisStore() {
  if (redisStore) return redisStore
  if (!useRedis) return null
  try {
    const { Redis } = await import('@upstash/redis')
    redisStore = new Redis({
      url: process.env.UPSTASH_REDIS_REST_URL!,
      token: process.env.UPSTASH_REDIS_REST_TOKEN!,
    })
    return redisStore
  } catch (err) {
    console.error('Failed to initialize Redis:', err)
    return null
  }
}

export function rateLimit(config: RateLimitConfig) {
  const { windowMs, maxRequests, message = 'Too many requests' } = config

  return async (identifier: string, endpoint?: string) => {
    const now = Date.now()
    const key = endpoint ? `rl:${endpoint}:${identifier}` : `rl:${identifier}`

    const redis = await getRedisStore()
    if (redis) {
      try {
        const count = await redis.incr(key)
        if (count === 1) await redis.pexpire(key, windowMs)
        if (count > maxRequests) {
          const ttl = await redis.pttl(key)
          return {
            success: false,
            response: NextResponse.json(
              { success: false, error: message, retryAfter: Math.ceil(ttl / 1000) },
              { status: 429, headers: { 'Retry-After': String(Math.ceil(ttl / 1000)) } }
            ),
          }
        }
        return { success: true }
      } catch (err) {
        console.error('Redis rate limit error:', err)
      }
    }

    let record = store.get(key)

    if (!record || now > record.resetTime) {
      record = { count: 0, resetTime: now + windowMs }
      store.set(key, record)
    }

    record.count++

    if (record.count > maxRequests) {
      const retryAfter = Math.ceil((record.resetTime - now) / 1000)
      return {
        success: false,
        response: NextResponse.json(
          { success: false, error: message, retryAfter },
          { status: 429, headers: { 'Retry-After': String(retryAfter) } }
        ),
      }
    }

    return { success: true }
  }
}

export const rateLimiters = {
  auth: rateLimit({ windowMs: 15 * 60 * 1000, maxRequests: 5, message: 'Too many login attempts' }),
  api: rateLimit({ windowMs: 1 * 60 * 1000, maxRequests: 100, message: 'API rate limit exceeded' }),
  search: rateLimit({ windowMs: 1 * 60 * 1000, maxRequests: 30, message: 'Search rate limit exceeded' }),
  upload: rateLimit({ windowMs: 10 * 60 * 1000, maxRequests: 20, message: 'Upload rate limit exceeded' }),
  orders: rateLimit({ windowMs: 1 * 60 * 1000, maxRequests: 10, message: 'Too many order attempts' }),
  coupons: rateLimit({ windowMs: 1 * 60 * 1000, maxRequests: 15, message: 'Too many coupon attempts' }),
}

export function getClientIp(request: Request): string {
  const realIp = request.headers.get('x-real-ip')
  if (realIp) return realIp.trim()
  
  const forwarded = request.headers.get('x-forwarded-for')
  if (forwarded) {
    const first = forwarded.split(',')[0]?.trim()
    if (first) return first
  }
  
  const cfConnectIp = request.headers.get('cf-connecting-ip')
  if (cfConnectIp) return cfConnectIp.trim()

  return 'unknown'
}
