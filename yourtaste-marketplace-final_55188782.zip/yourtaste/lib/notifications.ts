import { prisma } from '@/lib/prisma'

type Channel = 'EMAIL' | 'SMS' | 'IN_APP' | 'PUSH'
type Priority = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL'
type NotificationStatus = 'PENDING' | 'SENT' | 'DELIVERED' | 'FAILED' | 'RETRYING'
type NotificationType =
  | 'ORDER_CONFIRMED'
  | 'ORDER_SHIPPED'
  | 'ORDER_DELIVERED'
  | 'ORDER_CANCELLED'
  | 'PAYMENT_SUCCESS'
  | 'PAYMENT_FAILED'
  | 'PRICE_DROP'
  | 'BACK_IN_STOCK'
  | 'WELCOME'
  | 'PASSWORD_RESET'
  | 'REVIEW_REMINDER'
  | 'PROMOTION'
  | 'CAMPAIGN'
  | 'SYSTEM'
  | 'ALL'

interface SendOptions {
  userId?: string
  type: NotificationType | string
  channel: Channel
  title?: string
  message: string
  subject?: string
  htmlBody?: string
  email?: string
  phone?: string
  data?: Record<string, unknown>
  metadata?: Record<string, unknown>
  priority?: Priority
  scheduledAt?: Date
  orderId?: string
  productId?: string
  vendorId?: string
}

interface CampaignOptions {
  name: string
  subject: string
  body: string
  htmlBody?: string
  fromEmail: string
  fromName: string
  targetUserIds?: string[]
  targetCriteria?: Record<string, unknown>
  includeUnsubscribed?: boolean
  scheduledAt?: Date
  createdBy: string
}

interface TemplateRenderResult {
  subject: string | null
  title: string | null
  body: string
  htmlBody: string | null
}

const MAX_RETRIES = 3
const RETRY_DELAYS_MS = [5_000, 30_000, 120_000]
const BATCH_SIZE = 50

function escapeHtml(str: string): string {
  return str.replace(/[&<>"']/g, (char) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[char] || char))
}

function renderTemplateString(template: string, vars: Record<string, unknown>): string {
  return template.replace(/\{\{(\w+)\}\}/g, (_, key: string) => {
    const val = vars[key]
    return val !== undefined && val !== null ? escapeHtml(String(val)) : ''
  })
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

export class NotificationService {
  static async send(options: SendOptions) {
    const { userId, type, channel, priority = 'MEDIUM' } = options

    if (userId && channel !== 'IN_APP') {
      const allowed = await NotificationService.isChannelEnabled(userId, type, channel)
      if (!allowed) {
        return null
      }
    }

    if (channel === 'EMAIL' && options.email) {
      const unsubscribed = await NotificationService.isUnsubscribed(options.email)
      if (unsubscribed) return null
    }

    const notification = await prisma.notification.create({
      data: {
        userId: options.userId ?? null,
        type: options.type,
        channel: options.channel,
        status: 'PENDING',
        title: options.title ?? null,
        message: options.message,
        subject: options.subject ?? null,
        htmlBody: options.htmlBody ?? null,
        email: options.email ?? null,
        phone: options.phone ?? null,
        data: options.data ? JSON.stringify(options.data) : null,
        metadata: options.metadata ? JSON.stringify(options.metadata) : null,
        priority: options.priority ?? 'MEDIUM',
        scheduledAt: options.scheduledAt ?? null,
        orderId: options.orderId ?? null,
        productId: options.productId ?? null,
        vendorId: options.vendorId ?? null,
      },
    })

    if (channel === 'EMAIL' && options.email) {
      await prisma.emailNotification.create({
        data: {
          to: options.email,
          subject: options.subject ?? options.title ?? 'Notification',
          htmlContent: options.htmlBody ?? options.message,
          textContent: options.message,
          status: 'PENDING',
          scheduledFor: options.scheduledAt ?? new Date(),
          notificationId: notification.id,
        },
      })
    }

    if (!options.scheduledAt) {
      await NotificationService.dispatch(notification.id)
    }

    return notification
  }

  static async sendFromTemplate(
    userId: string,
    type: string,
    channel: Channel,
    variables: Record<string, unknown>,
    options?: { priority?: Priority; scheduledAt?: Date; orderId?: string; productId?: string; vendorId?: string }
  ) {
    const user = await prisma.user.findUnique({ where: { id: userId } })
    if (!user) throw new Error(`User ${userId} not found`)

    const template = await prisma.notificationTemplate.findFirst({
      where: { type, channel, isActive: true },
      orderBy: { version: 'desc' },
    })
    if (!template) throw new Error(`No active template for type=${type} channel=${channel}`)

    const rendered: TemplateRenderResult = {
      subject: template.subject ? renderTemplateString(template.subject, variables) : null,
      title: template.title ? renderTemplateString(template.title, variables) : null,
      body: renderTemplateString(template.body, variables),
      htmlBody: template.htmlBody ? renderTemplateString(template.htmlBody, variables) : null,
    }

    return NotificationService.send({
      userId,
      type,
      channel,
      title: rendered.title ?? undefined,
      message: rendered.body,
      subject: rendered.subject ?? undefined,
      htmlBody: rendered.htmlBody ?? undefined,
      email: channel === 'EMAIL' ? user.email : undefined,
      phone: channel === 'SMS' ? user.phone ?? undefined : undefined,
      data: variables,
      priority: options?.priority,
      scheduledAt: options?.scheduledAt,
      orderId: options?.orderId,
      productId: options?.productId,
      vendorId: options?.vendorId,
    })
  }

  static async dispatch(notificationId: string) {
    const notification = await prisma.notification.findUnique({
      where: { id: notificationId },
    })
    if (!notification) throw new Error(`Notification ${notificationId} not found`)

    try {
      switch (notification.channel) {
        case 'EMAIL':
          await NotificationService.dispatchEmail(notification)
          break
        case 'SMS':
          await NotificationService.dispatchSms(notification)
          break
        case 'IN_APP':
          await NotificationService.dispatchInApp(notification)
          break
        case 'PUSH':
          await NotificationService.dispatchPush(notification)
          break
        default:
          throw new Error(`Unknown channel: ${notification.channel}`)
      }

      await prisma.notification.update({
        where: { id: notificationId },
        data: { status: 'SENT', sentAt: new Date() },
      })
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error'
      const newRetryCount = notification.retryCount + 1

      if (newRetryCount <= MAX_RETRIES) {
        await prisma.notification.update({
          where: { id: notificationId },
          data: {
            status: 'RETRYING',
            retryCount: newRetryCount,
            errorMessage,
          },
        })
      } else {
        await prisma.notification.update({
          where: { id: notificationId },
          data: {
            status: 'FAILED',
            failedAt: new Date(),
            retryCount: newRetryCount,
            errorMessage,
          },
        })
      }
    }
  }

  private static async dispatchEmail(notification: {
    id: string
    email: string | null
    subject: string | null
    htmlBody: string | null
    message: string
  }) {
    if (!notification.email) throw new Error('No email address on notification')
    
    // Actually send the email via SMTP transport
    const { sendEmail } = await import('@/lib/email')
    await sendEmail({
      to: notification.email,
      subject: notification.subject ?? 'Notification',
      html: notification.htmlBody ?? undefined,
      text: notification.message,
    })

    const emailNotification = await prisma.emailNotification.findFirst({
      where: { notificationId: notification.id },
    })
    if (emailNotification) {
      await prisma.emailNotification.update({
        where: { id: emailNotification.id },
        data: {
          status: 'SENT',
          sentAt: new Date(),
          attempts: { increment: 1 },
        },
      })
    }
  }

  private static async dispatchSms(notification: { id: string; phone: string | null; message: string }) {
    if (!notification.phone) throw new Error('No phone number on notification')
    
    const smsWebhookUrl = process.env.SMS_WEBHOOK_URL
    if (smsWebhookUrl) {
      try {
        await fetch(smsWebhookUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ to: notification.phone, body: notification.message }),
        })
      } catch (err) {
        console.error('SMS webhook failed:', err)
        throw err
      }
    } else {
      console.warn('[SMS] Message queued for delivery')
    }

    await prisma.notification.update({
      where: { id: notification.id },
      data: { status: 'SENT' },
    })
  }

  private static async dispatchInApp(_notification: { id: string }) {
    // In-app notifications are already stored; client polls or uses websocket.
  }

  private static async dispatchPush(notification: { id: string; userId: string | null; title: string | null; message: string; data?: string | Record<string, unknown> | null }) {
    if (!notification.userId) {
      console.warn('[PUSH] No userId on notification, skipping')
      return
    }

    const { sendPushToUser } = await import('@/lib/web-push')

    let parsedData: Record<string, unknown> | null = null
    if (notification.data) {
      parsedData = typeof notification.data === 'string'
        ? JSON.parse(notification.data)
        : notification.data
    }

    let url = '/'
    if (parsedData) {
      if (parsedData.orderId) url = `/orders/${parsedData.orderId}`
      else if (parsedData.productId) url = `/products/${parsedData.productId}`
    }

    await sendPushToUser(notification.userId, {
      title: notification.title ?? 'YourTaste',
      body: notification.message,
      url,
      icon: '/icons/icon-192x192.png',
      tag: notification.id,
      data: parsedData ?? undefined,
    })
  }

  static async processPendingBatch() {
    const now = new Date()
    const pending = await prisma.notification.findMany({
      where: {
        status: { in: ['PENDING', 'RETRYING'] },
        OR: [
          { scheduledAt: null },
          { scheduledAt: { lte: now } },
        ],
      },
      orderBy: [
        { priority: 'desc' },
        { createdAt: 'asc' },
      ],
      take: BATCH_SIZE,
    })

    const results = await Promise.allSettled(
      pending.map((n) => NotificationService.dispatch(n.id))
    )

    return {
      processed: pending.length,
      succeeded: results.filter((r) => r.status === 'fulfilled').length,
      failed: results.filter((r) => r.status === 'rejected').length,
    }
  }

  static async retryFailed(limit = 20) {
    const failed = await prisma.notification.findMany({
      where: {
        status: 'FAILED',
        retryCount: { lt: MAX_RETRIES },
      },
      orderBy: { createdAt: 'asc' },
      take: limit,
    })

    await prisma.notification.updateMany({
      where: { id: { in: failed.map((n) => n.id) } },
      data: { status: 'RETRYING' },
    })

    const results = await Promise.allSettled(
      failed.map((n) => NotificationService.dispatch(n.id))
    )

    return {
      retried: failed.length,
      succeeded: results.filter((r) => r.status === 'fulfilled').length,
      failed: results.filter((r) => r.status === 'rejected').length,
    }
  }

  // ── Preferences ────────────────────────────────────────────

  private static notificationTypeToField(type: string, channel: Channel): string | null {
    const orderTypes = [
      'ORDER_CONFIRMED', 'ORDER_SHIPPED', 'ORDER_DELIVERED',
      'ORDER_CANCELLED', 'PAYMENT_SUCCESS', 'PAYMENT_FAILED',
      'REVIEW_REMINDER',
    ]
    const promotionTypes = ['PROMOTION', 'CAMPAIGN', 'BACK_IN_STOCK']
    const priceDropTypes = ['PRICE_DROP']

    if (orderTypes.includes(type)) {
      if (channel === 'EMAIL') return 'emailOrderUpdates'
      if (channel === 'PUSH') return 'pushOrderUpdates'
      if (channel === 'SMS') return 'smsOrderUpdates'
    }
    if (promotionTypes.includes(type)) {
      if (channel === 'EMAIL') return 'emailPromotions'
      if (channel === 'PUSH') return 'pushDeals'
    }
    if (priceDropTypes.includes(type)) {
      if (channel === 'PUSH') return 'pushPriceDrops'
    }
    if (type === 'WELCOME' || type === 'SYSTEM' || type === 'PASSWORD_RESET') {
      return null
    }

    return null
  }

  static async isChannelEnabled(userId: string, type: string, channel: Channel): Promise<boolean> {
    if (channel === 'IN_APP') return true

    const field = NotificationService.notificationTypeToField(type, channel)
    if (!field) return true

    const prefs = await prisma.notificationPreference.findUnique({
      where: { userId },
    })
    if (!prefs) return true

    return (prefs as Record<string, unknown>)[field] as boolean
  }

  static async setPreference(userId: string, updates: Record<string, boolean>) {
    return prisma.notificationPreference.upsert({
      where: { userId },
      update: updates,
      create: { userId, ...updates },
    })
  }

  static async getPreferences(userId: string) {
    return prisma.notificationPreference.findUnique({
      where: { userId },
    })
  }

  static async createDefaultPreferences(userId: string) {
    return prisma.notificationPreference.create({
      data: {
        userId,
        emailOrderUpdates: true,
        emailPromotions: false,
        emailNewsletter: true,
        pushOrderUpdates: true,
        pushDeals: true,
        pushPriceDrops: true,
        smsOrderUpdates: true,
      },
    })
  }

  // ── Unsubscribe ────────────────────────────────────────────

  static async isUnsubscribed(email: string): Promise<boolean> {
    const record = await prisma.emailUnsubscription.findFirst({
      where: { email: email.toLowerCase() },
    })
    return !!record
  }

  static async unsubscribe(email: string, reason?: string, campaignId?: string) {
    return prisma.emailUnsubscription.create({
      data: {
        email: email.toLowerCase(),
        reason: reason ?? null,
        campaignId: campaignId ?? null,
      },
    })
  }

  static async resubscribe(email: string) {
    await prisma.emailUnsubscription.deleteMany({
      where: { email: email.toLowerCase() },
    })
  }

  static async getUnsubscribedEmails() {
    return prisma.emailUnsubscription.findMany({
      select: { email: true },
    })
  }

  // ── Email Campaigns ────────────────────────────────────────

  static async createCampaign(options: CampaignOptions) {
    return prisma.emailCampaign.create({
      data: {
        name: options.name,
        subject: options.subject,
        body: options.body,
        htmlBody: options.htmlBody ?? null,
        fromEmail: options.fromEmail,
        fromName: options.fromName,
        targetUserIds: options.targetUserIds ? JSON.stringify(options.targetUserIds) : null,
        targetCriteria: options.targetCriteria ? JSON.stringify(options.targetCriteria) : null,
        includeUnsubscribed: options.includeUnsubscribed ?? false,
        scheduledAt: options.scheduledAt ?? null,
        createdBy: options.createdBy,
        status: options.scheduledAt ? 'SCHEDULED' : 'DRAFT',
      },
    })
  }

  static async launchCampaign(campaignId: string) {
    const campaign = await prisma.emailCampaign.findUnique({
      where: { id: campaignId },
    })
    if (!campaign) throw new Error(`Campaign ${campaignId} not found`)
    if (campaign.status !== 'DRAFT' && campaign.status !== 'SCHEDULED') {
      throw new Error(`Campaign ${campaignId} cannot be launched (status=${campaign.status})`)
    }

    let recipientIds: string[] = []

    if (campaign.targetUserIds) {
      try {
        recipientIds = JSON.parse(campaign.targetUserIds) as string[]
      } catch (err) {
        console.error('Failed to parse campaign targets:', err)
        recipientIds = []
      }
    } else if (campaign.targetCriteria) {
      try {
        const criteria = JSON.parse(campaign.targetCriteria) as Record<string, unknown>
        const users = await prisma.user.findMany({
          where: {
            isActive: true,
            ...(criteria.role ? { role: criteria.role as any } : {}),
          },
          select: { id: true },
        })
        recipientIds = users.map((u) => u.id)
      } catch (err) {
        console.error('Failed to parse campaign criteria:', err)
        recipientIds = []
      }
    } else {
      const allUsers = await prisma.user.findMany({
        where: { isActive: true },
        select: { id: true, email: true },
      })
      recipientIds = allUsers.map((u) => u.id)
    }

    const unsubscribedEmails = campaign.includeUnsubscribed
      ? new Set<string>()
      : new Set(
          (await NotificationService.getUnsubscribedEmails()).map((u) => u.email)
        )

    const recipients = await prisma.user.findMany({
      where: { id: { in: recipientIds }, isActive: true },
      select: { id: true, email: true },
    })

    const eligibleRecipients = recipients.filter(
      (r) => !unsubscribedEmails.has(r.email.toLowerCase())
    )

    await prisma.emailCampaign.update({
      where: { id: campaignId },
      data: {
        status: 'SENDING',
        totalRecipients: eligibleRecipients.length,
      },
    })

    let sentCount = 0
    for (let i = 0; i < eligibleRecipients.length; i += BATCH_SIZE) {
      const batch = eligibleRecipients.slice(i, i + BATCH_SIZE)
      await Promise.allSettled(
        batch.map(async (recipient) => {
          try {
            await NotificationService.send({
              userId: recipient.id,
              type: 'CAMPAIGN',
              channel: 'EMAIL',
              title: campaign.subject,
              message: campaign.body,
              subject: campaign.subject,
              htmlBody: campaign.htmlBody ?? undefined,
              email: recipient.email,
              vendorId: undefined,
              metadata: { campaignId },
            })
            sentCount++
          } catch (err) { console.error('Failed to send campaign email:', err) }
        })
      )
    }

    await prisma.emailCampaign.update({
      where: { id: campaignId },
      data: {
        status: 'COMPLETED',
        sentCount,
        sentAt: new Date(),
      },
    })

    return { totalRecipients: eligibleRecipients.length, sentCount }
  }

  static async getCampaigns(createdBy?: string) {
    return prisma.emailCampaign.findMany({
      where: createdBy ? { createdBy } : undefined,
      orderBy: { createdAt: 'desc' },
    })
  }

  // ── Templates ──────────────────────────────────────────────

  static async createTemplate(data: {
    type: string
    channel: Channel
    language?: string
    subject?: string
    title?: string
    body: string
    htmlBody?: string
    fromEmail?: string
    fromName?: string
    variables?: string[]
    createdBy: string
  }) {
    return prisma.notificationTemplate.create({
      data: {
        type: data.type,
        channel: data.channel,
        language: data.language ?? 'en',
        subject: data.subject ?? null,
        title: data.title ?? null,
        body: data.body,
        htmlBody: data.htmlBody ?? null,
        fromEmail: data.fromEmail ?? null,
        fromName: data.fromName ?? null,
        variables: data.variables ? JSON.stringify(data.variables) : '[]',
        createdBy: data.createdBy,
      },
    })
  }

  static async updateTemplate(id: string, data: {
    subject?: string
    title?: string
    body?: string
    htmlBody?: string
    fromEmail?: string
    fromName?: string
    variables?: string[]
    isActive?: boolean
  }) {
    const existing = await prisma.notificationTemplate.findUnique({ where: { id } })
    if (!existing) throw new Error(`Template ${id} not found`)

    return prisma.notificationTemplate.update({
      where: { id },
      data: {
        subject: data.subject ?? existing.subject,
        title: data.title ?? existing.title,
        body: data.body ?? existing.body,
        htmlBody: data.htmlBody ?? existing.htmlBody,
        fromEmail: data.fromEmail ?? existing.fromEmail,
        fromName: data.fromName ?? existing.fromName,
        variables: data.variables ? JSON.stringify(data.variables) : existing.variables,
        isActive: data.isActive ?? existing.isActive,
        version: { increment: 1 },
      },
    })
  }

  static async getTemplate(type: string, channel: Channel, language = 'en') {
    return prisma.notificationTemplate.findFirst({
      where: { type, channel, language, isActive: true },
      orderBy: { version: 'desc' },
    })
  }

  // ── Read / Query helpers ───────────────────────────────────

  static async getUserNotifications(userId: string, options?: { limit?: number; unreadOnly?: boolean }) {
    return prisma.notification.findMany({
      where: {
        userId,
        ...(options?.unreadOnly ? { isRead: false } : {}),
      },
      orderBy: { createdAt: 'desc' },
      take: options?.limit ?? 50,
    })
  }

  static async markAsRead(notificationId: string, userId: string) {
    return prisma.notification.updateMany({
      where: { id: notificationId, userId },
      data: { isRead: true, readAt: new Date() },
    })
  }

  static async markAllAsRead(userId: string) {
    return prisma.notification.updateMany({
      where: { userId, isRead: false },
      data: { isRead: true, readAt: new Date() },
    })
  }

  static async getUnreadCount(userId: string): Promise<number> {
    return prisma.notification.count({
      where: { userId, isRead: false },
    })
  }

  // ── Convenience helpers ────────────────────────────────────

  static async sendOrderConfirmed(userId: string, orderId: string) {
    const order = await prisma.order.findUnique({
      where: { id: orderId },
      include: { user: true },
    })
    if (!order) throw new Error(`Order ${orderId} not found`)

    const channels = await NotificationService.getEnabledChannels(userId, 'ORDER_CONFIRMED')
    const results = []

    for (const channel of channels) {
      const result = await NotificationService.send({
        userId,
        type: 'ORDER_CONFIRMED',
        channel,
        title: 'Order Confirmed',
        message: `Your order #${order.orderNumber} has been confirmed. Total: $${order.total.toFixed(2)}`,
        subject: `Order #${order.orderNumber} Confirmed`,
        email: channel === 'EMAIL' ? order.user.email : undefined,
        orderId,
        data: { orderNumber: order.orderNumber, total: order.total },
        priority: 'HIGH',
      })
      results.push(result)
    }

    return results
  }

  static async sendOrderShipped(userId: string, orderId: string) {
    const order = await prisma.order.findUnique({
      where: { id: orderId },
      include: { user: true },
    })
    if (!order) throw new Error(`Order ${orderId} not found`)

    const channels = await NotificationService.getEnabledChannels(userId, 'ORDER_SHIPPED')
    const results = []

    for (const channel of channels) {
      const result = await NotificationService.send({
        userId,
        type: 'ORDER_SHIPPED',
        channel,
        title: 'Order Shipped',
        message: `Your order #${order.orderNumber} has been shipped.${order.trackingNumber ? ` Tracking: ${order.trackingNumber}` : ''}`,
        subject: `Order #${order.orderNumber} Shipped`,
        email: channel === 'EMAIL' ? order.user.email : undefined,
        orderId,
        data: { orderNumber: order.orderNumber, trackingNumber: order.trackingNumber },
        priority: 'HIGH',
      })
      results.push(result)
    }

    return results
  }

  static async sendOrderDelivered(userId: string, orderId: string) {
    const order = await prisma.order.findUnique({
      where: { id: orderId },
      include: { user: true },
    })
    if (!order) throw new Error(`Order ${orderId} not found`)

    const channels = await NotificationService.getEnabledChannels(userId, 'ORDER_DELIVERED')
    const results = []

    for (const channel of channels) {
      const result = await NotificationService.send({
        userId,
        type: 'ORDER_DELIVERED',
        channel,
        title: 'Order Delivered',
        message: `Your order #${order.orderNumber} has been delivered. Enjoy!`,
        subject: `Order #${order.orderNumber} Delivered`,
        email: channel === 'EMAIL' ? order.user.email : undefined,
        orderId,
        data: { orderNumber: order.orderNumber },
        priority: 'MEDIUM',
      })
      results.push(result)
    }

    return results
  }

  static async sendPaymentSuccess(userId: string, orderId: string) {
    const order = await prisma.order.findUnique({
      where: { id: orderId },
      include: { user: true },
    })
    if (!order) throw new Error(`Order ${orderId} not found`)

    const channels = await NotificationService.getEnabledChannels(userId, 'PAYMENT_SUCCESS')
    const results = []

    for (const channel of channels) {
      const result = await NotificationService.send({
        userId,
        type: 'PAYMENT_SUCCESS',
        channel,
        title: 'Payment Successful',
        message: `Payment of $${order.total.toFixed(2)} for order #${order.orderNumber} was successful.`,
        subject: `Payment Confirmed - Order #${order.orderNumber}`,
        email: channel === 'EMAIL' ? order.user.email : undefined,
        orderId,
        data: { orderNumber: order.orderNumber, total: order.total },
        priority: 'HIGH',
      })
      results.push(result)
    }

    return results
  }

  static async sendPriceDrop(productId: string, oldPriceCents: number, newPriceCents: number) {
    const product = await prisma.product.findUnique({ where: { id: productId } })
    if (!product) throw new Error(`Product ${productId} not found`)

    const wishlistItems = await prisma.wishlistItem.findMany({
      where: { productId },
      include: { wishlist: { include: { user: true } } },
    })

    const results = []
    for (const item of wishlistItems) {
      const channels = await NotificationService.getEnabledChannels(item.wishlist.userId, 'PRICE_DROP')
      for (const channel of channels) {
        const oldPrice = (oldPriceCents / 100).toFixed(2)
        const newPrice = (newPriceCents / 100).toFixed(2)
        const result = await NotificationService.send({
          userId: item.wishlist.userId,
          type: 'PRICE_DROP',
          channel,
          title: 'Price Drop Alert',
          message: `${product.name} dropped from $${oldPrice} to $${newPrice}!`,
          subject: `Price Drop: ${product.name} is now $${newPrice}`,
          email: channel === 'EMAIL' ? item.wishlist.user.email : undefined,
          productId,
          data: { productName: product.name, oldPrice: oldPriceCents, newPrice: newPriceCents },
          priority: 'MEDIUM',
        })
        results.push(result)
      }
    }

    return results
  }

  static async sendBackInStock(productId: string) {
    const product = await prisma.product.findUnique({ where: { id: productId } })
    if (!product) throw new Error(`Product ${productId} not found`)

    const wishlistItems = await prisma.wishlistItem.findMany({
      where: { productId },
      include: { wishlist: { include: { user: true } } },
    })

    const results = []
    for (const item of wishlistItems) {
      const channels = await NotificationService.getEnabledChannels(item.wishlist.userId, 'BACK_IN_STOCK')
      for (const channel of channels) {
        const result = await NotificationService.send({
          userId: item.wishlist.userId,
          type: 'BACK_IN_STOCK',
          channel,
          title: 'Back in Stock',
          message: `${product.name} is back in stock! Order now before it runs out.`,
          subject: `Back in Stock: ${product.name}`,
          email: channel === 'EMAIL' ? item.wishlist.user.email : undefined,
          productId,
          data: { productName: product.name, stockQuantity: product.stockQuantity },
          priority: 'HIGH',
        })
        results.push(result)
      }
    }

    return results
  }

  static async sendDealAlert(dealId: string) {
    const deal = await prisma.deal.findUnique({
      where: { id: dealId },
      include: { product: true },
    })
    if (!deal) throw new Error(`Deal ${dealId} not found`)

    const wishlistItems = await prisma.wishlistItem.findMany({
      where: { productId: deal.productId },
      include: { wishlist: true },
    })

    const userIds = [...new Set(wishlistItems.map((item) => item.wishlist.userId))]
    const results = []

    for (const userId of userIds) {
      const channels = await NotificationService.getEnabledChannels(userId, 'PROMOTION')
      for (const channel of channels) {
        const user = await prisma.user.findUnique({ where: { id: userId } })
        if (!user) continue

        const result = await NotificationService.send({
          userId,
          type: 'PROMOTION',
          channel,
          title: 'Flash Deal Alert!',
          message: `${deal.product.name} is ${deal.discountPercent}% off! Grab it before the deal ends.`,
          subject: `Flash Deal: ${deal.product.name} - ${deal.discountPercent}% OFF`,
          email: channel === 'EMAIL' ? user.email : undefined,
          productId: deal.productId,
          data: {
            dealId,
            productName: deal.product.name,
            discountPercent: deal.discountPercent,
            endsAt: deal.endsAt,
          },
          priority: 'HIGH',
        })
        results.push(result)
      }
    }

    return results
  }

  static async sendNewMessage(userId: string, fromName: string, messagePreview: string) {
    const channels = await NotificationService.getEnabledChannels(userId, 'SYSTEM')
    const results = []

    for (const channel of channels) {
      const user = await prisma.user.findUnique({ where: { id: userId } })
      if (!user) continue

      const result = await NotificationService.send({
        userId,
        type: 'SYSTEM',
        channel,
        title: `New message from ${fromName}`,
        message: messagePreview,
        subject: `New message from ${fromName}`,
        email: channel === 'EMAIL' ? user.email : undefined,
        data: { fromName },
        priority: 'MEDIUM',
      })
      results.push(result)
    }

    return results
  }

  // ── Private helpers ────────────────────────────────────────

  private static async getEnabledChannels(userId: string, type: string): Promise<Channel[]> {
    const allChannels: Channel[] = ['EMAIL', 'SMS', 'IN_APP', 'PUSH']
    const enabled: Channel[] = []

    for (const channel of allChannels) {
      const is_enabled = await NotificationService.isChannelEnabled(userId, type, channel)
      if (is_enabled) enabled.push(channel)
    }

    return enabled.length > 0 ? enabled : ['IN_APP']
  }
}
